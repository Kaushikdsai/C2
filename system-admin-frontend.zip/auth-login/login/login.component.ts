import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnDestroy
} from '@angular/core';

import {
  FormsModule,
  NgForm
} from '@angular/forms';

import {
  Router,
  RouterLink
} from '@angular/router';

import {
  finalize
} from 'rxjs';

import {
  AuthService,
  LoginRequest,
  LoginResponse
} from '../../services/auth.service';

type UserRole =
  | 'USER'
  | 'ADMIN'
  | 'AMBULANCE';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent
  implements OnDestroy {

  private readonly authService =
    inject(AuthService);

  private readonly router =
    inject(Router);

private toastTimer: number | null = null;

  loginData: LoginRequest = {
    username: '',
    password: ''
  };

  isLoading = false;

  errorMessage = '';

  successMessage = '';

  login(
    loginForm: NgForm
  ): void {
    if (this.isLoading) {
      return;
    }

    if (loginForm.invalid) {
      loginForm.control.markAllAsTouched();

      this.showErrorToast(
        'Username and password are required.'
      );

      return;
    }

    const request: LoginRequest = {
      username:
        this.loginData.username.trim(),

      password:
        this.loginData.password
    };

    if (
      !request.username ||
      !request.password
    ) {
      this.showErrorToast(
        'Username and password are required.'
      );

      return;
    }

    this.isLoading = true;

    this.closeAllToasts();

    this.authService
      .login(request)
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe({
        next: (
          response: LoginResponse
        ) => {
          console.log(
            'Login successful:',
            response
          );

          this.handleLoginSuccess(
            response,
            request
          );
        },

        error: error => {
          console.error(
            'Login failed:',
            error
          );

          this.clearAuthenticationData();

          this.showErrorToast(
            this.getLoginErrorMessage(
              error
            )
          );
        }
      });
  }

  private handleLoginSuccess(
    response: LoginResponse,
    request: LoginRequest
  ): void {
    const token =
      response.token?.trim();

    if (!token) {
      this.handleLoginFailure(
        'Authentication token was not received.'
      );

      return;
    }

    const userId =
      response.id ??
      response.userId;

    if (
      userId === undefined ||
      userId === null
    ) {
      this.handleLoginFailure(
        'User ID was not received.'
      );

      return;
    }

    const numericUserId =
      Number(userId);

    if (
      !Number.isInteger(numericUserId) ||
      numericUserId <= 0
    ) {
      this.handleLoginFailure(
        'The received User ID is invalid.'
      );

      return;
    }

    const normalizedRole =
      response.role
        ?.trim()
        .toUpperCase();

    if (
      !this.isValidRole(
        normalizedRole
      )
    ) {
      console.error(
        'Unknown role:',
        response.role
      );

      this.handleLoginFailure(
        'Invalid user role.'
      );

      return;
    }

    const username =
      response.username?.trim() ||
      response.name?.trim() ||
      request.username;

    this.storeAuthenticationData(
      token,
      numericUserId,
      normalizedRole,
      username
    );

    this.showSuccessToast(
      'Login successful. Redirecting...'
    );

    this.navigateByRole(
      normalizedRole
    );
  }

  private isValidRole(
    role: string | undefined
  ): role is UserRole {
    return (
      role === 'USER' ||
      role === 'ADMIN' ||
      role === 'AMBULANCE'
    );
  }

  private storeAuthenticationData(
    token: string,
    userId: number,
    role: UserRole,
    username: string
  ): void {
    localStorage.setItem(
      'token',
      token
    );

    localStorage.setItem(
      'userId',
      String(userId)
    );

    localStorage.setItem(
      'role',
      role
    );

    localStorage.setItem(
      'username',
      username
    );
  }

  private navigateByRole(
    role: UserRole
  ): void {
    const routes:
      Record<UserRole, string> = {
        USER:
          '/appointment-search',

        ADMIN:
          '/admin/system-dashboard',

        AMBULANCE:
          '/ambulance'
      };

    const targetRoute =
      routes[role];

    void this.router
      .navigate([
        targetRoute
      ])
      .then(success => {
        if (!success) {
          this.clearAuthenticationData();

          this.showErrorToast(
            'Unable to open the requested page.'
          );
        }
      })
      .catch(error => {
        console.error(
          'Navigation failed:',
          error
        );

        this.clearAuthenticationData();

        this.showErrorToast(
          'Unable to open the requested page.'
        );
      });
  }

  private handleLoginFailure(
    message: string
  ): void {
    this.clearAuthenticationData();

    this.showErrorToast(
      message
    );
  }

  showErrorToast(
    message: string
  ): void {
    this.clearToastTimer();

    this.successMessage = '';
    this.errorMessage = message;

    this.toastTimer =
      window.setTimeout(() => {
        this.errorMessage = '';
        this.toastTimer = null;
      }, 5000);
  }

  showSuccessToast(
    message: string
  ): void {
    this.clearToastTimer();

    this.errorMessage = '';
    this.successMessage = message;

    this.toastTimer =
      window.setTimeout(() => {
        this.successMessage = '';
        this.toastTimer = null;
      }, 3000);
  }

  closeErrorToast(): void {
    this.errorMessage = '';

    this.clearToastTimer();
  }

  closeSuccessToast(): void {
    this.successMessage = '';

    this.clearToastTimer();
  }

  private closeAllToasts(): void {
    this.errorMessage = '';
    this.successMessage = '';

    this.clearToastTimer();
  }

  private clearToastTimer(): void {
    if (this.toastTimer !== null) {
      window.clearTimeout(
        this.toastTimer
      );

      this.toastTimer = null;
    }
  }

  private getLoginErrorMessage(
    error: unknown
  ): string {
    const httpError =
      error as {
        status?: number;
        message?: string;
        error?:
          | string
          | {
              message?: unknown;
              error?: unknown;
              details?: unknown;
            };
      };

    const backendMessage =
      this.extractBackendMessage(
        httpError.error
      );

    switch (httpError.status) {
      case 0:
        return (
          'Unable to connect to the server. ' +
          'Please check your connection and try again.'
        );

      case 400:
        return (
          backendMessage ||
          'Username and password are required.'
        );

      case 401:
        return (
          backendMessage ||
          'Invalid username or password.'
        );

      case 403:
        return (
          backendMessage ||
          'Your account is not authorized to sign in.'
        );

      case 404:
        return (
          backendMessage ||
          'The login service was not found.'
        );

      case 409:
        return (
          backendMessage ||
          'The login request could not be completed.'
        );

      case 429:
        return (
          backendMessage ||
          'Too many login attempts. ' +
          'Please wait before trying again.'
        );

      case 500:
      case 502:
      case 503:
      case 504:
        return (
          backendMessage ||
          'The login service is currently unavailable. ' +
          'Please try again later.'
        );

      default:
        return (
          backendMessage ||
          httpError.message ||
          'Login failed. Please try again.'
        );
    }
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (
      typeof errorBody === 'string'
    ) {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const responseBody =
        errorBody as {
          message?: unknown;
          error?: unknown;
          details?: unknown;
        };

      if (
        typeof responseBody.message ===
        'string'
      ) {
        return responseBody
          .message
          .trim();
      }

      if (
        typeof responseBody.error ===
        'string'
      ) {
        return responseBody
          .error
          .trim();
      }

      if (
        typeof responseBody.details ===
        'string'
      ) {
        return responseBody
          .details
          .trim();
      }
    }

    return '';
  }

  private clearAuthenticationData():
    void {
    localStorage.removeItem(
      'token'
    );

    localStorage.removeItem(
      'userId'
    );

    localStorage.removeItem(
      'role'
    );

    localStorage.removeItem(
      'username'
    );

    localStorage.removeItem(
      'userName'
    );

    localStorage.removeItem(
      'name'
    );

    localStorage.removeItem(
      'user'
    );
  }

  ngOnDestroy(): void {
    this.clearToastTimer();
  }
}