import {
  inject,
  Injectable
} from '@angular/core';

import {
  HttpClient,
  HttpParams
} from '@angular/common/http';

import {
  Observable
} from 'rxjs';

import {
  environment
} from '../../../../environments/environment';

import {
  Ambulance,
  CreateAmbulanceRequest,
  RecommendedHospital,
  UpdateAmbulanceRequest
} from '../models/ambulance.model';

@Injectable({
  providedIn: 'root'
})
export class AdminAmbulanceService {
  private readonly http =
    inject(HttpClient);

  private readonly apiUrl =
    `${environment.gatewayUrl}/api/ambulances`;

  /*
   * Fetch all ambulances.
   *
   * GET /api/ambulances
   *
   * Backend response:
   * List<Ambulance>
   */
  getAmbulances(): Observable<Ambulance[]> {
    return this.http.get<Ambulance[]>(
      this.apiUrl
    );
  }

  /*
   * Fetch one ambulance by ID.
   *
   * GET /api/ambulances/{id}
   *
   * Backend response:
   * Ambulance
   */
  getAmbulanceById(
    ambulanceId: number
  ): Observable<Ambulance> {
    return this.http.get<Ambulance>(
      `${this.apiUrl}/${ambulanceId}`
    );
  }

  /*
   * Create an ambulance.
   *
   * POST /api/ambulances
   *
   * Do not send ambulanceId because it is generated
   * by the database using GenerationType.IDENTITY.
   *
   * Backend response:
   * Ambulance
   */
  createAmbulance(
    request: CreateAmbulanceRequest
  ): Observable<Ambulance> {
    return this.http.post<Ambulance>(
      this.apiUrl,
      request
    );
  }

  /*
   * Update an ambulance.
   *
   * PUT /api/ambulances/{id}
   *
   * The ID is passed in the URL.
   *
   * Backend response:
   * Ambulance
   */
  updateAmbulance(
    ambulanceId: number,
    request: UpdateAmbulanceRequest
  ): Observable<Ambulance> {
    return this.http.put<Ambulance>(
      `${this.apiUrl}/${ambulanceId}`,
      request
    );
  }

  /*
   * Delete an ambulance.
   *
   * DELETE /api/ambulances/{id}
   *
   * The backend returns a plain-text response:
   * "Ambulance Deleted Successfully"
   */
  deleteAmbulance(
    ambulanceId: number
  ): Observable<string> {
    return this.http.delete(
      `${this.apiUrl}/${ambulanceId}`,
      {
        responseType: 'text'
      }
    );
  }

  /*
   * Find recommended hospitals based on symptoms,
   * bed requirements, and the ambulance location.
   *
   * POST /api/ambulances/recommend-hospital
   *
   * Request body:
   * string[]
   *
   * Query parameters:
   * beds
   * latitude
   * longitude
   */
  recommendHospital(
    symptoms: string[],
    beds: number,
    latitude: number,
    longitude: number
  ): Observable<RecommendedHospital[]> {
    const params = new HttpParams()
      .set(
        'beds',
        String(beds)
      )
      .set(
        'latitude',
        String(latitude)
      )
      .set(
        'longitude',
        String(longitude)
      );

    return this.http.post<
      RecommendedHospital[]
    >(
      `${this.apiUrl}/recommend-hospital`,
      symptoms,
      {
        params
      }
    );
  }
}