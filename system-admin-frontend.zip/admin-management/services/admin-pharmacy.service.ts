import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';

import {
  CreatePharmacyRequest,
  Pharmacy,
  PharmacyDetails,
  UpdatePharmacyRequest
} from '../models/pharmacy.model';

@Injectable({ providedIn: 'root' })
export class AdminPharmacyService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = `${environment.gatewayUrl}/api/pharmacies`;

  /* PHARMACY CRUD -- matches PharmacyController exactly */

  getPharmacies(): Observable<Pharmacy[]> {
    return this.http.get<Pharmacy[]>(this.apiUrl);
  }

  getAllPharmacies(): Observable<Pharmacy[]> {
    return this.getPharmacies();
  }

  getPharmacyById(pharmacyId: number): Observable<Pharmacy> {
    return this.http.get<Pharmacy>(`${this.apiUrl}/${pharmacyId}`);
  }

  createPharmacy(request: CreatePharmacyRequest): Observable<Pharmacy> {
    return this.http.post<Pharmacy>(this.apiUrl, request);
  }

  addPharmacy(request: CreatePharmacyRequest): Observable<Pharmacy> {
    return this.createPharmacy(request);
  }

  updatePharmacy(pharmacyId: number, request: UpdatePharmacyRequest): Observable<Pharmacy> {
    return this.http.put<Pharmacy>(`${this.apiUrl}/${pharmacyId}`, request);
  }

  deletePharmacy(pharmacyId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${pharmacyId}`);
  }

  getActivePharmacies(): Observable<Pharmacy[]> {
    return this.http.get<Pharmacy[]>(`${this.apiUrl}/active`);
  }

  /*
   * FIX: was GET /api/pharmacies/profile/{detailsId} -- that route does not
   * exist on PharmacyController. The real endpoint is scoped by pharmacyId:
   * GET /api/pharmacies/{pharmacyId}/profile
   */
  getPharmacyProfile(pharmacyId: number): Observable<PharmacyDetails> {
    return this.http.get<PharmacyDetails>(`${this.apiUrl}/${pharmacyId}/profile`);
  }

  /*
   * FIX: matches PUT /api/pharmacies/{pharmacyId}/profile
   */
  updatePharmacyProfile(pharmacyId: number, request: Partial<PharmacyDetails>): Observable<PharmacyDetails> {
    return this.http.put<PharmacyDetails>(`${this.apiUrl}/${pharmacyId}/profile`, request);
  }

  /*
   * Removed: getNearbyPharmacies, assignHospitalPharmacy, broadcastOrder,
   * rebroadcastOrder, isWithinRadius, getPendingOrders/getAcceptedOrders/
   * getCancelledOrders/getDeliveredOrders/getOutForDeliveryOrders, and the
   * old acceptOrder/rejectOrder/cancelAcceptedOrder signatures.
   * None of these routes exist on PharmacyController -- they were calling
   * endpoints that 404. Real equivalents on the backend, if ever needed:
   *   GET /api/pharmacies/{pharmacyId}/orders?status=...
   *   GET /api/pharmacies/{pharmacyId}/orders/available
   *   GET /api/pharmacies/{pharmacyId}/orders/history
   *   GET /api/pharmacies/{pharmacyId}/dashboard
   *   GET /api/pharmacies/{pharmacyId}/reports/success-rate
   *   GET /api/pharmacies/{pharmacyId}/reports/orders-this-month
   */
}
