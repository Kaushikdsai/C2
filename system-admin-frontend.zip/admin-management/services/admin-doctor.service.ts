import {
  inject,
  Injectable
} from '@angular/core';

import {
  HttpClient
} from '@angular/common/http';

import {
  Observable
} from 'rxjs';

import {
  environment
} from '../../../../environments/environment';

import {
  CreateDoctorRequest,
  Doctor,
  DoctorStatus,
  UpdateDoctorRequest
} from '../models/doctor.model';

@Injectable({
  providedIn: 'root'
})
export class AdminDoctorService {

  private readonly http =
    inject(HttpClient);

  private readonly apiUrl =
    // Routed to /api/admin/doctors at the gateway (rewritten internally to
    // /api/doctors on user-service) so it doesn't collide with
    // appointment-service's own /api/doctors, used by the booking flow.
    `${environment.gatewayUrl}/api/admin/doctors`;

  /*
   * GET /api/doctors
   */
  getDoctors(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(
      this.apiUrl
    );
  }

  /*
   * Optional alias if an existing component
   * calls getAllDoctors().
   */
  getAllDoctors(): Observable<Doctor[]> {
    return this.getDoctors();
  }

  /*
   * GET /api/doctors/{id}
   */
  getDoctorById(
    doctorId: number
  ): Observable<Doctor> {
    return this.http.get<Doctor>(
      `${this.apiUrl}/${doctorId}`
    );
  }

  /*
   * POST /api/doctors
   *
   * The request contains no ID.
   * The backend returns Boolean.
   */
  createDoctor(
    request: CreateDoctorRequest
  ): Observable<boolean> {
    return this.http.post<boolean>(
      this.apiUrl,
      request
    );
  }

  /*
   * Optional alias matching the backend method name.
   */
  addDoctor(
    request: CreateDoctorRequest
  ): Observable<boolean> {
    return this.createDoctor(request);
  }

  /*
   * PUT /api/doctors
   *
   * The Spring controller does not use /{id}.
   * Therefore, the ID is sent inside the request body.
   */
  updateDoctor(
    request: UpdateDoctorRequest
  ): Observable<boolean> {
    return this.http.put<boolean>(
      this.apiUrl,
      request
    );
  }

  /*
   * PATCH /api/doctors/{id}/status/{status}
   */
  updateDoctorStatus(
    doctorId: number,
    status: DoctorStatus
  ): Observable<boolean> {
    const normalizedStatus =
      status
        .trim()
        .toUpperCase();

    const encodedStatus =
      encodeURIComponent(
        normalizedStatus
      );

    return this.http.patch<boolean>(
      `${this.apiUrl}/${doctorId}` +
      `/status/${encodedStatus}`,
      null
    );
  }

  /*
   * DELETE /api/doctors/{id}
   *
   * The backend performs a soft delete and
   * returns Boolean.
   */
  deleteDoctor(
    doctorId: number
  ): Observable<boolean> {
    return this.http.delete<boolean>(
      `${this.apiUrl}/${doctorId}`
    );
  }
}