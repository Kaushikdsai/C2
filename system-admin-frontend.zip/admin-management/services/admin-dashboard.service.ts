import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, map, Observable, catchError, of } from 'rxjs';
import { environment } from '../../../../environments/environment';

export interface AdminDashboardCounts {
  doctors: number;
  pharmacies: number;
  ambulances: number;
  totalRecords: number;
  hospitalsAvailable: false; // backend has no hospital list/count endpoint yet
}

@Injectable({ providedIn: 'root' })
export class AdminDashboardService {
  private readonly http = inject(HttpClient);
  private readonly gatewayUrl = environment.gatewayUrl;

  // NOTE: doctor admin CRUD is routed through /api/admin/doctors at the
  // gateway (rewritten internally to /api/doctors on user-service) so it
  // doesn't collide with appointment-service's own /api/doctors.
  private readonly doctorsUrl = `${this.gatewayUrl}/api/admin/doctors`;
  private readonly pharmaciesUrl = `${this.gatewayUrl}/api/pharmacies`;
  private readonly ambulancesUrl = `${this.gatewayUrl}/api/ambulances`;

  /*
   * There is currently no /api/hospitals list/count endpoint on the
   * backend -- appointment-service's HospitalController only exposes
   * GET/PATCH /api/hospitals/{id}/icu. Hospital count is intentionally
   * left out until that endpoint exists.
   */
  getDashboardCounts(): Observable<AdminDashboardCounts> {
    return forkJoin({
      doctors: this.http.get<unknown[]>(this.doctorsUrl).pipe(catchError(() => of([]))),
      pharmacies: this.http.get<unknown[]>(this.pharmaciesUrl).pipe(catchError(() => of([]))),
      ambulances: this.http.get<unknown[]>(this.ambulancesUrl).pipe(catchError(() => of([])))
    }).pipe(
      map(({ doctors, pharmacies, ambulances }) => {
        const d = this.len(doctors);
        const p = this.len(pharmacies);
        const a = this.len(ambulances);
        return {
          doctors: d,
          pharmacies: p,
          ambulances: a,
          totalRecords: d + p + a,
          hospitalsAvailable: false as const
        };
      })
    );
  }

  private len(response: unknown): number {
    if (Array.isArray(response)) return response.length;
    if (response && typeof response === 'object') {
      const r = response as { totalElements?: number; content?: unknown[] };
      if (typeof r.totalElements === 'number') return r.totalElements;
      if (Array.isArray(r.content)) return r.content.length;
    }
    return 0;
  }
}
