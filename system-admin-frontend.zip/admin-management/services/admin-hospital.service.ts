import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';

import { IcuAvailability, UpdateIcuAvailabilityRequest } from '../models/hospital.model';

@Injectable({ providedIn: 'root' })
export class AdminHospitalService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = `${environment.gatewayUrl}/api/hospitals`;

  /* GET /api/hospitals/{id}/icu */
  getIcuAvailability(hospitalId: number): Observable<IcuAvailability> {
    return this.http.get<IcuAvailability>(`${this.apiUrl}/${hospitalId}/icu`);
  }

  /* PATCH /api/hospitals/{id}/icu */
  updateIcuAvailability(hospitalId: number, request: UpdateIcuAvailabilityRequest): Observable<IcuAvailability> {
    return this.http.patch<IcuAvailability>(`${this.apiUrl}/${hospitalId}/icu`, request);
  }
}
