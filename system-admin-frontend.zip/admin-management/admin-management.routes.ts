import { Routes } from '@angular/router';

export const ADMIN_MANAGEMENT_ROUTES: Routes = [
  {
    // Default landing for the ADMIN role (see login.component.ts).
    path: 'system-dashboard',
    loadComponent: () =>
      import('./pages/dashboard/dashboard.component').then((m) => m.DashboardComponent)
  },

  /* Hospitals -- ICU-only, matches the real backend (no list/CRUD endpoint exists) */
  {
    path: 'hospitals',
    loadComponent: () =>
      import('./pages/hospitals/hospital-icu/hospital-icu.component').then((m) => m.HospitalIcuComponent)
  },

  /* Doctors -- full CRUD, verified against DoctorController */
  {
    path: 'doctors',
    loadComponent: () =>
      import('./pages/doctors/doctor-list/doctor-list.component').then((m) => m.DoctorListComponent)
  },
  {
    path: 'doctors/create',
    loadComponent: () =>
      import('./pages/doctors/doctor-form/doctor-form.component').then((m) => m.DoctorFormComponent)
  },
  {
    path: 'doctors/:id/edit',
    loadComponent: () =>
      import('./pages/doctors/doctor-form/doctor-form.component').then((m) => m.DoctorFormComponent)
  },
  {
    path: 'doctors/:id',
    loadComponent: () =>
      import('./pages/doctors/doctor-details/doctor-details.component').then((m) => m.DoctorDetailsComponent)
  },

  /* Pharmacies -- full CRUD, verified against PharmacyController */
  {
    path: 'pharmacies',
    loadComponent: () =>
      import('./pages/pharmacies/pharmacy-list/pharmacy-list.component').then((m) => m.PharmacyListComponent)
  },
  {
    path: 'pharmacies/create',
    loadComponent: () =>
      import('./pages/pharmacies/pharmacy-form/pharmacy-form.component').then((m) => m.PharmacyFormComponent)
  },
  {
    path: 'pharmacies/:id/edit',
    loadComponent: () =>
      import('./pages/pharmacies/pharmacy-form/pharmacy-form.component').then((m) => m.PharmacyFormComponent)
  },
  {
    path: 'pharmacies/:id',
    loadComponent: () =>
      import('./pages/pharmacies/pharmacy-details/pharmacy-details.component').then((m) => m.PharmacyDetailsComponent)
  },

  /* Ambulances -- full CRUD, verified against AmbulanceController */
  {
    path: 'ambulances',
    loadComponent: () =>
      import('./pages/ambulances/ambulance-list/ambulance-list.component').then((m) => m.AmbulanceListComponent)
  },
  {
    path: 'ambulances/create',
    loadComponent: () =>
      import('./pages/ambulances/ambulance-form/ambulance-form.component').then((m) => m.AmbulanceFormComponent)
  },
  {
    path: 'ambulances/:id/edit',
    loadComponent: () =>
      import('./pages/ambulances/ambulance-form/ambulance-form.component').then((m) => m.AmbulanceFormComponent)
  },
  {
    path: 'ambulances/:id',
    loadComponent: () =>
      import('./pages/ambulances/ambulance-details/ambulance-details.component').then((m) => m.AmbulanceDetailsComponent)
  }
];
