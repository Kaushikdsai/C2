import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';

import { AdminHospitalService } from '../../../services/admin-hospital.service';
import { IcuAvailability } from '../../../models/hospital.model';
import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  selector: 'app-hospital-icu',
  standalone: true,
  imports: [CommonModule, FormsModule, HeaderComponent, AdminSidebarComponent],
  templateUrl: './hospital-icu.component.html',
  styleUrl: './hospital-icu.component.css'
})
export class HospitalIcuComponent {
  private readonly hospitalService = inject(AdminHospitalService);

  hospitalIdInput = '';
  icu: IcuAvailability | null = null;

  totalIcuBeds = 0;
  availableIcuBeds = 0;

  isLoading = false;
  isSaving = false;
  errorMessage = '';
  successMessage = '';

  search(): void {
    const id = Number(this.hospitalIdInput);
    if (!Number.isInteger(id) || id <= 0) {
      this.errorMessage = 'Enter a valid Hospital ID.';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';
    this.icu = null;

    this.hospitalService
      .getIcuAvailability(id)
      .pipe(finalize(() => (this.isLoading = false)))
      .subscribe({
        next: (icu) => {
          this.icu = icu;
          this.totalIcuBeds = icu.totalIcuBeds;
          this.availableIcuBeds = icu.availableIcuBeds;
        },
        error: () => (this.errorMessage = `No hospital found with ID ${id}.`)
      });
  }

  save(): void {
    if (!this.icu) return;

    if (this.availableIcuBeds > this.totalIcuBeds) {
      this.errorMessage = 'Available beds cannot exceed total beds.';
      return;
    }

    this.isSaving = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.hospitalService
      .updateIcuAvailability(this.icu.hospitalId, {
        totalIcuBeds: this.totalIcuBeds,
        availableIcuBeds: this.availableIcuBeds
      })
      .pipe(finalize(() => (this.isSaving = false)))
      .subscribe({
        next: (icu) => {
          this.icu = icu;
          this.successMessage = 'ICU bed availability updated.';
        },
        error: () => (this.errorMessage = 'Unable to save changes.')
      });
  }
}
