import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { finalize } from 'rxjs';

import { AdminDashboardService, AdminDashboardCounts } from '../../services/admin-dashboard.service';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  selector: 'app-system-admin-dashboard',
  standalone: true,
  imports: [CommonModule, HeaderComponent, AdminSidebarComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  private readonly dashboardService = inject(AdminDashboardService);
  private readonly router = inject(Router);

  counts: AdminDashboardCounts | null = null;
  isLoading = false;
  errorMessage = '';

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.dashboardService
      .getDashboardCounts()
      .pipe(finalize(() => (this.isLoading = false)))
      .subscribe({
        next: (counts) => (this.counts = counts),
        error: () => (this.errorMessage = 'Unable to load dashboard data. Verify the API Gateway is running.')
      });
  }

  goTo(path: string): void {
    void this.router.navigate([`/admin/${path}`]);
  }
}
