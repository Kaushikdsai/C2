import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import {
  FormsModule
} from '@angular/forms';

import {
  Router
} from '@angular/router';

import {
  finalize
} from 'rxjs';

import {
  AdminPharmacyService
} from '../../../services/admin-pharmacy.service';

import {
  Pharmacy,
  PharmacyStatus,
  PharmacyStatusFilter
} from '../../../models/pharmacy.model';

import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  selector: 'app-pharmacy-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  templateUrl: './pharmacy-list.component.html',
  styleUrl: './pharmacy-list.component.css'
})
export class PharmacyListComponent
  implements OnInit {

  /* =======================================================
     DEPENDENCIES
  ======================================================= */

  private readonly pharmacyService =
    inject(AdminPharmacyService);

  private readonly router =
    inject(Router);

  /* =======================================================
     DATA
  ======================================================= */

  pharmacies: Pharmacy[] = [];

  filteredPharmacies: Pharmacy[] = [];

  /* =======================================================
     FILTER STATE
  ======================================================= */

  searchText = '';

  selectedStatus:
    PharmacyStatusFilter = 'ALL';

  readonly statusFilters:
    PharmacyStatusFilter[] = [
      'ALL',
      'ACTIVE',
      'INACTIVE',
      'SUSPENDED'
    ];

  /* =======================================================
     PAGE STATE
  ======================================================= */

  isLoading = false;

  isDeleting = false;

  deletingPharmacyId:
    number | null = null;

  errorMessage = '';

  successMessage = '';

  /* =======================================================
     SUMMARY VALUES
  ======================================================= */

  get totalPharmacies(): number {
    return this.pharmacies.length;
  }

  get activePharmacies(): number {
    return this.countByStatus(
      'ACTIVE'
    );
  }

  get inactivePharmacies(): number {
    return this.countByStatus(
      'INACTIVE'
    );
  }

  get suspendedPharmacies(): number {
    return this.countByStatus(
      'SUSPENDED'
    );
  }

  get assignedPharmacies(): number {
    return this.pharmacies.filter(
      pharmacy =>
        pharmacy.hospitalId !== null &&
        pharmacy.hospitalId !== undefined
    ).length;
  }

  get unassignedPharmacies(): number {
    return this.pharmacies.filter(
      pharmacy =>
        pharmacy.hospitalId === null ||
        pharmacy.hospitalId === undefined
    ).length;
  }

  get hasPharmacies(): boolean {
    return (
      this.filteredPharmacies.length > 0
    );
  }

  get hasActiveFilters(): boolean {
    return (
      this.searchText.trim().length > 0 ||
      this.selectedStatus !== 'ALL'
    );
  }

  /* =======================================================
     LIFECYCLE
  ======================================================= */

  ngOnInit(): void {
    this.loadPharmacies();
  }

  /* =======================================================
     LOAD PHARMACIES
  ======================================================= */

  loadPharmacies(): void {
    if (this.isLoading) {
      return;
    }

    this.isLoading = true;

    this.errorMessage = '';
    this.successMessage = '';

    this.pharmacyService
      .getPharmacies()
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe({
        next: pharmacies => {
          this.pharmacies =
            Array.isArray(pharmacies)
              ? pharmacies
              : [];

          this.applyFilters();
        },

        error: error => {
          console.error(
            'Unable to load pharmacies:',
            error
          );

          this.pharmacies = [];
          this.filteredPharmacies = [];

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to load pharmacies.'
            );
        }
      });
  }

  /* =======================================================
     SEARCH AND FILTERING
  ======================================================= */

  onSearchChange(): void {
    this.applyFilters();
  }

  setStatusFilter(
    status: PharmacyStatusFilter
  ): void {
    this.selectedStatus = status;

    this.applyFilters();
  }

  clearSearch(): void {
    this.searchText = '';

    this.applyFilters();
  }

  clearFilters(): void {
    this.searchText = '';

    this.selectedStatus = 'ALL';

    this.applyFilters();
  }

  private applyFilters(): void {
    const normalizedSearch =
      this.searchText
        .trim()
        .toLowerCase();

    this.filteredPharmacies =
      this.pharmacies.filter(
        pharmacy => {
          const normalizedStatus =
            this.normalizeStatus(
              pharmacy.status
            );

          const matchesStatus =
            this.selectedStatus === 'ALL' ||
            normalizedStatus ===
              this.selectedStatus;

          if (!normalizedSearch) {
            return matchesStatus;
          }

          const searchableValues = [
            pharmacy.id,
            pharmacy.licenseNo,
            pharmacy.geoAddress,
            pharmacy.status,
            pharmacy.hospitalId
          ];

          const matchesSearch =
            searchableValues.some(
              value =>
                String(value ?? '')
                  .toLowerCase()
                  .includes(
                    normalizedSearch
                  )
            );

          return (
            matchesStatus &&
            matchesSearch
          );
        }
      );
  }

  /* =======================================================
     NAVIGATION
  ======================================================= */

  createPharmacy(): void {
    void this.router.navigate([
      '/admin/pharmacies/create'
    ]);
  }

  viewPharmacy(
    pharmacy: Pharmacy
  ): void {
    if (!this.hasValidId(pharmacy)) {
      this.errorMessage =
        'The selected Pharmacy has an invalid ID.';

      return;
    }

    void this.router.navigate([
      '/admin/pharmacies',
      pharmacy.id
    ]);
  }

  editPharmacy(
    pharmacy: Pharmacy
  ): void {
    if (!this.hasValidId(pharmacy)) {
      this.errorMessage =
        'The selected Pharmacy has an invalid ID.';

      return;
    }

    void this.router.navigate([
      '/admin/pharmacies',
      pharmacy.id,
      'edit'
    ]);
  }

  viewProfile(
    pharmacy: Pharmacy
  ): void {
    if (!this.hasValidId(pharmacy)) {
      this.errorMessage =
        'The selected Pharmacy has an invalid ID.';

      return;
    }

    void this.router.navigate([
      '/admin/pharmacies',
      pharmacy.id,
      'profile'
    ]);
  }

  viewOrders(
    pharmacy: Pharmacy
  ): void {
    if (!this.hasValidId(pharmacy)) {
      this.errorMessage =
        'The selected Pharmacy has an invalid ID.';

      return;
    }

    void this.router.navigate([
      '/admin/pharmacies',
      pharmacy.id,
      'orders'
    ]);
  }

  /* =======================================================
     DELETE PHARMACY
  ======================================================= */

  deletePharmacy(
    pharmacy: Pharmacy
  ): void {
    if (
      this.isDeleting ||
      !this.hasValidId(pharmacy)
    ) {
      return;
    }

    const pharmacyLabel =
      pharmacy.licenseNo?.trim() ||
      `Pharmacy ${pharmacy.id}`;

    const confirmed =
      window.confirm(
        'Are you sure you want to delete ' +
        `"${pharmacyLabel}"?`
      );

    if (!confirmed) {
      return;
    }

    this.isDeleting = true;

    this.deletingPharmacyId =
      pharmacy.id;

    this.errorMessage = '';
    this.successMessage = '';

    this.pharmacyService
      .deletePharmacy(
        pharmacy.id
      )
      .pipe(
        finalize(() => {
          this.isDeleting = false;

          this.deletingPharmacyId =
            null;
        })
      )
      .subscribe({
        next: () => {
          this.pharmacies =
            this.pharmacies.filter(
              item =>
                item.id !== pharmacy.id
            );

          this.applyFilters();

          this.successMessage =
            'Pharmacy deleted successfully.';

          this.clearSuccessMessageLater();
        },

        error: error => {
          console.error(
            'Unable to delete Pharmacy:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to delete the Pharmacy.'
            );
        }
      });
  }

  /* =======================================================
     DISPLAY HELPERS
  ======================================================= */

  getPharmacyName(
    pharmacy: Pharmacy
  ): string {
    return (
      pharmacy.licenseNo?.trim() ||
      `Pharmacy ${pharmacy.id}`
    );
  }

  getPharmacyInitials(
    pharmacy: Pharmacy
  ): string {
    const licenseNumber =
      pharmacy.licenseNo?.trim();

    if (!licenseNumber) {
      return 'PH';
    }

    const normalized =
      licenseNumber
        .replace(
          /[^a-zA-Z0-9]/g,
          ''
        )
        .toUpperCase();

    if (!normalized) {
      return 'PH';
    }

    return normalized.length >= 2
      ? normalized.slice(-2)
      : normalized;
  }

  getLicenseDisplay(
    pharmacy: Pharmacy
  ): string {
    return (
      pharmacy.licenseNo?.trim() ||
      'License not provided'
    );
  }

  getGeoAddressDisplay(
    pharmacy: Pharmacy
  ): string {
    return (
      pharmacy.geoAddress?.trim() ||
      'Geo address not provided'
    );
  }

  getHospitalDisplay(
    pharmacy: Pharmacy
  ): string {
    if (
      pharmacy.hospitalId === null ||
      pharmacy.hospitalId === undefined
    ) {
      return 'Not assigned';
    }

    return (
      `Hospital ID: ${pharmacy.hospitalId}`
    );
  }

  isHospitalAssigned(
    pharmacy: Pharmacy
  ): boolean {
    return (
      pharmacy.hospitalId !== null &&
      pharmacy.hospitalId !== undefined
    );
  }

  getStatusLabel(
    status:
      string |
      null |
      undefined
  ): string {
    switch (
      this.normalizeStatus(status)
    ) {
      case 'ACTIVE':
        return 'Active';

      case 'INACTIVE':
        return 'Inactive';

      case 'SUSPENDED':
        return 'Suspended';

      default:
        return 'Unknown';
    }
  }

  getStatusClass(
    status:
      string |
      null |
      undefined
  ): string {
    return this.normalizeStatus(status)
      .toLowerCase();
  }

  getStatusDescription(
    status:
      string |
      null |
      undefined
  ): string {
    switch (
      this.normalizeStatus(status)
    ) {
      case 'ACTIVE':
        return (
          'The Pharmacy is active and available.'
        );

      case 'INACTIVE':
        return (
          'The Pharmacy is currently inactive.'
        );

      case 'SUSPENDED':
        return (
          'The Pharmacy account is suspended.'
        );

      default:
        return (
          'The Pharmacy status is unavailable.'
        );
    }
  }

  isDeletingPharmacy(
    pharmacy: Pharmacy
  ): boolean {
    return (
      this.isDeleting &&
      this.deletingPharmacyId ===
        pharmacy.id
    );
  }

  getDeleteButtonLabel(
    pharmacy: Pharmacy
  ): string {
    return this.isDeletingPharmacy(
      pharmacy
    )
      ? 'Deleting...'
      : 'Delete';
  }

  private hasValidId(
    pharmacy: Pharmacy
  ): boolean {
    return (
      Number.isInteger(pharmacy.id) &&
      pharmacy.id > 0
    );
  }

  /* =======================================================
     STATUS HELPERS
  ======================================================= */

  private countByStatus(
    status: PharmacyStatus
  ): number {
    return this.pharmacies.filter(
      pharmacy =>
        this.normalizeStatus(
          pharmacy.status
        ) === status
    ).length;
  }

  private normalizeStatus(
    status:
      string |
      null |
      undefined
  ): PharmacyStatus | 'UNKNOWN' {
    const normalizedStatus =
      status
        ?.trim()
        .toUpperCase();

    switch (normalizedStatus) {
      case 'ACTIVE':
      case 'INACTIVE':
      case 'SUSPENDED':
        return normalizedStatus;

      default:
        return 'UNKNOWN';
    }
  }

  /* =======================================================
     MESSAGE ACTIONS
  ======================================================= */

  closeErrorMessage(): void {
    this.errorMessage = '';
  }

  closeSuccessMessage(): void {
    this.successMessage = '';
  }

  private clearSuccessMessageLater():
    void {
    window.setTimeout(() => {
      this.successMessage = '';
    }, 3500);
  }

  /* =======================================================
     ERROR HANDLING
  ======================================================= */

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    const httpError =
      error as {
        status?: number;
        message?: string;
        error?:
          | {
              message?: string;
              error?: string;
            }
          | string;
      };

    const backendMessage =
      this.extractBackendMessage(
        httpError.error
      );

    if (httpError.status === 0) {
      return (
        'Unable to connect to the server. ' +
        'Verify that the API Gateway and ' +
        'Pharmacy service are running.'
      );
    }

    if (httpError.status === 400) {
      return (
        backendMessage ||
        'The Pharmacy request is invalid.'
      );
    }

    if (httpError.status === 401) {
      return (
        'Your session has expired. ' +
        'Please log in again.'
      );
    }

    if (httpError.status === 403) {
      return (
        'You do not have permission to perform ' +
        'this Pharmacy operation.'
      );
    }

    if (httpError.status === 404) {
      return (
        backendMessage ||
        'The requested Pharmacy was not found.'
      );
    }

    if (httpError.status === 409) {
      return (
        backendMessage ||
        'A Pharmacy with this ID or license ' +
        'number already exists.'
      );
    }

    if (
      httpError.status !== undefined &&
      httpError.status >= 500
    ) {
      return (
        backendMessage ||
        'The Pharmacy service is unavailable. ' +
        'Please try again later.'
      );
    }

    return (
      backendMessage ||
      httpError.message ||
      fallbackMessage
    );
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (
      typeof errorBody === 'string'
    ) {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const responseBody =
        errorBody as {
          message?: unknown;
          error?: unknown;
        };

      if (
        typeof responseBody.message ===
        'string'
      ) {
        return responseBody
          .message
          .trim();
      }

      if (
        typeof responseBody.error ===
        'string'
      ) {
        return responseBody
          .error
          .trim();
      }
    }

    return '';
  }

  /* =======================================================
     TRACK BY
  ======================================================= */

  trackByPharmacyId(
    _index: number,
    pharmacy: Pharmacy
  ): number {
    return pharmacy.id;
  }

  trackByStatus(
    _index: number,
    status: PharmacyStatusFilter
  ): string {
    return status;
  }
}