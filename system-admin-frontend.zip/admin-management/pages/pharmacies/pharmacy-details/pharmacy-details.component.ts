import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import {
  catchError,
  finalize,
  forkJoin,
  of
} from 'rxjs';

import {
  AdminPharmacyService
} from '../../../services/admin-pharmacy.service';

import {
  Pharmacy,
  PharmacyDetails,
  PharmacyStatus
} from '../../../models/pharmacy.model';

import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  selector: 'app-pharmacy-details',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  templateUrl: './pharmacy-details.component.html',
  styleUrl: './pharmacy-details.component.css'
})
export class PharmacyDetailsComponent
  implements OnInit {

  private readonly pharmacyService =
    inject(AdminPharmacyService);

  private readonly activatedRoute =
    inject(ActivatedRoute);

  private readonly router =
    inject(Router);

  pharmacy: Pharmacy | null = null;

  pharmacyProfile:
    PharmacyDetails | null = null;

  pharmacyId: number | null = null;

  isLoading = false;

  isDeleting = false;

  profileLoadFailed = false;

  errorMessage = '';

  successMessage = '';

  ngOnInit(): void {
    this.readPharmacyId();
  }

  private readPharmacyId(): void {
    const idParameter =
      this.activatedRoute.snapshot
        .paramMap
        .get('id');

    if (!idParameter) {
      this.errorMessage =
        'Pharmacy ID is missing from the URL.';

      return;
    }

    const parsedId =
      Number(idParameter);

    if (
      !Number.isInteger(parsedId) ||
      parsedId <= 0
    ) {
      this.errorMessage =
        'The Pharmacy ID in the URL is invalid.';

      return;
    }

    this.pharmacyId = parsedId;

    this.loadPharmacy();
  }

  loadPharmacy(): void {
    if (
      this.isLoading ||
      this.pharmacyId === null
    ) {
      return;
    }

    this.isLoading = true;
    this.profileLoadFailed = false;

    this.errorMessage = '';
    this.successMessage = '';

    const pharmacyId =
      this.pharmacyId;

    const pharmacyRequest =
      this.pharmacyService
        .getPharmacyById(pharmacyId);

    const profileRequest =
      this.pharmacyService
        .getPharmacyProfile(pharmacyId)
        .pipe(
          catchError(error => {
            console.warn(
              'Unable to load Pharmacy profile:',
              error
            );

            this.profileLoadFailed = true;

            return of(
              null as PharmacyDetails | null
            );
          })
        );

    forkJoin({
      pharmacy: pharmacyRequest,
      profile: profileRequest
    })
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe({
        next: result => {
          this.pharmacy =
            result.pharmacy;

          this.pharmacyProfile =
            result.profile;
        },

        error: error => {
          console.error(
            'Unable to load Pharmacy:',
            error
          );

          this.pharmacy = null;
          this.pharmacyProfile = null;

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to load Pharmacy information.'
            );
        }
      });
  }

  editPharmacy(): void {
    if (this.pharmacyId === null) {
      return;
    }

    void this.router.navigate([
      '/admin/pharmacies',
      this.pharmacyId,
      'edit'
    ]);
  }

  viewProfile(): void {
    if (this.pharmacyId === null) {
      return;
    }

    void this.router.navigate([
      '/admin/pharmacies',
      this.pharmacyId,
      'profile'
    ]);
  }

  viewOrders(): void {
    if (this.pharmacyId === null) {
      return;
    }

    void this.router.navigate([
      '/admin/pharmacies',
      this.pharmacyId,
      'orders'
    ]);
  }

  deletePharmacy(): void {
    if (
      this.pharmacy === null ||
      this.isDeleting
    ) {
      return;
    }

    const pharmacyId =
      this.pharmacy.id;

    const pharmacyLabel =
      this.pharmacy.licenseNo?.trim() ||
      `Pharmacy ${pharmacyId}`;

    const confirmed =
      window.confirm(
        'Are you sure you want to delete ' +
        `"${pharmacyLabel}"?`
      );

    if (!confirmed) {
      return;
    }

    this.isDeleting = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.pharmacyService
      .deletePharmacy(pharmacyId)
      .pipe(
        finalize(() => {
          this.isDeleting = false;
        })
      )
      .subscribe({
        next: () => {
          this.successMessage =
            'Pharmacy deleted successfully.';

          window.setTimeout(() => {
            void this.router.navigate([
              '/admin/pharmacies'
            ]);
          }, 800);
        },

        error: error => {
          console.error(
            'Unable to delete Pharmacy:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to delete the Pharmacy.'
            );
        }
      });
  }

  navigateBack(): void {
    void this.router.navigate([
      '/admin/pharmacies'
    ]);
  }

  getPharmacyTitle(): string {
    if (!this.pharmacy) {
      return 'Pharmacy';
    }

    return (
      this.pharmacy.licenseNo?.trim() ||
      `Pharmacy ${this.pharmacy.id}`
    );
  }

  getPharmacyInitials(): string {
    const licenseNumber =
      this.pharmacy
        ?.licenseNo
        ?.trim();

    if (!licenseNumber) {
      return 'PH';
    }

    const normalized =
      licenseNumber
        .replace(
          /[^a-zA-Z0-9]/g,
          ''
        )
        .toUpperCase();

    if (!normalized) {
      return 'PH';
    }

    return normalized.length >= 2
      ? normalized.slice(-2)
      : normalized;
  }

  getProfileName(): string {
    return (
      this.pharmacyProfile
        ?.name
        ?.trim() ||
      'Pharmacy profile'
    );
  }

  getFullAddress(): string {
    if (!this.pharmacyProfile) {
      return 'Address not available';
    }

    const addressParts = [
      this.pharmacyProfile.address,
      this.pharmacyProfile.city,
      this.pharmacyProfile.state,
      this.pharmacyProfile.pincode
    ]
      .map(value =>
        value?.trim()
      )
      .filter(
        (value): value is string =>
          Boolean(value)
      );

    return addressParts.length > 0
      ? addressParts.join(', ')
      : 'Address not available';
  }

  getLicenseDisplay(): string {
    return (
      this.pharmacy
        ?.licenseNo
        ?.trim() ||
      'Not provided'
    );
  }

  getGeoAddressDisplay(): string {
    return (
      this.pharmacy
        ?.geoAddress
        ?.trim() ||
      'Not provided'
    );
  }

  getHospitalDisplay(): string {
    const hospitalId =
      this.pharmacy?.hospitalId;

    if (
      hospitalId === null ||
      hospitalId === undefined
    ) {
      return 'Not assigned';
    }

    return `Hospital ID: ${hospitalId}`;
  }

  isHospitalAssigned(): boolean {
    return (
      this.pharmacy?.hospitalId !== null &&
      this.pharmacy?.hospitalId !== undefined
    );
  }

  getStatusLabel(
    status: string | null | undefined
  ): string {
    switch (
      this.normalizeStatus(status)
    ) {
      case 'ACTIVE':
        return 'Active';

      case 'INACTIVE':
        return 'Inactive';

      case 'SUSPENDED':
        return 'Suspended';

      default:
        return 'Unknown';
    }
  }

  getStatusClass(
    status: string | null | undefined
  ): string {
    return this.normalizeStatus(status)
      .toLowerCase();
  }

  getStatusIcon(
    status: string | null | undefined
  ): string {
    switch (
      this.normalizeStatus(status)
    ) {
      case 'ACTIVE':
        return '✓';

      case 'INACTIVE':
        return '○';

      case 'SUSPENDED':
        return '!';

      default:
        return '?';
    }
  }

  getStatusDescription(
    status: string | null | undefined
  ): string {
    switch (
      this.normalizeStatus(status)
    ) {
      case 'ACTIVE':
        return (
          'This Pharmacy is active and available ' +
          'for medicine distribution.'
        );

      case 'INACTIVE':
        return (
          'This Pharmacy is currently inactive ' +
          'and unavailable for operations.'
        );

      case 'SUSPENDED':
        return (
          'This Pharmacy account is suspended ' +
          'and cannot perform regular operations.'
        );

      default:
        return (
          'The current Pharmacy status is unavailable.'
        );
    }
  }

  closeErrorMessage(): void {
    this.errorMessage = '';
  }

  closeSuccessMessage(): void {
    this.successMessage = '';
  }

  private normalizeStatus(
    status: string | null | undefined
  ): PharmacyStatus | 'UNKNOWN' {
    const normalizedStatus =
      status
        ?.trim()
        .toUpperCase();

    switch (normalizedStatus) {
      case 'ACTIVE':
      case 'INACTIVE':
      case 'SUSPENDED':
        return normalizedStatus;

      default:
        return 'UNKNOWN';
    }
  }

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    const httpError =
      error as {
        status?: number;
        message?: string;
        error?:
          | {
              message?: string;
              error?: string;
            }
          | string;
      };

    const backendMessage =
      this.extractBackendMessage(
        httpError.error
      );

    if (httpError.status === 0) {
      return (
        'Unable to connect to the server. ' +
        'Verify that the API Gateway and ' +
        'Pharmacy service are running.'
      );
    }

    if (httpError.status === 400) {
      return (
        backendMessage ||
        'The Pharmacy request is invalid.'
      );
    }

    if (httpError.status === 401) {
      return (
        'Your session has expired. ' +
        'Please log in again.'
      );
    }

    if (httpError.status === 403) {
      return (
        'You do not have permission to perform ' +
        'this Pharmacy operation.'
      );
    }

    if (httpError.status === 404) {
      return (
        backendMessage ||
        'The requested Pharmacy was not found.'
      );
    }

    if (httpError.status === 409) {
      return (
        backendMessage ||
        'The Pharmacy cannot be deleted because ' +
        'it is currently referenced by another record.'
      );
    }

    if (
      httpError.status !== undefined &&
      httpError.status >= 500
    ) {
      return (
        backendMessage ||
        'The Pharmacy service is unavailable. ' +
        'Please try again later.'
      );
    }

    return (
      backendMessage ||
      httpError.message ||
      fallbackMessage
    );
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (typeof errorBody === 'string') {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const responseBody =
        errorBody as {
          message?: unknown;
          error?: unknown;
        };

      if (
        typeof responseBody.message ===
        'string'
      ) {
        return responseBody
          .message
          .trim();
      }

      if (
        typeof responseBody.error ===
        'string'
      ) {
        return responseBody
          .error
          .trim();
      }
    }

    return '';
  }
}