import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import {
  AbstractControl,
  FormBuilder,
  ReactiveFormsModule,
  ValidationErrors,
  ValidatorFn,
  Validators
} from '@angular/forms';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import {
  finalize
} from 'rxjs';

import {
  AdminPharmacyService
} from '../../../services/admin-pharmacy.service';

import {
  CreatePharmacyRequest,
  PharmacyStatus,
  UpdatePharmacyRequest
} from '../../../models/pharmacy.model';

import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  selector: 'app-pharmacy-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  templateUrl: './pharmacy-form.component.html',
  styleUrl: './pharmacy-form.component.css'
})
export class PharmacyFormComponent
  implements OnInit {

  private readonly formBuilder =
    inject(FormBuilder);

  private readonly pharmacyService =
    inject(AdminPharmacyService);

  private readonly activatedRoute =
    inject(ActivatedRoute);

  private readonly router =
    inject(Router);

  pharmacyId: number | null = null;

  isEditMode = false;

  isLoading = false;

  isSubmitting = false;

  formSubmitted = false;

  errorMessage = '';

  successMessage = '';

  readonly pharmacyStatuses:
    PharmacyStatus[] = [
      'ACTIVE',
      'INACTIVE',
      'SUSPENDED'
    ];

  readonly pharmacyForm =
    this.formBuilder.nonNullable.group({
      id: [
        0,
        [
          Validators.required,
          Validators.min(1),
          this.integerValidator()
        ]
      ],

      licenseNo: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(50),
          Validators.pattern(
            /^[a-zA-Z0-9/_-]+$/
          )
        ]
      ],

      geoAddress: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(255)
        ]
      ],

      hospitalId: [
        null as number | null,
        [
          Validators.min(1),
          this.optionalIntegerValidator()
        ]
      ],

      status: [
        'ACTIVE' as PharmacyStatus,
        [
          Validators.required
        ]
      ]
    });

  get pageTitle(): string {
    return this.isEditMode
      ? 'Edit Pharmacy'
      : 'Add Pharmacy';
  }

  get pageDescription(): string {
    return this.isEditMode
      ? (
          'Update Pharmacy registration, location, ' +
          'hospital assignment, and status.'
        )
      : (
          'Create a Pharmacy record using an existing ' +
          'registered account ID.'
        );
  }

  get submitButtonLabel(): string {
    if (this.isSubmitting) {
      return this.isEditMode
        ? 'Updating Pharmacy...'
        : 'Creating Pharmacy...';
    }

    return this.isEditMode
      ? 'Update Pharmacy'
      : 'Create Pharmacy';
  }

  ngOnInit(): void {
    this.readRouteParameter();
  }

  private readRouteParameter(): void {
    const idParameter =
      this.activatedRoute.snapshot
        .paramMap
        .get('id');

    if (!idParameter) {
      this.isEditMode = false;
      this.pharmacyId = null;

      return;
    }

    const parsedId =
      Number(idParameter);

    if (
      !Number.isInteger(parsedId) ||
      parsedId <= 0
    ) {
      this.errorMessage =
        'The Pharmacy ID in the URL is invalid.';

      return;
    }

    this.isEditMode = true;
    this.pharmacyId = parsedId;

    this.loadPharmacy(parsedId);
  }

  private loadPharmacy(
    pharmacyId: number
  ): void {
    if (this.isLoading) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.pharmacyForm.disable();

    this.pharmacyService
      .getPharmacyById(pharmacyId)
      .pipe(
        finalize(() => {
          this.isLoading = false;
          this.pharmacyForm.enable();

          if (this.isEditMode) {
            this.pharmacyForm.controls.id
              .disable();
          }
        })
      )
      .subscribe({
        next: pharmacy => {
          this.pharmacyForm.patchValue({
            id:
              pharmacy.id,

            licenseNo:
              pharmacy.licenseNo ?? '',

            geoAddress:
              pharmacy.geoAddress ?? '',

            hospitalId:
              pharmacy.hospitalId ?? null,

            status:
              this.normalizeStatus(
                pharmacy.status
              )
          });

          this.pharmacyForm.controls.id
            .disable();

          this.pharmacyForm.markAsPristine();
          this.pharmacyForm.markAsUntouched();

          this.formSubmitted = false;
        },

        error: error => {
          console.error(
            'Unable to load Pharmacy:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to load Pharmacy information.'
            );
        }
      });
  }

  submitForm(): void {
    if (
      this.isSubmitting ||
      this.isLoading
    ) {
      return;
    }

    this.formSubmitted = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.pharmacyForm
      .updateValueAndValidity();

    if (this.pharmacyForm.invalid) {
      this.pharmacyForm
        .markAllAsTouched();

      this.focusFirstInvalidControl();

      return;
    }

    const value =
      this.pharmacyForm.getRawValue();

    const licenseNo =
      value.licenseNo
        .trim()
        .toUpperCase();

    const geoAddress =
      value.geoAddress.trim();

    const hospitalId =
      this.normalizeHospitalId(
        value.hospitalId
      );

    if (this.isEditMode) {
      if (this.pharmacyId === null) {
        this.errorMessage =
          'Pharmacy ID is unavailable.';

        return;
      }

      const updateRequest:
        UpdatePharmacyRequest = {
          licenseNo,
          geoAddress,
          hospitalId,
          status:
            value.status
        };

      this.updatePharmacy(
        this.pharmacyId,
        updateRequest
      );

      return;
    }

    const createRequest:
      CreatePharmacyRequest = {
        id:
          Number(value.id),

        licenseNo,
        geoAddress,
        hospitalId,

        status:
          value.status
      };

    this.createPharmacy(
      createRequest
    );
  }

  private createPharmacy(
    request: CreatePharmacyRequest
  ): void {
    this.isSubmitting = true;
    this.pharmacyForm.disable();

    this.pharmacyService
      .createPharmacy(request)
      .pipe(
        finalize(() => {
          this.isSubmitting = false;
          this.pharmacyForm.enable();
        })
      )
      .subscribe({
        next: createdPharmacy => {
          this.successMessage =
            'Pharmacy created successfully.';

          this.pharmacyForm.markAsPristine();

          const createdId =
            createdPharmacy?.id ??
            request.id;

          window.setTimeout(() => {
            void this.router.navigate([
              '/admin/pharmacies',
              createdId
            ]);
          }, 800);
        },

        error: error => {
          console.error(
            'Unable to create Pharmacy:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to create the Pharmacy.'
            );
        }
      });
  }

  private updatePharmacy(
    pharmacyId: number,
    request: UpdatePharmacyRequest
  ): void {
    this.isSubmitting = true;
    this.pharmacyForm.disable();

    this.pharmacyService
      .updatePharmacy(
        pharmacyId,
        request
      )
      .pipe(
        finalize(() => {
          this.isSubmitting = false;
          this.pharmacyForm.enable();

          this.pharmacyForm.controls.id
            .disable();
        })
      )
      .subscribe({
        next: () => {
          this.successMessage =
            'Pharmacy updated successfully.';

          this.pharmacyForm.markAsPristine();

          window.setTimeout(() => {
            void this.router.navigate([
              '/admin/pharmacies',
              pharmacyId
            ]);
          }, 800);
        },

        error: error => {
          console.error(
            'Unable to update Pharmacy:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to update the Pharmacy.'
            );
        }
      });
  }

  resetForm(): void {
    if (
      this.isSubmitting ||
      this.isLoading
    ) {
      return;
    }

    this.errorMessage = '';
    this.successMessage = '';
    this.formSubmitted = false;

    if (
      this.isEditMode &&
      this.pharmacyId !== null
    ) {
      this.loadPharmacy(
        this.pharmacyId
      );

      return;
    }

    this.pharmacyForm.reset({
      id: 0,
      licenseNo: '',
      geoAddress: '',
      hospitalId: null,
      status: 'ACTIVE'
    });

    this.pharmacyForm.markAsPristine();
    this.pharmacyForm.markAsUntouched();
  }

  cancel(): void {
    if (
      this.pharmacyForm.dirty &&
      !this.isSubmitting
    ) {
      const shouldLeave =
        window.confirm(
          'You have unsaved changes. ' +
          'Do you want to leave this page?'
        );

      if (!shouldLeave) {
        return;
      }
    }

    this.navigateBack();
  }

  navigateBack(): void {
    void this.router.navigate([
      '/admin/pharmacies'
    ]);
  }

  isFieldInvalid(
    controlName:
      keyof typeof this.pharmacyForm.controls
  ): boolean {
    const control =
      this.pharmacyForm.controls[
        controlName
      ];

    if (control.disabled) {
      return false;
    }

    return (
      control.invalid &&
      (
        control.touched ||
        control.dirty ||
        this.formSubmitted
      )
    );
  }

  getFieldError(
    controlName:
      keyof typeof this.pharmacyForm.controls
  ): string {
    const control =
      this.pharmacyForm.controls[
        controlName
      ];

    const label =
      this.getFieldLabel(controlName);

    if (
      control.disabled ||
      !control.errors
    ) {
      return '';
    }

    if (control.errors['required']) {
      return `${label} is required.`;
    }

    if (control.errors['minlength']) {
      const requiredLength =
        control.errors['minlength']
          .requiredLength;

      return (
        `${label} must contain at least ` +
        `${requiredLength} characters.`
      );
    }

    if (control.errors['maxlength']) {
      const requiredLength =
        control.errors['maxlength']
          .requiredLength;

      return (
        `${label} cannot exceed ` +
        `${requiredLength} characters.`
      );
    }

    if (control.errors['min']) {
      return (
        `${label} must be greater than zero.`
      );
    }

    if (control.errors['notInteger']) {
      return (
        `${label} must be a whole number.`
      );
    }

    if (control.errors['pattern']) {
      if (controlName === 'licenseNo') {
        return (
          'License number can contain only letters, ' +
          'numbers, slashes, underscores, and hyphens.'
        );
      }
    }

    return `${label} is invalid.`;
  }

  getStatusLabel(
    status: PharmacyStatus
  ): string {
    switch (status) {
      case 'ACTIVE':
        return 'Active';

      case 'INACTIVE':
        return 'Inactive';

      case 'SUSPENDED':
        return 'Suspended';
    }
  }

  getStatusDescription(
    status: PharmacyStatus
  ): string {
    switch (status) {
      case 'ACTIVE':
        return (
          'The Pharmacy is available for ' +
          'medicine distribution.'
        );

      case 'INACTIVE':
        return (
          'The Pharmacy is currently unavailable.'
        );

      case 'SUSPENDED':
        return (
          'The Pharmacy account is suspended.'
        );
    }
  }

  getStatusIcon(
    status: PharmacyStatus
  ): string {
    switch (status) {
      case 'ACTIVE':
        return '✓';

      case 'INACTIVE':
        return '○';

      case 'SUSPENDED':
        return '!';
    }
  }

  closeErrorMessage(): void {
    this.errorMessage = '';
  }

  closeSuccessMessage(): void {
    this.successMessage = '';
  }

  private normalizeStatus(
    status: string | null | undefined
  ): PharmacyStatus {
    const normalizedStatus =
      status
        ?.trim()
        .toUpperCase();

    switch (normalizedStatus) {
      case 'INACTIVE':
        return 'INACTIVE';

      case 'SUSPENDED':
        return 'SUSPENDED';

      default:
        return 'ACTIVE';
    }
  }

  private normalizeHospitalId(
    hospitalId:
      number |
      null |
      undefined
  ): number | null {
    if (
      hospitalId === null ||
      hospitalId === undefined ||
      hospitalId === 0
    ) {
      return null;
    }

    const value =
      Number(hospitalId);

    return (
      Number.isInteger(value) &&
      value > 0
    )
      ? value
      : null;
  }

  private getFieldLabel(
    controlName:
      keyof typeof this.pharmacyForm.controls
  ): string {
    const labels:
      Record<
        keyof typeof this.pharmacyForm.controls,
        string
      > = {
        id: 'Pharmacy ID',
        licenseNo: 'License number',
        geoAddress: 'Geo address',
        hospitalId: 'Hospital ID',
        status: 'Status'
      };

    return labels[controlName];
  }

  private integerValidator():
    ValidatorFn {
    return (
      control: AbstractControl
    ): ValidationErrors | null => {
      if (
        control.value === null ||
        control.value === ''
      ) {
        return null;
      }

      const value =
        Number(control.value);

      return Number.isInteger(value)
        ? null
        : {
            notInteger: true
          };
    };
  }

  private optionalIntegerValidator():
    ValidatorFn {
    return (
      control: AbstractControl
    ): ValidationErrors | null => {
      if (
        control.value === null ||
        control.value === undefined ||
        control.value === ''
      ) {
        return null;
      }

      const value =
        Number(control.value);

      return Number.isInteger(value)
        ? null
        : {
            notInteger: true
          };
    };
  }

  private focusFirstInvalidControl():
    void {
    window.setTimeout(() => {
      const invalidElement =
        document.querySelector(
          '.form-control.invalid'
        ) as HTMLElement | null;

      invalidElement?.focus();
    });
  }

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    const httpError =
      error as {
        status?: number;
        message?: string;
        error?:
          | {
              message?: string;
              error?: string;
            }
          | string;
      };

    const backendMessage =
      this.extractBackendMessage(
        httpError.error
      );

    if (httpError.status === 0) {
      return (
        'Unable to connect to the server. ' +
        'Verify that the API Gateway and ' +
        'Pharmacy service are running.'
      );
    }

    if (httpError.status === 400) {
      return (
        backendMessage ||
        'The Pharmacy information is invalid.'
      );
    }

    if (httpError.status === 401) {
      return (
        'Your session has expired. ' +
        'Please log in again.'
      );
    }

    if (httpError.status === 403) {
      return (
        'You do not have permission to perform ' +
        'this Pharmacy operation.'
      );
    }

    if (httpError.status === 404) {
      return (
        backendMessage ||
        'The Pharmacy or hospital was not found.'
      );
    }

    if (httpError.status === 409) {
      return (
        backendMessage ||
        'A Pharmacy with this ID or license ' +
        'number already exists.'
      );
    }

    if (
      httpError.status !== undefined &&
      httpError.status >= 500
    ) {
      return (
        backendMessage ||
        'The Pharmacy service is unavailable.'
      );
    }

    return (
      backendMessage ||
      httpError.message ||
      fallbackMessage
    );
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (typeof errorBody === 'string') {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const responseBody =
        errorBody as {
          message?: unknown;
          error?: unknown;
        };

      if (
        typeof responseBody.message ===
        'string'
      ) {
        return responseBody
          .message
          .trim();
      }

      if (
        typeof responseBody.error ===
        'string'
      ) {
        return responseBody
          .error
          .trim();
      }
    }

    return '';
  }
}