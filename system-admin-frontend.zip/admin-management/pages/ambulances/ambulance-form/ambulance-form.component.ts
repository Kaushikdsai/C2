import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import {
  finalize
} from 'rxjs';

import {
  AdminAmbulanceService
} from '../../../services/admin-ambulance.service';

import {
  AmbulanceStatus,
  CreateAmbulanceRequest,
  UpdateAmbulanceRequest
} from '../../../models/ambulance.model';

import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  selector: 'app-ambulance-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  templateUrl: './ambulance-form.component.html',
  styleUrl: './ambulance-form.component.css'
})
export class AmbulanceFormComponent
  implements OnInit {

  private readonly formBuilder =
    inject(FormBuilder);

  private readonly ambulanceService =
    inject(AdminAmbulanceService);

  private readonly activatedRoute =
    inject(ActivatedRoute);

  private readonly router =
    inject(Router);

  ambulanceId: number | null = null;

  isEditMode = false;

  isLoading = false;

  isSubmitting = false;

  formSubmitted = false;

  errorMessage = '';

  successMessage = '';

  readonly ambulanceStatuses:
    AmbulanceStatus[] = [
      'AVAILABLE',
      'ON_TRIP',
      'MAINTENANCE'
    ];

  readonly ambulanceForm =
    this.formBuilder.nonNullable.group({
      vehicleNumber: [
        '',
        [
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(30),
          Validators.pattern(
            /^[a-zA-Z0-9 -]+$/
          )
        ]
      ],

      licenseNo: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(50),
          Validators.pattern(
            /^[a-zA-Z0-9/_-]+$/
          )
        ]
      ],

      hospitalId: [
        null as number | null,
        [
          Validators.min(1)
        ]
      ],

      status: [
        'AVAILABLE' as AmbulanceStatus,
        [
          Validators.required
        ]
      ]
    });

  get pageTitle(): string {
    return this.isEditMode
      ? 'Edit Ambulance'
      : 'Add Ambulance';
  }

  get pageDescription(): string {
    return this.isEditMode
      ? (
          'Update vehicle registration, hospital ' +
          'assignment, and operational status.'
        )
      : (
          'Register a new ambulance vehicle. ' +
          'The ambulance ID is generated automatically.'
        );
  }

  get submitButtonLabel(): string {
    if (this.isSubmitting) {
      return this.isEditMode
        ? 'Updating Ambulance...'
        : 'Creating Ambulance...';
    }

    return this.isEditMode
      ? 'Update Ambulance'
      : 'Create Ambulance';
  }

  ngOnInit(): void {
    this.readRouteParameter();
  }

  private readRouteParameter(): void {
    const idParameter =
      this.activatedRoute.snapshot
        .paramMap
        .get('id');

    if (!idParameter) {
      this.isEditMode = false;
      this.ambulanceId = null;

      return;
    }

    const parsedId =
      Number(idParameter);

    if (
      !Number.isInteger(parsedId) ||
      parsedId <= 0
    ) {
      this.errorMessage =
        'The ambulance ID in the URL is invalid.';

      return;
    }

    this.ambulanceId = parsedId;
    this.isEditMode = true;

    this.loadAmbulance(parsedId);
  }

  private loadAmbulance(
    ambulanceId: number
  ): void {
    if (this.isLoading) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.ambulanceForm.disable();

    this.ambulanceService
      .getAmbulanceById(ambulanceId)
      .pipe(
        finalize(() => {
          this.isLoading = false;
          this.ambulanceForm.enable();
        })
      )
      .subscribe({
        next: ambulance => {
          this.ambulanceForm.patchValue({
            vehicleNumber:
              ambulance.vehicleNumber ?? '',

            licenseNo:
              ambulance.licenseNo ?? '',

            hospitalId:
              ambulance.hospitalId ?? null,

            status:
              this.normalizeStatus(
                ambulance.status
              )
          });

          this.ambulanceForm
            .markAsPristine();

          this.ambulanceForm
            .markAsUntouched();
        },

        error: error => {
          console.error(
            'Unable to load ambulance:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to load ambulance information.'
            );
        }
      });
  }

  submitForm(): void {
    if (this.isSubmitting) {
      return;
    }

    this.formSubmitted = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.ambulanceForm
      .updateValueAndValidity();

    if (this.ambulanceForm.invalid) {
      this.ambulanceForm
        .markAllAsTouched();

      this.focusFirstInvalidControl();

      return;
    }

    const formValue =
      this.ambulanceForm
        .getRawValue();

    const vehicleNumber =
      formValue.vehicleNumber
        .trim()
        .toUpperCase();

    const licenseNo =
      formValue.licenseNo
        .trim()
        .toUpperCase();

    const hospitalId =
      this.normalizeHospitalId(
        formValue.hospitalId
      );

    if (this.isEditMode) {
      const request:
        UpdateAmbulanceRequest = {
          vehicleNumber,
          licenseNo,
          hospitalId,
          status:
            formValue.status
        };

      this.updateAmbulance(request);

      return;
    }

    const request:
      CreateAmbulanceRequest = {
        vehicleNumber,
        licenseNo,
        hospitalId,
        status:
          formValue.status
    };

    this.createAmbulance(request);
  }

  private createAmbulance(
    request: CreateAmbulanceRequest
  ): void {
    this.isSubmitting = true;
    this.ambulanceForm.disable();

    this.ambulanceService
      .createAmbulance(request)
      .pipe(
        finalize(() => {
          this.isSubmitting = false;
          this.ambulanceForm.enable();
        })
      )
      .subscribe({
        next: createdAmbulance => {
          this.successMessage =
            'Ambulance created successfully.';

          this.ambulanceForm
            .markAsPristine();

          window.setTimeout(() => {
            if (
              createdAmbulance?.ambulanceId
            ) {
              void this.router.navigate([
                '/admin/ambulances',
                createdAmbulance
                  .ambulanceId
              ]);

              return;
            }

            void this.router.navigate([
              '/admin/ambulances'
            ]);
          }, 800);
        },

        error: error => {
          console.error(
            'Unable to create ambulance:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to create the ambulance.'
            );
        }
      });
  }

  private updateAmbulance(
    request: UpdateAmbulanceRequest
  ): void {
    if (this.ambulanceId === null) {
      this.errorMessage =
        'Ambulance ID is unavailable.';

      return;
    }

    this.isSubmitting = true;
    this.ambulanceForm.disable();

    this.ambulanceService
      .updateAmbulance(
        this.ambulanceId,
        request
      )
      .pipe(
        finalize(() => {
          this.isSubmitting = false;
          this.ambulanceForm.enable();
        })
      )
      .subscribe({
        next: updatedAmbulance => {
          this.successMessage =
            'Ambulance updated successfully.';

          this.ambulanceForm
            .markAsPristine();

          const updatedId =
            updatedAmbulance
              ?.ambulanceId ??
            this.ambulanceId;

          window.setTimeout(() => {
            void this.router.navigate([
              '/admin/ambulances',
              updatedId
            ]);
          }, 800);
        },

        error: error => {
          console.error(
            'Unable to update ambulance:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to update the ambulance.'
            );
        }
      });
  }

  resetForm(): void {
    if (
      this.isSubmitting ||
      this.isLoading
    ) {
      return;
    }

    this.errorMessage = '';
    this.successMessage = '';
    this.formSubmitted = false;

    if (
      this.isEditMode &&
      this.ambulanceId !== null
    ) {
      this.loadAmbulance(
        this.ambulanceId
      );

      return;
    }

    this.ambulanceForm.reset({
      vehicleNumber: '',
      licenseNo: '',
      hospitalId: null,
      status: 'AVAILABLE'
    });

    this.ambulanceForm
      .markAsPristine();

    this.ambulanceForm
      .markAsUntouched();
  }

  cancel(): void {
    if (
      this.ambulanceForm.dirty &&
      !this.isSubmitting
    ) {
      const shouldLeave =
        window.confirm(
          'You have unsaved changes. ' +
          'Do you want to leave this page?'
        );

      if (!shouldLeave) {
        return;
      }
    }

    this.navigateBack();
  }

  navigateBack(): void {
    void this.router.navigate([
      '/admin/ambulances'
    ]);
  }

  isFieldInvalid(
    controlName:
      keyof typeof this.ambulanceForm.controls
  ): boolean {
    const control =
      this.ambulanceForm.controls[
        controlName
      ];

    return (
      control.invalid &&
      (
        control.touched ||
        control.dirty ||
        this.formSubmitted
      )
    );
  }

  getFieldError(
    controlName:
      keyof typeof this.ambulanceForm.controls
  ): string {
    const control =
      this.ambulanceForm.controls[
        controlName
      ];

    const label =
      this.getFieldLabel(controlName);

    if (!control.errors) {
      return '';
    }

    if (control.errors['required']) {
      return `${label} is required.`;
    }

    if (control.errors['minlength']) {
      const requiredLength =
        control.errors['minlength']
          .requiredLength;

      return (
        `${label} must contain at least ` +
        `${requiredLength} characters.`
      );
    }

    if (control.errors['maxlength']) {
      const requiredLength =
        control.errors['maxlength']
          .requiredLength;

      return (
        `${label} cannot exceed ` +
        `${requiredLength} characters.`
      );
    }

    if (control.errors['min']) {
      return (
        'Hospital ID must be greater ' +
        'than zero.'
      );
    }

    if (control.errors['pattern']) {
      if (controlName === 'vehicleNumber') {
        return (
          'Vehicle number can contain only ' +
          'letters, numbers, spaces, and hyphens.'
        );
      }

      if (controlName === 'licenseNo') {
        return (
          'License number can contain only ' +
          'letters, numbers, underscores, ' +
          'slashes, and hyphens.'
        );
      }
    }

    return `${label} is invalid.`;
  }

  getStatusLabel(
    status: AmbulanceStatus
  ): string {
    switch (status) {
      case 'AVAILABLE':
        return 'Available';

      case 'ON_TRIP':
        return 'On Trip';

      case 'MAINTENANCE':
        return 'Maintenance';
    }
  }

  getStatusDescription(
    status: AmbulanceStatus
  ): string {
    switch (status) {
      case 'AVAILABLE':
        return (
          'Ready for emergency ' +
          'transportation.'
        );

      case 'ON_TRIP':
        return (
          'Currently assigned to ' +
          'an active trip.'
        );

      case 'MAINTENANCE':
        return (
          'Unavailable while undergoing ' +
          'maintenance.'
        );
    }
  }

  closeErrorMessage(): void {
    this.errorMessage = '';
  }

  closeSuccessMessage(): void {
    this.successMessage = '';
  }

  private normalizeHospitalId(
    value: number | null
  ): number | null {
    if (
      value === null ||
      value === undefined ||
      value === 0
    ) {
      return null;
    }

    const hospitalId =
      Number(value);

    return Number.isInteger(hospitalId) &&
      hospitalId > 0
        ? hospitalId
        : null;
  }

  private normalizeStatus(
    status: string | null | undefined
  ): AmbulanceStatus {
    const normalizedStatus =
      status
        ?.trim()
        .toUpperCase();

    switch (normalizedStatus) {
      case 'ON_TRIP':
        return 'ON_TRIP';

      case 'MAINTENANCE':
        return 'MAINTENANCE';

      default:
        return 'AVAILABLE';
    }
  }

  private getFieldLabel(
    controlName:
      keyof typeof this.ambulanceForm.controls
  ): string {
    const fieldLabels:
      Record<
        keyof typeof this.ambulanceForm.controls,
        string
      > = {
        vehicleNumber:
          'Vehicle number',

        licenseNo:
          'License number',

        hospitalId:
          'Hospital ID',

        status:
          'Status'
      };

    return fieldLabels[controlName];
  }

  private focusFirstInvalidControl():
    void {
    window.setTimeout(() => {
      const invalidElement =
        document.querySelector(
          '.form-control.invalid'
        ) as HTMLElement | null;

      invalidElement?.focus();
    });
  }

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    const httpError = error as {
      status?: number;
      message?: string;
      error?: {
        message?: string;
        error?: string;
      } | string;
    };

    if (httpError.status === 0) {
      return (
        'Unable to connect to the server. ' +
        'Verify that the API Gateway and ' +
        'Ambulance service are running.'
      );
    }

    if (httpError.status === 400) {
      return (
        this.extractBackendMessage(
          httpError.error
        ) ||
        'The ambulance information is invalid.'
      );
    }

    if (httpError.status === 401) {
      return (
        'Your session has expired. ' +
        'Please log in again.'
      );
    }

    if (httpError.status === 403) {
      return (
        'You do not have permission to perform ' +
        'this ambulance operation.'
      );
    }

    if (httpError.status === 404) {
      return (
        'The requested ambulance or hospital ' +
        'could not be found.'
      );
    }

    if (
      httpError.status !== undefined &&
      httpError.status >= 500
    ) {
      return (
        'The Ambulance service is unavailable. ' +
        'Please try again later.'
      );
    }

    return (
      this.extractBackendMessage(
        httpError.error
      ) ||
      httpError.message ||
      fallbackMessage
    );
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (typeof errorBody === 'string') {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const responseBody =
        errorBody as {
          message?: unknown;
          error?: unknown;
        };

      if (
        typeof responseBody.message ===
        'string'
      ) {
        return responseBody
          .message
          .trim();
      }

      if (
        typeof responseBody.error ===
        'string'
      ) {
        return responseBody
          .error
          .trim();
      }
    }

    return '';
  }

  trackByStatus(
    _index: number,
    status: AmbulanceStatus
  ): string {
    return status;
  }
}