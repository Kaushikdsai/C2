import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import {
  FormsModule
} from '@angular/forms';

import {
  Router
} from '@angular/router';

import {
  finalize
} from 'rxjs';

import {
  AdminAmbulanceService
} from '../../../services/admin-ambulance.service';

import {
  Ambulance,
  AmbulanceStatus
} from '../../../models/ambulance.model';

import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

type AmbulanceFilter =
  | 'ALL'
  | AmbulanceStatus;

@Component({
  selector: 'app-ambulance-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  templateUrl: './ambulance-list.component.html',
  styleUrl: './ambulance-list.component.css'
})
export class AmbulanceListComponent implements OnInit {
  private readonly ambulanceService =
    inject(AdminAmbulanceService);

  private readonly router =
    inject(Router);

  ambulances: Ambulance[] = [];

  filteredAmbulances: Ambulance[] = [];

  searchText = '';

  selectedStatus: AmbulanceFilter =
    'ALL';

  isLoading = false;

  isDeleting = false;

  deletingAmbulanceId:
    number | null = null;

  errorMessage = '';

  successMessage = '';

  readonly statusFilters:
    AmbulanceFilter[] = [
      'ALL',
      'AVAILABLE',
      'ON_TRIP',
      'MAINTENANCE'
    ];

  get totalAmbulances(): number {
    return this.ambulances.length;
  }

  get availableAmbulances(): number {
    return this.countByStatus(
      'AVAILABLE'
    );
  }

  get onTripAmbulances(): number {
    return this.countByStatus(
      'ON_TRIP'
    );
  }

  get maintenanceAmbulances(): number {
    return this.countByStatus(
      'MAINTENANCE'
    );
  }

  get hasAmbulances(): boolean {
    return (
      this.filteredAmbulances.length >
      0
    );
  }

  get hasActiveFilters(): boolean {
    return (
      this.searchText.trim().length >
        0 ||
      this.selectedStatus !== 'ALL'
    );
  }

  ngOnInit(): void {
    this.loadAmbulances();
  }

  loadAmbulances(): void {
    if (this.isLoading) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.ambulanceService
      .getAmbulances()
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe({
        next: ambulances => {
          this.ambulances =
            Array.isArray(ambulances)
              ? ambulances
              : [];

          this.applyFilters();
        },

        error: error => {
          console.error(
            'Unable to load ambulances:',
            error
          );

          this.ambulances = [];
          this.filteredAmbulances = [];

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to load ambulances.'
            );
        }
      });
  }

  onSearchChange(): void {
    this.applyFilters();
  }

  setStatusFilter(
    status: AmbulanceFilter
  ): void {
    this.selectedStatus = status;

    this.applyFilters();
  }

  clearFilters(): void {
    this.searchText = '';

    this.selectedStatus = 'ALL';

    this.applyFilters();
  }

  private applyFilters(): void {
    const normalizedSearch =
      this.searchText
        .trim()
        .toLowerCase();

    this.filteredAmbulances =
      this.ambulances.filter(
        ambulance => {
          const status =
            this.normalizeStatus(
              ambulance.status
            );

          const matchesStatus =
            this.selectedStatus ===
              'ALL' ||
            status ===
              this.selectedStatus;

          if (!normalizedSearch) {
            return matchesStatus;
          }

          const searchableValues = [
            ambulance.ambulanceId,
            ambulance.vehicleNumber,
            ambulance.licenseNo,
            ambulance.hospitalId,
            ambulance.status
          ];

          const matchesSearch =
            searchableValues.some(
              value =>
                String(value ?? '')
                  .toLowerCase()
                  .includes(
                    normalizedSearch
                  )
            );

          return (
            matchesStatus &&
            matchesSearch
          );
        }
      );
  }

  createAmbulance(): void {
    void this.router.navigate([
      '/admin/ambulances/create'
    ]);
  }

  viewAmbulance(
    ambulance: Ambulance
  ): void {
    void this.router.navigate([
      '/admin/ambulances',
      ambulance.ambulanceId
    ]);
  }

  editAmbulance(
    ambulance: Ambulance
  ): void {
    void this.router.navigate([
      '/admin/ambulances',
      ambulance.ambulanceId,
      'edit'
    ]);
  }

  deleteAmbulance(
    ambulance: Ambulance
  ): void {
    if (this.isDeleting) {
      return;
    }

    const confirmed =
      window.confirm(
        'Are you sure you want to delete ' +
        `ambulance "${ambulance.vehicleNumber}"?`
      );

    if (!confirmed) {
      return;
    }

    this.isDeleting = true;

    this.deletingAmbulanceId =
      ambulance.ambulanceId;

    this.errorMessage = '';
    this.successMessage = '';

    this.ambulanceService
      .deleteAmbulance(
        ambulance.ambulanceId
      )
      .pipe(
        finalize(() => {
          this.isDeleting = false;

          this.deletingAmbulanceId =
            null;
        })
      )
      .subscribe({
        next: message => {
          this.ambulances =
            this.ambulances.filter(
              item =>
                item.ambulanceId !==
                ambulance.ambulanceId
            );

          this.applyFilters();

          this.successMessage =
            message ||
            'Ambulance deleted successfully.';

          this.clearSuccessMessageLater();
        },

        error: error => {
          console.error(
            'Unable to delete ambulance:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to delete the ambulance.'
            );
        }
      });
  }

  getStatusLabel(
    status: string | null | undefined
  ): string {
    switch (
      this.normalizeStatus(status)
    ) {
      case 'AVAILABLE':
        return 'Available';

      case 'ON_TRIP':
        return 'On Trip';

      case 'MAINTENANCE':
        return 'Maintenance';

      default:
        return 'Unknown';
    }
  }

  getStatusClass(
    status: string | null | undefined
  ): string {
    return this.normalizeStatus(status)
      .toLowerCase()
      .replace('_', '-');
  }

  getVehicleInitials(
    ambulance: Ambulance
  ): string {
    const vehicleNumber =
      ambulance.vehicleNumber
        ?.trim();

    if (!vehicleNumber) {
      return 'AM';
    }

    const normalized =
      vehicleNumber
        .replace(
          /[^a-zA-Z0-9]/g,
          ''
        )
        .toUpperCase();

    return normalized.length >= 2
      ? normalized.slice(-2)
      : normalized;
  }

  getHospitalLabel(
    hospitalId: number | null
  ): string {
    return hospitalId !== null
      ? `Hospital ID: ${hospitalId}`
      : 'Not assigned';
  }

  closeErrorMessage(): void {
    this.errorMessage = '';
  }

  closeSuccessMessage(): void {
    this.successMessage = '';
  }

  private countByStatus(
    expectedStatus: AmbulanceStatus
  ): number {
    return this.ambulances.filter(
      ambulance =>
        this.normalizeStatus(
          ambulance.status
        ) === expectedStatus
    ).length;
  }

  private normalizeStatus(
    status: string | null | undefined
  ): string {
    return (
      status
        ?.trim()
        .toUpperCase() ||
      'UNKNOWN'
    );
  }

  private clearSuccessMessageLater():
    void {
    window.setTimeout(() => {
      this.successMessage = '';
    }, 3500);
  }

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    const httpError = error as {
      status?: number;
      message?: string;
      error?: {
        message?: string;
        error?: string;
      } | string;
    };

    if (httpError.status === 0) {
      return (
        'Unable to connect to the server. ' +
        'Verify that the API Gateway and ' +
        'Ambulance service are running.'
      );
    }

    if (httpError.status === 400) {
      return (
        this.extractBackendMessage(
          httpError.error
        ) ||
        'The ambulance request is invalid.'
      );
    }

    if (httpError.status === 401) {
      return (
        'Your session has expired. ' +
        'Please log in again.'
      );
    }

    if (httpError.status === 403) {
      return (
        'You do not have permission to ' +
        'perform this ambulance operation.'
      );
    }

    if (httpError.status === 404) {
      return (
        'The requested ambulance was ' +
        'not found.'
      );
    }

    if (
      httpError.status !== undefined &&
      httpError.status >= 500
    ) {
      return (
        'The Ambulance service is unavailable. ' +
        'Please try again later.'
      );
    }

    return (
      this.extractBackendMessage(
        httpError.error
      ) ||
      httpError.message ||
      fallbackMessage
    );
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (typeof errorBody === 'string') {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const body =
        errorBody as {
          message?: unknown;
          error?: unknown;
        };

      if (
        typeof body.message === 'string'
      ) {
        return body.message.trim();
      }

      if (
        typeof body.error === 'string'
      ) {
        return body.error.trim();
      }
    }

    return '';
  }

  trackByAmbulanceId(
    _index: number,
    ambulance: Ambulance
  ): number {
    return ambulance.ambulanceId;
  }

  trackByStatus(
    _index: number,
    status: AmbulanceFilter
  ): string {
    return status;
  }
}