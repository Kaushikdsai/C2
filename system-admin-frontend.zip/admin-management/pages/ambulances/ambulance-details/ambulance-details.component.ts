import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import {
  finalize
} from 'rxjs';

import {
  AdminAmbulanceService
} from '../../../services/admin-ambulance.service';

import {
  Ambulance,
  AmbulanceStatus
} from '../../../models/ambulance.model';

import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  selector: 'app-ambulance-details',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  templateUrl: './ambulance-details.component.html',
  styleUrl: './ambulance-details.component.css'
})
export class AmbulanceDetailsComponent
  implements OnInit {

  private readonly ambulanceService =
    inject(AdminAmbulanceService);

  private readonly activatedRoute =
    inject(ActivatedRoute);

  private readonly router =
    inject(Router);

  ambulance: Ambulance | null = null;

  ambulanceId: number | null = null;

  isLoading = false;

  isDeleting = false;

  errorMessage = '';

  successMessage = '';

  ngOnInit(): void {
    this.readAmbulanceId();
  }

  private readAmbulanceId(): void {
    const idParameter =
      this.activatedRoute.snapshot
        .paramMap
        .get('id');

    if (!idParameter) {
      this.errorMessage =
        'Ambulance ID is missing from the URL.';

      return;
    }

    const parsedId =
      Number(idParameter);

    if (
      !Number.isInteger(parsedId) ||
      parsedId <= 0
    ) {
      this.errorMessage =
        'The ambulance ID in the URL is invalid.';

      return;
    }

    this.ambulanceId = parsedId;

    this.loadAmbulance();
  }

  loadAmbulance(): void {
    if (
      this.isLoading ||
      this.ambulanceId === null
    ) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.ambulanceService
      .getAmbulanceById(
        this.ambulanceId
      )
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe({
        next: ambulance => {
          this.ambulance = ambulance;
        },

        error: error => {
          console.error(
            'Unable to load ambulance:',
            error
          );

          this.ambulance = null;

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to load ambulance information.'
            );
        }
      });
  }

  editAmbulance(): void {
    if (this.ambulanceId === null) {
      return;
    }

    void this.router.navigate([
      '/admin/ambulances',
      this.ambulanceId,
      'edit'
    ]);
  }

  deleteAmbulance(): void {
    if (
      this.ambulance === null ||
      this.isDeleting
    ) {
      return;
    }

    const ambulanceId =
      this.ambulance.ambulanceId;

    const vehicleNumber =
      this.ambulance.vehicleNumber ||
      `#${ambulanceId}`;

    const confirmed =
      window.confirm(
        'Are you sure you want to delete ' +
        `ambulance "${vehicleNumber}"?`
      );

    if (!confirmed) {
      return;
    }

    this.isDeleting = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.ambulanceService
      .deleteAmbulance(ambulanceId)
      .pipe(
        finalize(() => {
          this.isDeleting = false;
        })
      )
      .subscribe({
        next: message => {
          this.successMessage =
            message ||
            'Ambulance deleted successfully.';

          window.setTimeout(() => {
            void this.router.navigate([
              '/admin/ambulances'
            ]);
          }, 800);
        },

        error: error => {
          console.error(
            'Unable to delete ambulance:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to delete the ambulance.'
            );
        }
      });
  }

  navigateBack(): void {
    void this.router.navigate([
      '/admin/ambulances'
    ]);
  }

  getStatusLabel(
    status: string | null | undefined
  ): string {
    switch (
      this.normalizeStatus(status)
    ) {
      case 'AVAILABLE':
        return 'Available';

      case 'ON_TRIP':
        return 'On Trip';

      case 'MAINTENANCE':
        return 'Maintenance';

      default:
        return 'Unknown';
    }
  }

  getStatusClass(
    status: string | null | undefined
  ): string {
    return this.normalizeStatus(status)
      .toLowerCase()
      .replace(/_/g, '-');
  }

  getStatusDescription(
    status: string | null | undefined
  ): string {
    switch (
      this.normalizeStatus(status)
    ) {
      case 'AVAILABLE':
        return (
          'This ambulance is currently available ' +
          'for emergency transportation.'
        );

      case 'ON_TRIP':
        return (
          'This ambulance is currently assigned ' +
          'to an active emergency trip.'
        );

      case 'MAINTENANCE':
        return (
          'This ambulance is undergoing maintenance ' +
          'and is not available for trips.'
        );

      default:
        return (
          'The current operational status of this ' +
          'ambulance is unavailable.'
        );
    }
  }

  getStatusIcon(
    status: string | null | undefined
  ): string {
    switch (
      this.normalizeStatus(status)
    ) {
      case 'AVAILABLE':
        return '✓';

      case 'ON_TRIP':
        return '↗';

      case 'MAINTENANCE':
        return '⚙';

      default:
        return '?';
    }
  }

  getVehicleInitials(): string {
    const vehicleNumber =
      this.ambulance
        ?.vehicleNumber
        ?.trim();

    if (!vehicleNumber) {
      return 'AM';
    }

    const normalized =
      vehicleNumber
        .replace(
          /[^a-zA-Z0-9]/g,
          ''
        )
        .toUpperCase();

    if (!normalized) {
      return 'AM';
    }

    return normalized.length >= 2
      ? normalized.slice(-2)
      : normalized;
  }

  getHospitalDisplay(): string {
    const hospitalId =
      this.ambulance?.hospitalId;

    if (
      hospitalId === null ||
      hospitalId === undefined
    ) {
      return 'Not assigned to a hospital';
    }

    return `Hospital ID: ${hospitalId}`;
  }

  closeErrorMessage(): void {
    this.errorMessage = '';
  }

  closeSuccessMessage(): void {
    this.successMessage = '';
  }

  private normalizeStatus(
    status: string | null | undefined
  ): AmbulanceStatus | 'UNKNOWN' {
    const normalizedStatus =
      status
        ?.trim()
        .toUpperCase();

    switch (normalizedStatus) {
      case 'AVAILABLE':
      case 'ON_TRIP':
      case 'MAINTENANCE':
        return normalizedStatus;

      default:
        return 'UNKNOWN';
    }
  }

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    const httpError = error as {
      status?: number;
      message?: string;
      error?: {
        message?: string;
        error?: string;
      } | string;
    };

    if (httpError.status === 0) {
      return (
        'Unable to connect to the server. ' +
        'Verify that the API Gateway and ' +
        'Ambulance service are running.'
      );
    }

    if (httpError.status === 400) {
      return (
        this.extractBackendMessage(
          httpError.error
        ) ||
        'The ambulance request is invalid.'
      );
    }

    if (httpError.status === 401) {
      return (
        'Your session has expired. ' +
        'Please log in again.'
      );
    }

    if (httpError.status === 403) {
      return (
        'You do not have permission to view ' +
        'this ambulance.'
      );
    }

    if (httpError.status === 404) {
      return (
        'The requested ambulance was not found.'
      );
    }

    if (
      httpError.status !== undefined &&
      httpError.status >= 500
    ) {
      return (
        'The Ambulance service is unavailable. ' +
        'Please try again later.'
      );
    }

    return (
      this.extractBackendMessage(
        httpError.error
      ) ||
      httpError.message ||
      fallbackMessage
    );
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (typeof errorBody === 'string') {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const body =
        errorBody as {
          message?: unknown;
          error?: unknown;
        };

      if (
        typeof body.message === 'string'
      ) {
        return body.message.trim();
      }

      if (
        typeof body.error === 'string'
      ) {
        return body.error.trim();
      }
    }

    return '';
  }
}