import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import {
  FormsModule
} from '@angular/forms';

import {
  Router
} from '@angular/router';

import {
  finalize
} from 'rxjs';

import {
  AdminDoctorService
} from '../../../services/admin-doctor.service';

import {
  Doctor,
  DoctorStatus
} from '../../../models/doctor.model';

import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

type DoctorStatusFilter =
  | 'ALL'
  | DoctorStatus;

@Component({
  selector: 'app-doctor-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  templateUrl: './doctor-list.component.html',
  styleUrl: './doctor-list.component.css'
})
export class DoctorListComponent
  implements OnInit {

  private readonly doctorService =
    inject(AdminDoctorService);

  private readonly router =
    inject(Router);

  doctors: Doctor[] = [];

  filteredDoctors: Doctor[] = [];

  searchText = '';

  selectedStatus:
    DoctorStatusFilter = 'ALL';

  isLoading = false;

  isDeleting = false;

  isUpdatingStatus = false;

  deletingDoctorId:
    number | null = null;

  updatingDoctorId:
    number | null = null;

  errorMessage = '';

  successMessage = '';

  readonly statusFilters:
    DoctorStatusFilter[] = [
      'ALL',
      'ACTIVE',
      'INACTIVE'
    ];

  get totalDoctors(): number {
    return this.doctors.length;
  }

  get activeDoctors(): number {
    return this.countByStatus(
      'ACTIVE'
    );
  }

  get inactiveDoctors(): number {
    return this.countByStatus(
      'INACTIVE'
    );
  }

  get specializationCount(): number {
    const specializations =
      this.doctors
        .map(doctor =>
          doctor.specialization
            ?.trim()
            .toLowerCase()
        )
        .filter(
          specialization =>
            Boolean(specialization)
        );

    return new Set(
      specializations
    ).size;
  }

  get hasDoctors(): boolean {
    return (
      this.filteredDoctors.length > 0
    );
  }

  get hasActiveFilters(): boolean {
    return (
      this.searchText.trim().length > 0 ||
      this.selectedStatus !== 'ALL'
    );
  }

  ngOnInit(): void {
    this.loadDoctors();
  }

  loadDoctors(): void {
    if (this.isLoading) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.doctorService
      .getDoctors()
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe({
        next: doctors => {
          this.doctors =
            Array.isArray(doctors)
              ? doctors
              : [];

          this.applyFilters();
        },

        error: error => {
          console.error(
            'Unable to load doctors:',
            error
          );

          this.doctors = [];
          this.filteredDoctors = [];

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to load doctors.'
            );
        }
      });
  }

  onSearchChange(): void {
    this.applyFilters();
  }

  setStatusFilter(
    status: DoctorStatusFilter
  ): void {
    this.selectedStatus = status;

    this.applyFilters();
  }

  clearFilters(): void {
    this.searchText = '';
    this.selectedStatus = 'ALL';

    this.applyFilters();
  }

  private applyFilters(): void {
    const search =
      this.searchText
        .trim()
        .toLowerCase();

    this.filteredDoctors =
      this.doctors.filter(
        doctor => {
          const normalizedStatus =
            this.normalizeStatus(
              doctor.status
            );

          const matchesStatus =
            this.selectedStatus === 'ALL' ||
            normalizedStatus ===
              this.selectedStatus;

          if (!search) {
            return matchesStatus;
          }

          const searchableValues = [
            doctor.id,
            doctor.name,
            doctor.email,
            doctor.phone,
            doctor.licenseNo,
            doctor.experience,
            doctor.specialization,
            doctor.address,
            doctor.pincode,
            doctor.city,
            doctor.state,
            doctor.status
          ];

          const matchesSearch =
            searchableValues.some(
              value =>
                String(value ?? '')
                  .toLowerCase()
                  .includes(search)
            );

          return (
            matchesStatus &&
            matchesSearch
          );
        }
      );
  }

  createDoctor(): void {
    void this.router.navigate([
      '/admin/doctors/create'
    ]);
  }

  viewDoctor(
    doctor: Doctor
  ): void {
    void this.router.navigate([
      '/admin/doctors',
      doctor.id
    ]);
  }

  editDoctor(
    doctor: Doctor
  ): void {
    void this.router.navigate([
      '/admin/doctors',
      doctor.id,
      'edit'
    ]);
  }

  toggleDoctorStatus(
    doctor: Doctor
  ): void {
    if (
      this.isUpdatingStatus ||
      this.isDeleting
    ) {
      return;
    }

    const currentStatus =
      this.normalizeStatus(
        doctor.status
      );

    const newStatus:
      DoctorStatus =
        currentStatus === 'ACTIVE'
          ? 'INACTIVE'
          : 'ACTIVE';

    const doctorName =
      this.getDoctorName(doctor);

    const confirmed =
      window.confirm(
        `Change ${doctorName}'s status ` +
        `to ${newStatus}?`
      );

    if (!confirmed) {
      return;
    }

    this.isUpdatingStatus = true;
    this.updatingDoctorId =
      doctor.id;

    this.errorMessage = '';
    this.successMessage = '';

    this.doctorService
      .updateDoctorStatus(
        doctor.id,
        newStatus
      )
      .pipe(
        finalize(() => {
          this.isUpdatingStatus = false;
          this.updatingDoctorId = null;
        })
      )
      .subscribe({
        next: success => {
          if (!success) {
            this.errorMessage =
              'Doctor status could not be updated.';

            return;
          }

          doctor.status = newStatus;

          this.applyFilters();

          this.successMessage =
            `${doctorName}'s status was changed ` +
            `to ${newStatus}.`;

          this.clearSuccessMessageLater();
        },

        error: error => {
          console.error(
            'Unable to update doctor status:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to update doctor status.'
            );
        }
      });
  }

  deleteDoctor(
    doctor: Doctor
  ): void {
    if (
      this.isDeleting ||
      this.isUpdatingStatus
    ) {
      return;
    }

    const doctorName =
      this.getDoctorName(doctor);

    const confirmed =
      window.confirm(
        `Are you sure you want to deactivate ` +
        `${doctorName}?`
      );

    if (!confirmed) {
      return;
    }

    this.isDeleting = true;
    this.deletingDoctorId =
      doctor.id;

    this.errorMessage = '';
    this.successMessage = '';

    this.doctorService
      .deleteDoctor(doctor.id)
      .pipe(
        finalize(() => {
          this.isDeleting = false;
          this.deletingDoctorId = null;
        })
      )
      .subscribe({
        next: success => {
          if (!success) {
            this.errorMessage =
              'Doctor could not be deactivated.';

            return;
          }

          /*
           * The backend performs a soft delete by
           * setting the status to INACTIVE.
           */
          doctor.status = 'INACTIVE';

          this.applyFilters();

          this.successMessage =
            `${doctorName} was deactivated successfully.`;

          this.clearSuccessMessageLater();
        },

        error: error => {
          console.error(
            'Unable to deactivate doctor:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to deactivate the doctor.'
            );
        }
      });
  }

  getDoctorName(
    doctor: Doctor
  ): string {
    return (
      doctor.name?.trim() ||
      `Doctor ${doctor.id}`
    );
  }

  getDoctorInitials(
    doctor: Doctor
  ): string {
    const name =
      this.getDoctorName(doctor)
        .replace(/^dr\.?\s+/i, '');

    const initials =
      name
        .split(/\s+/)
        .filter(
          word => word.length > 0
        )
        .slice(0, 2)
        .map(word =>
          word.charAt(0).toUpperCase()
        )
        .join('');

    return initials || 'DR';
  }

  getLocation(
    doctor: Doctor
  ): string {
    const locationParts = [
      doctor.city,
      doctor.state
    ].filter(
      value =>
        Boolean(value?.trim())
    );

    return locationParts.length > 0
      ? locationParts.join(', ')
      : 'Location not provided';
  }

  getStatusLabel(
    status: string | null | undefined
  ): string {
    return this.normalizeStatus(status) ===
      'INACTIVE'
        ? 'Inactive'
        : 'Active';
  }

  getStatusClass(
    status: string | null | undefined
  ): string {
    return this.normalizeStatus(status)
      .toLowerCase();
  }

  getStatusActionLabel(
    doctor: Doctor
  ): string {
    const isUpdating =
      this.isUpdatingStatus &&
      this.updatingDoctorId === doctor.id;

    if (isUpdating) {
      return 'Updating...';
    }

    return this.normalizeStatus(
      doctor.status
    ) === 'ACTIVE'
      ? 'Deactivate'
      : 'Activate';
  }

  closeErrorMessage(): void {
    this.errorMessage = '';
  }

  closeSuccessMessage(): void {
    this.successMessage = '';
  }

  private countByStatus(
    status: DoctorStatus
  ): number {
    return this.doctors.filter(
      doctor =>
        this.normalizeStatus(
          doctor.status
        ) === status
    ).length;
  }

  private normalizeStatus(
    status: string | null | undefined
  ): DoctorStatus {
    return status
      ?.trim()
      .toUpperCase() === 'INACTIVE'
        ? 'INACTIVE'
        : 'ACTIVE';
  }

  private clearSuccessMessageLater():
    void {
    window.setTimeout(() => {
      this.successMessage = '';
    }, 3500);
  }

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    const httpError = error as {
      status?: number;
      message?: string;
      error?: {
        message?: string;
        error?: string;
      } | string;
    };

    if (httpError.status === 0) {
      return (
        'Unable to connect to the server. ' +
        'Verify that the API Gateway and ' +
        'User service are running.'
      );
    }

    if (httpError.status === 400) {
      return (
        this.extractBackendMessage(
          httpError.error
        ) ||
        'The doctor request is invalid.'
      );
    }

    if (httpError.status === 401) {
      return (
        'Your session has expired. ' +
        'Please log in again.'
      );
    }

    if (httpError.status === 403) {
      return (
        'You do not have permission to perform ' +
        'this doctor operation.'
      );
    }

    if (httpError.status === 404) {
      return (
        'The requested doctor was not found.'
      );
    }

    if (
      httpError.status !== undefined &&
      httpError.status >= 500
    ) {
      return (
        'The Doctor service is currently unavailable. ' +
        'Please try again later.'
      );
    }

    return (
      this.extractBackendMessage(
        httpError.error
      ) ||
      httpError.message ||
      fallbackMessage
    );
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (typeof errorBody === 'string') {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const body =
        errorBody as {
          message?: unknown;
          error?: unknown;
        };

      if (
        typeof body.message === 'string'
      ) {
        return body.message.trim();
      }

      if (
        typeof body.error === 'string'
      ) {
        return body.error.trim();
      }
    }

    return '';
  }

  trackByDoctorId(
    _index: number,
    doctor: Doctor
  ): number {
    return doctor.id;
  }

  trackByStatus(
    _index: number,
    status: DoctorStatusFilter
  ): string {
    return status;
  }
}
