import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import {
  AbstractControl,
  FormBuilder,
  ReactiveFormsModule,
  ValidationErrors,
  ValidatorFn,
  Validators
} from '@angular/forms';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import {
  finalize
} from 'rxjs';

import {
  AdminDoctorService
} from '../../../services/admin-doctor.service';

import {
  CreateDoctorRequest,
  DoctorStatus,
  UpdateDoctorRequest
} from '../../../models/doctor.model';

import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

/* =========================================================
   FORM VALUE TYPE
========================================================= */

interface DoctorFormValue {
  username: string;
  password: string;

  name: string;
  email: string;
  phone: string;
  address: string;
  pincode: string;
  city: string;
  state: string;

  licenseNo: string;
  experience: number;
  specialization: string;
  status: DoctorStatus;
}

/* =========================================================
   COMPONENT
========================================================= */

@Component({
  selector: 'app-doctor-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  templateUrl: './doctor-form.component.html',
  styleUrl: './doctor-form.component.css'
})
export class DoctorFormComponent
  implements OnInit {

  /* =======================================================
     DEPENDENCIES
  ======================================================= */

  private readonly formBuilder =
    inject(FormBuilder);

  private readonly doctorService =
    inject(AdminDoctorService);

  private readonly activatedRoute =
    inject(ActivatedRoute);

  private readonly router =
    inject(Router);

  /* =======================================================
     PAGE STATE
  ======================================================= */

  doctorId: number | null = null;

  isEditMode = false;

  isLoading = false;

  isSubmitting = false;

  formSubmitted = false;

  errorMessage = '';

  successMessage = '';

  readonly doctorStatuses:
    DoctorStatus[] = [
      'ACTIVE',
      'INACTIVE'
    ];

  /* =======================================================
     REACTIVE FORM
  ======================================================= */

  readonly doctorForm =
    this.formBuilder.nonNullable.group({
      /*
       * Credentials fields.
       *
       * These fields are required only during creation.
       */
      username: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(50),
          Validators.pattern(
            /^[a-zA-Z0-9._-]+$/
          )
        ]
      ],

      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(100)
        ]
      ],

      /*
       * Details fields.
       */
      name: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(100),
          Validators.pattern(
            /^[a-zA-Z\s.'-]+$/
          )
        ]
      ],

      email: [
        '',
        [
          Validators.required,
          Validators.email,
          Validators.maxLength(120)
        ]
      ],

      phone: [
        '',
        [
          Validators.required,
          Validators.pattern(
            /^[6-9][0-9]{9}$/
          )
        ]
      ],

      address: [
        '',
        [
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(250)
        ]
      ],

      pincode: [
        '',
        [
          Validators.required,
          Validators.pattern(
            /^[1-9][0-9]{5}$/
          )
        ]
      ],

      city: [
        '',
        [
          Validators.required,
          Validators.maxLength(60),
          Validators.pattern(
            /^[a-zA-Z\s.-]+$/
          )
        ]
      ],

      state: [
        '',
        [
          Validators.required,
          Validators.maxLength(60),
          Validators.pattern(
            /^[a-zA-Z\s.-]+$/
          )
        ]
      ],

      /*
       * Doctor fields.
       */
      licenseNo: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(50),
          Validators.pattern(
            /^[a-zA-Z0-9/_-]+$/
          )
        ]
      ],

      experience: [
        0,
        [
          Validators.required,
          Validators.min(0),
          Validators.max(80),
          this.integerValidator()
        ]
      ],

      specialization: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(100),
          Validators.pattern(
            /^[a-zA-Z\s,.'()&/-]+$/
          )
        ]
      ],

      status: [
        'ACTIVE' as DoctorStatus,
        [
          Validators.required
        ]
      ]
    });

  /* =======================================================
     COMPUTED VALUES
  ======================================================= */

  get pageTitle(): string {
    return this.isEditMode
      ? 'Edit Doctor'
      : 'Add Doctor';
  }

  get pageDescription(): string {
    return this.isEditMode
      ? (
          'Update the doctor professional, personal, ' +
          'location, and account information.'
        )
      : (
          'Create a Doctor account. The backend will ' +
          'generate and share the account ID.'
        );
  }

  get submitButtonLabel(): string {
    if (this.isSubmitting) {
      return this.isEditMode
        ? 'Updating Doctor...'
        : 'Creating Doctor...';
    }

    return this.isEditMode
      ? 'Update Doctor'
      : 'Create Doctor';
  }

  /* =======================================================
     LIFECYCLE
  ======================================================= */

  ngOnInit(): void {
    this.readRouteParameter();
  }

  /* =======================================================
     ROUTE HANDLING
  ======================================================= */

  private readRouteParameter(): void {
    const idParameter =
      this.activatedRoute.snapshot
        .paramMap
        .get('id');

    /*
     * No route ID means create mode.
     */
    if (!idParameter) {
      this.isEditMode = false;
      this.doctorId = null;

      this.configureCredentialControls();

      return;
    }

    const parsedId =
      Number(idParameter);

    if (
      !Number.isInteger(parsedId) ||
      parsedId <= 0
    ) {
      this.errorMessage =
        'The doctor ID in the URL is invalid.';

      return;
    }

    this.doctorId = parsedId;
    this.isEditMode = true;

    this.configureCredentialControls();
    this.loadDoctor(parsedId);
  }

  /* =======================================================
     CREDENTIAL CONTROL CONFIGURATION
  ======================================================= */

  private configureCredentialControls():
    void {
    const usernameControl =
      this.doctorForm.controls.username;

    const passwordControl =
      this.doctorForm.controls.password;

    if (this.isEditMode) {
      /*
       * Username and password are not updated by
       * the normal Doctor update API.
       */
      usernameControl.clearValidators();
      passwordControl.clearValidators();

      usernameControl.setValue('');
      passwordControl.setValue('');

      usernameControl.disable();
      passwordControl.disable();
    } else {
      usernameControl.enable();
      passwordControl.enable();

      usernameControl.setValidators([
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(50),
        Validators.pattern(
          /^[a-zA-Z0-9._-]+$/
        )
      ]);

      passwordControl.setValidators([
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(100)
      ]);
    }

    usernameControl.updateValueAndValidity({
      emitEvent: false
    });

    passwordControl.updateValueAndValidity({
      emitEvent: false
    });
  }

  /* =======================================================
     LOAD DOCTOR
  ======================================================= */

  private loadDoctor(
    doctorId: number
  ): void {
    if (this.isLoading) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.doctorForm.disable();

    this.doctorService
      .getDoctorById(doctorId)
      .pipe(
        finalize(() => {
          this.isLoading = false;

          this.doctorForm.enable();

          /*
           * Keep credential controls disabled
           * when editing.
           */
          this.configureCredentialControls();
        })
      )
      .subscribe({
        next: doctor => {
          this.doctorForm.patchValue({
            username: '',
            password: '',

            name:
              doctor.name ?? '',

            email:
              doctor.email ?? '',

            phone:
              doctor.phone ?? '',

            address:
              doctor.address ?? '',

            pincode:
              doctor.pincode ?? '',

            city:
              doctor.city ?? '',

            state:
              doctor.state ?? '',

            licenseNo:
              doctor.licenseNo ?? '',

            experience:
              doctor.experience ?? 0,

            specialization:
              doctor.specialization ?? '',

            status:
              this.normalizeStatus(
                doctor.status
              )
          });

          this.doctorForm.markAsPristine();
          this.doctorForm.markAsUntouched();

          this.formSubmitted = false;
        },

        error: error => {
          console.error(
            'Unable to load doctor:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to load doctor information.'
            );
        }
      });
  }

  /* =======================================================
     SUBMIT FORM
  ======================================================= */

  submitForm(): void {
    if (
      this.isSubmitting ||
      this.isLoading
    ) {
      return;
    }

    this.formSubmitted = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.doctorForm
      .updateValueAndValidity();

    if (this.doctorForm.invalid) {
      this.doctorForm.markAllAsTouched();

      this.focusFirstInvalidControl();

      return;
    }

    const rawValue =
      this.doctorForm.getRawValue();

    const formValue:
      DoctorFormValue = {
        username:
          rawValue.username,

        password:
          rawValue.password,

        name:
          rawValue.name,

        email:
          rawValue.email,

        phone:
          rawValue.phone,

        address:
          rawValue.address,

        pincode:
          rawValue.pincode,

        city:
          rawValue.city,

        state:
          rawValue.state,

        licenseNo:
          rawValue.licenseNo,

        experience:
          Number(rawValue.experience),

        specialization:
          rawValue.specialization,

        status:
          rawValue.status
      };

    if (this.isEditMode) {
      this.prepareUpdateRequest(
        formValue
      );

      return;
    }

    this.prepareCreateRequest(
      formValue
    );
  }

  /* =======================================================
     PREPARE CREATE REQUEST
  ======================================================= */

  private prepareCreateRequest(
    formValue: DoctorFormValue
  ): void {
    const request:
      CreateDoctorRequest = {
        /*
         * Credentials fields.
         */
        username:
          formValue.username
            .trim()
            .toLowerCase(),

        password:
          formValue.password,

        /*
         * Details fields.
         */
        name:
          formValue.name.trim(),

        email:
          formValue.email
            .trim()
            .toLowerCase(),

        phone:
          formValue.phone.trim(),

        address:
          formValue.address.trim(),

        pincode:
          formValue.pincode.trim(),

        city:
          formValue.city.trim(),

        state:
          formValue.state.trim(),

        /*
         * Doctor fields.
         */
        licenseNo:
          formValue.licenseNo
            .trim()
            .toUpperCase(),

        experience:
          Number(formValue.experience),

        specialization:
          formValue.specialization.trim(),

        status:
          formValue.status
      };

    this.createDoctor(request);
  }

  /* =======================================================
     PREPARE UPDATE REQUEST
  ======================================================= */

  private prepareUpdateRequest(
    formValue: DoctorFormValue
  ): void {
    if (this.doctorId === null) {
      this.errorMessage =
        'Doctor ID is unavailable.';

      return;
    }

    const request:
      UpdateDoctorRequest = {
        /*
         * Existing shared primary key.
         */
        id:
          this.doctorId,

        /*
         * Details fields.
         */
        name:
          formValue.name.trim(),

        email:
          formValue.email
            .trim()
            .toLowerCase(),

        phone:
          formValue.phone.trim(),

        address:
          formValue.address.trim(),

        pincode:
          formValue.pincode.trim(),

        city:
          formValue.city.trim(),

        state:
          formValue.state.trim(),

        /*
         * Doctor fields.
         */
        licenseNo:
          formValue.licenseNo
            .trim()
            .toUpperCase(),

        experience:
          Number(formValue.experience),

        specialization:
          formValue.specialization.trim(),

        status:
          formValue.status
      };

    this.updateDoctor(request);
  }

  /* =======================================================
     CREATE DOCTOR
  ======================================================= */

  private createDoctor(
    request: CreateDoctorRequest
  ): void {
    this.isSubmitting = true;
    this.doctorForm.disable();

    this.doctorService
      .createDoctor(request)
      .pipe(
        finalize(() => {
          this.isSubmitting = false;

          this.doctorForm.enable();
          this.configureCredentialControls();
        })
      )
      .subscribe({
        next: success => {
          if (!success) {
            this.errorMessage =
              'The doctor could not be created.';

            return;
          }

          this.successMessage =
            'Doctor created successfully.';

          this.doctorForm.markAsPristine();

          window.setTimeout(() => {
            void this.router.navigate([
              '/admin/doctors'
            ]);
          }, 800);
        },

        error: error => {
          console.error(
            'Unable to create doctor:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to create the doctor.'
            );
        }
      });
  }

  /* =======================================================
     UPDATE DOCTOR
  ======================================================= */

  private updateDoctor(
    request: UpdateDoctorRequest
  ): void {
    this.isSubmitting = true;
    this.doctorForm.disable();

    this.doctorService
      .updateDoctor(request)
      .pipe(
        finalize(() => {
          this.isSubmitting = false;

          this.doctorForm.enable();
          this.configureCredentialControls();
        })
      )
      .subscribe({
        next: success => {
          if (!success) {
            this.errorMessage =
              'The doctor could not be updated.';

            return;
          }

          this.successMessage =
            'Doctor updated successfully.';

          this.doctorForm.markAsPristine();

          window.setTimeout(() => {
            if (this.doctorId !== null) {
              void this.router.navigate([
                '/admin/doctors',
                this.doctorId
              ]);

              return;
            }

            void this.router.navigate([
              '/admin/doctors'
            ]);
          }, 800);
        },

        error: error => {
          console.error(
            'Unable to update doctor:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to update the doctor.'
            );
        }
      });
  }

  /* =======================================================
     FORM ACTIONS
  ======================================================= */

  resetForm(): void {
    if (
      this.isSubmitting ||
      this.isLoading
    ) {
      return;
    }

    this.errorMessage = '';
    this.successMessage = '';
    this.formSubmitted = false;

    /*
     * In edit mode, reload the original data.
     */
    if (
      this.isEditMode &&
      this.doctorId !== null
    ) {
      this.loadDoctor(
        this.doctorId
      );

      return;
    }

    /*
     * Reset creation form.
     */
    this.doctorForm.reset({
      username: '',
      password: '',
      name: '',
      email: '',
      phone: '',
      address: '',
      pincode: '',
      city: '',
      state: '',
      licenseNo: '',
      experience: 0,
      specialization: '',
      status: 'ACTIVE'
    });

    this.configureCredentialControls();

    this.doctorForm.markAsPristine();
    this.doctorForm.markAsUntouched();
  }

  cancel(): void {
    if (
      this.doctorForm.dirty &&
      !this.isSubmitting
    ) {
      const shouldLeave =
        window.confirm(
          'You have unsaved changes. ' +
          'Do you want to leave this page?'
        );

      if (!shouldLeave) {
        return;
      }
    }

    this.navigateBack();
  }

  navigateBack(): void {
    void this.router.navigate([
      '/admin/doctors'
    ]);
  }

  /* =======================================================
     VALIDATION
  ======================================================= */

  isFieldInvalid(
    controlName:
      keyof typeof this.doctorForm.controls
  ): boolean {
    const control =
      this.doctorForm.controls[
        controlName
      ];

    if (control.disabled) {
      return false;
    }

    return (
      control.invalid &&
      (
        control.touched ||
        control.dirty ||
        this.formSubmitted
      )
    );
  }

  getFieldError(
    controlName:
      keyof typeof this.doctorForm.controls
  ): string {
    const control =
      this.doctorForm.controls[
        controlName
      ];

    const label =
      this.getFieldLabel(
        controlName
      );

    if (
      control.disabled ||
      !control.errors
    ) {
      return '';
    }

    if (control.errors['required']) {
      return `${label} is required.`;
    }

    if (control.errors['email']) {
      return 'Enter a valid email address.';
    }

    if (control.errors['minlength']) {
      const requiredLength =
        control.errors['minlength']
          .requiredLength;

      return (
        `${label} must contain at least ` +
        `${requiredLength} characters.`
      );
    }

    if (control.errors['maxlength']) {
      const requiredLength =
        control.errors['maxlength']
          .requiredLength;

      return (
        `${label} cannot exceed ` +
        `${requiredLength} characters.`
      );
    }

    if (control.errors['min']) {
      return `${label} cannot be negative.`;
    }

    if (control.errors['max']) {
      return (
        `${label} exceeds the maximum value.`
      );
    }

    if (control.errors['notInteger']) {
      return (
        `${label} must be a whole number.`
      );
    }

    if (control.errors['pattern']) {
      switch (controlName) {
        case 'username':
          return (
            'Username can contain only letters, ' +
            'numbers, dots, underscores, and hyphens.'
          );

        case 'name':
          return (
            'Name can contain only letters, spaces, ' +
            'apostrophes, periods, and hyphens.'
          );

        case 'phone':
          return (
            'Enter a valid 10-digit Indian ' +
            'mobile number.'
          );

        case 'licenseNo':
          return (
            'License number can contain only letters, ' +
            'numbers, slashes, underscores, and hyphens.'
          );

        case 'specialization':
          return (
            'Specialization contains invalid characters.'
          );

        case 'pincode':
          return (
            'Enter a valid 6-digit pincode.'
          );

        case 'city':
          return (
            'City can contain only letters, spaces, ' +
            'periods, and hyphens.'
          );

        case 'state':
          return (
            'State can contain only letters, spaces, ' +
            'periods, and hyphens.'
          );

        default:
          return (
            `Enter a valid ` +
            `${label.toLowerCase()}.`
          );
      }
    }

    return `${label} is invalid.`;
  }

  private getFieldLabel(
    controlName:
      keyof typeof this.doctorForm.controls
  ): string {
    const labels:
      Record<
        keyof typeof this.doctorForm.controls,
        string
      > = {
        username:
          'Username',

        password:
          'Password',

        name:
          'Doctor name',

        email:
          'Email',

        phone:
          'Phone number',

        address:
          'Address',

        pincode:
          'Pincode',

        city:
          'City',

        state:
          'State',

        licenseNo:
          'License number',

        experience:
          'Experience',

        specialization:
          'Specialization',

        status:
          'Status'
      };

    return labels[controlName];
  }

  private integerValidator():
    ValidatorFn {
    return (
      control: AbstractControl
    ): ValidationErrors | null => {
      if (
        control.value === null ||
        control.value === ''
      ) {
        return null;
      }

      const value =
        Number(control.value);

      return Number.isInteger(value)
        ? null
        : {
            notInteger: true
          };
    };
  }

  private focusFirstInvalidControl():
    void {
    window.setTimeout(() => {
      const invalidElement =
        document.querySelector(
          '.form-control.invalid'
        ) as HTMLElement | null;

      invalidElement?.focus();
    });
  }

  /* =======================================================
     STATUS HELPERS
  ======================================================= */

  getStatusLabel(
    status: DoctorStatus
  ): string {
    return status === 'ACTIVE'
      ? 'Active'
      : 'Inactive';
  }

  getStatusDescription(
    status: DoctorStatus
  ): string {
    return status === 'ACTIVE'
      ? (
          'The doctor account is available ' +
          'for regular operations.'
        )
      : (
          'The doctor account is inactive ' +
          'and unavailable for operations.'
        );
  }

  private normalizeStatus(
    status: string | null | undefined
  ): DoctorStatus {
    return status
      ?.trim()
      .toUpperCase() === 'INACTIVE'
        ? 'INACTIVE'
        : 'ACTIVE';
  }

  trackByStatus(
    _index: number,
    status: DoctorStatus
  ): string {
    return status;
  }

  /* =======================================================
     MESSAGE ACTIONS
  ======================================================= */

  closeErrorMessage(): void {
    this.errorMessage = '';
  }

  closeSuccessMessage(): void {
    this.successMessage = '';
  }

  /* =======================================================
     ERROR HANDLING
  ======================================================= */

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    const httpError =
      error as {
        status?: number;
        message?: string;
        error?:
          | {
              message?: string;
              error?: string;
            }
          | string;
      };

    const backendMessage =
      this.extractBackendMessage(
        httpError.error
      );

    if (httpError.status === 0) {
      return (
        'Unable to connect to the server. ' +
        'Verify that the API Gateway and ' +
        'User service are running.'
      );
    }

    if (httpError.status === 400) {
      return (
        backendMessage ||
        'The doctor information is invalid.'
      );
    }

    if (httpError.status === 401) {
      return (
        'Your session has expired. ' +
        'Please log in again.'
      );
    }

    if (httpError.status === 403) {
      return (
        'You do not have permission to perform ' +
        'this doctor operation.'
      );
    }

    if (httpError.status === 404) {
      return (
        backendMessage ||
        'The requested doctor was not found.'
      );
    }

    if (httpError.status === 409) {
      return (
        backendMessage ||
        'The username or license number already exists.'
      );
    }

    if (
      httpError.status !== undefined &&
      httpError.status >= 500
    ) {
      return (
        backendMessage ||
        'The User service is currently unavailable.'
      );
    }

    return (
      backendMessage ||
      httpError.message ||
      fallbackMessage
    );
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (
      typeof errorBody === 'string'
    ) {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const responseBody =
        errorBody as {
          message?: unknown;
          error?: unknown;
        };

      if (
        typeof responseBody.message ===
        'string'
      ) {
        return responseBody
          .message
          .trim();
      }

      if (
        typeof responseBody.error ===
        'string'
      ) {
        return responseBody
          .error
          .trim();
      }
    }

    return '';
  }
}