import {
  CommonModule
} from '@angular/common';

import {
  Component,
  inject,
  OnInit
} from '@angular/core';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import {
  finalize
} from 'rxjs';

import {
  AdminDoctorService
} from '../../../services/admin-doctor.service';

import {
  Doctor,
  DoctorStatus
} from '../../../models/doctor.model';

import { HeaderComponent } from '../../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  selector: 'app-doctor-details',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  templateUrl: './doctor-details.component.html',
  styleUrl: './doctor-details.component.css'
})
export class DoctorDetailsComponent
  implements OnInit {

  /* =======================================================
     DEPENDENCIES
  ======================================================= */

  private readonly doctorService =
    inject(AdminDoctorService);

  private readonly activatedRoute =
    inject(ActivatedRoute);

  private readonly router =
    inject(Router);

  /* =======================================================
     PAGE STATE
  ======================================================= */

  doctor: Doctor | null = null;

  doctorId: number | null = null;

  isLoading = false;

  isDeleting = false;

  isUpdatingStatus = false;

  errorMessage = '';

  successMessage = '';

  /* =======================================================
     LIFECYCLE
  ======================================================= */

  ngOnInit(): void {
    this.readDoctorId();
  }

  /* =======================================================
     ROUTE HANDLING
  ======================================================= */

  private readDoctorId(): void {
    const idParameter =
      this.activatedRoute.snapshot
        .paramMap
        .get('id');

    if (!idParameter) {
      this.errorMessage =
        'Doctor ID is missing from the URL.';

      return;
    }

    const parsedId =
      Number(idParameter);

    if (
      !Number.isInteger(parsedId) ||
      parsedId <= 0
    ) {
      this.errorMessage =
        'The doctor ID in the URL is invalid.';

      return;
    }

    this.doctorId = parsedId;

    this.loadDoctor();
  }

  /* =======================================================
     LOAD DOCTOR
  ======================================================= */

  loadDoctor(): void {
    if (
      this.isLoading ||
      this.doctorId === null
    ) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.doctorService
      .getDoctorById(
        this.doctorId
      )
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe({
        next: doctor => {
          this.doctor = doctor;
        },

        error: error => {
          console.error(
            'Unable to load doctor:',
            error
          );

          this.doctor = null;

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to load doctor information.'
            );
        }
      });
  }

  /* =======================================================
     NAVIGATION
  ======================================================= */

  editDoctor(): void {
    if (this.doctorId === null) {
      return;
    }

    void this.router.navigate([
      '/admin/doctors',
      this.doctorId,
      'edit'
    ]);
  }

  navigateBack(): void {
    void this.router.navigate([
      '/admin/doctors'
    ]);
  }

  /* =======================================================
     STATUS UPDATE
  ======================================================= */

  toggleDoctorStatus(): void {
    if (
      this.doctor === null ||
      this.isUpdatingStatus ||
      this.isDeleting
    ) {
      return;
    }

    const currentStatus =
      this.normalizeStatus(
        this.doctor.status
      );

    const newStatus: DoctorStatus =
      currentStatus === 'ACTIVE'
        ? 'INACTIVE'
        : 'ACTIVE';

    const doctorName =
      this.getDoctorName();

    const confirmed =
      window.confirm(
        `Change ${doctorName}'s status ` +
        `to ${newStatus}?`
      );

    if (!confirmed) {
      return;
    }

    this.isUpdatingStatus = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.doctorService
      .updateDoctorStatus(
        this.doctor.id,
        newStatus
      )
      .pipe(
        finalize(() => {
          this.isUpdatingStatus = false;
        })
      )
      .subscribe({
        next: success => {
          if (!success) {
            this.errorMessage =
              'Doctor status could not be updated.';

            return;
          }

          if (this.doctor !== null) {
            this.doctor = {
              ...this.doctor,
              status: newStatus
            };
          }

          this.successMessage =
            `${doctorName}'s status was changed ` +
            `to ${newStatus}.`;

          this.clearSuccessMessageLater();
        },

        error: error => {
          console.error(
            'Unable to update doctor status:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to update doctor status.'
            );
        }
      });
  }

  /* =======================================================
     DELETE DOCTOR
  ======================================================= */

  deleteDoctor(): void {
    if (
      this.doctor === null ||
      this.isDeleting ||
      this.isUpdatingStatus
    ) {
      return;
    }

    const doctorId =
      this.doctor.id;

    const doctorName =
      this.getDoctorName();

    const confirmed =
      window.confirm(
        'Are you sure you want to deactivate ' +
        `${doctorName}?`
      );

    if (!confirmed) {
      return;
    }

    this.isDeleting = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.doctorService
      .deleteDoctor(doctorId)
      .pipe(
        finalize(() => {
          this.isDeleting = false;
        })
      )
      .subscribe({
        next: success => {
          if (!success) {
            this.errorMessage =
              'Doctor could not be deactivated.';

            return;
          }

          this.successMessage =
            `${doctorName} was deactivated successfully.`;

          window.setTimeout(() => {
            void this.router.navigate([
              '/admin/doctors'
            ]);
          }, 800);
        },

        error: error => {
          console.error(
            'Unable to deactivate doctor:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Unable to deactivate the doctor.'
            );
        }
      });
  }

  /* =======================================================
     DOCTOR DISPLAY HELPERS
  ======================================================= */

  getDoctorName(): string {
    const doctorName =
      this.doctor?.name?.trim();

    if (doctorName) {
      return doctorName;
    }

    if (this.doctorId !== null) {
      return `Doctor ${this.doctorId}`;
    }

    return 'Doctor';
  }

  getDoctorInitials(): string {
    const doctorName =
      this.getDoctorName()
        .replace(/^dr\.?\s+/i, '');

    const initials =
      doctorName
        .split(/\s+/)
        .filter(
          word => word.length > 0
        )
        .slice(0, 2)
        .map(word =>
          word
            .charAt(0)
            .toUpperCase()
        )
        .join('');

    return initials || 'DR';
  }

  getFullAddress(): string {
    if (!this.doctor) {
      return 'Address not provided';
    }

    const addressParts = [
      this.doctor.address,
      this.doctor.city,
      this.doctor.state,
      this.doctor.pincode
    ]
      .map(value =>
        value?.trim()
      )
      .filter(
        (
          value
        ): value is string =>
          Boolean(value)
      );

    return addressParts.length > 0
      ? addressParts.join(', ')
      : 'Address not provided';
  }

  getExperienceLabel(): string {
    const experience =
      this.doctor?.experience;

    if (
      experience === null ||
      experience === undefined
    ) {
      return 'Not provided';
    }

    return experience === 1
      ? '1 year'
      : `${experience} years`;
  }

  getSpecialization(): string {
    return (
      this.doctor
        ?.specialization
        ?.trim() ||
      'Not specified'
    );
  }

  getLicenseNumber(): string {
    return (
      this.doctor
        ?.licenseNo
        ?.trim() ||
      'Not provided'
    );
  }

  getEmailAddress(): string {
    return (
      this.doctor
        ?.email
        ?.trim() ||
      'Not provided'
    );
  }

  getPhoneNumber(): string {
    return (
      this.doctor
        ?.phone
        ?.trim() ||
      'Not provided'
    );
  }

  /* =======================================================
     STATUS DISPLAY HELPERS
  ======================================================= */

  getStatusLabel(
    status: string | null | undefined
  ): string {
    return this.normalizeStatus(status) ===
      'INACTIVE'
        ? 'Inactive'
        : 'Active';
  }

  getStatusClass(
    status: string | null | undefined
  ): string {
    return this.normalizeStatus(status)
      .toLowerCase();
  }

  getStatusIcon(
    status: string | null | undefined
  ): string {
    return this.normalizeStatus(status) ===
      'ACTIVE'
        ? '✓'
        : '○';
  }

  getStatusDescription(
    status: string | null | undefined
  ): string {
    if (
      this.normalizeStatus(status) ===
      'ACTIVE'
    ) {
      return (
        'This doctor account is active and ' +
        'available in the Curonex system.'
      );
    }

    return (
      'This doctor account is inactive and ' +
      'is not available for regular operations.'
    );
  }

  getStatusActionLabel(): string {
    if (this.isUpdatingStatus) {
      return 'Updating...';
    }

    return this.normalizeStatus(
      this.doctor?.status
    ) === 'ACTIVE'
      ? 'Deactivate'
      : 'Activate';
  }

  private normalizeStatus(
    status: string | null | undefined
  ): DoctorStatus {
    const normalizedStatus =
      status
        ?.trim()
        .toUpperCase();

    return normalizedStatus ===
      'INACTIVE'
        ? 'INACTIVE'
        : 'ACTIVE';
  }

  /* =======================================================
     MESSAGE HANDLING
  ======================================================= */

  closeErrorMessage(): void {
    this.errorMessage = '';
  }

  closeSuccessMessage(): void {
    this.successMessage = '';
  }

  private clearSuccessMessageLater():
    void {
    window.setTimeout(() => {
      this.successMessage = '';
    }, 3500);
  }

  /* =======================================================
     ERROR HANDLING
  ======================================================= */

  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    const httpError =
      error as {
        status?: number;
        message?: string;
        error?:
          | {
              message?: string;
              error?: string;
            }
          | string;
      };

    if (httpError.status === 0) {
      return (
        'Unable to connect to the server. ' +
        'Verify that the API Gateway and ' +
        'User service are running.'
      );
    }

    if (httpError.status === 400) {
      return (
        this.extractBackendMessage(
          httpError.error
        ) ||
        'The doctor request is invalid.'
      );
    }

    if (httpError.status === 401) {
      return (
        'Your session has expired. ' +
        'Please log in again.'
      );
    }

    if (httpError.status === 403) {
      return (
        'You do not have permission to perform ' +
        'this doctor operation.'
      );
    }

    if (httpError.status === 404) {
      return (
        'The requested doctor was not found.'
      );
    }

    if (
      httpError.status !== undefined &&
      httpError.status >= 500
    ) {
      return (
        'The Doctor service is currently unavailable. ' +
        'Please try again later.'
      );
    }

    return (
      this.extractBackendMessage(
        httpError.error
      ) ||
      httpError.message ||
      fallbackMessage
    );
  }

  private extractBackendMessage(
    errorBody: unknown
  ): string {
    if (typeof errorBody === 'string') {
      return errorBody.trim();
    }

    if (
      errorBody &&
      typeof errorBody === 'object'
    ) {
      const responseBody =
        errorBody as {
          message?: unknown;
          error?: unknown;
        };

      if (
        typeof responseBody.message ===
        'string'
      ) {
        return responseBody
          .message
          .trim();
      }

      if (
        typeof responseBody.error ===
        'string'
      ) {
        return responseBody
          .error
          .trim();
      }
    }

    return '';
  }
}