/*
 * Supported Doctor statuses.
 */
export type DoctorStatus =
  | 'ACTIVE'
  | 'INACTIVE';

/*
 * Used by the Doctor List status filter.
 */
export type DoctorStatusFilter =
  | 'ALL'
  | DoctorStatus;

/*
 * Doctor response returned by:
 *
 * GET /api/doctors
 * GET /api/doctors/{id}
 *
 * The backend-generated ID is shared by:
 *
 * credentials.id
 * details.id
 * doctors.id
 */
export interface Doctor {
  id: number;

  /*
   * Doctor table fields.
   */
  licenseNo: string;
  experience: number;
  specialization: string;
  status: DoctorStatus | string;

  /*
   * Details table fields.
   */
  name: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  pincode: string | null;
  city: string | null;
  state: string | null;
}

/*
 * Request sent to:
 *
 * POST /api/doctors
 *
 * No ID is sent from Angular.
 *
 * Backend sequence:
 *
 * 1. Create Credentials using username and password.
 * 2. Obtain the generated Credentials ID.
 * 3. Create Details using the same ID.
 * 4. Create Doctor using the same ID.
 */
export interface CreateDoctorRequest {
  /*
   * Credentials table fields.
   */
  username: string;
  password: string;

  /*
   * Details table fields.
   */
  name: string;
  email: string;
  phone: string;
  address: string;
  pincode: string;
  city: string;
  state: string;

  /*
   * Doctor table fields.
   */
  licenseNo: string;
  experience: number;
  specialization: string;
  status: DoctorStatus;
}

/*
 * Request sent to:
 *
 * PUT /api/doctors
 *
 * The existing ID is read from the Angular edit route.
 * Username and password are not changed through the
 * regular Doctor update operation.
 */
export interface UpdateDoctorRequest {
  /*
   * Existing shared primary key.
   */
  id: number;

  /*
   * Details table fields.
   */
  name: string;
  email: string;
  phone: string;
  address: string;
  pincode: string;
  city: string;
  state: string;

  /*
   * Doctor table fields.
   */
  licenseNo: string;
  experience: number;
  specialization: string;
  status: DoctorStatus;
}

/*
 * Optional local model for status updates.
 *
 * Your current backend receives the status as
 * a URL path variable.
 */
export interface UpdateDoctorStatusRequest {
  status: DoctorStatus;
}