/*
 * The backend has NO hospital list/create/update/delete endpoint.
 * appointment-service's HospitalController only exposes:
 *   GET   /api/hospitals/{id}/icu
 *   PATCH /api/hospitals/{id}/icu
 * This model reflects exactly that -- nothing more.
 */

export interface IcuAvailability {
  hospitalId: number;
  licenseNo: string;
  totalIcuBeds: number;
  availableIcuBeds: number;
  occupiedIcuBeds: number;
  facilities: string;
}

export interface UpdateIcuAvailabilityRequest {
  totalIcuBeds: number;
  availableIcuBeds: number;
}
