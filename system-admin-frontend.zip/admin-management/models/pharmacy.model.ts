export type PharmacyStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED';
export type PharmacyStatusFilter = 'ALL' | PharmacyStatus;

/* GET /api/pharmacies, GET /api/pharmacies/{id}, GET /api/pharmacies/active */
export interface Pharmacy {
  id: number;
  licenseNo: string;
  geoAddress: string;
  status: PharmacyStatus | string;
  hospitalId: number | null;
}

/*
 * GET/PUT /api/pharmacies/{pharmacyId}/profile -- matches PharmacyProfileDTO
 * exactly (previously mismatched: backend returns pharmacyId, not id).
 */
export interface PharmacyDetails {
  pharmacyId: number;
  licenseNo: string;
  geoAddress: string;
  status: PharmacyStatus | string;
  hospitalId: number | null;
  name: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  pincode: string | null;
  city: string | null;
  state: string | null;
  rating?: number;
  ratingCount?: number;
}

/*
 * POST /api/pharmacies
 * NOTE: Pharmacy.id has no @GeneratedValue on the backend, so id must be
 * supplied (shared with the credentials/details id created elsewhere).
 */
export interface CreatePharmacyRequest {
  id: number;
  licenseNo: string;
  geoAddress: string;
  status: PharmacyStatus;
  hospitalId: number | null;
}

/* PUT /api/pharmacies/{id} */
export interface UpdatePharmacyRequest {
  licenseNo: string;
  geoAddress: string;
  status: PharmacyStatus;
  hospitalId: number | null;
}
