export type AmbulanceStatus =
  | 'AVAILABLE'
  | 'ON_TRIP'
  | 'MAINTENANCE';

export interface Ambulance {
  ambulanceId: number;
  vehicleNumber: string;
  licenseNo: string;
  hospitalId: number | null;
  status: AmbulanceStatus | string;
}

export interface CreateAmbulanceRequest {
  vehicleNumber: string;
  licenseNo: string;
  hospitalId?: number | null;
  status: AmbulanceStatus | string;
}

export interface UpdateAmbulanceRequest {
  vehicleNumber: string;
  licenseNo: string;
  hospitalId?: number | null;
  status: AmbulanceStatus | string;
}

export interface AmbulanceDetails {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string;
  pincode: string;
  city: string;
  state: string;
}

/*
 * Replace these optional fields with the exact fields
 * from your Spring HospitalResponseDto when available.
 */
export interface RecommendedHospital {
  id?: number;
  hospitalId?: number;
  name?: string;
  hospitalName?: string;
  address?: string;
  city?: string;
  state?: string;
  availableBeds?: number;
  distance?: number;
  specialization?: string;
  [key: string]: unknown;
}