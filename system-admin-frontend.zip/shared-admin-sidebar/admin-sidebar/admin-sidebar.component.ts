import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-admin-sidebar',
  standalone: true,
  imports: [
    RouterLink,
    RouterLinkActive
  ],
  templateUrl: './admin-sidebar.component.html',
  styleUrl: './admin-sidebar.component.css'
})
export class AdminSidebarComponent {

  dashboardIcon = 'icons/dashboard.png';
  systemDashboardIcon = 'icons/dashboard.png';
  createDoctorIcon = 'icons/icons8-plus-50.png';
  calendarIcon = 'icons/calendar.png';
  icuIcon = 'icons/icons8-hospital-bed-50.png';
  campIcon = 'icons/refugee-camp.png';
  resourceIcon = 'icons/diabetes.png';
  helpIcon = 'icons/customer-service.png';
  hospitalManagementIcon = 'icons/hospital.png';
  doctorManagementIcon = 'icons/doctor.png';
  pharmacyManagementIcon = 'icons/pharmacy.png';
  ambulanceManagementIcon = 'icons/ambulance.png';

}