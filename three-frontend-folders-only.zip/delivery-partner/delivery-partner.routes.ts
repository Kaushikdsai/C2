import { Routes } from '@angular/router';

import { DeliveryPartnerLayoutComponent } from './layout/delivery-partner-layout.component';
import { DashboardHomeComponent } from './pages/dashboard-home/dashboard-home.component';
import { AvailableOrdersComponent } from './pages/available-orders/available-orders.component';
import { ActiveDeliveriesComponent } from './pages/active-deliveries/active-deliveries.component';
import { DeliveryHistoryComponent } from './pages/delivery-history/delivery-history.component';
import { EarningsComponent } from './pages/earnings/earnings.component';
import { RatingsComponent } from './pages/ratings/ratings.component';

export const DELIVERY_PARTNER_ROUTES: Routes = [
  {
    path: '',
    component: DeliveryPartnerLayoutComponent,
    children: [
      { path: '', component: DashboardHomeComponent },
      { path: 'available', component: AvailableOrdersComponent },
      { path: 'active', component: ActiveDeliveriesComponent },
      { path: 'history', component: DeliveryHistoryComponent },
      { path: 'earnings', component: EarningsComponent },
      { path: 'ratings', component: RatingsComponent }
    ]
  }
];
