import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AvailableOrderDTO } from '../../../../core/models/available-order.model';

@Component({
  standalone: true,
  imports: [CommonModule],
  selector: 'app-order-card-available',
  templateUrl: './order-card-available.component.html',
  styleUrls: ['./order-card-available.component.scss']
})
export class OrderCardAvailableComponent {
  @Input({ required: true }) order!: AvailableOrderDTO;
  @Input() busy = false;

  @Output() accept = new EventEmitter<number>();
  @Output() reject = new EventEmitter<number>();
}
