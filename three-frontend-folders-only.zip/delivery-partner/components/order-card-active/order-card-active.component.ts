import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActiveDeliveryDTO } from '../../../../core/models/active-delivery.model';
import { OrderStatus } from '../../../../core/models/order-status.enum';

interface Step {
  label: string;
  done: boolean;
  current: boolean;
}

/** Emitted when the partner marks pickup done at one specific pharmacy stop. */
export interface PickupEvent {
  orderId: number;
  pharmacyId: number;
}

@Component({
  standalone: true,
  imports: [CommonModule],
  selector: 'app-order-card-active',
  templateUrl: './order-card-active.component.html',
  styleUrls: ['./order-card-active.component.scss']
})
export class OrderCardActiveComponent {
  @Input({ required: true }) order!: ActiveDeliveryDTO;
  @Input() busy = false;

  @Output() pickup = new EventEmitter<PickupEvent>();
  @Output() delivered = new EventEmitter<number>();
  @Output() cancel = new EventEmitter<number>();

  readonly OrderStatus = OrderStatus;

  /** True for a 2-pharmacy partial-fulfillment order (item 5/7) - drives whether the multi-stop route UI shows. */
  get isMultiStop(): boolean {
    return (this.order.pharmacyStops?.length ?? 0) > 1;
  }

  /** The next pharmacy stop the partner still needs to visit, or null once every stop is picked up. */
  get nextStop() {
    return (this.order.pharmacyStops ?? []).find(s => !s.pickedUp) ?? null;
  }

  get allStopsPickedUp(): boolean {
    return (this.order.pharmacyStops ?? []).length > 0 && this.nextStop === null;
  }

  get steps(): Step[] {
    const status = this.order.status;
    return [
      { label: 'Accepted', done: true, current: false },
      { label: this.isMultiStop ? 'All Picked Up' : 'Picked Up', done: status === OrderStatus.OUT_FOR_DELIVERY, current: status === OrderStatus.CONFIRMED },
      { label: 'Delivered', done: false, current: status === OrderStatus.OUT_FOR_DELIVERY }
    ];
  }

  get canCancel(): boolean {
    return this.order.status === OrderStatus.CONFIRMED;
  }

  /**
   * Before pickup (CONFIRMED): partner's current location -> the NEXT
   * pharmacy stop still needing pickup (not just "the" pharmacy - a
   * 2-pharmacy order has two different stops in sequence).
   * After pickup (OUT_FOR_DELIVERY): partner's current location -> patient.
   * Returns null if either endpoint's geo address isn't on file - the
   * button hides rather than open Maps with a blank/broken destination.
   */
  get directionsUrl(): string | null {
    const origin = this.order.partnerGeoAddress;
    const destination =
      this.order.status === OrderStatus.CONFIRMED
        ? (this.nextStop?.pharmacyGeoAddress ?? this.order.pharmacyGeoAddress)
        : this.order.patientGeoAddress;

    if (!origin || !destination) return null;

    return `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&travelmode=driving`;
  }

  get directionsLabel(): string {
    if (this.order.status === OrderStatus.CONFIRMED) {
      return this.isMultiStop && this.nextStop
        ? `Directions to Stop ${this.nextStop.sequenceNo} (${this.nextStop.pharmacyName || 'Pharmacy'})`
        : 'Directions to Pharmacy';
    }
    return 'Directions to Patient';
  }

  openDirections(): void {
    const url = this.directionsUrl;
    if (url) {
      window.open(url, '_blank', 'noopener');
    }
  }

  markStopPickedUp(pharmacyId: number): void {
    this.pickup.emit({ orderId: this.order.orderId, pharmacyId });
  }
}
