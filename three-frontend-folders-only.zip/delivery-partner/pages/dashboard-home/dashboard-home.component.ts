import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../../core/services/auth.service';
import { DeliveryPartnerService } from '../../../../core/services/delivery-partner.service';
import { ToastService } from '../../../../core/services/toast.service';
import { DeliveryPartnerDashboardDTO } from '../../../../core/models/delivery-partner-dashboard.model';
import { AvailableOrderDTO } from '../../../../core/models/available-order.model';
import { ActiveDeliveryDTO } from '../../../../core/models/active-delivery.model';

import { CommonModule } from '@angular/common';
import { OrderCardActiveComponent } from '../../components/order-card-active/order-card-active.component';
import { OrderCardAvailableComponent } from '../../components/order-card-available/order-card-available.component';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    OrderCardActiveComponent,
    OrderCardAvailableComponent
  ],
  selector: 'app-dashboard-home',
  templateUrl: './dashboard-home.component.html',
  styleUrls: ['./dashboard-home.component.scss']
})
export class DashboardHomeComponent implements OnInit {
  dashboard: DeliveryPartnerDashboardDTO | null = null;
  availablePreview: AvailableOrderDTO[] = [];
  activePreview: ActiveDeliveryDTO[] = [];
  online = true;
  loading = true;

  greeting = '';

  constructor(
    private auth: AuthService,
    private dpService: DeliveryPartnerService,
    private toast: ToastService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const hour = new Date().getHours();
    this.greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';

    const partnerId = this.auth.getDeliveryPartnerId() ?? 16;
    //const partnerId = 20;
    console.log("P"+partnerId);
    this.dpService.getDashboard(partnerId).subscribe({
      next: (d) => (this.dashboard = d),
      error: () => this.toast.show('Could not load dashboard stats.', 'error')
    });

    this.dpService.getAvailableOrders(partnerId).subscribe({
      next: (list) => (this.availablePreview = list.slice(0, 1)),
      complete: () => (this.loading = false)
    });

    this.dpService.getActiveDeliveries(partnerId).subscribe({
      next: (list) => (this.activePreview = list.slice(0, 1))
    });
  }

  toggleOnline(): void {
    const partnerId = 20;
    const action = this.online
      ? this.dpService.markOffline(partnerId)
      : this.dpService.markAvailable(partnerId);

    action.subscribe({
      next: () => {
        this.online = !this.online;
        this.toast.show(this.online ? 'You are now online.' : 'You are now offline.', 'info');
      },
      error: () => this.toast.show('Could not update availability.', 'error')
    });
  }

  goTo(route: string): void {
    this.router.navigate([`/delivery-partner/${route}`]);
  }

  quickPickup(event: { orderId: number; pharmacyId: number }): void {
    const partnerId = this.auth.getDeliveryPartnerId();
    this.dpService.pickupFromPharmacy(event.orderId, partnerId, event.pharmacyId).subscribe({
      next: () => {
        this.toast.show(`Order #${event.orderId} pickup recorded.`, 'success');
        this.ngOnInit();
      }
    });
  }

  quickDelivered(orderId: number): void {
    const partnerId = this.auth.getDeliveryPartnerId();
    this.dpService.markDelivered(orderId, partnerId).subscribe({
      next: () => {
        this.toast.show(`Order #${orderId} delivered successfully! 🎉`, 'success');
        this.ngOnInit();
      }
    });
  }

  quickCancel(orderId: number): void {
    if (!window.confirm('Cancel this delivery? It will go back to the available orders pool.')) return;
    const partnerId = this.auth.getDeliveryPartnerId();
    this.dpService.cancelDelivery(orderId, partnerId).subscribe({
      next: () => {
        this.toast.show(`Order #${orderId} released.`, 'info');
        this.ngOnInit();
      }
    });
  }

  quickAccept(orderId: number): void {
  const partnerId = this.auth.getDeliveryPartnerId();
  this.dpService.acceptDelivery(orderId, partnerId).subscribe({
    next: () => {
      this.toast.show(`Order #${orderId} accepted!`, 'success');
      this.ngOnInit(); // refresh the previews
    }
  });
}

quickReject(orderId: number): void {
  const partnerId = this.auth.getDeliveryPartnerId();
  this.dpService.rejectDelivery(orderId, partnerId).subscribe({
    next: () => {
      this.toast.show(`Order #${orderId} declined.`, 'info');
      this.ngOnInit();
    }
  });
}
}
