import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { DeliveryPartnerService } from '../../../../core/services/delivery-partner.service';
import { OrderResponseDTO } from '../../../../core/models/order.model';

import { CommonModule } from '@angular/common';

// Mirrors DeliveryPartnersServiceImpl.sumEarnings() — the platform commission
// rate isn't exposed via any endpoint, so this is hardcoded to match the
// backend's application.properties default (delivery.commission-rate=0.10).
// If that value changes server-side, update this constant to match.
const COMMISSION_RATE = 0.10;

interface HistoryRow {
  order: OrderResponseDTO;
  partnerEarning: number;
}

@Component({
  standalone: true,
  imports: [
    CommonModule
  ],
  selector: 'app-delivery-history',
  templateUrl: './delivery-history.component.html',
  styleUrls: ['./delivery-history.component.scss']
})
export class DeliveryHistoryComponent implements OnInit {
  rows: HistoryRow[] = [];
  loading = true;

  constructor(private auth: AuthService, private dpService: DeliveryPartnerService) {}

  ngOnInit(): void {
    this.dpService.getDeliveryHistory(this.auth.getDeliveryPartnerId()).subscribe({
      next: (orders) => {
        this.rows = orders.map(order => ({
          order,
          partnerEarning: (order.totalAmount ?? 0) * (1 - COMMISSION_RATE)
        }));
        this.loading = false;
      },
      error: () => (this.loading = false)
    });
  }
}
