import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { DeliveryPartnerService } from '../../../../core/services/delivery-partner.service';
import { DeliveryPartnerDashboardDTO } from '../../../../core/models/delivery-partner-dashboard.model';

import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  imports: [
    CommonModule
  ],
  selector: 'app-earnings',
  templateUrl: './earnings.component.html',
  styleUrls: ['./earnings.component.scss']
})
export class EarningsComponent implements OnInit {
  dashboard: DeliveryPartnerDashboardDTO | null = null;
  loading = true;

  constructor(private auth: AuthService, private dpService: DeliveryPartnerService) {}

  ngOnInit(): void {
    this.dpService.getDashboard(this.auth.getDeliveryPartnerId()).subscribe({
      next: (d) => {
        this.dashboard = d;
        this.loading = false;
      },
      error: () => (this.loading = false)
    });
  }
}
