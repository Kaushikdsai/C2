import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { DeliveryPartnerService } from '../../../../core/services/delivery-partner.service';
import { ToastService } from '../../../../core/services/toast.service';
import { ActiveDeliveryDTO } from '../../../../core/models/active-delivery.model';

import { CommonModule } from '@angular/common';
import { OrderCardActiveComponent } from '../../components/order-card-active/order-card-active.component';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    OrderCardActiveComponent
  ],
  selector: 'app-active-deliveries',
  templateUrl: './active-deliveries.component.html',
  styleUrls: ['./active-deliveries.component.scss']
})
export class ActiveDeliveriesComponent implements OnInit {
  orders: ActiveDeliveryDTO[] = [];
  loading = true;
  busyOrderId: number | null = null;

  constructor(
    private auth: AuthService,
    private dpService: DeliveryPartnerService,
    private toast: ToastService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.loading = true;
    this.dpService.getActiveDeliveries(this.auth.getDeliveryPartnerId()).subscribe({
      next: (orders) => {
        this.orders = orders;
        this.loading = false;
      },
      error: () => (this.loading = false)
    });
  }

  pickup(event: { orderId: number; pharmacyId: number }): void {
    this.busyOrderId = event.orderId;
    this.dpService.pickupFromPharmacy(event.orderId, this.auth.getDeliveryPartnerId(), event.pharmacyId).subscribe({
      next: () => {
        this.toast.show(`Order #${event.orderId} pickup recorded.`, 'success');
        this.load();
        this.busyOrderId = null;
      },
      error: () => (this.busyOrderId = null)
    });
  }

  delivered(orderId: number): void {
    this.busyOrderId = orderId;
    this.dpService.markDelivered(orderId, this.auth.getDeliveryPartnerId()).subscribe({
      next: () => {
        this.toast.show(`Order #${orderId} delivered successfully! 🎉`, 'success');
        this.load();
        this.busyOrderId = null;
      },
      error: () => (this.busyOrderId = null)
    });
  }

  cancel(orderId: number): void {
    if (!window.confirm('Cancel this delivery? It will go back to the available orders pool.')) return;
    this.busyOrderId = orderId;
    this.dpService.cancelDelivery(orderId, this.auth.getDeliveryPartnerId()).subscribe({
      next: () => {
        this.toast.show(`Order #${orderId} released.`, 'info');
        this.load();
        this.busyOrderId = null;
      },
      error: () => (this.busyOrderId = null)
    });
  }
}
