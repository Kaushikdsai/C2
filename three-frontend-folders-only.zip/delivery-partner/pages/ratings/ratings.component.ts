import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { DeliveryPartnerService } from '../../../../core/services/delivery-partner.service';
import { DeliveryPartnerProfileDTO } from '../../../../core/models/delivery-partner-profile.model';
import { OrderFeedbackResponseDTO } from '../../../../core/models/order-feedback.model';

import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  imports: [
    CommonModule
  ],
  selector: 'app-ratings',
  templateUrl: './ratings.component.html',
  styleUrls: ['./ratings.component.scss']
})
export class RatingsComponent implements OnInit {
  stars = [1, 2, 3, 4, 5];

  profile: DeliveryPartnerProfileDTO | null = null;
  loading = true;

  /**
   * Individual reviews - each row's deliveryRating is exactly what fed
   * into profile.rating (the real running average, computed in
   * DeliveryPartnersServiceImpl#submitRating), never a separate/mock
   * number. This list and the aggregate above are guaranteed consistent
   * because they're both derived from the same submitRating() call chain.
   */
  feedback: OrderFeedbackResponseDTO[] = [];
  feedbackLoading = true;

  constructor(private auth: AuthService, private dpService: DeliveryPartnerService) {}

  ngOnInit(): void {
    const partnerId = this.auth.getDeliveryPartnerId();

    this.dpService.getProfile(partnerId).subscribe({
      next: (p) => {
        this.profile = p;
        this.loading = false;
      },
      error: () => (this.loading = false)
    });

    this.dpService.getFeedback(partnerId).subscribe({
      next: (rows) => {
        this.feedback = rows;
        this.feedbackLoading = false;
      },
      error: () => (this.feedbackLoading = false)
    });
  }

  get filledStars(): number[] {
    return Array(Math.round(this.profile?.rating ?? 0)).fill(0);
  }

  get emptyStars(): number[] {
    return Array(5 - Math.round(this.profile?.rating ?? 0)).fill(0);
  }

  ratingStars(rating: number | null): number {
    return Math.round(rating ?? 0);
  }
}
