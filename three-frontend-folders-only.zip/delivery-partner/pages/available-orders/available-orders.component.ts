import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { DeliveryPartnerService } from '../../../../core/services/delivery-partner.service';
import { ToastService } from '../../../../core/services/toast.service';
import { AvailableOrderDTO } from '../../../../core/models/available-order.model';

import { CommonModule } from '@angular/common';
import { OrderCardAvailableComponent } from '../../components/order-card-available/order-card-available.component';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    OrderCardAvailableComponent
  ],
  selector: 'app-available-orders',
  templateUrl: './available-orders.component.html',
  styleUrls: ['./available-orders.component.scss']
})
export class AvailableOrdersComponent implements OnInit {
  orders: AvailableOrderDTO[] = [];
  loading = true;
  busyOrderId: number | null = null;

  constructor(
    private auth: AuthService,
    private dpService: DeliveryPartnerService,
    private toast: ToastService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.loading = true;
    this.dpService.getAvailableOrders(this.auth.getDeliveryPartnerId()).subscribe({
      next: (orders) => {
        this.orders = orders;
        this.loading = false;
      },
      error: () => (this.loading = false)
    });
  }

  accept(orderId: number): void {
    this.busyOrderId = orderId;
    const partnerId = this.auth.getDeliveryPartnerId();
    this.dpService.acceptDelivery(orderId, partnerId).subscribe({
      next: () => {
        this.toast.show(`Order #${orderId} accepted! Head to the pharmacy for pickup.`, 'success');
        this.load();
        this.busyOrderId = null;
      },
      error: () => (this.busyOrderId = null)
    });
  }

  reject(orderId: number): void {
    this.busyOrderId = orderId;
    const partnerId = this.auth.getDeliveryPartnerId();
    this.dpService.rejectDelivery(orderId, partnerId).subscribe({
      next: () => {
        this.toast.show(`Order #${orderId} declined.`, 'info');
        this.load();
        this.busyOrderId = null;
      },
      error: () => (this.busyOrderId = null)
    });
  }
}
