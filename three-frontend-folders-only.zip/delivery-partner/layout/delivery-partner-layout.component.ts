import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { ClickOutsideDirective } from '../../../shared/directives/click-outside.directive';

interface NavEntry {
  label: string;
  icon: string;
  route: string;
}

@Component({
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, ClickOutsideDirective],
  selector: 'app-delivery-partner-layout',
  templateUrl: './delivery-partner-layout.component.html',
  styleUrls: ['./delivery-partner-layout.component.scss']
})
export class DeliveryPartnerLayoutComponent {
  userMenuOpen = false;

  navItems: NavEntry[] = [
    { label: 'Dashboard', icon: '🏠', route: '/delivery-partner' },
    { label: 'Available Orders', icon: '📦', route: '/delivery-partner/available' },
    { label: 'Active Deliveries', icon: '🛵', route: '/delivery-partner/active' },
    { label: 'Delivery History', icon: '📋', route: '/delivery-partner/history' },
    { label: 'Earnings', icon: '💰', route: '/delivery-partner/earnings' },
    { label: 'Ratings', icon: '⭐', route: '/delivery-partner/ratings' }
  ];

  constructor(private auth: AuthService, private toast: ToastService) {}

  toggleUserMenu(): void {
    this.userMenuOpen = !this.userMenuOpen;
  }

  logout(): void {
    this.auth.logout();
    this.toast.show('Logged out', 'info');
  }
}
