import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { OrderService } from '../../../../core/services/order.service';
import { OrderResponseDTO } from '../../../../core/models/order.model';

import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { PatientSidebarComponent } from '../../../../shared/components/patient-sidebar/patient-sidebar.component';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    PatientSidebarComponent
  ],
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.scss']
})
export class OrderHistoryComponent implements OnInit {
  orders: OrderResponseDTO[] = [];
  loading = true;
  loadFailed = false;

  constructor(private orderService: OrderService, private auth: AuthService) {}

  ngOnInit(): void {
    const userId = this.auth.getUserId();
    this.orderService.getOrdersByUser(userId).subscribe({
      next: (orders) => {
        this.orders = orders;
        this.loading = false;
      },
      error: () => {
        this.loadFailed = true;
        this.loading = false;
      }
    });
  }

  medicinesSummary(order: OrderResponseDTO): string {
    return order.items.map(i => i.medicineName).join(', ');
  }

  statusLabel(status: string): string {
    return status.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  }
}
