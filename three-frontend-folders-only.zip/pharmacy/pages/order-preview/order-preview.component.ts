import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { finalize } from 'rxjs';
import { ToastService } from '../../../../core/services/toast.service';
import { AuthService } from '../../../../core/services/auth.service';
import { PrescriptionService, PatientInfo } from '../../../../core/services/prescription.service';
import { OrderService } from '../../../../core/services/order.service';
import { SideCard } from '../../../../core/models/side-card.model';
import { OrderCreateItemDTO } from '../../../../core/models/order.model';
import { PrescriptionMedicinesDTO } from '../../../../core/models/prescription.model';
import { PharmacyOrderStateService } from '../../services/pharmacy-order-state.service';
import { PreviewMedicine } from '../../models/medicine.model';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { PatientSidebarComponent } from '../../../../shared/components/patient-sidebar/patient-sidebar.component';
import { SidebarRightComponent } from '../../../../shared/components/sidebar-right/sidebar-right.component';

const RELATIONSHIP_OPTIONS = ['Self', 'Mother', 'Father', 'Spouse', 'Child', 'Other'];

@Component({
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HeaderComponent,
    PatientSidebarComponent,
    SidebarRightComponent
  ],
  selector: 'app-order-preview',
  templateUrl: './order-preview.component.html',
  styleUrls: ['./order-preview.component.scss']
})
export class OrderPreviewComponent implements OnInit {
  private readonly DEFAULT_PATIENT_GEO_ADDRESS = '12.9550,77.6300';

  relationshipOptions = RELATIONSHIP_OPTIONS;

  // Patient details (item 2 - "order for someone else"). isSelf just
  // toggles whether patientUserId is set to the logged-in user - name/
  // phone/age/relationship are always typed explicitly, since there's no
  // profile-lookup endpoint on the frontend yet to auto-fill them even for
  // "Self". Editable until the prescription is created, and again
  // afterwards (via a PUT) right up until the order itself is placed.
  isSelf = true;
  patientName = '';
  patientAge: number | null = null;
  patientPhone = '';
  patientRelationship = 'Self';
  editingPatient = true;
  savingPatient = false;
  patientConfirmed = false;

  deliveryNote = '';

  medicines: PreviewMedicine[] = [];
  medicinesLoading = false;
  orderProcessing = false;

  rightSideCards: SideCard[] = [
    {
      title: 'Order History',
      sub: 'View your past orders',
      route: '/pharmacy/order-history',
      iconSvg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
    }
  ];

  constructor(
    private toast: ToastService,
    private router: Router,
    private location: Location,
    private auth: AuthService,
    private prescriptionService: PrescriptionService,
    private orderService: OrderService,
    private orderState: PharmacyOrderStateService
  ) {}

  ngOnInit(): void {
    if (!this.orderState.extractedMedicines || this.orderState.extractedMedicines.length === 0) {
      this.toast.show('No prescription found. Please upload one first.', 'error');
      this.router.navigate(['/pharmacy']);
      return;
    }
    this.captureGeoAddress();
  }

  onIsSelfChange(): void {
    this.patientRelationship = this.isSelf ? 'Self' : (this.patientRelationship === 'Self' ? 'Other' : this.patientRelationship);
  }

  private thumbClassFor(index: number): string {
    const classes = ['thumb-paracetamol', 'thumb-cetirizine', 'thumb-azithromycin', 'thumb-omeprazole'];
    return classes[index % classes.length];
  }

  private captureGeoAddress(): void {
    this.orderState.patientGeoAddress = this.DEFAULT_PATIENT_GEO_ADDRESS;
    if (!navigator.geolocation) {
      this.toast.show('Location not supported. Using default location.', 'info');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        this.orderState.patientGeoAddress = `${position.coords.latitude},${position.coords.longitude}`;
      },
      () => {
        this.orderState.patientGeoAddress = this.DEFAULT_PATIENT_GEO_ADDRESS;
        this.toast.show('Location access denied. Using default location.', 'info');
      }
    );
  }

  get medicineCount(): number {
    return this.medicines.length;
  }

  goBack(): void {
    this.location.back();
  }

  private currentPatientInfo(): PatientInfo {
    return {
      patientUserId: this.isSelf ? this.auth.getUserId() : null,
      patientName: this.patientName.trim(),
      patientAge: this.patientAge,
      patientPhone: this.patientPhone.trim(),
      patientRelationship: this.patientRelationship
    };
  }

  private validatePatientInfo(): boolean {
    if (!this.patientName.trim() || !this.patientPhone.trim()) {
      this.toast.show('Patient name and phone number are required.', 'error');
      return false;
    }
    return true;
  }

  /**
   * First save: creates the prescription (header + every extracted
   * medicine, each with its prescribedQuantity ceiling locked in) and
   * loads the real, backend-tracked medicine rows. Everything after this
   * point (quantity +/-, remove/restore) talks to the backend directly -
   * nothing is edited only in memory anymore.
   */
  confirmPatientAndLoadMedicines(): void {
    if (!this.validatePatientInfo() || this.savingPatient) return;

    this.savingPatient = true;
    const userId = this.auth.getUserId();

    this.prescriptionService
      .createFullPrescription(
        userId,
        this.orderState.hospitalId,
        this.orderState.doctorId,
        this.currentPatientInfo(),
        this.orderState.extractedMedicines
      )
      .pipe(finalize(() => (this.savingPatient = false)))
      .subscribe({
        next: (prescription) => {
          this.orderState.prescriptionId = prescription.prescriptionId;
          this.patientConfirmed = true;
          this.editingPatient = false;
          this.loadMedicines();
        }
      });
  }

  /** Edits patient details on the ALREADY-created prescription (still before the order is placed). */
  savePatientEdit(): void {
    if (!this.validatePatientInfo() || this.savingPatient || !this.orderState.prescriptionId) return;

    this.savingPatient = true;
    this.prescriptionService
      .updatePrescriptionHeader(
        this.orderState.prescriptionId,
        this.auth.getUserId(),
        this.orderState.hospitalId,
        this.orderState.doctorId,
        this.currentPatientInfo()
      )
      .pipe(finalize(() => (this.savingPatient = false)))
      .subscribe({
        next: () => {
          this.editingPatient = false;
          this.toast.show('Patient details updated.', 'success');
        }
      });
  }

  toggleEditPatient(): void {
    if (!this.patientConfirmed) {
      // Not created yet - "Edit" just means "keep filling the form in".
      return;
    }
    if (this.editingPatient) {
      this.savePatientEdit();
    } else {
      this.editingPatient = true;
    }
  }

  private loadMedicines(): void {
    if (!this.orderState.prescriptionId) return;
    this.medicinesLoading = true;
    this.prescriptionService.getMedicinesByPrescription(this.orderState.prescriptionId)
      .pipe(finalize(() => (this.medicinesLoading = false)))
      .subscribe({
        next: (rows) => {
          this.medicines = rows.map((row, index) => this.toPreviewMedicine(row, index));
        }
      });
  }

  private toPreviewMedicine(row: PrescriptionMedicinesDTO, index: number): PreviewMedicine {
    return {
      id: `m${index}`,
      name: row.medicineName,
      sub: '',
      thumbLabel: row.medicineName.split(' ')[0].toUpperCase().slice(0, 8),
      thumbClass: this.thumbClassFor(index),
      prescribedQuantity: row.prescribedQuantity,
      quantity: row.selectedQuantity,
      removed: row.selectedQuantity === 0,
      saving: false
    };
  }

  /**
   * Real fix for "can't increase quantity back up": this calls the
   * backend, which enforces 0 <= selectedQuantity <= prescribedQuantity
   * server-side. Previously this only ever showed a fixed error message
   * with no backend call at all - now an increase genuinely succeeds up to
   * the actual prescribed ceiling, and only fails (with the backend's real
   * reason) once that ceiling is hit.
   */
  private setQuantity(med: PreviewMedicine, newQuantity: number): void {
    if (!this.orderState.prescriptionId || med.saving) return;
    const clamped = Math.max(0, newQuantity);

    med.saving = true;
    this.prescriptionService.updateMedicineQuantity(this.orderState.prescriptionId, med.name, clamped)
      .pipe(finalize(() => (med.saving = false)))
      .subscribe({
        next: (updated) => {
          med.quantity = updated.selectedQuantity;
          med.removed = updated.selectedQuantity === 0;
        }
        // On error (e.g. would exceed prescribedQuantity), the global HTTP
        // interceptor / toast service surfaces the backend's real message -
        // med.quantity is deliberately left untouched since the change did
        // not actually happen.
      });
  }

  decreaseQty(med: PreviewMedicine): void {
    this.setQuantity(med, med.quantity - 1);
  }

  increaseQty(med: PreviewMedicine): void {
    if (med.quantity >= med.prescribedQuantity) {
      this.toast.show(`Cannot exceed the prescribed amount (${med.prescribedQuantity}) for ${med.name}.`, 'error');
      return;
    }
    this.setQuantity(med, med.quantity + 1);
  }

  toggleRemove(med: PreviewMedicine): void {
    if (med.removed) {
      // Restore to the full prescribed amount - a reasonable default; the
      // patient can immediately decrease again if they only meant to undo
      // the removal partially.
      this.setQuantity(med, med.prescribedQuantity);
    } else {
      this.setQuantity(med, 0);
    }
  }

  confirmOrder(): void {
    if (this.orderProcessing || !this.orderState.prescriptionId) return;

    const validMedicines = this.medicines.filter(m => !m.removed && m.quantity > 0);
    if (validMedicines.length === 0) {
      this.toast.show('At least one medicine with quantity greater than 0 is required.', 'error');
      return;
    }
    if (!this.orderState.patientGeoAddress) {
      this.toast.show('Your location is required before placing the order.', 'error');
      return;
    }

    const proceed = window.confirm(
      `Confirm order with ${validMedicines.length} medicine${validMedicines.length > 1 ? 's' : ''}?`
    );
    if (!proceed) return;

    this.orderProcessing = true;
    const items: OrderCreateItemDTO[] = validMedicines.map(m => ({
      medicineName: m.name,
      quantity: m.quantity
    }));

    this.orderService
      .createOrder({
        userId: this.auth.getUserId(),
        prescriptionId: this.orderState.prescriptionId,
        patientGeoAddress: this.orderState.patientGeoAddress as string,
        items,
        deliveryNote: this.deliveryNote.trim() || null
      })
      .pipe(finalize(() => (this.orderProcessing = false)))
      .subscribe({
        next: (order) => {
          this.orderState.orderId = order.orderId;
          this.toast.show(
            `Order confirmed successfully (${validMedicines.length} medicine${validMedicines.length > 1 ? 's' : ''}).`,
            'success'
          );
          this.router.navigate(['/pharmacy/delivery']);
        }
      });
  }

  cancelOrder(): void {
    if (this.orderProcessing) return;
    if (!window.confirm('Are you sure you want to cancel this order?')) return;

    this.orderState.reset();
    this.toast.show('Order cancelled.', 'error');
    this.router.navigate(['/pharmacy']);
  }
}
