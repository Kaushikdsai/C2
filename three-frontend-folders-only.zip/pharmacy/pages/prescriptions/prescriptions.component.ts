import { Component, OnInit } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from '../../../../core/services/auth.service';
import { PrescriptionService } from '../../../../core/services/prescription.service';
import { PrescriptionMedicinesDTO, PrescriptionsDTO } from '../../../../core/models/prescription.model';

import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { PatientSidebarComponent } from '../../../../shared/components/patient-sidebar/patient-sidebar.component';

interface PrescriptionGroup {
  prescription: PrescriptionsDTO;
  medicines: PrescriptionMedicinesDTO[];
}

@Component({
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    PatientSidebarComponent
  ],
  selector: 'app-prescriptions',
  templateUrl: './prescriptions.component.html',
  styleUrls: ['./prescriptions.component.scss']
})
export class PrescriptionsComponent implements OnInit {
  groups: PrescriptionGroup[] = [];
  loading = true;
  loadFailed = false;

  constructor(private prescriptionService: PrescriptionService, private auth: AuthService) {}

  ngOnInit(): void {
    const userId = this.auth.getUserId();

    this.prescriptionService.getPrescriptionsByUser(userId).subscribe({
      next: (prescriptions) => {
        if (prescriptions.length === 0) {
          this.loading = false;
          return;
        }

        const medicineCalls = prescriptions.map(p =>
          this.prescriptionService.getMedicinesByPrescription(p.prescriptionId as number).pipe(
            catchError(() => of([] as PrescriptionMedicinesDTO[]))
          )
        );

        forkJoin(medicineCalls).subscribe(medicineLists => {
          this.groups = prescriptions.map((prescription, i) => ({
            prescription,
            medicines: medicineLists[i]
          }));
          this.loading = false;
        });
      },
      error: () => {
        this.loadFailed = true;
        this.loading = false;
      }
    });
  }
}
