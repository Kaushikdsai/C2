import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ToastService } from '../../../../core/services/toast.service';
import { OrderService } from '../../../../core/services/order.service';
import { OrderFeedbackService } from '../../../../core/services/order-feedback.service';
import { SideCard } from '../../../../core/models/side-card.model';
import { OrderStatus } from '../../../../core/models/order-status.enum';
import { OrderTrackingDTO } from '../../../../core/models/order.model';
import { PharmacyOrderStateService } from '../../services/pharmacy-order-state.service';

import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { PatientSidebarComponent } from '../../../../shared/components/patient-sidebar/patient-sidebar.component';
import { SidebarRightComponent } from '../../../../shared/components/sidebar-right/sidebar-right.component';

interface TrackStep {
  label: string;
  time: string;
  done: boolean;
  current: boolean;
}

const STEP_LABELS = [
  'Searching for Pharmacy',
  'Pharmacy Assigned',
  'Delivery Partner Assigned',
  'Picked Up & Out for Delivery',
  'Delivered'
];

const POLL_INTERVAL_MS = 15000;
/** Countdown ticks every second so "time left" genuinely feels live, not just re-synced every poll. */
const COUNTDOWN_TICK_MS = 1000;

@Component({
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HeaderComponent,
    PatientSidebarComponent,
    SidebarRightComponent
  ],
  selector: 'app-delivery-tracking',
  templateUrl: './delivery-tracking.component.html',
  styleUrls: ['./delivery-tracking.component.scss']
})
export class DeliveryTrackingComponent implements OnInit, OnDestroy {
  stars = [1, 2, 3, 4, 5];

  private pollHandle?: ReturnType<typeof setInterval>;
  private countdownHandle?: ReturnType<typeof setInterval>;
  private previousStepIndex = -1;

  loading = true;
  cancelled = false;
  delivered = false;
  fulfillmentFailed = false;
  paymentWindowExpired = false;
  rebroadcastNotice = false;

  orderPlacedAt = '';

  steps: TrackStep[] = STEP_LABELS.map(label => ({ label, time: '---', done: false, current: false }));

  partnerName = '';
  partnerPhone = '';
  pharmacyName = '';

  orderId: number | null = null;
  itemCount = 0;
  totalAmount: number | null = null;
  estimatedDeliveryMinutes: number | null = null;
  deliveryNote: string | null = null;

  // Item 11: price acceptance window.
  awaitingPriceAcceptance = false;
  priceConfirmationDeadline: string | null = null;
  /** "4:37" style, recomputed every second while awaitingPriceAcceptance is true. */
  timeRemainingText = '';
  acceptingPrice = false;

  // Item 3: single combined feedback page, shown once the order is DELIVERED.
  feedbackChecked = false;
  feedbackAlreadySubmitted = false;
  feedbackSubmitting = false;
  pharmacyRating = 0;
  pharmacyFeedbackText = '';
  deliveryRating = 0;
  deliveryFeedbackText = '';

  rightSideCards: SideCard[] = [
    {
      title: 'Order History',
      sub: 'View your past orders',
      route: '/pharmacy/order-history',
      iconSvg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
    },
    {
      title: 'Report an Issue',
      sub: 'Something wrong with this order?',
      route: '/pharmacy/report-issue',
      iconSvg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="13"/><circle cx="12" cy="16" r="0.5" fill="currentColor"/></svg>'
    }
  ];

  constructor(
    private toast: ToastService,
    private router: Router,
    private orderService: OrderService,
    private orderFeedbackService: OrderFeedbackService,
    private orderState: PharmacyOrderStateService
  ) {}

  ngOnInit(): void {
    this.orderId = this.orderState.orderId ?? 1;
    this.fetchTracking();
    this.pollHandle = setInterval(() => this.fetchTracking(), POLL_INTERVAL_MS);
    this.countdownHandle = setInterval(() => this.tickCountdown(), COUNTDOWN_TICK_MS);
  }

  ngOnDestroy(): void {
    if (this.pollHandle) clearInterval(this.pollHandle);
    if (this.countdownHandle) clearInterval(this.countdownHandle);
  }

  private fetchTracking(): void {
    if (!this.orderId) return;

    this.orderService.getOrderTracking(this.orderId).subscribe({
      next: (tracking) => {
        this.loading = false;
        this.applyTracking(tracking);
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  /** Returns -1..4, or -1 if cancelled/failed/expired (terminal, not a step). PHARMACY_CONFIRMED sits at the same visual point as "Pharmacy Assigned" - the dedicated price-acceptance card above the tracker is what actually calls out that state. */
  private computeStepIndex(tracking: OrderTrackingDTO): number {
    switch (tracking.status) {
      case OrderStatus.CANCELLED:
      case OrderStatus.FULFILLMENT_FAILED:
      case OrderStatus.PAYMENT_WINDOW_EXPIRED:
        return -1;
      case OrderStatus.PENDING:
      case OrderStatus.PARTIALLY_ALLOCATED:
        return 0;
      case OrderStatus.PHARMACY_CONFIRMED:
        return 1;
      case OrderStatus.CONFIRMED:
        return tracking.deliveryPartnerId != null ? 2 : 1;
      case OrderStatus.OUT_FOR_DELIVERY:
        return 3;
      case OrderStatus.DELIVERED:
        return 4;
      default:
        return 0;
    }
  }

  private applyTracking(tracking: OrderTrackingDTO): void {
    this.orderPlacedAt = tracking.orderDatetime
      ? new Date(tracking.orderDatetime).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })
      : '';
    this.itemCount = tracking.itemCount ?? 0;
    this.totalAmount = tracking.totalAmount ?? null;
    this.pharmacyName = tracking.pharmacyName ?? '';
    this.partnerName = tracking.deliveryPartnerName ?? '';
    this.partnerPhone = tracking.deliveryPartnerPhone ?? '';
    this.estimatedDeliveryMinutes = tracking.estimatedDeliveryMinutes ?? null;
    this.deliveryNote = tracking.deliveryNote ?? null;

    if (tracking.status === OrderStatus.CANCELLED) {
      this.cancelled = true;
      this.stopAllTimers();
      return;
    }
    if (tracking.status === OrderStatus.FULFILLMENT_FAILED) {
      this.fulfillmentFailed = true;
      this.stopAllTimers();
      return;
    }
    if (tracking.status === OrderStatus.PAYMENT_WINDOW_EXPIRED) {
      this.paymentWindowExpired = true;
      this.stopAllTimers();
      return;
    }

    // Item 11: price acceptance window.
    this.awaitingPriceAcceptance = tracking.status === OrderStatus.PHARMACY_CONFIRMED;
    this.priceConfirmationDeadline = tracking.priceConfirmationDeadline ?? null;
    if (this.awaitingPriceAcceptance) {
      this.tickCountdown();
    }

    const stepIndex = this.computeStepIndex(tracking);

    if (stepIndex === 0 && this.previousStepIndex > 0) {
      this.rebroadcastNotice = true;
      this.toast.show('Order was declined by the pharmacy — searching for a new one.', 'info');
    } else if (stepIndex > 0) {
      this.rebroadcastNotice = false;
    }

    this.steps.forEach((step, i) => {
      step.done = i < stepIndex || (i === 4 && stepIndex === 4);
      step.current = i === stepIndex && stepIndex < 4;
      if (step.done && step.time === '---') {
        step.time = this.timestampFor(i, tracking);
      }
      if (!step.done && i > stepIndex) {
        step.time = '---';
      }
    });

    this.previousStepIndex = stepIndex;

    const wasDelivered = this.delivered;
    this.delivered = tracking.status === OrderStatus.DELIVERED;
    if (this.delivered && !wasDelivered) {
      this.toast.show('Your order has been delivered!', 'success');
      this.stopAllTimers();
    }
    if (this.delivered && !this.feedbackChecked) {
      this.checkExistingFeedback();
    }
  }

  /** Avoids re-showing the feedback form if this order was already rated in a previous visit to this page. */
  private checkExistingFeedback(): void {
    if (!this.orderId) return;
    this.feedbackChecked = true;
    this.orderFeedbackService.getFeedbackForOrder(this.orderId).subscribe({
      next: () => (this.feedbackAlreadySubmitted = true),
      error: () => (this.feedbackAlreadySubmitted = false)
    });
  }

  setPharmacyRating(value: number): void {
    this.pharmacyRating = value;
  }

  setDeliveryRating(value: number): void {
    this.deliveryRating = value;
  }

  submitFeedback(): void {
    if (!this.orderId || this.feedbackSubmitting) return;
    if (this.pharmacyRating === 0 || this.deliveryRating === 0) {
      this.toast.show('Please rate both the pharmacy and the delivery partner.', 'error');
      return;
    }

    this.feedbackSubmitting = true;
    this.orderFeedbackService.submitFeedback(this.orderId, {
      pharmacyRating: this.pharmacyRating,
      pharmacyFeedback: this.pharmacyFeedbackText.trim() || null,
      deliveryRating: this.deliveryRating,
      deliveryFeedback: this.deliveryFeedbackText.trim() || null
    }).subscribe({
      next: () => {
        this.feedbackSubmitting = false;
        this.feedbackAlreadySubmitted = true;
        this.toast.show('Thanks for your feedback!', 'success');
      },
      error: () => {
        this.feedbackSubmitting = false;
      }
    });
  }

  /** Recomputes timeRemainingText from priceConfirmationDeadline every second - this is what makes "time left" feel live rather than only updating once per 15s poll. */
  private tickCountdown(): void {
    if (!this.awaitingPriceAcceptance || !this.priceConfirmationDeadline) {
      this.timeRemainingText = '';
      return;
    }
    const deadlineMs = new Date(this.priceConfirmationDeadline).getTime();
    const remainingMs = deadlineMs - Date.now();

    if (remainingMs <= 0) {
      this.timeRemainingText = '0:00';
      // Don't flip to "expired" purely from the client clock - wait for
      // the next poll to confirm the backend has actually moved the order
      // to PAYMENT_WINDOW_EXPIRED, so a slightly-off client clock can never
      // show "expired" for an order the backend still considers open.
      return;
    }

    const totalSeconds = Math.floor(remainingMs / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    this.timeRemainingText = `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  acceptPrice(): void {
    if (!this.orderId || this.acceptingPrice) return;
    this.acceptingPrice = true;

    this.orderService.acceptPrice(this.orderId).subscribe({
      next: () => {
        this.acceptingPrice = false;
        this.toast.show('Price accepted — looking for a delivery partner.', 'success');
        this.fetchTracking();
      },
      error: () => {
        this.acceptingPrice = false;
        // Backend's real reason (e.g. window already expired) surfaces via the toast interceptor - re-fetch either way so the UI reflects the actual current state.
        this.fetchTracking();
      }
    });
  }

  private stopAllTimers(): void {
    if (this.pollHandle) clearInterval(this.pollHandle);
    if (this.countdownHandle) clearInterval(this.countdownHandle);
  }

  private timestampFor(stepIndex: number, tracking: OrderTrackingDTO): string {
    const raw =
      stepIndex === 1 || stepIndex === 2
        ? tracking.confirmedAt
        : stepIndex === 3
          ? tracking.pickedUpAt
          : stepIndex === 4
            ? tracking.deliveredAt
            : null;
    return raw ? new Date(raw).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '---';
  }

  callPartner(): void {
    if (!this.partnerPhone) return;
    window.location.href = `tel:${this.partnerPhone.replace(/\s+/g, '')}`;
  }
}
