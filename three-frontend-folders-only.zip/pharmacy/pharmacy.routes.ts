import { Routes } from '@angular/router';

import { PharmacyHomeComponent } from './pages/pharmacy-home/pharmacy-home.component';
import { OrderPreviewComponent } from './pages/order-preview/order-preview.component';
import { DeliveryTrackingComponent } from './pages/delivery-tracking/delivery-tracking.component';
import { OrderHistoryComponent } from './pages/order-history/order-history.component';
import { PrescriptionsComponent } from './pages/prescriptions/prescriptions.component';

export const PHARMACY_ROUTES: Routes = [
  {
    path: '',
    component: PharmacyHomeComponent
  },
  {
    path: 'preview',
    component: OrderPreviewComponent
  },
  {
    path: 'delivery',
    component: DeliveryTrackingComponent
  },
  {
    path: 'order-history',
    component: OrderHistoryComponent
  },
  {
    path: 'prescriptions',
    component: PrescriptionsComponent
  }
];
