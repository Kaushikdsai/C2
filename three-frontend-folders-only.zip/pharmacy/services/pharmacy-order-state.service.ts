import { Injectable } from '@angular/core';
import { ExtractedMedicineDTO } from '../../../core/models/prescription.model';

@Injectable({ providedIn: 'root' })
export class PharmacyOrderStateService {
  extractedMedicines: ExtractedMedicineDTO[] = [];
  hospitalId: number | null = null;
  doctorId: number | null = null;

  prescriptionId: number | null = null;
  patientGeoAddress: string | null = null;
  orderId: number | null = null;

  reset(): void {
    this.extractedMedicines = [];
    this.hospitalId = null;
    this.doctorId = null;
    this.prescriptionId = null;
    this.patientGeoAddress = null;
    this.orderId = null;
  }
}
