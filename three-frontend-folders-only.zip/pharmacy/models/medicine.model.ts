export interface PreviewMedicine {
  id: string;
  name: string;
  sub: string;
  thumbLabel: string;
  thumbClass: string;
  /** Immutable ceiling from the prescription - "+"" can never push quantity past this. */
  prescribedQuantity: number;
  /** What the patient currently wants to order - the only thing +/- ever changes. */
  quantity: number;
  removed: boolean;
  /** True while a backend call for this row (quantity change or remove/restore) is in flight - disables its own buttons only, not the whole page. */
  saving: boolean;
}
