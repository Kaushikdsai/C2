import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OrderService } from '../../../../core/services/order.service';
import { OrderResponseDTO } from '../../../../core/models/order.model';
import { ModalComponent } from '../../../../shared/components/modal/modal.component';

interface PriceRow {
  medicineName: string;
  quantity: number;
  price: number | null;
}

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, ModalComponent],
  selector: 'app-accept-order-modal',
  templateUrl: './accept-order-modal.component.html',
  styleUrls: ['./accept-order-modal.component.scss']
})
export class AcceptOrderModalComponent implements OnChanges {
  @Input() open = false;
  @Input() orderId: number | null = null;

  @Output() closed = new EventEmitter<void>();
  @Output() confirmed = new EventEmitter<{ orderId: number; itemPrices: { medicineName: string; price: number }[] }>();

  rows: PriceRow[] = [];
  loading = false;
  errorText: string | null = null;

  constructor(private orderService: OrderService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['open'] && this.open && this.orderId) {
      this.loadOrder(this.orderId);
    }
  }

  private loadOrder(orderId: number): void {
    this.loading = true;
    this.errorText = null;
    this.orderService.getOrderById(orderId).subscribe({
      next: (order: OrderResponseDTO) => {
        this.rows = order.items.map(item => ({
          medicineName: item.medicineName,
          quantity: item.quantity,
          price: null
        }));
        this.loading = false;
      },
      error: () => {
        this.errorText = 'Could not load order details.';
        this.loading = false;
      }
    });
  }

  get allPricesEntered(): boolean {
    return this.rows.length > 0 && this.rows.every(r => r.price !== null && r.price > 0);
  }

  get total(): number {
    return this.rows.reduce((sum, r) => sum + (r.price ?? 0) * r.quantity, 0);
  }

  close(): void {
    this.closed.emit();
  }

  confirm(): void {
    if (!this.allPricesEntered || !this.orderId) return;
    this.confirmed.emit({
      orderId: this.orderId,
      itemPrices: this.rows.map(r => ({ medicineName: r.medicineName, price: r.price as number }))
    });
  }
}
