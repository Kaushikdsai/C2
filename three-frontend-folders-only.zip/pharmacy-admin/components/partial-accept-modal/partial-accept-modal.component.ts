import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OrderService } from '../../../../core/services/order.service';
import { OrderResponseDTO } from '../../../../core/models/order.model';
import { MissingItemDTO } from '../../../../core/models/missing-item.model';
import { ModalComponent } from '../../../../shared/components/modal/modal.component';

interface PartialRow {
  medicineName: string;
  quantity: number;
  /** Only relevant in "new" mode - unchecked items are left out of the offer entirely. In "complete" mode every row is always included (backend requires an exact match to what's missing). */
  included: boolean;
  price: number | null;
}

/**
 * Handles BOTH partial-fulfillment moments (item 5/7) in one modal:
 *   - mode 'new': the order is still fully open (PENDING) - pharmacy picks
 *     a SUBSET of items it can supply (>= the configured threshold %).
 *   - mode 'complete': the order is PARTIALLY_ALLOCATED - pharmacy must
 *     price exactly the medicines still missing, no picking allowed.
 */
@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, ModalComponent],
  selector: 'app-partial-accept-modal',
  templateUrl: './partial-accept-modal.component.html',
  styleUrls: ['./partial-accept-modal.component.scss']
})
export class PartialAcceptModalComponent implements OnChanges {
  @Input() open = false;
  @Input() orderId: number | null = null;
  @Input() mode: 'new' | 'complete' = 'new';
  /** Required when mode === 'complete' - the exact missing items to price (from AvailablePartialOrderDTO). */
  @Input() missingItems: MissingItemDTO[] = [];
  /** Threshold shown as a hint in 'new' mode - purely informational, the backend is the real enforcer. */
  @Input() thresholdPercent = 50;

  @Output() closed = new EventEmitter<void>();
  @Output() confirmed = new EventEmitter<{ orderId: number; itemPrices: { medicineName: string; price: number }[] }>();

  rows: PartialRow[] = [];
  loading = false;
  errorText: string | null = null;

  constructor(private orderService: OrderService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['open'] && this.open && this.orderId) {
      if (this.mode === 'complete') {
        this.rows = this.missingItems.map(m => ({
          medicineName: m.medicineName,
          quantity: m.quantity,
          included: true,
          price: null
        }));
      } else {
        this.loadOrder(this.orderId);
      }
    }
  }

  private loadOrder(orderId: number): void {
    this.loading = true;
    this.errorText = null;
    this.orderService.getOrderById(orderId).subscribe({
      next: (order: OrderResponseDTO) => {
        this.rows = order.items.map(item => ({
          medicineName: item.medicineName,
          quantity: item.quantity,
          included: false,
          price: null
        }));
        this.loading = false;
      },
      error: () => {
        this.errorText = 'Could not load order details.';
        this.loading = false;
      }
    });
  }

  get includedRows(): PartialRow[] {
    return this.rows.filter(r => this.mode === 'complete' || r.included);
  }

  get coveragePercent(): number {
    if (this.rows.length === 0) return 0;
    return Math.round((this.includedRows.length / this.rows.length) * 100);
  }

  get canSubmit(): boolean {
    const included = this.includedRows;
    if (included.length === 0) return false;
    if (this.mode === 'new' && this.coveragePercent < this.thresholdPercent) return false;
    return included.every(r => r.price !== null && r.price > 0);
  }

  get total(): number {
    return this.includedRows.reduce((sum, r) => sum + (r.price ?? 0) * r.quantity, 0);
  }

  close(): void {
    this.closed.emit();
  }

  confirm(): void {
    if (!this.canSubmit || !this.orderId) return;
    this.confirmed.emit({
      orderId: this.orderId,
      itemPrices: this.includedRows.map(r => ({ medicineName: r.medicineName, price: r.price as number }))
    });
  }
}
