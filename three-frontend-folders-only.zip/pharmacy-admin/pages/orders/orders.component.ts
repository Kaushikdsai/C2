import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { PharmacyService } from '../../../../core/services/pharmacy.service';
import { ToastService } from '../../../../core/services/toast.service';
import { OrderSummaryDTO } from '../../../../core/models/order-summary.model';
import { AvailablePartialOrderDTO } from '../../../../core/models/available-partial-order.model';
import { OrderStatus } from '../../../../core/models/order-status.enum';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AcceptOrderModalComponent } from '../../components/accept-order-modal/accept-order-modal.component';
import { PartialAcceptModalComponent } from '../../components/partial-accept-modal/partial-accept-modal.component';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../shared/components/admin-sidebar/admin-sidebar.component';

type Tab = 'new' | 'partial' | 'completed' | 'cancelled';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    AcceptOrderModalComponent,
    PartialAcceptModalComponent,
    HeaderComponent,
    AdminSidebarComponent
  ],
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss']
})
export class OrdersComponent implements OnInit {
  activeTab: Tab = 'new';
  searchQuery = '';
  orders: OrderSummaryDTO[] = [];
  /** Item 5/7: PARTIALLY_ALLOCATED orders this pharmacy could complete the remainder of - separate list, separate shape (missing items only, no total yet). */
  partialOrders: AvailablePartialOrderDTO[] = [];
  loading = true;
  busyOrderId: number | null = null;

  acceptModalOpen = false;
  acceptModalOrderId: number | null = null;

  partialModalOpen = false;
  partialModalOrderId: number | null = null;
  partialModalMode: 'new' | 'complete' = 'new';
  partialModalMissingItems: { medicineName: string; quantity: number }[] = [];

  constructor(
    private auth: AuthService,
    private pharmacyService: PharmacyService,
    private toast: ToastService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  get filteredOrders(): OrderSummaryDTO[] {
    const q = this.searchQuery.trim().toLowerCase();
    if (!q) return this.orders;
    return this.orders.filter(o =>
      String(o.orderId).includes(q) || (o.patientName ?? '').toLowerCase().includes(q)
    );
  }

  get filteredPartialOrders(): AvailablePartialOrderDTO[] {
    const q = this.searchQuery.trim().toLowerCase();
    if (!q) return this.partialOrders;
    return this.partialOrders.filter(o =>
      String(o.orderId).includes(q) || (o.patientName ?? '').toLowerCase().includes(q)
    );
  }

  /** Angular templates can't contain arrow functions (NG5002) - this is the fix for that, not just a convenience. */
  missingItemsSummary(order: AvailablePartialOrderDTO): string {
    const names = order.missingItems.map(m => m.medicineName).join(', ');
    return `${order.missingItems.length} medicine${order.missingItems.length === 1 ? '' : 's'} — ${names}`;
  }

  switchTab(tab: Tab): void {
    this.activeTab = tab;
    this.load();
  }

  private load(): void {
    this.loading = true;
    const pharmacyId = this.auth.getPharmacyId();

    if (this.activeTab === 'partial') {
      this.pharmacyService.getAvailableOrdersForPartialFulfillment(pharmacyId).subscribe({
        next: (orders) => {
          this.partialOrders = orders;
          this.loading = false;
        },
        error: () => (this.loading = false)
      });
      return;
    }

    const call =
      this.activeTab === 'new'
        ? this.pharmacyService.getAvailableOrders(pharmacyId)
        : this.pharmacyService.getOrdersByStatus(
            pharmacyId,
            this.activeTab === 'completed' ? OrderStatus.DELIVERED : OrderStatus.CANCELLED
          );

    call.subscribe({
      next: (orders) => {
        this.orders = orders;
        this.loading = false;
      },
      error: () => (this.loading = false)
    });
  }

  openAcceptModal(orderId: number): void {
    this.acceptModalOrderId = orderId;
    this.acceptModalOpen = true;
  }

  closeAcceptModal(): void {
    this.acceptModalOpen = false;
    this.acceptModalOrderId = null;
  }

  confirmAccept(event: { orderId: number; itemPrices: { medicineName: string; price: number }[] }): void {
    const pharmacyId = this.auth.getPharmacyId();
    this.busyOrderId = event.orderId;

    this.pharmacyService.acceptOrder(event.orderId, pharmacyId, { itemPrices: event.itemPrices }).subscribe({
      next: () => {
        this.toast.show(`Order #${event.orderId} accepted.`, 'success');
        this.closeAcceptModal();
        this.busyOrderId = null;
        this.load();
      },
      error: () => {
        this.busyOrderId = null;
      }
    });
  }

  /** Opens the partial-offer modal from the "New" tab - order is still fully open, pharmacy is choosing a subset. */
  openPartialOfferModal(orderId: number): void {
    this.partialModalOrderId = orderId;
    this.partialModalMode = 'new';
    this.partialModalMissingItems = [];
    this.partialModalOpen = true;
  }

  /** Opens the partial-complete modal from the "Complete Partial Orders" tab - pharmacy must cover exactly the listed missing items. */
  openPartialCompleteModal(order: AvailablePartialOrderDTO): void {
    this.partialModalOrderId = order.orderId;
    this.partialModalMode = 'complete';
    this.partialModalMissingItems = order.missingItems;
    this.partialModalOpen = true;
  }

  closePartialModal(): void {
    this.partialModalOpen = false;
    this.partialModalOrderId = null;
  }

  confirmPartial(event: { orderId: number; itemPrices: { medicineName: string; price: number }[] }): void {
    const pharmacyId = this.auth.getPharmacyId();
    this.busyOrderId = event.orderId;

    this.pharmacyService.acceptPartialOrder(event.orderId, pharmacyId, { itemPrices: event.itemPrices }).subscribe({
      next: () => {
        this.toast.show(
          this.partialModalMode === 'new'
            ? `Partial offer submitted for order #${event.orderId}.`
            : `Order #${event.orderId} completed and fully allocated.`,
          'success'
        );
        this.closePartialModal();
        this.busyOrderId = null;
        this.load();
      },
      error: () => {
        this.busyOrderId = null;
      }
    });
  }

  reject(orderId: number): void {
    const pharmacyId = this.auth.getPharmacyId();
    this.busyOrderId = orderId;

    this.pharmacyService.rejectOrder(orderId, pharmacyId).subscribe({
      next: () => {
        this.toast.show(`Order #${orderId} declined.`, 'info');
        this.busyOrderId = null;
        this.load();
      },
      error: () => {
        this.busyOrderId = null;
      }
    });
  }
}
