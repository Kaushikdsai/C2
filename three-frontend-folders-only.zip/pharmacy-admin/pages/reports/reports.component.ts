import { Component, OnInit } from '@angular/core';
import { forkJoin } from 'rxjs';
import { AuthService } from '../../../../core/services/auth.service';
import { PharmacyService } from '../../../../core/services/pharmacy.service';

import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {
  ordersThisMonth: number | null = null;
  successRate: number | null = null;
  loading = true;

  constructor(private auth: AuthService, private pharmacyService: PharmacyService) {}

  ngOnInit(): void {
    const pharmacyId = this.auth.getPharmacyId();

    forkJoin({
      ordersThisMonth: this.pharmacyService.getOrdersThisMonth(pharmacyId),
      successRate: this.pharmacyService.getDeliverySuccessRate(pharmacyId)
    }).subscribe({
      next: (result) => {
        this.ordersThisMonth = result.ordersThisMonth;
        this.successRate = result.successRate;
        this.loading = false;
      },
      error: () => (this.loading = false)
    });
  }
}
