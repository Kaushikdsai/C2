import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { PharmacyService } from '../../../../core/services/pharmacy.service';
import { PharmacyProfileDTO } from '../../../../core/models/pharmacy-profile.model';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FieldMessageComponent } from '../../../../shared/components/field-message/field-message.component';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    FieldMessageComponent,
    HeaderComponent,
    AdminSidebarComponent
  ],
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class PharmacyAdminProfileComponent implements OnInit {
  profile: PharmacyProfileDTO | null = null;
  loading = true;
  saving = false;
  messageText: string | null = null;
  messageType: 'success' | 'error' = 'success';

  // editable fields
  name = '';
  licenseNo = '';
  phone = '';
  address = '';

  constructor(private auth: AuthService, private pharmacyService: PharmacyService) {}

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.loading = true;
    this.pharmacyService.getProfile(this.auth.getPharmacyId()).subscribe({
      next: (p) => {
        this.profile = p;
        this.name = p.name || '';
        this.licenseNo = p.licenseNo || '';
        this.phone = p.phone || '';
        this.address = p.address || '';
        this.loading = false;
      },
      error: () => (this.loading = false)
    });
  }

  discard(): void {
    if (!this.profile) return;
    this.name = this.profile.name || '';
    this.licenseNo = this.profile.licenseNo || '';
    this.phone = this.profile.phone || '';
    this.address = this.profile.address || '';
    this.messageText = null;
  }

  private isValidPhone(value: string): boolean {
    return /^[0-9+\-\s()]{7,20}$/.test(value.trim());
  }

  save(): void {
    if (!this.name.trim() || !this.licenseNo.trim() || !this.phone.trim() || !this.address.trim()) {
      this.messageText = 'All fields are required.';
      this.messageType = 'error';
      return;
    }
    if (!this.isValidPhone(this.phone)) {
      this.messageText = 'Please enter a valid contact number.';
      this.messageType = 'error';
      return;
    }

    this.saving = true;
    const pharmacyId = this.auth.getPharmacyId();

    this.pharmacyService
      .updateProfile(pharmacyId, {
        licenseNo: this.licenseNo,
        geoAddress: this.profile?.geoAddress,
        name: this.name,
        email: this.profile?.email,
        phone: this.phone,
        address: this.address,
        pincode: this.profile?.pincode,
        city: this.profile?.city,
        state: this.profile?.state
      })
      .subscribe({
        next: (updated) => {
          this.profile = updated;
          this.messageText = 'Pharmacy profile updated successfully.';
          this.messageType = 'success';
          this.saving = false;
        },
        error: () => {
          this.saving = false;
        }
      });
  }
}
