import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { PharmacyService } from '../../../../core/services/pharmacy.service';
import { PharmacyDashboardDTO } from '../../../../core/models/pharmacy-dashboard.model';
import { OrderSummaryDTO } from '../../../../core/models/order-summary.model';
import { OrderStatus } from '../../../../core/models/order-status.enum';

import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  stats: PharmacyDashboardDTO | null = null;
  recentOrders: OrderSummaryDTO[] = [];
  loading = true;

  constructor(private auth: AuthService, private pharmacyService: PharmacyService) {}

  ngOnInit(): void {
    const pharmacyId = this.auth.getPharmacyId() ?? 50;
    console.log(pharmacyId);

    this.pharmacyService.getDashboard(pharmacyId).subscribe({
      next: (s) => (this.stats = s)
    });

    this.pharmacyService.getOrdersByStatus(pharmacyId, OrderStatus.CONFIRMED).subscribe({
      next: (orders) => {
        this.recentOrders = orders.slice(0, 5);
        this.loading = false;
      },
      error: () => (this.loading = false)
    });
  }

  statusBadgeClass(status: OrderStatus): string {
    switch (status) {
      case OrderStatus.DELIVERED: return 'badge-success';
      case OrderStatus.CANCELLED: return 'badge-error';
      case OrderStatus.CONFIRMED: return 'badge-warn';
      default: return 'badge-info';
    }
  }
}
