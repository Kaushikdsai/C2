import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../../core/services/auth.service';
import { PharmacyService } from '../../../../core/services/pharmacy.service';
import { PharmacyProfileDTO } from '../../../../core/models/pharmacy-profile.model';
import { OrderFeedbackResponseDTO } from '../../../../core/models/order-feedback.model';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../shared/components/admin-sidebar/admin-sidebar.component';

/**
 * Pharmacy-side counterpart to delivery-partner/pages/ratings - same
 * shape, same real data source (profile.rating/ratingCount is the exact
 * running average submitRating() maintains, and each row below is one of
 * the individual submissions that fed into it), so both roles get the
 * same rating experience (item: "ratings connected... both r same").
 */
@Component({
  standalone: true,
  imports: [CommonModule, HeaderComponent, AdminSidebarComponent],
  selector: 'app-pharmacy-admin-ratings',
  templateUrl: './ratings.component.html',
  styleUrls: ['./ratings.component.scss']
})
export class PharmacyAdminRatingsComponent implements OnInit {
  stars = [1, 2, 3, 4, 5];

  profile: PharmacyProfileDTO | null = null;
  loading = true;

  feedback: OrderFeedbackResponseDTO[] = [];
  feedbackLoading = true;

  constructor(private auth: AuthService, private pharmacyService: PharmacyService) {}

  ngOnInit(): void {
    const pharmacyId = this.auth.getPharmacyId();

    this.pharmacyService.getProfile(pharmacyId).subscribe({
      next: (p) => {
        this.profile = p;
        this.loading = false;
      },
      error: () => (this.loading = false)
    });

    this.pharmacyService.getFeedback(pharmacyId).subscribe({
      next: (rows) => {
        this.feedback = rows;
        this.feedbackLoading = false;
      },
      error: () => (this.feedbackLoading = false)
    });
  }

  get filledStars(): number[] {
    return Array(Math.round(this.profile?.rating ?? 0)).fill(0);
  }

  get emptyStars(): number[] {
    return Array(5 - Math.round(this.profile?.rating ?? 0)).fill(0);
  }

  ratingStars(rating: number | null): number {
    return Math.round(rating ?? 0);
  }
}
