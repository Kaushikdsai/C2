import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { PharmacyService } from '../../../../core/services/pharmacy.service';
import { OrderSummaryDTO } from '../../../../core/models/order-summary.model';
import { OrderStatus } from '../../../../core/models/order-status.enum';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../../shared/components/header/header.component';
import { AdminSidebarComponent } from '../../../../shared/components/admin-sidebar/admin-sidebar.component';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HeaderComponent,
    AdminSidebarComponent
  ],
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent implements OnInit {
  orders: OrderSummaryDTO[] = [];
  loading = true;
  searchQuery = '';
  dateFilter = '';

  constructor(private auth: AuthService, private pharmacyService: PharmacyService) {}

  ngOnInit(): void {
    this.pharmacyService.getOrderHistory(this.auth.getPharmacyId()).subscribe({
      next: (orders) => {
        this.orders = orders;
        this.loading = false;
      },
      error: () => (this.loading = false)
    });
  }

  get filtered(): OrderSummaryDTO[] {
    return this.orders.filter(o => {
      const matchesSearch =
        !this.searchQuery ||
        String(o.orderId).includes(this.searchQuery) ||
        (o.patientName ?? '').toLowerCase().includes(this.searchQuery.toLowerCase());

      const matchesDate =
        !this.dateFilter ||
        new Date(o.orderDatetime).toISOString().slice(0, 10) === this.dateFilter;

      return matchesSearch && matchesDate;
    });
  }

  statusLabel(status: OrderStatus): string {
    return status === OrderStatus.DELIVERED ? 'Completed' : 'Cancelled';
  }
}
