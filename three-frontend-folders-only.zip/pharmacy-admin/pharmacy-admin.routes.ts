import { Routes } from '@angular/router';

import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { HistoryComponent } from './pages/history/history.component';
import { ReportsComponent } from './pages/reports/reports.component';
import { PharmacyAdminProfileComponent } from './pages/profile/profile.component';
import { PharmacyAdminRatingsComponent } from './pages/ratings/ratings.component';

export const PHARMACY_ADMIN_ROUTES: Routes = [
  {
    path: '',
    component: DashboardComponent
  },
  {
    path: 'orders',
    component: OrdersComponent
  },
  {
    path: 'history',
    component: HistoryComponent
  },
  {
    path: 'reports',
    component: ReportsComponent
  },
  {
    path: 'profile',
    component: PharmacyAdminProfileComponent
  },
  {
    path: 'ratings',
    component: PharmacyAdminRatingsComponent
  }
];
