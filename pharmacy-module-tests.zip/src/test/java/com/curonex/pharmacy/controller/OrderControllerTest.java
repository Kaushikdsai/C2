package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.curonex.pharmacy.dto.OrderCreateRequestDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderTrackingDTO;
import com.curonex.pharmacy.dto.PatientDetailsUpdateDTO;
import com.curonex.pharmacy.service.OrderService;

/**
 * Plain Mockito unit tests, not @WebMvcTest - avoids loading a Spring web
 * context just to confirm each endpoint delegates to the service and
 * returns the right status/body. Faster, and sufficient for line coverage
 * on a thin controller layer that has no logic of its own.
 */
@ExtendWith(MockitoExtension.class)
class OrderControllerTest {

    @Mock private OrderService orderService;
    @InjectMocks private OrderController controller;

    @Test
    void createOrder_returns201WithBody() {
        OrderResponseDTO response = new OrderResponseDTO();
        response.setOrderId(1L);
        when(orderService.createOrder(any(OrderCreateRequestDTO.class))).thenReturn(response);

        ResponseEntity<OrderResponseDTO> result = controller.createOrder(new OrderCreateRequestDTO());

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(result.getBody().getOrderId()).isEqualTo(1L);
    }

    @Test
    void getOrderById_returns200WithBody() {
        OrderResponseDTO response = new OrderResponseDTO();
        when(orderService.getOrderById(1L)).thenReturn(response);

        ResponseEntity<OrderResponseDTO> result = controller.getOrderById(1L);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
        verify(orderService).getOrderById(1L);
    }

    @Test
    void getAllOrders_returnsList() {
        when(orderService.getAllOrders()).thenReturn(List.of(new OrderResponseDTO()));
        ResponseEntity<List<OrderResponseDTO>> result = controller.getAllOrders();
        assertThat(result.getBody()).hasSize(1);
    }

    @Test
    void getAllOrdersPaged_delegatesWithPageable() {
        Page<OrderResponseDTO> page = new PageImpl<>(List.of(new OrderResponseDTO()));
        Pageable pageable = Pageable.unpaged();
        when(orderService.getAllOrders(pageable)).thenReturn(page);

        ResponseEntity<Page<OrderResponseDTO>> result = controller.getAllOrdersPaged(pageable);

        assertThat(result.getBody().getContent()).hasSize(1);
    }

    @Test
    void getOrdersByUser_delegates() {
        when(orderService.getOrdersByUser(41L)).thenReturn(List.of(new OrderResponseDTO()));
        assertThat(controller.getOrdersByUser(41L).getBody()).hasSize(1);
    }

    @Test
    void getOrderTracking_delegates() {
        OrderTrackingDTO tracking = new OrderTrackingDTO();
        when(orderService.getOrderTracking(1L)).thenReturn(tracking);
        assertThat(controller.getOrderTracking(1L).getBody()).isSameAs(tracking);
    }

    @Test
    void updatePatientDetails_delegates() {
        OrderResponseDTO response = new OrderResponseDTO();
        PatientDetailsUpdateDTO dto = new PatientDetailsUpdateDTO();
        when(orderService.updatePatientDetails(1L, dto)).thenReturn(response);

        ResponseEntity<OrderResponseDTO> result = controller.updatePatientDetails(1L, dto);
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void acceptPrice_delegates() {
        OrderResponseDTO response = new OrderResponseDTO();
        when(orderService.acceptPrice(1L)).thenReturn(response);
        assertThat(controller.acceptPrice(1L).getBody()).isSameAs(response);
    }

    @Test
    void cancelOrder_delegates() {
        OrderResponseDTO response = new OrderResponseDTO();
        when(orderService.cancelOrder(1L)).thenReturn(response);
        assertThat(controller.cancelOrder(1L).getBody()).isSameAs(response);
    }
}
