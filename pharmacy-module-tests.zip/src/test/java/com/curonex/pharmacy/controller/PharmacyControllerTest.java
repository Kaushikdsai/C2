package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.curonex.pharmacy.dto.*;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import com.curonex.pharmacy.service.PharmacyService;

@ExtendWith(MockitoExtension.class)
class PharmacyControllerTest {

    @Mock private PharmacyService service;
    @Mock private PharmacyRoutingService pharmacyRoutingService;
    @InjectMocks private PharmacyController controller;

    @Test
    void addPharmacy_returns201() {
        PharmacyDTO dto = new PharmacyDTO();
        when(service.addPharmacy(any())).thenReturn(dto);
        ResponseEntity<PharmacyDTO> result = controller.addPharmacy(dto);
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.CREATED);
    }

    @Test
    void getPharmacyById_delegates() {
        when(service.getPharmacyById(50L)).thenReturn(new PharmacyDTO());
        assertThat(controller.getPharmacyById(50L).getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void getAllPharmacies_returnsList() {
        when(service.getAllPharmacies()).thenReturn(List.of(new PharmacyDTO()));
        assertThat(controller.getAllPharmacies().getBody()).hasSize(1);
    }

    @Test
    void deletePharmacy_returns200() {
        ResponseEntity<Void> result = controller.deletePharmacy(50L);
        verify(service).deletePharmacy(50L);
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void getDashboard_delegates() {
        when(service.getDashboard(50L)).thenReturn(new PharmacyDashboardDTO());
        assertThat(controller.getDashboard(50L).getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void getOrdersByStatus_delegates() {
        when(service.getOrdersByStatus(50L, OrderStatusEnum.DELIVERED)).thenReturn(List.of());
        assertThat(controller.getOrdersByStatus(50L, OrderStatusEnum.DELIVERED).getBody()).isEmpty();
    }

    @Test
    void getAvailableOrders_delegatesToRoutingService() {
        when(pharmacyRoutingService.getAvailableOrdersForPharmacy(50L)).thenReturn(List.of());
        assertThat(controller.getAvailableOrders(50L).getBody()).isEmpty();
    }

    @Test
    void getAvailableOrdersForPartialFulfillment_delegates() {
        when(pharmacyRoutingService.getAvailableOrdersForPartialFulfillment(50L)).thenReturn(List.of());
        assertThat(controller.getAvailableOrdersForPartialFulfillment(50L).getBody()).isEmpty();
    }

    @Test
    void acceptOrder_delegates() {
        OrderResponseDTO response = new OrderResponseDTO();
        PharmacyAcceptRequestDTO request = new PharmacyAcceptRequestDTO();
        when(service.acceptOrder(1L, 50L, request)).thenReturn(response);
        assertThat(controller.acceptOrder(1L, 50L, request).getBody()).isSameAs(response);
    }

    @Test
    void acceptPartialOrder_delegates() {
        OrderResponseDTO response = new OrderResponseDTO();
        PharmacyPartialAcceptRequestDTO request = new PharmacyPartialAcceptRequestDTO();
        when(service.acceptPartialOrder(1L, 50L, request)).thenReturn(response);
        assertThat(controller.acceptPartialOrder(1L, 50L, request).getBody()).isSameAs(response);
    }

    @Test
    void rejectOrder_delegates() {
        ResponseEntity<String> result = controller.rejectOrder(1L, 50L);
        verify(service).rejectOrder(1L, 50L);
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void cancelAcceptedOrder_delegates() {
        when(service.cancelAcceptedOrder(1L, 50L)).thenReturn(true);
        assertThat(controller.cancelAcceptedOrder(1L, 50L).getBody()).isTrue();
    }

    @Test
    void getDeliverySuccessRate_delegates() {
        when(service.getDeliverySuccessRate(50L)).thenReturn(95.5);
        assertThat(controller.getDeliverySuccessRate(50L).getBody()).isEqualTo(95.5);
    }

    @Test
    void getOrdersThisMonth_delegates() {
        when(service.getOrdersThisMonth(50L)).thenReturn(12L);
        assertThat(controller.getOrdersThisMonth(50L).getBody()).isEqualTo(12L);
    }
}
