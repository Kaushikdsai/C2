package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.curonex.pharmacy.dto.*;
import com.curonex.pharmacy.service.DeliveryPartnersService;
import com.curonex.pharmacy.service.DeliveryRoutingService;

@ExtendWith(MockitoExtension.class)
class DeliveryPartnersControllerTest {

    @Mock private DeliveryPartnersService service;
    @Mock private DeliveryRoutingService deliveryRoutingService;
    @InjectMocks private DeliveryPartnersController controller;

    @Test
    void addDeliveryPartner_returns201() {
        DeliveryPartnerDTO dto = new DeliveryPartnerDTO();
        when(service.addDeliveryPartner(any())).thenReturn(dto);
        assertThat(controller.addDeliveryPartner(dto).getStatusCode()).isEqualTo(HttpStatus.CREATED);
    }

    @Test
    void markAvailable_delegates() {
        when(service.markAvailable(700L)).thenReturn(true);
        assertThat(controller.markAvailable(700L).getBody()).isTrue();
    }

    @Test
    void markOnDelivery_delegates() {
        when(service.markOnDelivery(700L)).thenReturn(true);
        assertThat(controller.markOnDelivery(700L).getBody()).isTrue();
    }

    @Test
    void markOffline_delegates() {
        when(service.markOffline(700L)).thenReturn(true);
        assertThat(controller.markOffline(700L).getBody()).isTrue();
    }

    @Test
    void getDashboard_delegates() {
        when(service.getDashboard(700L)).thenReturn(new DeliveryPartnerDashboardDTO());
        assertThat(controller.getDashboard(700L).getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void getAvailableOrders_delegatesToRoutingService() {
        when(deliveryRoutingService.getAvailableOrdersForPartner(700L)).thenReturn(List.of());
        assertThat(controller.getAvailableOrders(700L).getBody()).isEmpty();
    }

    @Test
    void getActiveDeliveries_delegates() {
        when(deliveryRoutingService.getActiveDeliveriesForPartner(700L)).thenReturn(List.of());
        assertThat(controller.getActiveDeliveries(700L).getBody()).isEmpty();
    }

    @Test
    void getDeliveryHistory_delegates() {
        when(deliveryRoutingService.getDeliveryHistoryForPartner(700L)).thenReturn(List.of());
        assertThat(controller.getDeliveryHistory(700L).getBody()).isEmpty();
    }

    @Test
    void acceptDelivery_delegates() {
        when(deliveryRoutingService.acceptDelivery(1L, 700L)).thenReturn(true);
        assertThat(controller.acceptDelivery(1L, 700L).getBody()).isTrue();
    }

    @Test
    void cancelDelivery_delegates() {
        when(deliveryRoutingService.cancelDelivery(1L, 700L)).thenReturn(true);
        assertThat(controller.cancelDelivery(1L, 700L).getBody()).isTrue();
    }

    @Test
    void rejectDelivery_delegates() {
        ResponseEntity<String> result = controller.rejectDelivery(1L, 700L);
        verify(deliveryRoutingService).rejectDelivery(1L, 700L);
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void pickupFromPharmacy_delegates() {
        when(deliveryRoutingService.pickupFromPharmacy(1L, 700L, 50L)).thenReturn(true);
        assertThat(controller.pickupFromPharmacy(1L, 700L, 50L).getBody()).isTrue();
    }

    @Test
    void deleteDeliveryPartner_delegates() {
        controller.deleteDeliveryPartner(700L);
        verify(service).deleteDeliveryPartner(700L);
    }
}
