package com.curonex.pharmacy.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.curonex.pharmacy.dto.ExtractedMedicineDTO;

class PrescriptionParserUtilTest {

    @Test
    void parseMedicines_singleLine_extractsNameAndQuantity() {
        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines("Paracetamol 650mg Qty: 10");

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getMedicineName()).isEqualTo("Paracetamol 650mg");
        assertThat(result.get(0).getQuantity()).isEqualTo(10);
    }

    @Test
    void parseMedicines_multipleLines_extractsAll() {
        String text = "Hospital: 12\n"
                + "Paracetamol 650mg Qty: 10\n"
                + "Azithromycin 250mg Qty:6\n"
                + "Cetirizine 10mg Qty : 15\n"
                + "End of document.";

        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines(text);

        assertThat(result).hasSize(3);
        assertThat(result.get(0).getMedicineName()).isEqualTo("Paracetamol 650mg");
        assertThat(result.get(1).getQuantity()).isEqualTo(6);
        assertThat(result.get(2).getMedicineName()).isEqualTo("Cetirizine 10mg");
        assertThat(result.get(2).getQuantity()).isEqualTo(15);
    }

    @Test
    void parseMedicines_caseInsensitiveQtyLabel() {
        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines("Ibuprofen 400mg qty: 20");
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getQuantity()).isEqualTo(20);
    }

    @Test
    void parseMedicines_noMatchingLines_returnsEmptyList() {
        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines("Just some prose with no medicines listed.");
        assertThat(result).isEmpty();
    }

    @Test
    void parseMedicines_emptyString_returnsEmptyList() {
        assertThat(PrescriptionParserUtil.parseMedicines("")).isEmpty();
    }

    @Test
    void parseMedicines_crlfLineEndings_handledCorrectly() {
        String text = "Paracetamol Qty: 5\r\nAzithromycin Qty: 3\r\n";
        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines(text);
        assertThat(result).hasSize(2);
    }
}
