package com.curonex.pharmacy.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

import org.junit.jupiter.api.Test;

class DistanceUtilTest {

    private final DistanceUtil distanceUtil = new DistanceUtil();

    @Test
    void calculateDistance_sameCoordinate_returnsZero() {
        double distance = distanceUtil.calculateDistance(12.9716, 77.5946, 12.9716, 77.5946);
        assertThat(distance).isCloseTo(0.0, within(0.0001));
    }

    @Test
    void calculateDistance_knownPair_matchesExpectedHaversine() {
        // Bangalore MG Road (12.9716,77.5946) to Bangalore Airport (13.1986,77.7066) - roughly 34km.
        double distance = distanceUtil.calculateDistance(12.9716, 77.5946, 13.1986, 77.7066);
        assertThat(distance).isBetween(30.0, 40.0);
    }

    @Test
    void calculateDistance_isSymmetric() {
        double forward = distanceUtil.calculateDistance(12.9716, 77.5946, 13.1986, 77.7066);
        double backward = distanceUtil.calculateDistance(13.1986, 77.7066, 12.9716, 77.5946);
        assertThat(forward).isCloseTo(backward, within(0.0001));
    }

    @Test
    void calculateDistance_negativeCoordinates_handledCorrectly() {
        double distance = distanceUtil.calculateDistance(-33.8688, 151.2093, -37.8136, 144.9631);
        assertThat(distance).isGreaterThan(0);
    }
}
