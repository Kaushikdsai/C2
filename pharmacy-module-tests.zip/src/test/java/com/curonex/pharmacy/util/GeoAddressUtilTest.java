package com.curonex.pharmacy.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

import com.curonex.pharmacy.dto.CoordinateDTO;

class GeoAddressUtilTest {

    private final GeoAddressUtil geoAddressUtil = new GeoAddressUtil();

    @Test
    void parse_validAddress_returnsCorrectCoordinate() {
        CoordinateDTO result = geoAddressUtil.parse("12.9716,77.5946");
        assertThat(result.getLatitude()).isEqualTo(12.9716);
        assertThat(result.getLongitude()).isEqualTo(77.5946);
    }

    @Test
    void parse_withWhitespaceAroundValues_trims() {
        CoordinateDTO result = geoAddressUtil.parse(" 12.9716 , 77.5946 ");
        assertThat(result.getLatitude()).isEqualTo(12.9716);
        assertThat(result.getLongitude()).isEqualTo(77.5946);
    }

    @Test
    void parse_negativeCoordinates_parsedCorrectly() {
        CoordinateDTO result = geoAddressUtil.parse("-33.8688,151.2093");
        assertThat(result.getLatitude()).isEqualTo(-33.8688);
        assertThat(result.getLongitude()).isEqualTo(151.2093);
    }

    @Test
    void parse_nullInput_throws() {
        assertThatThrownBy(() -> geoAddressUtil.parse(null))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void parse_blankInput_throws() {
        assertThatThrownBy(() -> geoAddressUtil.parse("  "))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void parse_missingComma_throws() {
        assertThatThrownBy(() -> geoAddressUtil.parse("12.9716"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void parse_tooManyParts_throws() {
        assertThatThrownBy(() -> geoAddressUtil.parse("12.9716,77.5946,extra"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void parse_nonNumericValue_throwsNumberFormatException() {
        assertThatThrownBy(() -> geoAddressUtil.parse("abc,def"))
                .isInstanceOf(NumberFormatException.class);
    }
}
