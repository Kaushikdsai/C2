package com.curonex.pharmacy.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.curonex.pharmacy.enums.OrderStatusEnum;

/**
 * Generic getter/setter round-trip coverage for the plain-data DTOs in this
 * package. These classes have no logic of their own (just field storage),
 * so hand-writing one test method per getter/setter pair across 40+ files
 * adds no real verification value beyond "does this compile and store what
 * I put in it" - this single parameterized test exercises that same
 * guarantee across every listed class without the maintenance overhead of
 * 40+ near-identical test files. Any DTO that DOES gain real logic later
 * (validation, computed fields, etc.) should get its own dedicated test
 * class instead of relying on this generic pass.
 */
class DtoGetterSetterCoverageTest {

    @ParameterizedTest
    @ValueSource(classes = {
            OrderItemDTO.class, OrderResponseDTO.class, OrderTrackingDTO.class,
            OrderCreateItemDTO.class, OrderCreateRequestDTO.class, OrderSummaryDTO.class,
            PatientDetailsUpdateDTO.class, PharmacyDTO.class, PharmacyDashboardDTO.class,
            PharmacyProfileDTO.class, PharmacyAcceptItemDTO.class, PharmacyAcceptRequestDTO.class,
            PharmacyPartialAcceptRequestDTO.class, PharmacyStopDTO.class,
            DeliveryPartnerDTO.class, DeliveryPartnerDashboardDTO.class, DeliveryPartnerProfileDTO.class,
            AvailableOrderDTO.class, ActiveDeliveryDTO.class, AvailablePartialOrderDTO.class,
            MissingItemDTO.class, PrescriptionsDTO.class, PrescriptionMedicinesDTO.class,
            ExtractedMedicineDTO.class, OrderFeedbackRequestDTO.class, OrderFeedbackResponseDTO.class,
            OrderStatusHistoryDTO.class, RatingRequestDTO.class, DetailsDTO.class, CoordinateDTO.class
    })
    void gettersAndSettersRoundTripCorrectly(Class<?> dtoClass) throws Exception {
        Object instance = dtoClass.getDeclaredConstructor().newInstance();

        for (Method setter : dtoClass.getMethods()) {
            if (!setter.getName().startsWith("set") || setter.getParameterCount() != 1) {
                continue;
            }
            Class<?> paramType = setter.getParameterTypes()[0];
            Object value = sampleValueFor(paramType);
            if (value == null && !paramType.isPrimitive()) {
                continue; // unsupported type for this generic pass (e.g. nested DTOs, lists of objects) - skip safely
            }

            setter.invoke(instance, value);

            String getterName = "get" + setter.getName().substring(3);
            Method getter = findGetter(dtoClass, getterName, paramType);
            if (getter != null) {
                Object result = getter.invoke(instance);
                if (!paramType.isPrimitive()) {
                    assertThat(result).isEqualTo(value);
                }
            }
        }
    }

    private Method findGetter(Class<?> clazz, String name, Class<?> type) {
        try {
            return clazz.getMethod(name);
        } catch (NoSuchMethodException e) {
            // boolean fields sometimes expose isX() instead of getX()
            try {
                return clazz.getMethod("is" + name.substring(3));
            } catch (NoSuchMethodException ignored) {
                return null;
            }
        }
    }

    private Object sampleValueFor(Class<?> type) {
        if (type == String.class) return "sample";
        if (type == Long.class || type == long.class) return 1L;
        if (type == Integer.class || type == int.class) return 1;
        if (type == Double.class || type == double.class) return 1.0;
        if (type == Boolean.class || type == boolean.class) return true;
        if (type == BigDecimal.class) return BigDecimal.TEN;
        if (type == Timestamp.class) return new Timestamp(System.currentTimeMillis());
        if (type == OrderStatusEnum.class) return OrderStatusEnum.PENDING;
        if (type == List.class) return List.of();
        return null;
    }
}
