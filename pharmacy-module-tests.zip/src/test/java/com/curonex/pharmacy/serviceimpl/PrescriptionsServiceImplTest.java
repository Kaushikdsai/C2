package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.dto.PrescriptionsDTO;
import com.curonex.pharmacy.entity.Prescriptions;
import com.curonex.pharmacy.exceptions.PrescriptionNotFoundException;
import com.curonex.pharmacy.repository.PrescriptionsRepository;

@ExtendWith(MockitoExtension.class)
class PrescriptionsServiceImplTest {

    @Mock private PrescriptionsRepository repository;
    @InjectMocks private PrescriptionsServiceImpl service;

    @Test
    void addPrescription_missingPatientName_throws() {
        PrescriptionsDTO dto = validDto();
        dto.setPatientName(null);

        assertThatThrownBy(() -> service.addPrescription(dto))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void addPrescription_blankPatientName_throws() {
        PrescriptionsDTO dto = validDto();
        dto.setPatientName("   ");

        assertThatThrownBy(() -> service.addPrescription(dto))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void addPrescription_missingPatientPhone_throws() {
        PrescriptionsDTO dto = validDto();
        dto.setPatientPhone(null);

        assertThatThrownBy(() -> service.addPrescription(dto))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void addPrescription_valid_savesAsNotDeleted() {
        PrescriptionsDTO dto = validDto();
        when(repository.save(any(Prescriptions.class))).thenAnswer(inv -> {
            Prescriptions p = inv.getArgument(0);
            p.setPrescriptionId(10L);
            return p;
        });

        PrescriptionsDTO result = service.addPrescription(dto);

        assertThat(result.getPrescriptionId()).isEqualTo(10L);
        assertThat(result.getPatientName()).isEqualTo("Test Patient");
    }

    @Test
    void getPrescriptionById_notFound_throws() {
        when(repository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> service.getPrescriptionById(99L))
                .isInstanceOf(PrescriptionNotFoundException.class);
    }

    @Test
    void getPrescriptionById_found_returnsMappedDto() {
        Prescriptions p = new Prescriptions();
        p.setPrescriptionId(10L);
        p.setPatientName("Test Patient");
        p.setPatientPhone("1234567890");
        when(repository.findById(10L)).thenReturn(Optional.of(p));

        PrescriptionsDTO result = service.getPrescriptionById(10L);
        assertThat(result.getPrescriptionId()).isEqualTo(10L);
    }

    @Test
    void getAllPrescriptions_returnsOnlyNonDeleted() {
        Prescriptions p = new Prescriptions();
        p.setPrescriptionId(10L);
        when(repository.findByIsDeletedFalse()).thenReturn(List.of(p));

        assertThat(service.getAllPrescriptions()).hasSize(1);
    }

    @Test
    void updatePrescription_notFound_throws() {
        when(repository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> service.updatePrescription(99L, validDto()))
                .isInstanceOf(PrescriptionNotFoundException.class);
    }

    @Test
    void updatePrescription_invalidPatientDetails_throwsBeforeTouchingRepository() {
        PrescriptionsDTO dto = validDto();
        dto.setPatientPhone(null);

        assertThatThrownBy(() -> service.updatePrescription(10L, dto))
                .isInstanceOf(IllegalArgumentException.class);
        verify(repository, never()).findById(anyLong());
    }

    @Test
    void updatePrescription_valid_updatesAllFields() {
        Prescriptions existing = new Prescriptions();
        existing.setPrescriptionId(10L);
        when(repository.findById(10L)).thenReturn(Optional.of(existing));
        when(repository.save(existing)).thenReturn(existing);

        PrescriptionsDTO dto = validDto();
        dto.setPatientName("Updated Name");
        dto.setPatientRelationship("Mother");

        PrescriptionsDTO result = service.updatePrescription(10L, dto);

        assertThat(existing.getPatientName()).isEqualTo("Updated Name");
        assertThat(existing.getPatientRelationship()).isEqualTo("Mother");
    }

    @Test
    void deletePrescription_notFound_throws() {
        when(repository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> service.deletePrescription(99L))
                .isInstanceOf(PrescriptionNotFoundException.class);
    }

    @Test
    void deletePrescription_softDeletesOnly() {
        Prescriptions existing = new Prescriptions();
        existing.setPrescriptionId(10L);
        when(repository.findById(10L)).thenReturn(Optional.of(existing));

        service.deletePrescription(10L);

        assertThat(existing.getIsDeleted()).isTrue();
        verify(repository).save(existing);
        verify(repository, never()).delete(any());
        verify(repository, never()).deleteById(anyLong());
    }

    @Test
    void getPrescriptionsByUser_delegatesToRepository() {
        Prescriptions p = new Prescriptions();
        p.setPrescriptionId(10L);
        when(repository.findByUserIdAndIsDeletedFalse(41L)).thenReturn(List.of(p));

        assertThat(service.getPrescriptionsByUser(41L)).hasSize(1);
    }

    private PrescriptionsDTO validDto() {
        PrescriptionsDTO dto = new PrescriptionsDTO();
        dto.setUserId(41L);
        dto.setHospitalId(12L);
        dto.setDoctorId(501L);
        dto.setPatientName("Test Patient");
        dto.setPatientPhone("1234567890");
        dto.setPatientRelationship("Self");
        return dto;
    }
}
