package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.dto.PrescriptionMedicinesDTO;
import com.curonex.pharmacy.entity.PrescriptionMedicineId;
import com.curonex.pharmacy.entity.PrescriptionMedicines;
import com.curonex.pharmacy.exceptions.PrescriptionQuantityExceededException;
import com.curonex.pharmacy.repository.PrescriptionMedicinesRepository;

@ExtendWith(MockitoExtension.class)
class PrescriptionMedicinesServiceImplTest {

    @Mock private PrescriptionMedicinesRepository repository;
    @InjectMocks private PrescriptionMedicinesServiceImpl service;

    @Test
    void addMedicine_negativeQuantity_throws() {
        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setMedicineName("Paracetamol");
        dto.setPrescribedQuantity(-1);

        assertThatThrownBy(() -> service.addMedicine(10L, dto))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void addMedicine_valid_setsSelectedEqualToPrescribed() {
        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setMedicineName("Paracetamol");
        dto.setPrescribedQuantity(10);

        when(repository.save(org.mockito.ArgumentMatchers.any(PrescriptionMedicines.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        PrescriptionMedicinesDTO result = service.addMedicine(10L, dto);

        assertThat(result.getPrescribedQuantity()).isEqualTo(10);
        assertThat(result.getSelectedQuantity()).isEqualTo(10);
    }

    @Test
    void getMedicinesByPrescription_mapsAllRows() {
        PrescriptionMedicines med = new PrescriptionMedicines();
        med.setId(new PrescriptionMedicineId(10L, "Paracetamol"));
        med.setPrescribedQuantity(10);
        med.setSelectedQuantity(8);
        when(repository.findByIdPrescriptionId(10L)).thenReturn(List.of(med));

        List<PrescriptionMedicinesDTO> result = service.getMedicinesByPrescription(10L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getSelectedQuantity()).isEqualTo(8);
    }

    @Test
    void updateMedicine_notFound_throwsRuntimeException() {
        PrescriptionMedicineId id = new PrescriptionMedicineId(10L, "Paracetamol");
        when(repository.findById(id)).thenReturn(Optional.empty());

        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setSelectedQuantity(5);

        assertThatThrownBy(() -> service.updateMedicine(10L, "Paracetamol", dto))
                .isInstanceOf(RuntimeException.class);
    }

    @Test
    void updateMedicine_negativeQuantity_throws() {
        PrescriptionMedicineId id = new PrescriptionMedicineId(10L, "Paracetamol");
        PrescriptionMedicines existing = new PrescriptionMedicines();
        existing.setId(id);
        existing.setPrescribedQuantity(10);
        existing.setSelectedQuantity(10);
        when(repository.findById(id)).thenReturn(Optional.of(existing));

        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setSelectedQuantity(-1);

        assertThatThrownBy(() -> service.updateMedicine(10L, "Paracetamol", dto))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void updateMedicine_exceedsCeiling_throwsPrescriptionQuantityExceeded() {
        PrescriptionMedicineId id = new PrescriptionMedicineId(10L, "Paracetamol");
        PrescriptionMedicines existing = new PrescriptionMedicines();
        existing.setId(id);
        existing.setPrescribedQuantity(10);
        existing.setSelectedQuantity(5);
        when(repository.findById(id)).thenReturn(Optional.of(existing));

        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setSelectedQuantity(15); // exceeds prescribedQuantity=10

        assertThatThrownBy(() -> service.updateMedicine(10L, "Paracetamol", dto))
                .isInstanceOf(PrescriptionQuantityExceededException.class);

        // Critical regression guard - the whole bug that started this: ceiling must never move.
        assertThat(existing.getPrescribedQuantity()).isEqualTo(10);
    }

    @Test
    void updateMedicine_canIncreaseBackUpToCeiling_afterPriorDecrease() {
        // Regression test for the original bug: patient decreases then wants to increase again.
        PrescriptionMedicineId id = new PrescriptionMedicineId(10L, "Paracetamol");
        PrescriptionMedicines existing = new PrescriptionMedicines();
        existing.setId(id);
        existing.setPrescribedQuantity(10);
        existing.setSelectedQuantity(3); // already decreased once
        when(repository.findById(id)).thenReturn(Optional.of(existing));
        when(repository.save(existing)).thenReturn(existing);

        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setSelectedQuantity(10); // increasing back to the full ceiling

        PrescriptionMedicinesDTO result = service.updateMedicine(10L, "Paracetamol", dto);

        assertThat(result.getSelectedQuantity()).isEqualTo(10);
        assertThat(result.getPrescribedQuantity()).isEqualTo(10); // ceiling untouched
    }

    @Test
    void updateMedicine_exactlyAtCeiling_succeeds() {
        PrescriptionMedicineId id = new PrescriptionMedicineId(10L, "Paracetamol");
        PrescriptionMedicines existing = new PrescriptionMedicines();
        existing.setId(id);
        existing.setPrescribedQuantity(10);
        existing.setSelectedQuantity(5);
        when(repository.findById(id)).thenReturn(Optional.of(existing));
        when(repository.save(existing)).thenReturn(existing);

        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setSelectedQuantity(10);

        PrescriptionMedicinesDTO result = service.updateMedicine(10L, "Paracetamol", dto);
        assertThat(result.getSelectedQuantity()).isEqualTo(10);
    }

    @Test
    void updateMedicine_zero_removesItemButKeepsCeiling() {
        PrescriptionMedicineId id = new PrescriptionMedicineId(10L, "Paracetamol");
        PrescriptionMedicines existing = new PrescriptionMedicines();
        existing.setId(id);
        existing.setPrescribedQuantity(10);
        existing.setSelectedQuantity(5);
        when(repository.findById(id)).thenReturn(Optional.of(existing));
        when(repository.save(existing)).thenReturn(existing);

        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setSelectedQuantity(0);

        PrescriptionMedicinesDTO result = service.updateMedicine(10L, "Paracetamol", dto);
        assertThat(result.getSelectedQuantity()).isZero();
        assertThat(result.getPrescribedQuantity()).isEqualTo(10);
    }

    @Test
    void deleteMedicine_delegatesToRepository() {
        service.deleteMedicine(10L, "Paracetamol");
        verify(repository).deleteById(new PrescriptionMedicineId(10L, "Paracetamol"));
    }
}
