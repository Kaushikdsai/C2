package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.dto.OrderFeedbackRequestDTO;
import com.curonex.pharmacy.dto.OrderFeedbackResponseDTO;
import com.curonex.pharmacy.entity.OrderFeedback;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.OrderFeedbackRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.service.DeliveryPartnersService;
import com.curonex.pharmacy.service.PharmacyService;

@ExtendWith(MockitoExtension.class)
class OrderFeedbackServiceImplTest {

    @Mock private OrderFeedbackRepository orderFeedbackRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private PharmacyService pharmacyService;
    @Mock private DeliveryPartnersService deliveryPartnersService;

    @InjectMocks private OrderFeedbackServiceImpl service;

    @Test
    void submitFeedback_orderNotFound_throws() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> service.submitFeedback(1L, requestDto()))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void submitFeedback_orderNotDelivered_throws() {
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.CONFIRMED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> service.submitFeedback(1L, requestDto()))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void submitFeedback_missingPharmacyOrPartnerAssignment_throws() {
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.DELIVERED);
        order.setPharmacyId(null);
        order.setDeliveryPartnerId(700L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> service.submitFeedback(1L, requestDto()))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void submitFeedback_valid_delegatesToBothRatingServicesAndSaves() {
        Orders order = new Orders();
        order.setOrderId(1L);
        order.setStatus(OrderStatusEnum.DELIVERED);
        order.setPharmacyId(50L);
        order.setDeliveryPartnerId(700L);
        order.setPatientName("Test Patient");
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        OrderFeedback saved = new OrderFeedback();
        saved.setOrderId(1L);
        saved.setPharmacyId(50L);
        saved.setDeliveryPartnerId(700L);
        when(orderFeedbackRepository.save(any(OrderFeedback.class))).thenReturn(saved);

        OrderFeedbackResponseDTO result = service.submitFeedback(1L, requestDto());

        assertThat(result.getOrderId()).isEqualTo(1L);
        verify(pharmacyService).submitRating(50L, 1L, BigDecimal.valueOf(4.5));
        verify(deliveryPartnersService).submitRating(700L, 1L, BigDecimal.valueOf(5.0));
    }

    @Test
    void getFeedbackForOrder_notFound_throws() {
        when(orderFeedbackRepository.findByOrderId(1L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> service.getFeedbackForOrder(1L))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void getFeedbackForOrder_found_returnsDto() {
        OrderFeedback feedback = new OrderFeedback();
        feedback.setOrderId(1L);
        when(orderFeedbackRepository.findByOrderId(1L)).thenReturn(Optional.of(feedback));
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        OrderFeedbackResponseDTO result = service.getFeedbackForOrder(1L);
        assertThat(result.getOrderId()).isEqualTo(1L);
    }

    @Test
    void getFeedbackForPharmacy_delegatesAndMaps() {
        OrderFeedback feedback = new OrderFeedback();
        feedback.setOrderId(1L);
        when(orderFeedbackRepository.findByPharmacyIdOrderBySubmittedAtDesc(50L)).thenReturn(List.of(feedback));
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        List<OrderFeedbackResponseDTO> result = service.getFeedbackForPharmacy(50L);
        assertThat(result).hasSize(1);
    }

    @Test
    void getFeedbackForDeliveryPartner_delegatesAndMaps() {
        OrderFeedback feedback = new OrderFeedback();
        feedback.setOrderId(1L);
        when(orderFeedbackRepository.findByDeliveryPartnerIdOrderBySubmittedAtDesc(700L)).thenReturn(List.of(feedback));
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        List<OrderFeedbackResponseDTO> result = service.getFeedbackForDeliveryPartner(700L);
        assertThat(result).hasSize(1);
    }

    private OrderFeedbackRequestDTO requestDto() {
        OrderFeedbackRequestDTO dto = new OrderFeedbackRequestDTO();
        dto.setPharmacyRating(BigDecimal.valueOf(4.5));
        dto.setPharmacyFeedback("Good service");
        dto.setDeliveryRating(BigDecimal.valueOf(5.0));
        dto.setDeliveryFeedback("Fast delivery");
        return dto;
    }
}
