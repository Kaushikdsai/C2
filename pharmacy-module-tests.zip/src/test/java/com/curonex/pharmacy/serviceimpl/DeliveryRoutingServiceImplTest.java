package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.OrderPharmacyAllocation;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.*;
import com.curonex.pharmacy.util.DistanceUtil;
import com.curonex.pharmacy.util.GeoAddressUtil;

@ExtendWith(MockitoExtension.class)
class DeliveryRoutingServiceImplTest {

    @Mock private DeliveryPartnerRepository deliveryPartnerRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private OrderItemRepository orderItemRepository;
    @Mock private PharmacyRepository pharmacyRepository;
    @Mock private OrderPharmacyAllocationRepository orderPharmacyAllocationRepository;
    @Mock private DetailsFeignClient detailsFeignClient;
    @Mock private DistanceUtil distanceUtil;
    @Mock private GeoAddressUtil geoAddressUtil;
    @Mock private OrderDeliveryPartnerRejectionRepository orderDeliveryPartnerRejectionRepository;
    @Mock private ApplicationEventPublisher eventPublisher;

    @InjectMocks private DeliveryRoutingServiceImpl service;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(service, "assumedAverageSpeedKmph", 25.0);
    }

    // ---------- acceptDelivery ----------

    @Test
    void acceptDelivery_alreadyClaimed_throwsConflict() {
        when(orderRepository.acceptOrderByDeliveryPartner(1L, 700L, OrderStatusEnum.CONFIRMED)).thenReturn(0);

        assertThatThrownBy(() -> service.acceptDelivery(1L, 700L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void acceptDelivery_success_marksPartnerOnDeliveryAndPublishesEvent() {
        when(orderRepository.acceptOrderByDeliveryPartner(1L, 700L, OrderStatusEnum.CONFIRMED)).thenReturn(1);

        DeliveryPartners partner = new DeliveryPartners();
        partner.setDeliveryPartnerId(700L);
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));

        Orders order = new Orders();
        order.setOrderId(1L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderPharmacyAllocationRepository.findByOrderIdOrderBySequenceNoAsc(1L)).thenReturn(List.of());

        boolean result = service.acceptDelivery(1L, 700L);

        assertThat(result).isTrue();
        assertThat(partner.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.ON_DELIVERY);
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void acceptDelivery_partnerNotFound_throwsNotFound() {
        when(orderRepository.acceptOrderByDeliveryPartner(1L, 700L, OrderStatusEnum.CONFIRMED)).thenReturn(1);
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.acceptDelivery(1L, 700L))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void acceptDelivery_etaComputedForSingleStop() {
        when(orderRepository.acceptOrderByDeliveryPartner(1L, 700L, OrderStatusEnum.CONFIRMED)).thenReturn(1);

        DeliveryPartners partner = new DeliveryPartners();
        partner.setDeliveryPartnerId(700L);
        partner.setGeoAddress("12.9,77.6");
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));

        Orders order = new Orders();
        order.setOrderId(1L);
        order.setPatientGeoAddress("13.0,77.7");
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        OrderPharmacyAllocation allocation = new OrderPharmacyAllocation();
        allocation.setPharmacyId(50L);
        when(orderPharmacyAllocationRepository.findByOrderIdOrderBySequenceNoAsc(1L)).thenReturn(List.of(allocation));

        Pharmacy pharmacy = new Pharmacy();
        pharmacy.setGeoAddress("12.95,77.65");
        when(pharmacyRepository.findById(50L)).thenReturn(Optional.of(pharmacy));

        com.curonex.pharmacy.dto.CoordinateDTO coord = new com.curonex.pharmacy.dto.CoordinateDTO(12.9, 77.6);
        when(geoAddressUtil.parse(anyString())).thenReturn(coord);
        when(distanceUtil.calculateDistance(anyDouble(), anyDouble(), anyDouble(), anyDouble())).thenReturn(10.0);

        service.acceptDelivery(1L, 700L);

        assertThat(order.getEstimatedDeliveryMinutes()).isNotNull();
        assertThat(order.getEstimatedDeliveryMinutes()).isGreaterThan(0);
    }

    // ---------- cancelDelivery ----------

    @Test
    void cancelDelivery_notAssignedOrPastConfirmed_throws() {
        when(orderRepository.releaseOrderFromDeliveryPartner(1L, 700L, OrderStatusEnum.CONFIRMED)).thenReturn(0);
        assertThatThrownBy(() -> service.cancelDelivery(1L, 700L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void cancelDelivery_success_freesPartnerAndRebroadcasts() {
        when(orderRepository.releaseOrderFromDeliveryPartner(1L, 700L, OrderStatusEnum.CONFIRMED)).thenReturn(1);
        DeliveryPartners partner = new DeliveryPartners();
        partner.setDeliveryPartnerId(700L);
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(new Orders()));

        boolean result = service.cancelDelivery(1L, 700L);

        assertThat(result).isTrue();
        assertThat(partner.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.AVAILABLE);
    }

    // ---------- rejectDelivery ----------

    @Test
    void rejectDelivery_notAlreadyRejected_saves() {
        when(orderDeliveryPartnerRejectionRepository.existsById(any())).thenReturn(false);
        service.rejectDelivery(1L, 700L);
        verify(orderDeliveryPartnerRejectionRepository).save(any());
    }

    // ---------- pickupFromPharmacy ----------

    @Test
    void pickupFromPharmacy_orderNotAssignedToThisPartner_throws() {
        Orders order = new Orders();
        order.setDeliveryPartnerId(999L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> service.pickupFromPharmacy(1L, 700L, 50L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void pickupFromPharmacy_wrongOrderStatus_throws() {
        Orders order = new Orders();
        order.setDeliveryPartnerId(700L);
        order.setStatus(OrderStatusEnum.DELIVERED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> service.pickupFromPharmacy(1L, 700L, 50L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void pickupFromPharmacy_noAllocationForPharmacy_throws() {
        Orders order = new Orders();
        order.setDeliveryPartnerId(700L);
        order.setStatus(OrderStatusEnum.CONFIRMED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderPharmacyAllocationRepository.findByOrderIdAndPharmacyId(1L, 50L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.pickupFromPharmacy(1L, 700L, 50L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void pickupFromPharmacy_singleStop_transitionsToOutForDelivery() {
        Orders order = new Orders();
        order.setOrderId(1L);
        order.setDeliveryPartnerId(700L);
        order.setStatus(OrderStatusEnum.CONFIRMED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        OrderPharmacyAllocation allocation = new OrderPharmacyAllocation();
        when(orderPharmacyAllocationRepository.findByOrderIdAndPharmacyId(1L, 50L)).thenReturn(Optional.of(allocation));
        when(orderPharmacyAllocationRepository.existsByOrderIdAndPickedUpAtIsNull(1L)).thenReturn(false);
        when(orderRepository.pickupOrderByDeliveryPartner(1L, 700L, OrderStatusEnum.OUT_FOR_DELIVERY, OrderStatusEnum.CONFIRMED))
                .thenReturn(1);

        boolean result = service.pickupFromPharmacy(1L, 700L, 50L);

        assertThat(result).isTrue();
        assertThat(allocation.getPickedUpAt()).isNotNull();
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void pickupFromPharmacy_twoStops_stillWaitingOnSecondStop_doesNotTransition() {
        Orders order = new Orders();
        order.setOrderId(1L);
        order.setDeliveryPartnerId(700L);
        order.setStatus(OrderStatusEnum.CONFIRMED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        OrderPharmacyAllocation allocation = new OrderPharmacyAllocation();
        when(orderPharmacyAllocationRepository.findByOrderIdAndPharmacyId(1L, 50L)).thenReturn(Optional.of(allocation));
        when(orderPharmacyAllocationRepository.existsByOrderIdAndPickedUpAtIsNull(1L)).thenReturn(true); // second stop still pending

        boolean result = service.pickupFromPharmacy(1L, 700L, 50L);

        assertThat(result).isTrue();
        verify(orderRepository, never()).pickupOrderByDeliveryPartner(anyLong(), anyLong(), any(), any());
        verify(eventPublisher, never()).publishEvent(any());
    }

    @Test
    void pickupFromPharmacy_alreadyPickedUp_doesNotOverwriteTimestamp() {
        Orders order = new Orders();
        order.setOrderId(1L);
        order.setDeliveryPartnerId(700L);
        order.setStatus(OrderStatusEnum.CONFIRMED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        java.sql.Timestamp originalTimestamp = java.sql.Timestamp.from(java.time.Instant.now().minusSeconds(60));
        OrderPharmacyAllocation allocation = new OrderPharmacyAllocation();
        allocation.setPickedUpAt(originalTimestamp);
        when(orderPharmacyAllocationRepository.findByOrderIdAndPharmacyId(1L, 50L)).thenReturn(Optional.of(allocation));
        when(orderPharmacyAllocationRepository.existsByOrderIdAndPickedUpAtIsNull(1L)).thenReturn(false);
        when(orderRepository.pickupOrderByDeliveryPartner(anyLong(), anyLong(), any(), any())).thenReturn(1);

        service.pickupFromPharmacy(1L, 700L, 50L);

        assertThat(allocation.getPickedUpAt()).isEqualTo(originalTimestamp);
        verify(orderPharmacyAllocationRepository, never()).save(allocation);
    }

    // ---------- markDelivered ----------

    @Test
    void markDelivered_wrongAssignmentOrStatus_throws() {
        when(orderRepository.markDeliveredByDeliveryPartner(1L, 700L, OrderStatusEnum.DELIVERED, OrderStatusEnum.OUT_FOR_DELIVERY))
                .thenReturn(0);

        assertThatThrownBy(() -> service.markDelivered(1L, 700L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void markDelivered_success_freesPartnerAndPublishesEvent() {
        when(orderRepository.markDeliveredByDeliveryPartner(1L, 700L, OrderStatusEnum.DELIVERED, OrderStatusEnum.OUT_FOR_DELIVERY))
                .thenReturn(1);
        DeliveryPartners partner = new DeliveryPartners();
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));

        boolean result = service.markDelivered(1L, 700L);

        assertThat(result).isTrue();
        assertThat(partner.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.AVAILABLE);
        verify(eventPublisher).publishEvent(any());
    }
}
