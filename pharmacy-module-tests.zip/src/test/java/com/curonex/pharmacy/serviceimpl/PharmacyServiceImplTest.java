package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.*;
import com.curonex.pharmacy.entity.*;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;
import com.curonex.pharmacy.exceptions.*;
import com.curonex.pharmacy.repository.*;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.PharmacyRoutingService;

@ExtendWith(MockitoExtension.class)
class PharmacyServiceImplTest {

    @Mock private PharmacyRepository pharmacyRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private OrderItemRepository orderItemRepository;
    @Mock private OrderPharmacyAllocationRepository orderPharmacyAllocationRepository;
    @Mock private DetailsFeignClient detailsFeignClient;
    @Mock private PharmacyRoutingService pharmacyRoutingService;
    @Mock private DeliveryRoutingService deliveryRoutingService;
    @Mock private OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;
    @Mock private ApplicationEventPublisher eventPublisher;

    @InjectMocks private PharmacyServiceImpl pharmacyService;

    private Pharmacy pharmacy;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(pharmacyService, "partialThresholdPercent", 50);
        ReflectionTestUtils.setField(pharmacyService, "priceAcceptanceWindowMinutes", 10L);

        pharmacy = new Pharmacy();
        pharmacy.setId(50L);
        pharmacy.setRating(BigDecimal.ZERO);
        pharmacy.setRatingCount(0);
    }

    // ---------- CRUD ----------

    @Test
    void addPharmacy_savesWithDefaults() {
        PharmacyDTO dto = new PharmacyDTO();
        dto.setLicenseNo("LIC-1");
        when(pharmacyRepository.save(any(Pharmacy.class))).thenAnswer(inv -> inv.getArgument(0));

        PharmacyDTO result = pharmacyService.addPharmacy(dto);

        assertThat(result.getRating()).isEqualTo(BigDecimal.ZERO);
        assertThat(result.getRatingCount()).isEqualTo(0);
    }

    @Test
    void getPharmacyById_notFound_throws() {
        when(pharmacyRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> pharmacyService.getPharmacyById(99L))
                .isInstanceOf(PharmacyNotFoundException.class);
    }

    @Test
    void getPharmacyById_found_returnsDto() {
        when(pharmacyRepository.findById(50L)).thenReturn(Optional.of(pharmacy));
        PharmacyDTO result = pharmacyService.getPharmacyById(50L);
        assertThat(result.getPharmacyId()).isEqualTo(50L);
    }

    @Test
    void deletePharmacy_softDeletesOnly() {
        when(pharmacyRepository.findById(50L)).thenReturn(Optional.of(pharmacy));
        pharmacyService.deletePharmacy(50L);
        assertThat(pharmacy.getIsDeleted()).isTrue();
        verify(pharmacyRepository).save(pharmacy);
    }

    @Test
    void getActivePharmacies_delegatesToRepository() {
        when(pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE)).thenReturn(List.of(pharmacy));
        assertThat(pharmacyService.getActivePharmacies()).hasSize(1);
    }

    // ---------- submitRating ----------

    @Test
    void submitRating_orderNotDelivered_throws() {
        when(pharmacyRepository.findById(50L)).thenReturn(Optional.of(pharmacy));
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.CONFIRMED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> pharmacyService.submitRating(50L, 1L, BigDecimal.valueOf(4)))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void submitRating_notFulfilledByThisPharmacy_throws() {
        when(pharmacyRepository.findById(50L)).thenReturn(Optional.of(pharmacy));
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.DELIVERED);
        order.setPharmacyId(999L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderPharmacyAllocationRepository.findByOrderIdAndPharmacyId(1L, 50L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> pharmacyService.submitRating(50L, 1L, BigDecimal.valueOf(4)))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void submitRating_alreadyRated_throws() {
        when(pharmacyRepository.findById(50L)).thenReturn(Optional.of(pharmacy));
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.DELIVERED);
        order.setPharmacyId(50L);
        order.setPharmacyRated(true);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> pharmacyService.submitRating(50L, 1L, BigDecimal.valueOf(4)))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void submitRating_firstRating_setsAverageDirectly() {
        when(pharmacyRepository.findById(50L)).thenReturn(Optional.of(pharmacy));
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.DELIVERED);
        order.setPharmacyId(50L);
        order.setPharmacyRated(false);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(detailsFeignClient.getDetails(50L)).thenReturn(null);

        pharmacyService.submitRating(50L, 1L, BigDecimal.valueOf(4));

        assertThat(pharmacy.getRating()).isEqualByComparingTo(BigDecimal.valueOf(4.00));
        assertThat(pharmacy.getRatingCount()).isEqualTo(1);
        assertThat(order.getPharmacyRated()).isTrue();
    }

    @Test
    void submitRating_secondRating_averagesCorrectly() {
        pharmacy.setRating(BigDecimal.valueOf(4.00));
        pharmacy.setRatingCount(1);
        when(pharmacyRepository.findById(50L)).thenReturn(Optional.of(pharmacy));
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.DELIVERED);
        order.setPharmacyId(50L);
        order.setPharmacyRated(false);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(detailsFeignClient.getDetails(50L)).thenReturn(null);

        pharmacyService.submitRating(50L, 1L, BigDecimal.valueOf(2));

        // (4*1 + 2) / 2 = 3.00
        assertThat(pharmacy.getRating()).isEqualByComparingTo(BigDecimal.valueOf(3.00));
        assertThat(pharmacy.getRatingCount()).isEqualTo(2);
    }

    // ---------- acceptOrder ----------

    @Test
    void acceptOrder_noItems_throwsNotFound() {
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());
        assertThatThrownBy(() -> pharmacyService.acceptOrder(1L, 50L, new PharmacyAcceptRequestDTO()))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void acceptOrder_missingPriceForItem_throws() {
        OrderItem item = new OrderItem(1L, "Paracetamol", 5, null);
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(pendingOrder()));

        PharmacyAcceptRequestDTO request = new PharmacyAcceptRequestDTO();
        request.setItemPrices(List.of());

        assertThatThrownBy(() -> pharmacyService.acceptOrder(1L, 50L, request))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void acceptOrder_bothCasUpdatesFail_throwsConflict() {
        OrderItem item = new OrderItem(1L, "Paracetamol", 5, null);
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(pendingOrder()));
        when(orderRepository.acceptOrderByPharmacy(eq(1L), eq(50L), any(), any(), any())).thenReturn(0);
        when(orderRepository.acceptOrderByPharmacyOverridingPartial(eq(1L), eq(50L), any(), any(), any())).thenReturn(0);

        assertThatThrownBy(() -> pharmacyService.acceptOrder(1L, 50L, acceptRequest()))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void acceptOrder_successFromPending_savesAllocationAndPublishesEvent() {
        OrderItem item = new OrderItem(1L, "Paracetamol", 5, null);
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(pendingOrder()));
        when(orderRepository.acceptOrderByPharmacy(eq(1L), eq(50L), any(), any(), any())).thenReturn(1);
        when(orderRepository.save(any(Orders.class))).thenAnswer(inv -> inv.getArgument(0));

        OrderPharmacyAllocation savedAllocation = new OrderPharmacyAllocation();
        savedAllocation.setAllocationId(999L);
        when(orderPharmacyAllocationRepository.save(any(OrderPharmacyAllocation.class))).thenReturn(savedAllocation);

        OrderResponseDTO result = pharmacyService.acceptOrder(1L, 50L, acceptRequest());

        assertThat(result).isNotNull();
        verify(eventPublisher).publishEvent(any());
        verify(orderItemRepository).save(item);
        assertThat(item.getAllocationId()).isEqualTo(999L);
    }

    // ---------- rejectOrder / cancelAcceptedOrder ----------

    @Test
    void rejectOrder_notAlreadyRejected_savesRejection() {
        OrderPharmacyRejectionId id = new OrderPharmacyRejectionId(1L, 50L);
        when(orderPharmacyRejectionRepository.existsById(id)).thenReturn(false);

        pharmacyService.rejectOrder(1L, 50L);

        verify(orderPharmacyRejectionRepository).save(any(OrderPharmacyRejection.class));
    }

    @Test
    void rejectOrder_alreadyRejected_doesNotSaveDuplicate() {
        OrderPharmacyRejectionId id = new OrderPharmacyRejectionId(1L, 50L);
        when(orderPharmacyRejectionRepository.existsById(id)).thenReturn(true);

        pharmacyService.rejectOrder(1L, 50L);

        verify(orderPharmacyRejectionRepository, never()).save(any());
    }

    @Test
    void cancelAcceptedOrder_notHeldByThisPharmacy_throws() {
        Orders order = new Orders();
        order.setPharmacyId(999L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> pharmacyService.cancelAcceptedOrder(1L, 50L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void cancelAcceptedOrder_deliveryPartnerAlreadyAssigned_throws() {
        Orders order = new Orders();
        order.setPharmacyId(50L);
        order.setStatus(OrderStatusEnum.PHARMACY_CONFIRMED);
        order.setDeliveryPartnerId(777L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> pharmacyService.cancelAcceptedOrder(1L, 50L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void cancelAcceptedOrder_valid_resetsOrderAndRebroadcasts() {
        Orders order = new Orders();
        order.setOrderId(1L);
        order.setPharmacyId(50L);
        order.setStatus(OrderStatusEnum.PHARMACY_CONFIRMED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());

        boolean result = pharmacyService.cancelAcceptedOrder(1L, 50L);

        assertThat(result).isTrue();
        assertThat(order.getStatus()).isEqualTo(OrderStatusEnum.PENDING);
        assertThat(order.getPharmacyId()).isNull();
        verify(pharmacyRoutingService).rebroadcastOrder(1L);
        verify(orderPharmacyAllocationRepository).deleteByOrderId(1L);
    }

    // ---------- helpers ----------

    private Orders pendingOrder() {
        Orders order = new Orders();
        order.setOrderId(1L);
        order.setStatus(OrderStatusEnum.PENDING);
        return order;
    }

    private PharmacyAcceptRequestDTO acceptRequest() {
        PharmacyAcceptItemDTO item = new PharmacyAcceptItemDTO();
        item.setMedicineName("Paracetamol");
        item.setPrice(BigDecimal.TEN);
        PharmacyAcceptRequestDTO request = new PharmacyAcceptRequestDTO();
        request.setItemPrices(List.of(item));
        return request;
    }
}
