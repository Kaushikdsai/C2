package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.PharmacyAcceptItemDTO;
import com.curonex.pharmacy.dto.PharmacyPartialAcceptRequestDTO;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.OrderPharmacyAllocation;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.*;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.PharmacyRoutingService;

/**
 * Separate test class for acceptPartialOrder() / claimFirstPartial() /
 * completeSecondPartial() - the riskiest logic in the module (item 5/7),
 * kept isolated from PharmacyServiceImplTest for readability given how many
 * branches this one method fans out into.
 */
@ExtendWith(MockitoExtension.class)
class PharmacyServiceImplPartialTest {

    @Mock private PharmacyRepository pharmacyRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private OrderItemRepository orderItemRepository;
    @Mock private OrderPharmacyAllocationRepository orderPharmacyAllocationRepository;
    @Mock private DetailsFeignClient detailsFeignClient;
    @Mock private PharmacyRoutingService pharmacyRoutingService;
    @Mock private DeliveryRoutingService deliveryRoutingService;
    @Mock private OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;
    @Mock private ApplicationEventPublisher eventPublisher;

    @InjectMocks private PharmacyServiceImpl pharmacyService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(pharmacyService, "partialThresholdPercent", 50);
        ReflectionTestUtils.setField(pharmacyService, "priceAcceptanceWindowMinutes", 10L);
    }

    @Test
    void acceptPartialOrder_orderNotFound_throws() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> pharmacyService.acceptPartialOrder(1L, 50L, new PharmacyPartialAcceptRequestDTO()))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void acceptPartialOrder_noItems_throws() {
        when(orderRepository.findById(1L)).thenReturn(Optional.of(new Orders()));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());
        assertThatThrownBy(() -> pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Paracetamol", 5)))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void acceptPartialOrder_orderNeitherPendingNorPartial_throwsConflict() {
        Orders order = orderWithStatus(OrderStatusEnum.DELIVERED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item("Paracetamol", null)));

        assertThatThrownBy(() -> pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Paracetamol", 5)))
                .isInstanceOf(OrderConflictException.class);
    }

    // ---------- claimFirstPartial (order PENDING) ----------

    @Test
    void claimFirstPartial_medicineNotOnOrder_throws() {
        Orders order = orderWithStatus(OrderStatusEnum.PENDING);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item("Paracetamol", null)));

        assertThatThrownBy(() -> pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Azithromycin", 5)))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void claimFirstPartial_belowThreshold_throwsConflict() {
        Orders order = orderWithStatus(OrderStatusEnum.PENDING);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        // 1 of 4 items = 25% < 50% threshold
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(
                item("Paracetamol", null), item("Azithromycin", null), item("Cetirizine", null), item("Ibuprofen", null)));

        assertThatThrownBy(() -> pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Paracetamol", 5)))
                .isInstanceOf(OrderConflictException.class)
                .hasMessageContaining("50%");
    }

    @Test
    void claimFirstPartial_casUpdateFails_throwsConflict() {
        Orders order = orderWithStatus(OrderStatusEnum.PENDING);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item("Paracetamol", null)));
        when(orderRepository.claimPartialOrder(eq(1L), eq(50L), any(), any())).thenReturn(0);

        assertThatThrownBy(() -> pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Paracetamol", 5)))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void claimFirstPartial_success_allocatesOnlyDeclaredItems() {
        Orders order = orderWithStatus(OrderStatusEnum.PENDING);
        OrderItem paracetamol = item("Paracetamol", null);
        OrderItem azithromycin = item("Azithromycin", null);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(paracetamol, azithromycin));
        when(orderRepository.claimPartialOrder(eq(1L), eq(50L), any(), any())).thenReturn(1);

        OrderPharmacyAllocation savedAllocation = new OrderPharmacyAllocation();
        savedAllocation.setAllocationId(111L);
        when(orderPharmacyAllocationRepository.save(any(OrderPharmacyAllocation.class))).thenReturn(savedAllocation);

        pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Paracetamol", 5));

        assertThat(paracetamol.getAllocationId()).isEqualTo(111L);
        assertThat(azithromycin.getAllocationId()).isNull(); // untouched - not declared
        verify(eventPublisher).publishEvent(any());
    }

    // ---------- completeSecondPartial (order PARTIALLY_ALLOCATED) ----------

    @Test
    void completeSecondPartial_samePharmacyAsFirst_throwsConflict() {
        Orders order = orderWithStatus(OrderStatusEnum.PARTIALLY_ALLOCATED);
        order.setPharmacyId(50L); // same pharmacy trying to complete its own partial
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item("Paracetamol", 1L)));

        assertThatThrownBy(() -> pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Azithromycin", 5)))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void completeSecondPartial_doesNotCoverExactRemainder_throws() {
        Orders order = orderWithStatus(OrderStatusEnum.PARTIALLY_ALLOCATED);
        order.setPharmacyId(999L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        // Paracetamol already allocated (allocationId=1), Azithromycin + Cetirizine still unallocated
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(
                item("Paracetamol", 1L), item("Azithromycin", null), item("Cetirizine", null)));

        // Only declares Azithromycin, not the full remainder (Cetirizine missing)
        assertThatThrownBy(() -> pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Azithromycin", 5)))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void completeSecondPartial_casUpdateFails_throwsConflict() {
        Orders order = orderWithStatus(OrderStatusEnum.PARTIALLY_ALLOCATED);
        order.setPharmacyId(999L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(
                item("Paracetamol", 1L), item("Azithromycin", null)));
        when(orderRepository.completeWithSecondPharmacy(eq(1L), any(), any(), any(), any())).thenReturn(0);

        assertThatThrownBy(() -> pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Azithromycin", 5)))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void completeSecondPartial_success_allocatesRemainderAndMovesToPharmacyConfirmed() {
        Orders order = orderWithStatus(OrderStatusEnum.PARTIALLY_ALLOCATED);
        order.setPharmacyId(999L);
        OrderItem paracetamol = item("Paracetamol", 1L);
        paracetamol.setPrice(BigDecimal.TEN);
        paracetamol.setQuantity(2);
        OrderItem azithromycin = item("Azithromycin", null);
        azithromycin.setQuantity(3);

        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(paracetamol, azithromycin));
        when(orderRepository.completeWithSecondPharmacy(eq(1L), any(), any(), any(), any())).thenReturn(1);

        OrderPharmacyAllocation savedAllocation = new OrderPharmacyAllocation();
        savedAllocation.setAllocationId(222L);
        savedAllocation.setSequenceNo(2);
        when(orderPharmacyAllocationRepository.save(any(OrderPharmacyAllocation.class))).thenReturn(savedAllocation);

        pharmacyService.acceptPartialOrder(1L, 50L, requestFor("Azithromycin", 5));

        assertThat(azithromycin.getAllocationId()).isEqualTo(222L);
        assertThat(paracetamol.getAllocationId()).isEqualTo(1L); // unchanged - already allocated
        verify(eventPublisher).publishEvent(any());
    }

    // ---------- helpers ----------

    private Orders orderWithStatus(OrderStatusEnum status) {
        Orders order = new Orders();
        order.setOrderId(1L);
        order.setStatus(status);
        return order;
    }

    private OrderItem item(String name, Long allocationId) {
        OrderItem item = new OrderItem(1L, name, 5, null);
        item.setAllocationId(allocationId);
        return item;
    }

    private PharmacyPartialAcceptRequestDTO requestFor(String medicineName, double price) {
        PharmacyAcceptItemDTO item = new PharmacyAcceptItemDTO();
        item.setMedicineName(medicineName);
        item.setPrice(BigDecimal.valueOf(price));
        PharmacyPartialAcceptRequestDTO request = new PharmacyPartialAcceptRequestDTO();
        request.setItemPrices(List.of(item));
        return request;
    }
}
