package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DeliveryPartnerDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerDashboardDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.exceptions.DeliveryPartnerNotFoundException;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.OrderRepository;

@ExtendWith(MockitoExtension.class)
class DeliveryPartnersServiceImplTest {

    @Mock private DeliveryPartnerRepository deliveryPartnerRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private DetailsFeignClient detailsFeignClient;

    @InjectMocks private DeliveryPartnersServiceImpl service;

    private DeliveryPartners partner;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(service, "commissionRate", BigDecimal.valueOf(0.1));
        partner = new DeliveryPartners();
        partner.setDeliveryPartnerId(700L);
        partner.setRating(BigDecimal.ZERO);
        partner.setRatingCount(0);
    }

    @Test
    void getDeliveryPartnerById_notFound_throws() {
        when(deliveryPartnerRepository.findById(999L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> service.getDeliveryPartnerById(999L))
                .isInstanceOf(DeliveryPartnerNotFoundException.class);
    }

    @Test
    void markAvailable_updatesStatusAndReturnsTrue() {
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));
        boolean result = service.markAvailable(700L);
        assertThat(result).isTrue();
        assertThat(partner.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.AVAILABLE);
        verify(deliveryPartnerRepository).save(partner);
    }

    @Test
    void markOnDelivery_updatesStatus() {
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));
        service.markOnDelivery(700L);
        assertThat(partner.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.ON_DELIVERY);
    }

    @Test
    void markOffline_updatesStatus() {
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));
        service.markOffline(700L);
        assertThat(partner.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.OFFLINE);
    }

    // ---------- submitRating ----------

    @Test
    void submitRating_orderNotDelivered_throws() {
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.CONFIRMED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> service.submitRating(700L, 1L, BigDecimal.valueOf(5)))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void submitRating_wrongDeliveryPartner_throws() {
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.DELIVERED);
        order.setDeliveryPartnerId(999L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> service.submitRating(700L, 1L, BigDecimal.valueOf(5)))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void submitRating_alreadyRated_throws() {
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.DELIVERED);
        order.setDeliveryPartnerId(700L);
        order.setDeliveryPartnerRated(true);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> service.submitRating(700L, 1L, BigDecimal.valueOf(5)))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void submitRating_valid_updatesRunningAverage() {
        partner.setRating(BigDecimal.valueOf(4.00));
        partner.setRatingCount(1);
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));
        Orders order = new Orders();
        order.setStatus(OrderStatusEnum.DELIVERED);
        order.setDeliveryPartnerId(700L);
        order.setDeliveryPartnerRated(false);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(detailsFeignClient.getDetails(700L)).thenReturn(null);

        service.submitRating(700L, 1L, BigDecimal.valueOf(2));

        assertThat(partner.getRating()).isEqualByComparingTo(BigDecimal.valueOf(3.00));
        assertThat(order.getDeliveryPartnerRated()).isTrue();
    }

    // ---------- getDashboard ----------

    @Test
    void getDashboard_aggregatesCountsAndEarningsCorrectly() {
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));

        Orders confirmed = deliveredLikeOrder(OrderStatusEnum.CONFIRMED, null, null);
        Orders outForDelivery = deliveredLikeOrder(OrderStatusEnum.OUT_FOR_DELIVERY, null, null);
        Orders delivered = deliveredLikeOrder(OrderStatusEnum.DELIVERED, Timestamp.from(Instant.now()), BigDecimal.valueOf(100));

        when(orderRepository.findByDeliveryPartnerId(700L)).thenReturn(List.of(confirmed, outForDelivery, delivered));

        DeliveryPartnerDashboardDTO dto = service.getDashboard(700L);

        assertThat(dto.getPendingPickups()).isEqualTo(1);
        assertThat(dto.getOutForDeliveryCount()).isEqualTo(1);
        assertThat(dto.getCompletedCount()).isEqualTo(1);
        assertThat(dto.getTodaysEarnings()).isEqualByComparingTo(BigDecimal.valueOf(10.0)); // 10% of 100
    }

    @Test
    void getDashboard_noOrders_returnsZeroedDto() {
        when(deliveryPartnerRepository.findById(700L)).thenReturn(Optional.of(partner));
        when(orderRepository.findByDeliveryPartnerId(700L)).thenReturn(List.of());

        DeliveryPartnerDashboardDTO dto = service.getDashboard(700L);

        assertThat(dto.getCompletedCount()).isZero();
        assertThat(dto.getTodaysEarnings()).isEqualByComparingTo(BigDecimal.ZERO);
    }

    private Orders deliveredLikeOrder(OrderStatusEnum status, Timestamp deliveredAt, BigDecimal totalAmount) {
        Orders order = new Orders();
        order.setStatus(status);
        order.setOrderDatetime(Timestamp.from(Instant.now()));
        order.setDeliveredAt(deliveredAt);
        order.setTotalAmount(totalAmount);
        return order;
    }
}
