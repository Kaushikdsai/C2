# Test suite - pharmacy + order + delivery-partner module

## How to use this

1. Copy the `src/test/java/com/curonex/pharmacy/` tree into your project's
   `pharmacy-service/src/test/java/com/curonex/pharmacy/`, merging folder
   by folder (don't overwrite `src/main`, this only adds `src/test`).
2. Add the JaCoCo plugin block below to your `pom.xml`.
3. Run `mvn test` from `pharmacy-service/`.
4. Open `target/site/jacoco/index.html` in a browser for the real,
   measured per-class and overall line-coverage percentages.

## Honest scope note - please read before assuming 95%+ is already hit

This sandbox cannot reach Maven Central (confirmed directly - a request to
`repo.maven.apache.org` returns `403 host_not_allowed`), so **none of this
has actually been compiled or run**. Every test here was written by reading
the exact source of the class it targets and reasoning through each branch
by hand - not verified by an actual test run. Run `mvn test` yourself
before trusting any number.

What's covered, with real branch-level tests (happy path + every
error/conflict branch, not just one smoke test per class):
- `OrderServiceImpl` - createOrder, getOrderById, updatePatientDetails,
  acceptPrice, cancelOrder, getOrderTracking
- `PharmacyServiceImpl` - CRUD, submitRating, acceptOrder (both CAS paths)
- `PharmacyServiceImpl` partial fulfillment - claimFirstPartial and
  completeSecondPartial specifically, since that's the highest-risk logic
  in the whole module (separate test file, `PharmacyServiceImplPartialTest`)
- `DeliveryPartnersServiceImpl` - status transitions, submitRating,
  getDashboard aggregation math
- `DeliveryRoutingServiceImpl` - acceptDelivery + ETA calculation,
  cancelDelivery, pickupFromPharmacy (including the single-stop vs.
  still-waiting-on-second-stop branch, and the already-picked-up
  idempotency guard)
- `OrderFeedbackServiceImpl` - all four public methods
- `PrescriptionsServiceImpl` - all public methods including the patient-
  details validation guard
- `PrescriptionMedicinesServiceImpl` - includes explicit regression tests
  for the original quantity-ceiling bug (decrease then increase back up,
  exceed-the-ceiling rejection, ceiling never moves)
- `OrderController`, `PharmacyController`, `DeliveryPartnersController` -
  every endpoint, confirming correct delegation + HTTP status
- `DistanceUtil`, `GeoAddressUtil`, `PrescriptionParserUtil` - pure logic,
  every branch including malformed input
- All plain-data DTOs - one generic reflection-based getter/setter
  round-trip test (`DtoGetterSetterCoverageTest`) instead of 40+ near-
  identical hand-written files

## NOT covered - you'll need to add these yourself

- Prescription-verification classes were deliberately excluded, since you
  removed that feature from the project - testing dead code wouldn't help
  your real coverage number.
- Repository interfaces (Spring Data - no logic to unit test; these need
  `@DataJpaTest` + an embedded DB if you want them counted, which is a
  different kind of test than what's here).
- `OrderFeedbackController`, remaining `PharmacyController`/
  `DeliveryPartnersController` endpoints not listed above (profile
  get/update, getActivePharmacies, updatePharmacy, getOrderHistory) -
  same pattern as the ones already written, just not yet written out.
- Entities - mostly JPA annotation holders; low value to unit test beyond
  what the generic DTO test already demonstrates the pattern for.
- `OrderRetryScheduler`, `PrescriptionExtractionServiceImpl`,
  `NotificationServiceImpl` - not covered in this pass.

## pom.xml addition (JaCoCo)

Add this inside `<build><plugins>` in `pharmacy-service/pom.xml`:

```xml
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <version>0.8.12</version>
    <executions>
        <execution>
            <goals><goal>prepare-agent</goal></goals>
        </execution>
        <execution>
            <id>report</id>
            <phase>test</phase>
            <goals><goal>report</goal></goals>
        </execution>
        <execution>
            <id>jacoco-check</id>
            <goals><goal>check</goal></goals>
            <configuration>
                <rules>
                    <rule>
                        <element>CLASS</element>
                        <limits>
                            <limit>
                                <counter>LINE</counter>
                                <minimum>0.95</minimum>
                            </limit>
                        </limits>
                    </rule>
                </rules>
            </configuration>
        </execution>
    </executions>
</plugin>
```

And confirm this is in `<dependencies>` (usually already present in a
Spring Boot project):

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
```
