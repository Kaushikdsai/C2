package com.curonex.pharmacy.util;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

/**
 * Tracks which pharmacies have declined which orders, so a rejected order
 * stops appearing in that specific pharmacy's "available orders" list.
 *
 * NOTE: in-memory only - there is no "pharmacy_order_rejection" table in the
 * approved schema, so this does not survive an application restart. A
 * restart means a previously-declined order could reappear for that
 * pharmacy. Acceptable for this project; a production system would persist
 * this in a real table.
 */
@Component
public class OrderRejectionTracker {

    private final Set<String> rejections = ConcurrentHashMap.newKeySet();

    public void reject(Long orderId, Long pharmacyId) {
        rejections.add(key(orderId, pharmacyId));
    }

    public boolean isRejectedBy(Long orderId, Long pharmacyId) {
        return rejections.contains(key(orderId, pharmacyId));
    }

    /** Called when an order is claimed/cancelled/deleted so the tracker doesn't leak memory forever. */
    public void clear(Long orderId) {
        rejections.removeIf(k -> k.startsWith(orderId + ":"));
    }

    private String key(Long orderId, Long pharmacyId) {
        return orderId + ":" + pharmacyId;
    }
}
