package com.curonex.pharmacy.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;

@Repository
public interface OrderRepository extends JpaRepository<Orders, Long> {

    List<Orders> findByUserId(Long userId);

    List<Orders> findByPharmacyId(Long pharmacyId);

    List<Orders> findByStatus(OrderStatusEnum status);

    List<Orders> findByPharmacyIdAndStatus(Long pharmacyId, OrderStatusEnum status);

    List<Orders> findByDeliveryPartnerId(Long deliveryPartnerId);

    List<Orders> findByDeliveryPartnerIdAndStatus(Long deliveryPartnerId, OrderStatusEnum status);

    List<Orders> findByStatusAndPharmacyIdIsNull(OrderStatusEnum status);

    List<Orders> findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum status);

    /** Atomic pharmacy-accept: also stamps confirmedAt. Only succeeds if unclaimed. */
    @Modifying
    @Query("UPDATE Orders o SET o.pharmacyId = :pharmacyId, o.status = :newStatus, o.totalAmount = :totalAmount, "
            + "o.confirmedAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.pharmacyId IS NULL AND o.status = :requiredStatus")
    int acceptOrderByPharmacy(
            @Param("orderId") Long orderId,
            @Param("pharmacyId") Long pharmacyId,
            @Param("totalAmount") BigDecimal totalAmount,
            @Param("newStatus") OrderStatusEnum newStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    @Modifying
    @Query("UPDATE Orders o SET o.deliveryPartnerId = :partnerId "
            + "WHERE o.orderId = :orderId AND o.deliveryPartnerId IS NULL AND o.status = :requiredStatus")
    int acceptOrderByDeliveryPartner(
            @Param("orderId") Long orderId,
            @Param("partnerId") Long partnerId,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    @Modifying
    @Query("UPDATE Orders o SET o.deliveryPartnerId = NULL "
            + "WHERE o.orderId = :orderId AND o.deliveryPartnerId = :partnerId AND o.status = :requiredStatus")
    int releaseOrderFromDeliveryPartner(
            @Param("orderId") Long orderId,
            @Param("partnerId") Long partnerId,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    /** Stamps pickedUpAt. */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :newStatus, o.pickedUpAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.deliveryPartnerId = :partnerId AND o.status = :requiredStatus")
    int pickupOrderByDeliveryPartner(
            @Param("orderId") Long orderId,
            @Param("partnerId") Long partnerId,
            @Param("newStatus") OrderStatusEnum newStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    /** Stamps deliveredAt. */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :newStatus, o.deliveredAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.deliveryPartnerId = :partnerId AND o.status = :requiredStatus")
    int markDeliveredByDeliveryPartner(
            @Param("orderId") Long orderId,
            @Param("partnerId") Long partnerId,
            @Param("newStatus") OrderStatusEnum newStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    /** Cancels an order that hasn't been delivered or already cancelled yet. Stamps cancelledAt. */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :cancelledStatus, o.cancelledAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.status <> :deliveredStatus AND o.status <> :cancelledStatus")
    int cancelOrder(
            @Param("orderId") Long orderId,
            @Param("cancelledStatus") OrderStatusEnum cancelledStatus,
            @Param("deliveredStatus") OrderStatusEnum deliveredStatus);

    /** Marks a delivered order as returned. Only valid on DELIVERED orders not already marked returned. */
    @Modifying
    @Query("UPDATE Orders o SET o.isReturned = true, o.returnedAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.status = :deliveredStatus "
            + "AND (o.isReturned = false OR o.isReturned IS NULL)")
    int markReturned(
            @Param("orderId") Long orderId,
            @Param("deliveredStatus") OrderStatusEnum deliveredStatus);
}
