package com.curonex.pharmacy.serviceimpl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.ActiveDeliveryDTO;
import com.curonex.pharmacy.dto.AvailableOrderDTO;
import com.curonex.pharmacy.dto.CoordinateDTO;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderItemDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.Medicine;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.event.OrderStatusChangedEvent;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.MedicineRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.util.DistanceUtil;
import com.curonex.pharmacy.util.GeoAddressUtil;

@Service
public class DeliveryRoutingServiceImpl implements DeliveryRoutingService {

    private static final double DEFAULT_DELIVERY_RADIUS_KM = 5.0;

    private final DeliveryPartnerRepository deliveryPartnerRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final MedicineRepository medicineRepository;
    private final PharmacyRepository pharmacyRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final DistanceUtil distanceUtil;
    private final GeoAddressUtil geoAddressUtil;
    private final ApplicationEventPublisher eventPublisher;

    public DeliveryRoutingServiceImpl(
            DeliveryPartnerRepository deliveryPartnerRepository,
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            MedicineRepository medicineRepository,
            PharmacyRepository pharmacyRepository,
            DetailsFeignClient detailsFeignClient,
            DistanceUtil distanceUtil,
            GeoAddressUtil geoAddressUtil,
            ApplicationEventPublisher eventPublisher) {

        this.deliveryPartnerRepository = deliveryPartnerRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.medicineRepository = medicineRepository;
        this.pharmacyRepository = pharmacyRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.distanceUtil = distanceUtil;
        this.geoAddressUtil = geoAddressUtil;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public List<DeliveryPartners> findNearbyDeliveryPartners(String geoAddress, double radiusKm) {
        CoordinateDTO source = geoAddressUtil.parse(geoAddress);

        return deliveryPartnerRepository.findByStatus(DeliveryPartnerStatusEnum.AVAILABLE).stream()
                .filter(partner -> {
                    if (partner.getGeoAddress() == null) {
                        return false;
                    }
                    CoordinateDTO destination = geoAddressUtil.parse(partner.getGeoAddress());
                    double distance = distanceUtil.calculateDistance(
                            source.getLatitude(), source.getLongitude(),
                            destination.getLatitude(), destination.getLongitude());
                    return distance <= radiusKm;
                })
                .toList();
    }

    @Override
    @Transactional
    public boolean acceptDelivery(Long orderId, Long deliveryPartnerId) {
        int rowsAffected = orderRepository.acceptOrderByDeliveryPartner(
                orderId, deliveryPartnerId, OrderStatusEnum.CONFIRMED);

        if (rowsAffected == 0) {
            throw new OrderConflictException("Order has already been claimed by another delivery partner.");
        }

        DeliveryPartners partner = deliveryPartnerRepository.findById(deliveryPartnerId)
                .orElseThrow(() -> new OrderNotFoundException("Delivery partner not found: " + deliveryPartnerId));
        partner.setStatus(DeliveryPartnerStatusEnum.ON_DELIVERY);
        deliveryPartnerRepository.save(partner);

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.CONFIRMED, "Delivery partner " + deliveryPartnerId + " assigned"));

        return true;
    }

    @Override
    @Transactional
    public boolean cancelDelivery(Long orderId, Long deliveryPartnerId) {
        int rowsAffected = orderRepository.releaseOrderFromDeliveryPartner(
                orderId, deliveryPartnerId, OrderStatusEnum.CONFIRMED);

        if (rowsAffected == 0) {
            throw new OrderConflictException(
                    "Order is not currently assigned to delivery partner " + deliveryPartnerId + ", or has moved past CONFIRMED.");
        }

        DeliveryPartners partner = deliveryPartnerRepository.findById(deliveryPartnerId).orElse(null);
        if (partner != null) {
            partner.setStatus(DeliveryPartnerStatusEnum.AVAILABLE);
            deliveryPartnerRepository.save(partner);
        }

        rebroadcastOrder(orderId);

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.CONFIRMED, "Delivery partner " + deliveryPartnerId + " cancelled - rebroadcast"));

        return true;
    }

    @Override
    @Transactional
    public boolean pickupOrder(Long orderId, Long deliveryPartnerId) {
        int rowsAffected = orderRepository.pickupOrderByDeliveryPartner(
                orderId, deliveryPartnerId, OrderStatusEnum.OUT_FOR_DELIVERY, OrderStatusEnum.CONFIRMED);

        if (rowsAffected == 0) {
            throw new OrderConflictException("Order cannot be picked up - check assignment/status.");
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.OUT_FOR_DELIVERY, "Order picked up by partner " + deliveryPartnerId));

        return true;
    }

    @Override
    @Transactional
    public boolean markDelivered(Long orderId, Long deliveryPartnerId) {
        int rowsAffected = orderRepository.markDeliveredByDeliveryPartner(
                orderId, deliveryPartnerId, OrderStatusEnum.DELIVERED, OrderStatusEnum.OUT_FOR_DELIVERY);

        if (rowsAffected == 0) {
            throw new OrderConflictException("Order cannot be marked delivered - check assignment/status.");
        }

        DeliveryPartners partner = deliveryPartnerRepository.findById(deliveryPartnerId).orElse(null);
        if (partner != null) {
            partner.setStatus(DeliveryPartnerStatusEnum.AVAILABLE);
            deliveryPartnerRepository.save(partner);
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.DELIVERED, "Order delivered by partner " + deliveryPartnerId));

        return true;
    }

    @Override
    public void broadcastOrder(Long orderId) {
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found: " + orderId));

        if (order.getPharmacyId() == null) {
            return;
        }

        Pharmacy pharmacy = pharmacyRepository.findById(order.getPharmacyId())
                .orElseThrow(() -> new OrderNotFoundException("Pharmacy not found for order: " + orderId));

        List<DeliveryPartners> partners =
                findNearbyDeliveryPartners(pharmacy.getGeoAddress(), DEFAULT_DELIVERY_RADIUS_KM);

        org.slf4j.LoggerFactory.getLogger(DeliveryRoutingServiceImpl.class)
                .info("Order {} broadcast to {} nearby delivery partners", orderId, partners.size());
    }

    @Override
    public void rebroadcastOrder(Long orderId) {
        broadcastOrder(orderId);
    }

    @Override
    public List<AvailableOrderDTO> getAvailableOrdersForPartner(Long deliveryPartnerId) {
        DeliveryPartners partner = deliveryPartnerRepository.findById(deliveryPartnerId).orElse(null);
        if (partner == null || partner.getGeoAddress() == null) {
            return List.of();
        }

        List<Orders> unclaimedOrders =
                orderRepository.findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum.CONFIRMED);

        return unclaimedOrders.stream()
                .filter(order -> order.getPharmacyId() != null)
                .map(order -> {
                    Pharmacy pharmacy = pharmacyRepository.findById(order.getPharmacyId()).orElse(null);
                    if (pharmacy == null || pharmacy.getGeoAddress() == null) {
                        return null;
                    }
                    CoordinateDTO source = geoAddressUtil.parse(partner.getGeoAddress());
                    CoordinateDTO destination = geoAddressUtil.parse(pharmacy.getGeoAddress());
                    double distanceKm = distanceUtil.calculateDistance(
                            source.getLatitude(), source.getLongitude(),
                            destination.getLatitude(), destination.getLongitude());

                    if (distanceKm > DEFAULT_DELIVERY_RADIUS_KM) {
                        return null;
                    }

                    List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
                    DetailsDTO pharmacyDetails = safeFetchDetails(pharmacy.getId());

                    AvailableOrderDTO dto = new AvailableOrderDTO();
                    dto.setOrderId(order.getOrderId());
                    dto.setPharmacyName(pharmacyDetails != null ? pharmacyDetails.getName() : null);
                    dto.setPharmacyGeoAddress(pharmacy.getGeoAddress());
                    dto.setItemCount(items.size());
                    dto.setTotalAmount(order.getTotalAmount());
                    dto.setDistanceKm(distanceKm);
                    return dto;
                })
                .filter(java.util.Objects::nonNull)
                .sorted((a, b) -> Double.compare(a.getDistanceKm(), b.getDistanceKm()))
                .toList();
    }

    @Override
    public List<ActiveDeliveryDTO> getActiveDeliveriesForPartner(Long deliveryPartnerId) {
        List<Orders> orders = orderRepository.findByDeliveryPartnerId(deliveryPartnerId).stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.CONFIRMED || o.getStatus() == OrderStatusEnum.OUT_FOR_DELIVERY)
                .toList();

        return orders.stream().map(order -> {
            List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
            DetailsDTO patientDetails = safeFetchDetails(order.getUserId());
            Pharmacy pharmacy = order.getPharmacyId() != null
                    ? pharmacyRepository.findById(order.getPharmacyId()).orElse(null)
                    : null;
            DetailsDTO pharmacyDetails = pharmacy != null ? safeFetchDetails(pharmacy.getId()) : null;

            ActiveDeliveryDTO dto = new ActiveDeliveryDTO();
            dto.setOrderId(order.getOrderId());
            dto.setStatus(order.getStatus());
            dto.setPatientName(patientDetails != null ? patientDetails.getName() : null);
            dto.setPatientPhone(patientDetails != null ? patientDetails.getPhone() : null);
            dto.setPatientAddress(patientDetails != null ? patientDetails.getAddress() : null);
            dto.setPharmacyName(pharmacyDetails != null ? pharmacyDetails.getName() : null);
            dto.setItemCount(items.size());
            dto.setTotalAmount(order.getTotalAmount());
            return dto;
        }).toList();
    }

    @Override
    public List<OrderResponseDTO> getDeliveryHistoryForPartner(Long deliveryPartnerId) {
        List<Orders> orders = orderRepository.findByDeliveryPartnerIdAndStatus(deliveryPartnerId, OrderStatusEnum.DELIVERED);
        return orders.stream().map(this::toResponseDTO).toList();
    }

    private OrderResponseDTO toResponseDTO(Orders order) {
        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
        Map<Long, String> names = medicineRepository
                .findAllById(items.stream().map(OrderItem::getMedicineId).collect(Collectors.toSet()))
                .stream().collect(Collectors.toMap(Medicine::getMedicineId, Medicine::getName));

        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderId(order.getOrderId());
        dto.setPharmacyId(order.getPharmacyId());
        dto.setDeliveryPartnerId(order.getDeliveryPartnerId());
        dto.setUserId(order.getUserId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());
        dto.setCancelledAt(order.getCancelledAt());
        dto.setIsReturned(order.getIsReturned());
        dto.setReturnedAt(order.getReturnedAt());

        List<OrderItemDTO> itemDTOs = items.stream().map(item -> {
            OrderItemDTO itemDTO = new OrderItemDTO();
            itemDTO.setItemId(item.getItemId());
            itemDTO.setMedicineId(item.getMedicineId());
            itemDTO.setMedicineName(names.get(item.getMedicineId()));
            itemDTO.setQuantity(item.getQuantity());
            itemDTO.setPrice(item.getPrice());
            return itemDTO;
        }).toList();

        dto.setItems(itemDTOs);
        return dto;
    }

    private DetailsDTO safeFetchDetails(Long id) {
        try {
            return detailsFeignClient.getDetails(id);
        } catch (Exception ex) {
            return null;
        }
    }
}
