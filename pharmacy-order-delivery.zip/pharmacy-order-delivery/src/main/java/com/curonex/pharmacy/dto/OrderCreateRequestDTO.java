package com.curonex.pharmacy.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class OrderCreateRequestDTO {

    @NotNull(message = "userId is required")
    private Long userId;

    /** "13.0980,81.0890" - captured from the browser geolocation prompt at checkout. */
    @Pattern(regexp = "^-?\\d{1,3}\\.\\d+,-?\\d{1,3}\\.\\d+$", message = "patientGeoAddress must be in 'lat,lon' format")
    private String patientGeoAddress;

    @NotEmpty(message = "items must not be empty")
    @Valid
    private List<OrderCreateItemDTO> items;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getPatientGeoAddress() {
        return patientGeoAddress;
    }

    public void setPatientGeoAddress(String patientGeoAddress) {
        this.patientGeoAddress = patientGeoAddress;
    }

    public List<OrderCreateItemDTO> getItems() {
        return items;
    }

    public void setItems(List<OrderCreateItemDTO> items) {
        this.items = items;
    }
}
