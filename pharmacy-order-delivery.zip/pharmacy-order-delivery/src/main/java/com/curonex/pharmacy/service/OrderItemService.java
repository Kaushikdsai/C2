package com.curonex.pharmacy.service;

import java.util.List;

import com.curonex.pharmacy.entity.OrderItem;

public interface OrderItemService {

    OrderItem addOrderItem(OrderItem orderItem);

    OrderItem getOrderItemById(Long id);

    List<OrderItem> getAllOrderItems();

    OrderItem updateOrderItem(Long id, OrderItem orderItem);

    void deleteOrderItem(Long id);

    List<OrderItem> getOrderItemsByOrderId(Long orderId);
}
