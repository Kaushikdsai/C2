package com.curonex.pharmacy.service;

import java.util.List;

import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.entity.Pharmacy;

public interface PharmacyRoutingService {

    Pharmacy assignHospitalPharmacy(Long hospitalId, String patientGeoAddress);

    List<Pharmacy> findNearbyPharmacies(String patientGeoAddress, double radiusKm);

    void broadcastOrder(Long orderId, String patientGeoAddress);

    void rebroadcastOrder(Long orderId);

    boolean isWithinRadius(String sourceGeoAddress, String destinationGeoAddress, double radiusKm);

    /** Orders currently broadcast and still unclaimed, visible to this pharmacy. */
    List<OrderSummaryDTO> getAvailableOrdersForPharmacy(Long pharmacyId);
}
