package com.curonex.pharmacy.entity;

import java.math.BigDecimal;

import com.curonex.pharmacy.converter.DeliveryPartnerStatusEnumConverter;
import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "delivery_partners")
public class DeliveryPartners {

    @Id
    @Column(name = "delivery_partner_id")
    private Long deliveryPartnerId;

    @Column(name = "name")
    private String name;

    @Column(name = "mobile_number")
    private String mobileNumber;

    @Column(name = "geo_address")
    private String geoAddress;

    @Convert(converter = DeliveryPartnerStatusEnumConverter.class)
    @Column(name = "status")
    private DeliveryPartnerStatusEnum status;

    @Column(name = "rating")
    private BigDecimal rating;

    @Column(name = "rating_count")
    private Integer ratingCount;

    public Long getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(Long deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getGeoAddress() {
        return geoAddress;
    }

    public void setGeoAddress(String geoAddress) {
        this.geoAddress = geoAddress;
    }

    public DeliveryPartnerStatusEnum getStatus() {
        return status;
    }

    public void setStatus(DeliveryPartnerStatusEnum status) {
        this.status = status;
    }

    public BigDecimal getRating() {
        return rating;
    }

    public void setRating(BigDecimal rating) {
        this.rating = rating;
    }

    public Integer getRatingCount() {
        return ratingCount;
    }

    public void setRatingCount(Integer ratingCount) {
        this.ratingCount = ratingCount;
    }
}
