package com.curonex.pharmacy.serviceimpl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.FrequentMedicineDTO;
import com.curonex.pharmacy.dto.OrderItemDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptItemDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyDTO;
import com.curonex.pharmacy.dto.PharmacyDashboardDTO;
import com.curonex.pharmacy.dto.PharmacyProfileDTO;
import com.curonex.pharmacy.entity.Medicine;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.event.OrderStatusChangedEvent;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.exceptions.PharmacyNotFoundException;
import com.curonex.pharmacy.repository.MedicineRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import com.curonex.pharmacy.service.PharmacyService;
import com.curonex.pharmacy.util.OrderRejectionTracker;

@Service
public class PharmacyServiceImpl implements PharmacyService {

    private final PharmacyRepository pharmacyRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final MedicineRepository medicineRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final PharmacyRoutingService pharmacyRoutingService;
    private final DeliveryRoutingService deliveryRoutingService;
    private final OrderRejectionTracker orderRejectionTracker;
    private final ApplicationEventPublisher eventPublisher;

    public PharmacyServiceImpl(
            PharmacyRepository pharmacyRepository,
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            MedicineRepository medicineRepository,
            DetailsFeignClient detailsFeignClient,
            PharmacyRoutingService pharmacyRoutingService,
            DeliveryRoutingService deliveryRoutingService,
            OrderRejectionTracker orderRejectionTracker,
            ApplicationEventPublisher eventPublisher) {

        this.pharmacyRepository = pharmacyRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.medicineRepository = medicineRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.pharmacyRoutingService = pharmacyRoutingService;
        this.deliveryRoutingService = deliveryRoutingService;
        this.orderRejectionTracker = orderRejectionTracker;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public PharmacyDTO addPharmacy(PharmacyDTO dto) {
        Pharmacy pharmacy = new Pharmacy();
        BeanUtils.copyProperties(dto, pharmacy);
        pharmacy.setRating(BigDecimal.ZERO);
        pharmacy.setRatingCount(0);
        return toDTO(pharmacyRepository.save(pharmacy));
    }

    @Override
    public PharmacyDTO getPharmacyById(Long id) {
        return toDTO(findPharmacyOrThrow(id));
    }

    @Override
    public List<PharmacyDTO> getAllPharmacies() {
        return pharmacyRepository.findAll().stream().map(this::toDTO).toList();
    }

    @Override
    public PharmacyDTO updatePharmacy(Long id, PharmacyDTO dto) {
        Pharmacy pharmacy = findPharmacyOrThrow(id);
        pharmacy.setLicenseNo(dto.getLicenseNo());
        pharmacy.setGeoAddress(dto.getGeoAddress());
        pharmacy.setStatus(dto.getStatus());
        pharmacy.setHospitalId(dto.getHospitalId());
        return toDTO(pharmacyRepository.save(pharmacy));
    }

    @Override
    public void deletePharmacy(Long id) {
        pharmacyRepository.deleteById(id);
    }

    @Override
    public List<PharmacyDTO> getActivePharmacies() {
        return pharmacyRepository.findByStatus(com.curonex.pharmacy.enums.PharmacyStatusEnum.ACTIVE)
                .stream().map(this::toDTO).toList();
    }

    @Override
    public PharmacyProfileDTO getPharmacyProfile(Long pharmacyId) {
        Pharmacy pharmacy = findPharmacyOrThrow(pharmacyId);
        PharmacyProfileDTO dto = new PharmacyProfileDTO();
        dto.setPharmacyId(pharmacy.getId());
        dto.setLicenseNo(pharmacy.getLicenseNo());
        dto.setGeoAddress(pharmacy.getGeoAddress());
        dto.setStatus(pharmacy.getStatus());
        dto.setHospitalId(pharmacy.getHospitalId());
        dto.setRating(pharmacy.getRating());
        dto.setRatingCount(pharmacy.getRatingCount());

        DetailsDTO details = detailsFeignClient.getDetails(pharmacyId);
        if (details != null) {
            dto.setName(details.getName());
            dto.setEmail(details.getEmail());
            dto.setPhone(details.getPhone());
            dto.setAddress(details.getAddress());
            dto.setPincode(details.getPincode());
            dto.setCity(details.getCity());
            dto.setState(details.getState());
        }
        return dto;
    }

    @Override
    public PharmacyProfileDTO updatePharmacyProfile(Long pharmacyId, PharmacyProfileDTO dto) {
        Pharmacy pharmacy = findPharmacyOrThrow(pharmacyId);
        pharmacy.setLicenseNo(dto.getLicenseNo());
        pharmacy.setGeoAddress(dto.getGeoAddress());
        pharmacyRepository.save(pharmacy);

        DetailsDTO detailsUpdate = new DetailsDTO();
        detailsUpdate.setId(pharmacyId);
        detailsUpdate.setName(dto.getName());
        detailsUpdate.setEmail(dto.getEmail());
        detailsUpdate.setPhone(dto.getPhone());
        detailsUpdate.setAddress(dto.getAddress());
        detailsUpdate.setPincode(dto.getPincode());
        detailsUpdate.setCity(dto.getCity());
        detailsUpdate.setState(dto.getState());
        detailsFeignClient.updateDetails(pharmacyId, detailsUpdate);

        return getPharmacyProfile(pharmacyId);
    }

    @Override
    @Transactional
    public PharmacyProfileDTO submitRating(Long pharmacyId, BigDecimal rating) {
        Pharmacy pharmacy = findPharmacyOrThrow(pharmacyId);

        int previousCount = pharmacy.getRatingCount() != null ? pharmacy.getRatingCount() : 0;
        BigDecimal previousAverage = pharmacy.getRating() != null ? pharmacy.getRating() : BigDecimal.ZERO;

        BigDecimal newCount = BigDecimal.valueOf(previousCount + 1);
        BigDecimal newAverage = previousAverage.multiply(BigDecimal.valueOf(previousCount))
                .add(rating)
                .divide(newCount, 2, RoundingMode.HALF_UP);

        pharmacy.setRating(newAverage);
        pharmacy.setRatingCount(previousCount + 1);
        pharmacyRepository.save(pharmacy);

        return getPharmacyProfile(pharmacyId);
    }

    @Override
    public PharmacyDashboardDTO getDashboard(Long pharmacyId) {
        List<Orders> pharmacyOrders = orderRepository.findByPharmacyId(pharmacyId);

        PharmacyDashboardDTO dto = new PharmacyDashboardDTO();
        dto.setNewOrders(pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.CONFIRMED && o.getDeliveryPartnerId() == null)
                .count());
        dto.setProcessingOrders(pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.CONFIRMED || o.getStatus() == OrderStatusEnum.OUT_FOR_DELIVERY)
                .count());

        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        long todaysDeliveries = pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED)
                .filter(o -> o.getDeliveredAt() != null
                        && o.getDeliveredAt().toLocalDateTime().toLocalDate().equals(today))
                .count();
        dto.setTodaysDeliveries(todaysDeliveries);

        BigDecimal todaysRevenue = pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED)
                .filter(o -> o.getDeliveredAt() != null
                        && o.getDeliveredAt().toLocalDateTime().toLocalDate().equals(today))
                .map(Orders::getTotalAmount)
                .filter(java.util.Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        dto.setTodaysRevenue(todaysRevenue);

        return dto;
    }

    @Override
    public List<OrderSummaryDTO> getOrdersByStatus(Long pharmacyId, OrderStatusEnum status) {
        return orderRepository.findByPharmacyIdAndStatus(pharmacyId, status).stream()
                .map(this::toSummaryDTO)
                .toList();
    }

    @Override
    public List<OrderSummaryDTO> getOrderHistory(Long pharmacyId) {
        return orderRepository.findByPharmacyId(pharmacyId).stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED || o.getStatus() == OrderStatusEnum.CANCELLED)
                .map(this::toSummaryDTO)
                .toList();
    }

    @Override
    public List<FrequentMedicineDTO> getFrequentlyOrderedMedicines(Long pharmacyId) {
        List<Long> orderIds = orderRepository.findByPharmacyId(pharmacyId).stream().map(Orders::getOrderId).toList();

        Map<Long, Long> countByMedicineId = new HashMap<>();
        for (Long orderId : orderIds) {
            for (OrderItem item : orderItemRepository.findByOrderId(orderId)) {
                countByMedicineId.merge(item.getMedicineId(), 1L, Long::sum);
            }
        }

        Map<Long, String> names = medicineRepository.findAllById(countByMedicineId.keySet()).stream()
                .collect(Collectors.toMap(Medicine::getMedicineId, Medicine::getName));

        return countByMedicineId.entrySet().stream()
                .sorted(Map.Entry.<Long, Long>comparingByValue().reversed())
                .map(entry -> {
                    FrequentMedicineDTO dto = new FrequentMedicineDTO();
                    dto.setMedicineId(entry.getKey());
                    dto.setMedicineName(names.get(entry.getKey()));
                    dto.setOrderCount(entry.getValue());
                    return dto;
                })
                .toList();
    }

    @Override
    public double getDeliverySuccessRate(Long pharmacyId) {
        List<Orders> orders = orderRepository.findByPharmacyId(pharmacyId);
        long total = orders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED || o.getStatus() == OrderStatusEnum.CANCELLED)
                .count();
        if (total == 0) {
            return 0.0;
        }
        long delivered = orders.stream().filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED).count();
        return (delivered * 100.0) / total;
    }

    @Override
    public long getOrdersThisMonth(Long pharmacyId) {
        LocalDate firstOfMonth = LocalDate.now(ZoneId.systemDefault()).with(TemporalAdjusters.firstDayOfMonth());
        return orderRepository.findByPharmacyId(pharmacyId).stream()
                .filter(o -> o.getOrderDatetime() != null
                        && !o.getOrderDatetime().toLocalDateTime().toLocalDate().isBefore(firstOfMonth))
                .count();
    }

    @Override
    @Transactional
    public OrderResponseDTO acceptOrder(Long orderId, Long pharmacyId, PharmacyAcceptRequestDTO request) {

        List<OrderItem> items = orderItemRepository.findByOrderId(orderId);
        if (items.isEmpty()) {
            throw new OrderNotFoundException("No items found for order id: " + orderId);
        }

        Map<Long, BigDecimal> priceByMedicineId = request.getItemPrices().stream()
                .collect(Collectors.toMap(PharmacyAcceptItemDTO::getMedicineId, PharmacyAcceptItemDTO::getPrice));

        BigDecimal totalAmount = BigDecimal.ZERO;
        for (OrderItem item : items) {
            BigDecimal price = priceByMedicineId.get(item.getMedicineId());
            if (price == null) {
                throw new IllegalArgumentException("Missing price for medicineId: " + item.getMedicineId());
            }
            totalAmount = totalAmount.add(price.multiply(BigDecimal.valueOf(item.getQuantity())));
        }

        int rowsAffected = orderRepository.acceptOrderByPharmacy(
                orderId, pharmacyId, totalAmount, OrderStatusEnum.CONFIRMED, OrderStatusEnum.PENDING);

        if (rowsAffected == 0) {
            throw new OrderConflictException("Order has already been accepted by another pharmacy or is not pending.");
        }

        for (OrderItem item : items) {
            item.setPrice(priceByMedicineId.get(item.getMedicineId()));
            orderItemRepository.save(item);
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.CONFIRMED, "Order accepted by pharmacy " + pharmacyId));

        deliveryRoutingService.broadcastOrder(orderId);

        Orders updated = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
        return toResponseDTO(updated, items);
    }

    @Override
    public void rejectOrder(Long orderId, Long pharmacyId) {
        orderRejectionTracker.reject(orderId, pharmacyId);

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.PENDING, "Pharmacy " + pharmacyId + " declined order " + orderId));
    }

    @Override
    @Transactional
    public boolean cancelAcceptedOrder(Long orderId, Long pharmacyId) {
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));

        if (order.getPharmacyId() == null || !order.getPharmacyId().equals(pharmacyId)) {
            throw new OrderConflictException("Order is not currently held by pharmacy " + pharmacyId);
        }
        if (order.getStatus() != OrderStatusEnum.CONFIRMED || order.getDeliveryPartnerId() != null) {
            throw new OrderConflictException("Order can only be cancelled before a delivery partner is assigned.");
        }

        order.setPharmacyId(null);
        order.setStatus(OrderStatusEnum.PENDING);
        order.setTotalAmount(null);
        order.setConfirmedAt(null);
        orderRepository.save(order);

        for (OrderItem item : orderItemRepository.findByOrderId(orderId)) {
            item.setPrice(null);
            orderItemRepository.save(item);
        }

        pharmacyRoutingService.rebroadcastOrder(orderId);

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.PENDING, "Pharmacy " + pharmacyId + " cancelled - rebroadcast to nearby pharmacies"));

        return true;
    }

    private Pharmacy findPharmacyOrThrow(Long id) {
        return pharmacyRepository.findById(id)
                .orElseThrow(() -> new PharmacyNotFoundException("Pharmacy not found with id: " + id));
    }

    private PharmacyDTO toDTO(Pharmacy pharmacy) {
        PharmacyDTO dto = new PharmacyDTO();
        BeanUtils.copyProperties(pharmacy, dto);
        return dto;
    }

    private OrderSummaryDTO toSummaryDTO(Orders order) {
        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
        Map<Long, String> names = medicineRepository
                .findAllById(items.stream().map(OrderItem::getMedicineId).collect(Collectors.toSet()))
                .stream().collect(Collectors.toMap(Medicine::getMedicineId, Medicine::getName));

        OrderSummaryDTO dto = new OrderSummaryDTO();
        dto.setOrderId(order.getOrderId());
        dto.setItemCount(items.size());
        dto.setMedicinesSummary(items.stream().map(i -> names.get(i.getMedicineId())).collect(Collectors.joining(", ")));
        dto.setTotalAmount(order.getTotalAmount());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setIsReturned(order.getIsReturned());

        DetailsDTO patientDetails = safeFetchDetails(order.getUserId());
        dto.setPatientName(patientDetails != null ? patientDetails.getName() : null);
        return dto;
    }

    private OrderResponseDTO toResponseDTO(Orders order, List<OrderItem> items) {
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderId(order.getOrderId());
        dto.setPharmacyId(order.getPharmacyId());
        dto.setDeliveryPartnerId(order.getDeliveryPartnerId());
        dto.setUserId(order.getUserId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());
        dto.setCancelledAt(order.getCancelledAt());
        dto.setIsReturned(order.getIsReturned());
        dto.setReturnedAt(order.getReturnedAt());

        Map<Long, String> names = medicineRepository
                .findAllById(items.stream().map(OrderItem::getMedicineId).collect(Collectors.toSet()))
                .stream().collect(Collectors.toMap(Medicine::getMedicineId, Medicine::getName));

        List<OrderItemDTO> itemDTOs = items.stream().map(item -> {
            OrderItemDTO itemDTO = new OrderItemDTO();
            itemDTO.setItemId(item.getItemId());
            itemDTO.setMedicineId(item.getMedicineId());
            itemDTO.setMedicineName(names.get(item.getMedicineId()));
            itemDTO.setQuantity(item.getQuantity());
            itemDTO.setPrice(item.getPrice());
            return itemDTO;
        }).toList();

        dto.setItems(itemDTOs);
        return dto;
    }

    private DetailsDTO safeFetchDetails(Long id) {
        try {
            return detailsFeignClient.getDetails(id);
        } catch (Exception ex) {
            return null;
        }
    }
}
