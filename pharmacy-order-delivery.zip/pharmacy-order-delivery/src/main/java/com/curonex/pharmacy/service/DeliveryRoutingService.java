package com.curonex.pharmacy.service;

import java.util.List;

import com.curonex.pharmacy.dto.ActiveDeliveryDTO;
import com.curonex.pharmacy.dto.AvailableOrderDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;

public interface DeliveryRoutingService {

    List<DeliveryPartners> findNearbyDeliveryPartners(String geoAddress, double radiusKm);

    /** Atomic accept: fails with OrderConflictException if another partner already claimed it. */
    boolean acceptDelivery(Long orderId, Long deliveryPartnerId);

    boolean cancelDelivery(Long orderId, Long deliveryPartnerId);

    boolean pickupOrder(Long orderId, Long deliveryPartnerId);

    boolean markDelivered(Long orderId, Long deliveryPartnerId);

    void broadcastOrder(Long orderId);

    void rebroadcastOrder(Long orderId);

    List<AvailableOrderDTO> getAvailableOrdersForPartner(Long deliveryPartnerId);

    List<ActiveDeliveryDTO> getActiveDeliveriesForPartner(Long deliveryPartnerId);

    List<OrderResponseDTO> getDeliveryHistoryForPartner(Long deliveryPartnerId);
}
