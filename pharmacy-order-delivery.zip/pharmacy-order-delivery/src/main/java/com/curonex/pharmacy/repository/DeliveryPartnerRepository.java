package com.curonex.pharmacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;

@Repository
public interface DeliveryPartnerRepository extends JpaRepository<DeliveryPartners, Long> {

    List<DeliveryPartners> findByStatus(DeliveryPartnerStatusEnum status);

    boolean existsByMobileNumber(String mobileNumber);

    DeliveryPartners findByMobileNumber(String mobileNumber);
}
