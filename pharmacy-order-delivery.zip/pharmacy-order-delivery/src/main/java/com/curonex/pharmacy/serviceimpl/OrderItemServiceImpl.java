package com.curonex.pharmacy.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.exceptions.OrderItemNotFoundException;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.service.OrderItemService;

@Service
public class OrderItemServiceImpl implements OrderItemService {

    private final OrderItemRepository orderItemRepository;

    public OrderItemServiceImpl(OrderItemRepository orderItemRepository) {
        this.orderItemRepository = orderItemRepository;
    }

    @Override
    public OrderItem addOrderItem(OrderItem orderItem) {
        return orderItemRepository.save(orderItem);
    }

    @Override
    public OrderItem getOrderItemById(Long id) {
        return orderItemRepository.findById(id)
                .orElseThrow(() -> new OrderItemNotFoundException("Order Item not found with id : " + id));
    }

    @Override
    public List<OrderItem> getAllOrderItems() {
        return orderItemRepository.findAll();
    }

    @Override
    public OrderItem updateOrderItem(Long id, OrderItem orderItem) {
        OrderItem existing = getOrderItemById(id);
        existing.setOrderId(orderItem.getOrderId());
        existing.setMedicineId(orderItem.getMedicineId());
        existing.setQuantity(orderItem.getQuantity());
        existing.setPrice(orderItem.getPrice());
        return orderItemRepository.save(existing);
    }

    @Override
    public void deleteOrderItem(Long id) {
        OrderItem item = getOrderItemById(id);
        orderItemRepository.delete(item);
    }

    @Override
    public List<OrderItem> getOrderItemsByOrderId(Long orderId) {
        List<OrderItem> items = orderItemRepository.findByOrderId(orderId);
        if (items.isEmpty()) {
            throw new OrderItemNotFoundException("No order items found for order id : " + orderId);
        }
        return items;
    }
}
