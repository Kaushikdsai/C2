package com.curonex.pharmacy.service;

import java.util.List;

import com.curonex.pharmacy.dto.PrescriptionsDTO;

public interface PrescriptionsService {

    PrescriptionsDTO addPrescription(PrescriptionsDTO dto);

    PrescriptionsDTO getPrescriptionById(Long prescriptionId);

    List<PrescriptionsDTO> getAllPrescriptions();

    PrescriptionsDTO updatePrescription(Long prescriptionId, PrescriptionsDTO dto);

    void deletePrescription(Long prescriptionId);

    List<PrescriptionsDTO> getPrescriptionsByUser(Long userId);

    List<PrescriptionsDTO> getPrescriptionsByHospital(Long hospitalId);

    List<PrescriptionsDTO> getPrescriptionsByDoctor(Long doctorId);
}
