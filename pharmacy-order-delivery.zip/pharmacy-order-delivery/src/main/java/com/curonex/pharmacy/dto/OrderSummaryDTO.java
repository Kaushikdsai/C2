package com.curonex.pharmacy.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;

import com.curonex.pharmacy.enums.OrderStatusEnum;

public class OrderSummaryDTO {

    private Long orderId;
    private String patientName;
    private String medicinesSummary;
    private Integer itemCount;
    private BigDecimal totalAmount;
    private OrderStatusEnum status;
    private Timestamp orderDatetime;
    private Boolean isReturned;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getMedicinesSummary() {
        return medicinesSummary;
    }

    public void setMedicinesSummary(String medicinesSummary) {
        this.medicinesSummary = medicinesSummary;
    }

    public Integer getItemCount() {
        return itemCount;
    }

    public void setItemCount(Integer itemCount) {
        this.itemCount = itemCount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public OrderStatusEnum getStatus() {
        return status;
    }

    public void setStatus(OrderStatusEnum status) {
        this.status = status;
    }

    public Timestamp getOrderDatetime() {
        return orderDatetime;
    }

    public void setOrderDatetime(Timestamp orderDatetime) {
        this.orderDatetime = orderDatetime;
    }

    public Boolean getIsReturned() {
        return isReturned;
    }

    public void setIsReturned(Boolean isReturned) {
        this.isReturned = isReturned;
    }
}
