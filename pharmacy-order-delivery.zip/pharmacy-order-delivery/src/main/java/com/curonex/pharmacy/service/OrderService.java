package com.curonex.pharmacy.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.curonex.pharmacy.dto.OrderCreateRequestDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderTrackingDTO;

public interface OrderService {

    OrderResponseDTO createOrder(OrderCreateRequestDTO request);

    OrderResponseDTO getOrderById(Long orderId);

    List<OrderResponseDTO> getOrdersByUser(Long userId);

    List<OrderResponseDTO> getAllOrders();

    Page<OrderResponseDTO> getAllOrders(Pageable pageable);

    void deleteOrder(Long orderId);

    OrderTrackingDTO getOrderTracking(Long orderId);

    /** Cancels an order that hasn't been delivered yet (e.g. patient-initiated cancel). */
    OrderResponseDTO cancelOrder(Long orderId);

    /** Marks a delivered order as returned. */
    OrderResponseDTO markReturned(Long orderId);
}
