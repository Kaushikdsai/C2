package com.curonex.pharmacy.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

import com.curonex.pharmacy.converter.OrderStatusEnumConverter;
import com.curonex.pharmacy.enums.OrderStatusEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "orders")
public class Orders {

    @Id
    @Column(name = "order_id")
    private Long orderId;

    @Column(name = "pharmacy_id")
    private Long pharmacyId;

    @Column(name = "delivery_partner_id")
    private Long deliveryPartnerId;

    @Column(name = "user_id")
    private Long userId;

    @Convert(converter = OrderStatusEnumConverter.class)
    @Column(name = "status")
    private OrderStatusEnum status;

    @Column(name = "order_datetime")
    private Timestamp orderDatetime;

    @Column(name = "total_amount")
    private BigDecimal totalAmount;

    /** "13.0980,81.0890" - captured once at checkout from the browser's geolocation prompt. */
    @Column(name = "patient_geo_address")
    private String patientGeoAddress;

    @Column(name = "confirmed_at")
    private Timestamp confirmedAt;

    @Column(name = "picked_up_at")
    private Timestamp pickedUpAt;

    @Column(name = "delivered_at")
    private Timestamp deliveredAt;

    @Column(name = "cancelled_at")
    private Timestamp cancelledAt;

    @Column(name = "is_returned")
    private Boolean isReturned;

    @Column(name = "returned_at")
    private Timestamp returnedAt;

    public Orders() {
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getPharmacyId() {
        return pharmacyId;
    }

    public void setPharmacyId(Long pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    public Long getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(Long deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public OrderStatusEnum getStatus() {
        return status;
    }

    public void setStatus(OrderStatusEnum status) {
        this.status = status;
    }

    public Timestamp getOrderDatetime() {
        return orderDatetime;
    }

    public void setOrderDatetime(Timestamp orderDatetime) {
        this.orderDatetime = orderDatetime;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getPatientGeoAddress() {
        return patientGeoAddress;
    }

    public void setPatientGeoAddress(String patientGeoAddress) {
        this.patientGeoAddress = patientGeoAddress;
    }

    public Timestamp getConfirmedAt() {
        return confirmedAt;
    }

    public void setConfirmedAt(Timestamp confirmedAt) {
        this.confirmedAt = confirmedAt;
    }

    public Timestamp getPickedUpAt() {
        return pickedUpAt;
    }

    public void setPickedUpAt(Timestamp pickedUpAt) {
        this.pickedUpAt = pickedUpAt;
    }

    public Timestamp getDeliveredAt() {
        return deliveredAt;
    }

    public void setDeliveredAt(Timestamp deliveredAt) {
        this.deliveredAt = deliveredAt;
    }

    public Timestamp getCancelledAt() {
        return cancelledAt;
    }

    public void setCancelledAt(Timestamp cancelledAt) {
        this.cancelledAt = cancelledAt;
    }

    public Boolean getIsReturned() {
        return isReturned;
    }

    public void setIsReturned(Boolean isReturned) {
        this.isReturned = isReturned;
    }

    public Timestamp getReturnedAt() {
        return returnedAt;
    }

    public void setReturnedAt(Timestamp returnedAt) {
        this.returnedAt = returnedAt;
    }
}
