package com.curonex.pharmacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;

@Repository
public interface PharmacyRepository extends JpaRepository<Pharmacy, Long> {

    List<Pharmacy> findByStatus(PharmacyStatusEnum status);

    List<Pharmacy> findByHospitalId(Long hospitalId);

    List<Pharmacy> findByStatusAndHospitalId(PharmacyStatusEnum status, Long hospitalId);

    boolean existsByLicenseNo(String licenseNo);
}
