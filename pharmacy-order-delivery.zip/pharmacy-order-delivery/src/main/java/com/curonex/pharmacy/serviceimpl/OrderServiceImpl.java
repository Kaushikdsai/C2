package com.curonex.pharmacy.serviceimpl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderCreateItemDTO;
import com.curonex.pharmacy.dto.OrderCreateRequestDTO;
import com.curonex.pharmacy.dto.OrderItemDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderTrackingDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.Medicine;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.event.OrderStatusChangedEvent;
import com.curonex.pharmacy.exceptions.InvalidOrderStateException;
import com.curonex.pharmacy.exceptions.MedicineNotFoundException;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.MedicineRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.service.OrderService;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import com.curonex.pharmacy.util.OrderRejectionTracker;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final MedicineRepository medicineRepository;
    private final PharmacyRepository pharmacyRepository;
    private final DeliveryPartnerRepository deliveryPartnerRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final PharmacyRoutingService pharmacyRoutingService;
    private final OrderRejectionTracker orderRejectionTracker;
    private final ApplicationEventPublisher eventPublisher;

    public OrderServiceImpl(
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            MedicineRepository medicineRepository,
            PharmacyRepository pharmacyRepository,
            DeliveryPartnerRepository deliveryPartnerRepository,
            DetailsFeignClient detailsFeignClient,
            PharmacyRoutingService pharmacyRoutingService,
            OrderRejectionTracker orderRejectionTracker,
            ApplicationEventPublisher eventPublisher) {

        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.medicineRepository = medicineRepository;
        this.pharmacyRepository = pharmacyRepository;
        this.deliveryPartnerRepository = deliveryPartnerRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.pharmacyRoutingService = pharmacyRoutingService;
        this.orderRejectionTracker = orderRejectionTracker;
        this.eventPublisher = eventPublisher;
    }

    @Override
    @Transactional
    public OrderResponseDTO createOrder(OrderCreateRequestDTO request) {

        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one medicine");
        }

        for (OrderCreateItemDTO item : request.getItems()) {
            medicineRepository.findById(item.getMedicineId())
                    .orElseThrow(() -> new MedicineNotFoundException(
                            "Medicine not found with id: " + item.getMedicineId()));
        }

        Orders order = new Orders();
        order.setUserId(request.getUserId());
        order.setStatus(OrderStatusEnum.PENDING);
        order.setOrderDatetime(Timestamp.from(Instant.now()));
        order.setPatientGeoAddress(request.getPatientGeoAddress());
        order.setIsReturned(false);
        order = orderRepository.save(order);

        for (OrderCreateItemDTO item : request.getItems()) {
            OrderItem orderItem = new OrderItem(order.getOrderId(), item.getMedicineId(), item.getQuantity(), null);
            orderItemRepository.save(orderItem);
        }

        pharmacyRoutingService.broadcastOrder(order.getOrderId(), request.getPatientGeoAddress());

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                order.getOrderId(), OrderStatusEnum.PENDING, "Order created and broadcast to nearby pharmacies"));

        return toResponseDTO(order);
    }

    @Override
    public OrderResponseDTO getOrderById(Long orderId) {
        return toResponseDTO(findOrderOrThrow(orderId));
    }

    @Override
    public List<OrderResponseDTO> getOrdersByUser(Long userId) {
        return orderRepository.findByUserId(userId).stream().map(this::toResponseDTO).toList();
    }

    @Override
    public List<OrderResponseDTO> getAllOrders() {
        return orderRepository.findAll().stream().map(this::toResponseDTO).toList();
    }

    @Override
    public Page<OrderResponseDTO> getAllOrders(Pageable pageable) {
        return orderRepository.findAll(pageable).map(this::toResponseDTO);
    }

    @Override
    @Transactional
    public void deleteOrder(Long orderId) {
        Orders order = findOrderOrThrow(orderId);
        orderItemRepository.deleteByOrderId(orderId);
        orderRepository.delete(order);
        orderRejectionTracker.clear(orderId);
    }

    @Override
    public OrderTrackingDTO getOrderTracking(Long orderId) {
        Orders order = findOrderOrThrow(orderId);
        List<OrderItem> items = orderItemRepository.findByOrderId(orderId);

        OrderTrackingDTO dto = new OrderTrackingDTO();
        dto.setOrderId(order.getOrderId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setItemCount(items.size());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());

        if (order.getPharmacyId() != null) {
            pharmacyRepository.findById(order.getPharmacyId()).ifPresent(pharmacy -> {
                dto.setPharmacyGeoAddress(pharmacy.getGeoAddress());
                DetailsDTO pharmacyDetails = safeFetchDetails(pharmacy.getId());
                dto.setPharmacyName(pharmacyDetails != null ? pharmacyDetails.getName() : null);
            });
        }

        if (order.getDeliveryPartnerId() != null) {
            DeliveryPartners partner = deliveryPartnerRepository.findById(order.getDeliveryPartnerId()).orElse(null);
            if (partner != null) {
                dto.setDeliveryPartnerName(partner.getName());
                dto.setDeliveryPartnerPhone(partner.getMobileNumber());
            }
        }

        return dto;
    }

    @Override
    @Transactional
    public OrderResponseDTO cancelOrder(Long orderId) {
        int rowsAffected = orderRepository.cancelOrder(orderId, OrderStatusEnum.CANCELLED, OrderStatusEnum.DELIVERED);
        if (rowsAffected == 0) {
            throw new OrderConflictException("Order cannot be cancelled - it is already delivered or already cancelled.");
        }

        orderRejectionTracker.clear(orderId);

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.CANCELLED, "Order cancelled"));

        return toResponseDTO(findOrderOrThrow(orderId));
    }

    @Override
    @Transactional
    public OrderResponseDTO markReturned(Long orderId) {
        int rowsAffected = orderRepository.markReturned(orderId, OrderStatusEnum.DELIVERED);
        if (rowsAffected == 0) {
            throw new InvalidOrderStateException("Order can only be marked returned if it has been delivered and is not already returned.");
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.DELIVERED, "Order marked as returned"));

        return toResponseDTO(findOrderOrThrow(orderId));
    }

    private DetailsDTO safeFetchDetails(Long id) {
        try {
            return detailsFeignClient.getDetails(id);
        } catch (Exception ex) {
            return null;
        }
    }

    private Orders findOrderOrThrow(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
    }

    private OrderResponseDTO toResponseDTO(Orders order) {
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderId(order.getOrderId());
        dto.setPharmacyId(order.getPharmacyId());
        dto.setDeliveryPartnerId(order.getDeliveryPartnerId());
        dto.setUserId(order.getUserId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());
        dto.setCancelledAt(order.getCancelledAt());
        dto.setIsReturned(order.getIsReturned());
        dto.setReturnedAt(order.getReturnedAt());

        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
        Map<Long, String> medicineNames = medicineRepository
                .findAllById(items.stream().map(OrderItem::getMedicineId).collect(Collectors.toSet()))
                .stream()
                .collect(Collectors.toMap(Medicine::getMedicineId, Medicine::getName));

        List<OrderItemDTO> itemDTOs = items.stream().map(item -> {
            OrderItemDTO itemDTO = new OrderItemDTO();
            itemDTO.setItemId(item.getItemId());
            itemDTO.setMedicineId(item.getMedicineId());
            itemDTO.setMedicineName(medicineNames.get(item.getMedicineId()));
            itemDTO.setQuantity(item.getQuantity());
            itemDTO.setPrice(item.getPrice());
            return itemDTO;
        }).toList();

        dto.setItems(itemDTOs);
        return dto;
    }
}
