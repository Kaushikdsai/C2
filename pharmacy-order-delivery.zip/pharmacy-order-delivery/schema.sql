-- Run this against your existing Curonex Postgres schema BEFORE starting the
-- application. spring.jpa.hibernate.ddl-auto=validate will refuse to boot if
-- these columns are missing, since the entities now map to them.

ALTER TABLE orders ADD COLUMN IF NOT EXISTS patient_geo_address VARCHAR(50);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS confirmed_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS picked_up_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS is_returned BOOLEAN DEFAULT FALSE;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS returned_at TIMESTAMP;

ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS rating NUMERIC(3,2) DEFAULT 0;
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;

ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS rating NUMERIC(3,2) DEFAULT 0;
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;
