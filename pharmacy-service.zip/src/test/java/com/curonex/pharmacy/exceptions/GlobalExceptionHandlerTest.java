package com.curonex.pharmacy.exceptions;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void handleOrderNotFound_returns404() {
        ResponseEntity<ErrorResponse> response = handler.handleOrderNotFound(new OrderNotFoundException("not found"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody().getMessage()).isEqualTo("not found");
    }

    @Test
    void handlePharmacyNotFound_returns404() {
        ResponseEntity<ErrorResponse> response =
                handler.handlePharmacyNotFound(new PharmacyNotFoundException("pharmacy missing"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void handleDeliveryPartnerNotFound_returns404() {
        ResponseEntity<ErrorResponse> response =
                handler.handleDeliveryPartnerNotFound(new DeliveryPartnerNotFoundException("partner missing"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void handlePrescriptionNotFound_returns404() {
        ResponseEntity<ErrorResponse> response =
                handler.handlePrescriptionNotFound(new PrescriptionNotFoundException("prescription missing"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void handleOrderConflict_returns409() {
        ResponseEntity<ErrorResponse> response =
                handler.handleOrderConflict(new OrderConflictException("already claimed"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
    }

    @Test
    void handlePrescriptionQuantityExceeded_returns400() {
        ResponseEntity<ErrorResponse> response =
                handler.handlePrescriptionQuantityExceeded(new PrescriptionQuantityExceededException("qty too high"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void handleIllegalArgument_returns400() {
        ResponseEntity<ErrorResponse> response =
                handler.handleIllegalArgument(new IllegalArgumentException("bad arg"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void handleGeneric_returns500() {
        ResponseEntity<ErrorResponse> response = handler.handleGeneric(new RuntimeException("boom"));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    void handleValidation_joinsFieldErrorsIntoMessage() {
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        FieldError error1 = new FieldError("request", "userId", "userId is required");
        FieldError error2 = new FieldError("request", "items", "items must not be empty");
        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getFieldErrors()).thenReturn(List.of(error1, error2));

        ResponseEntity<ErrorResponse> response = handler.handleValidation(ex);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody().getMessage())
                .contains("userId: userId is required")
                .contains("items: items must not be empty");
    }

    @Test
    void errorResponse_timestampAndStatusArePopulated() {
        ResponseEntity<ErrorResponse> response = handler.handleOrderNotFound(new OrderNotFoundException("x"));

        assertThat(response.getBody().getTimestamp()).isNotNull();
        assertThat(response.getBody().getStatus()).isEqualTo(404);
    }
}
