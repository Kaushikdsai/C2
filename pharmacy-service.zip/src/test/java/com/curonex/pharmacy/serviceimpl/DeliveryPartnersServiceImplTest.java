package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DeliveryPartnerDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerDashboardDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerProfileDTO;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.exceptions.DeliveryPartnerNotFoundException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.OrderRepository;

@ExtendWith(MockitoExtension.class)
class DeliveryPartnersServiceImplTest {

    @Mock private DeliveryPartnerRepository deliveryPartnerRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private DetailsFeignClient detailsFeignClient;

    private DeliveryPartnersServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new DeliveryPartnersServiceImpl(deliveryPartnerRepository, orderRepository, detailsFeignClient);
        ReflectionTestUtils.setField(service, "commissionRate", new BigDecimal("0.10"));
    }

    private DeliveryPartners partner(Long id) {
        DeliveryPartners p = new DeliveryPartners();
        p.setDeliveryPartnerId(id);
        p.setMobileNumber("9999999999");
        p.setStatus(DeliveryPartnerStatusEnum.AVAILABLE);
        p.setRating(BigDecimal.ZERO);
        p.setRatingCount(0);
        p.setIsDeleted(false);
        return p;
    }

    @Test
    void addDeliveryPartner_throwsWhenMobileAlreadyExists() {
        DeliveryPartnerDTO dto = new DeliveryPartnerDTO();
        dto.setMobileNumber("9999999999");
        when(deliveryPartnerRepository.existsByMobileNumber("9999999999")).thenReturn(true);

        assertThatThrownBy(() -> service.addDeliveryPartner(dto))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void addDeliveryPartner_initializesRatingAndSaves() {
        DeliveryPartnerDTO dto = new DeliveryPartnerDTO();
        dto.setMobileNumber("8888888888");
        when(deliveryPartnerRepository.existsByMobileNumber("8888888888")).thenReturn(false);
        when(deliveryPartnerRepository.save(any(DeliveryPartners.class))).thenAnswer(inv -> inv.getArgument(0));

        DeliveryPartnerDTO result = service.addDeliveryPartner(dto);

        assertThat(result.getMobileNumber()).isEqualTo("8888888888");
    }

    @Test
    void getDeliveryPartnerById_throwsWhenNotFound() {
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.getDeliveryPartnerById(1L))
                .isInstanceOf(DeliveryPartnerNotFoundException.class);
    }

    @Test
    void deleteDeliveryPartner_softDeletesOnly() {
        DeliveryPartners p = partner(1L);
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(p));

        service.deleteDeliveryPartner(1L);

        assertThat(p.getIsDeleted()).isTrue();
        verify(deliveryPartnerRepository, never()).deleteById(1L);
        verify(deliveryPartnerRepository).save(p);
    }

    @Test
    void markAvailable_updatesStatus() {
        DeliveryPartners p = partner(1L);
        p.setStatus(DeliveryPartnerStatusEnum.OFFLINE);
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(p));

        assertThat(service.markAvailable(1L)).isTrue();
        assertThat(p.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.AVAILABLE);
    }

    @Test
    void markOnDelivery_updatesStatus() {
        DeliveryPartners p = partner(1L);
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(p));

        assertThat(service.markOnDelivery(1L)).isTrue();
        assertThat(p.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.ON_DELIVERY);
    }

    @Test
    void markOffline_updatesStatus() {
        DeliveryPartners p = partner(1L);
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(p));

        assertThat(service.markOffline(1L)).isTrue();
        assertThat(p.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.OFFLINE);
    }

    @Test
    void getPartnerProfile_enrichesFromFeign() {
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(partner(1L)));
        DetailsDTO details = new DetailsDTO();
        details.setName("Ramesh Kumar");
        when(detailsFeignClient.getDetails(1L)).thenReturn(details);

        DeliveryPartnerProfileDTO dto = service.getPartnerProfile(1L);

        assertThat(dto.getName()).isEqualTo("Ramesh Kumar");
    }

    @Test
    void updatePartnerProfile_pushesToFeign() {
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(partner(1L)));
        when(detailsFeignClient.getDetails(1L)).thenReturn(new DetailsDTO());

        DeliveryPartnerProfileDTO dto = new DeliveryPartnerProfileDTO();
        dto.setMobileNumber("7777777777");
        dto.setName("New Name");

        service.updatePartnerProfile(1L, dto);

        verify(detailsFeignClient).updateDetails(org.mockito.ArgumentMatchers.eq(1L), any(DetailsDTO.class));
    }

    @Test
    void submitRating_throwsWhenOrderNotFound() {
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(partner(1L)));
        when(orderRepository.findById(500L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.submitRating(1L, 500L, new BigDecimal("5.00")))
                .isInstanceOf(com.curonex.pharmacy.exceptions.OrderNotFoundException.class);
    }

    @Test
    void submitRating_throwsWhenOrderNotDelivered() {
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(partner(1L)));
        Orders o = new Orders();
        o.setOrderId(500L);
        o.setStatus(OrderStatusEnum.OUT_FOR_DELIVERY);
        o.setDeliveryPartnerId(1L);
        when(orderRepository.findById(500L)).thenReturn(Optional.of(o));

        assertThatThrownBy(() -> service.submitRating(1L, 500L, new BigDecimal("5.00")))
                .isInstanceOf(com.curonex.pharmacy.exceptions.OrderConflictException.class)
                .hasMessageContaining("DELIVERED");
    }

    @Test
    void submitRating_throwsWhenOrderBelongsToDifferentPartner() {
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(partner(1L)));
        Orders o = new Orders();
        o.setOrderId(500L);
        o.setStatus(OrderStatusEnum.DELIVERED);
        o.setDeliveryPartnerId(99L); // different partner
        when(orderRepository.findById(500L)).thenReturn(Optional.of(o));

        assertThatThrownBy(() -> service.submitRating(1L, 500L, new BigDecimal("5.00")))
                .isInstanceOf(com.curonex.pharmacy.exceptions.OrderConflictException.class)
                .hasMessageContaining("not delivered by partner");
    }

    @Test
    void submitRating_throwsWhenAlreadyRated() {
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(partner(1L)));
        Orders o = new Orders();
        o.setOrderId(500L);
        o.setStatus(OrderStatusEnum.DELIVERED);
        o.setDeliveryPartnerId(1L);
        o.setDeliveryPartnerRated(true);
        when(orderRepository.findById(500L)).thenReturn(Optional.of(o));

        assertThatThrownBy(() -> service.submitRating(1L, 500L, new BigDecimal("5.00")))
                .isInstanceOf(com.curonex.pharmacy.exceptions.OrderConflictException.class)
                .hasMessageContaining("already been rated");
    }

    @Test
    void submitRating_firstRatingSetsAverageAndMarksOrderRated() {
        DeliveryPartners p = partner(1L);
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(p));
        when(detailsFeignClient.getDetails(1L)).thenReturn(new DetailsDTO());

        Orders o = new Orders();
        o.setOrderId(500L);
        o.setStatus(OrderStatusEnum.DELIVERED);
        o.setDeliveryPartnerId(1L);
        when(orderRepository.findById(500L)).thenReturn(Optional.of(o));

        service.submitRating(1L, 500L, new BigDecimal("5.00"));

        assertThat(p.getRating()).isEqualByComparingTo("5.00");
        assertThat(p.getRatingCount()).isEqualTo(1);
        assertThat(o.getDeliveryPartnerRated()).isTrue();
        verify(orderRepository).save(o);
    }

    @Test
    void getDashboard_computesEarningsWithCommissionDeducted() {
        DeliveryPartners p = partner(1L);
        p.setRating(new BigDecimal("4.80"));
        p.setRatingCount(10);
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(p));

        Orders delivered = new Orders();
        delivered.setOrderId(1L);
        delivered.setStatus(OrderStatusEnum.DELIVERED);
        delivered.setTotalAmount(new BigDecimal("100.00"));
        Timestamp now = Timestamp.from(Instant.now());
        delivered.setDeliveredAt(now);
        delivered.setOrderDatetime(now);

        when(orderRepository.findByDeliveryPartnerId(1L)).thenReturn(List.of(delivered));

        DeliveryPartnerDashboardDTO dto = service.getDashboard(1L);

        // 100.00 * (1 - 0.10) = 90.00
        assertThat(dto.getTodaysEarnings()).isEqualByComparingTo("90.00");
        assertThat(dto.getWeekEarnings()).isEqualByComparingTo("90.00");
        assertThat(dto.getMonthEarnings()).isEqualByComparingTo("90.00");
        assertThat(dto.getCompletedDeliveries()).isEqualTo(1);
        assertThat(dto.getRating()).isEqualByComparingTo("4.80");
    }

    @Test
    void getDashboard_zeroEarningsWhenNoDeliveredOrders() {
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(partner(1L)));
        when(orderRepository.findByDeliveryPartnerId(1L)).thenReturn(List.of());

        DeliveryPartnerDashboardDTO dto = service.getDashboard(1L);

        assertThat(dto.getTodaysEarnings()).isEqualByComparingTo("0.00");
        assertThat(dto.getCompletedDeliveries()).isEqualTo(0);
    }

    @Test
    void getDashboard_pendingPickupsCountsConfirmedOrders() {
        when(deliveryPartnerRepository.findById(1L)).thenReturn(Optional.of(partner(1L)));
        Orders confirmed = new Orders();
        confirmed.setOrderId(1L);
        confirmed.setStatus(OrderStatusEnum.CONFIRMED);
        confirmed.setOrderDatetime(Timestamp.from(Instant.now()));
        when(orderRepository.findByDeliveryPartnerId(1L)).thenReturn(List.of(confirmed));

        DeliveryPartnerDashboardDTO dto = service.getDashboard(1L);

        assertThat(dto.getPendingPickups()).isEqualTo(1);
        assertThat(dto.getAcceptedCount()).isEqualTo(1);
    }
}
