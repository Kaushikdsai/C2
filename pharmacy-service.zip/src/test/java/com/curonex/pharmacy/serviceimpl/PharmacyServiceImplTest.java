package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptItemDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyDTO;
import com.curonex.pharmacy.dto.PharmacyDashboardDTO;
import com.curonex.pharmacy.dto.PharmacyProfileDTO;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.exceptions.PharmacyNotFoundException;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.PharmacyRoutingService;

@ExtendWith(MockitoExtension.class)
class PharmacyServiceImplTest {

    @Mock private PharmacyRepository pharmacyRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private OrderItemRepository orderItemRepository;
    @Mock private DetailsFeignClient detailsFeignClient;
    @Mock private PharmacyRoutingService pharmacyRoutingService;
    @Mock private DeliveryRoutingService deliveryRoutingService;
    @Mock private OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;
    @Mock private ApplicationEventPublisher eventPublisher;

    private PharmacyServiceImpl pharmacyService;

    @BeforeEach
    void setUp() {
        pharmacyService = new PharmacyServiceImpl(
                pharmacyRepository, orderRepository, orderItemRepository, detailsFeignClient,
                pharmacyRoutingService, deliveryRoutingService, orderPharmacyRejectionRepository, eventPublisher);
    }

    private Pharmacy pharmacy(Long id) {
        Pharmacy p = new Pharmacy();
        p.setId(id);
        p.setLicenseNo("LIC-" + id);
        p.setGeoAddress("13.0,80.2");
        p.setStatus(PharmacyStatusEnum.ACTIVE);
        p.setRating(BigDecimal.ZERO);
        p.setRatingCount(0);
        p.setIsDeleted(false);
        return p;
    }

    private Orders order(Long id, OrderStatusEnum status) {
        Orders o = new Orders();
        o.setOrderId(id);
        o.setUserId(1L);
        o.setStatus(status);
        o.setOrderDatetime(Timestamp.from(Instant.now()));
        o.setPharmacyRated(false);
        o.setDeliveryPartnerRated(false);
        return o;
    }

    // ---- CRUD ----

    @Test
    void addPharmacy_initializesRatingAndNotDeleted() {
        PharmacyDTO dto = new PharmacyDTO();
        dto.setLicenseNo("LIC-1");
        when(pharmacyRepository.save(any(Pharmacy.class))).thenAnswer(inv -> inv.getArgument(0));

        PharmacyDTO result = pharmacyService.addPharmacy(dto);

        assertThat(result.getLicenseNo()).isEqualTo("LIC-1");
    }

    @Test
    void getPharmacyById_throwsWhenNotFound() {
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> pharmacyService.getPharmacyById(1L))
                .isInstanceOf(PharmacyNotFoundException.class);
    }

    @Test
    void getAllPharmacies_usesIsDeletedFalseFilter() {
        when(pharmacyRepository.findByIsDeletedFalse()).thenReturn(List.of(pharmacy(1L)));

        assertThat(pharmacyService.getAllPharmacies()).hasSize(1);
        verify(pharmacyRepository).findByIsDeletedFalse();
    }

    @Test
    void deletePharmacy_softDeletesInsteadOfHardDelete() {
        Pharmacy p = pharmacy(1L);
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(p));

        pharmacyService.deletePharmacy(1L);

        assertThat(p.getIsDeleted()).isTrue();
        verify(pharmacyRepository).save(p);
        verify(pharmacyRepository, never()).deleteById(anyLong());
        verify(pharmacyRepository, never()).delete(any());
    }

    @Test
    void getActivePharmacies_filtersByStatusAndIsDeletedFalse() {
        when(pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE))
                .thenReturn(List.of(pharmacy(1L)));

        assertThat(pharmacyService.getActivePharmacies()).hasSize(1);
    }

    // ---- Profile ----

    @Test
    void getPharmacyProfile_enrichesFromFeign() {
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(pharmacy(1L)));
        DetailsDTO details = new DetailsDTO();
        details.setName("Prime Pharmacy");
        details.setCity("Chennai");
        when(detailsFeignClient.getDetails(1L)).thenReturn(details);

        PharmacyProfileDTO dto = pharmacyService.getPharmacyProfile(1L);

        assertThat(dto.getName()).isEqualTo("Prime Pharmacy");
        assertThat(dto.getCity()).isEqualTo("Chennai");
    }

    @Test
    void getPharmacyProfile_toleratesNullFeignResponse() {
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(pharmacy(1L)));
        when(detailsFeignClient.getDetails(1L)).thenReturn(null);

        PharmacyProfileDTO dto = pharmacyService.getPharmacyProfile(1L);

        assertThat(dto.getName()).isNull();
    }

    @Test
    void updatePharmacyProfile_pushesUpdateToFeign() {
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(pharmacy(1L)));
        when(detailsFeignClient.getDetails(1L)).thenReturn(new DetailsDTO());

        PharmacyProfileDTO dto = new PharmacyProfileDTO();
        dto.setLicenseNo("NEW-LIC");
        dto.setName("Updated Name");

        pharmacyService.updatePharmacyProfile(1L, dto);

        verify(detailsFeignClient).updateDetails(anyLong(), any(DetailsDTO.class));
    }

    // ---- Rating (now order-validated) ----

    @Test
    void submitRating_throwsWhenOrderNotFound() {
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(pharmacy(1L)));
        when(orderRepository.findById(500L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> pharmacyService.submitRating(1L, 500L, new BigDecimal("4.5")))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void submitRating_throwsWhenOrderNotDelivered() {
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(pharmacy(1L)));
        Orders o = order(500L, OrderStatusEnum.OUT_FOR_DELIVERY);
        o.setPharmacyId(1L);
        when(orderRepository.findById(500L)).thenReturn(Optional.of(o));

        assertThatThrownBy(() -> pharmacyService.submitRating(1L, 500L, new BigDecimal("4.5")))
                .isInstanceOf(OrderConflictException.class)
                .hasMessageContaining("DELIVERED");
    }

    @Test
    void submitRating_throwsWhenOrderBelongsToDifferentPharmacy() {
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(pharmacy(1L)));
        Orders o = order(500L, OrderStatusEnum.DELIVERED);
        o.setPharmacyId(99L); // different pharmacy
        when(orderRepository.findById(500L)).thenReturn(Optional.of(o));

        assertThatThrownBy(() -> pharmacyService.submitRating(1L, 500L, new BigDecimal("4.5")))
                .isInstanceOf(OrderConflictException.class)
                .hasMessageContaining("not fulfilled by pharmacy");
    }

    @Test
    void submitRating_throwsWhenAlreadyRated() {
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(pharmacy(1L)));
        Orders o = order(500L, OrderStatusEnum.DELIVERED);
        o.setPharmacyId(1L);
        o.setPharmacyRated(true);
        when(orderRepository.findById(500L)).thenReturn(Optional.of(o));

        assertThatThrownBy(() -> pharmacyService.submitRating(1L, 500L, new BigDecimal("4.5")))
                .isInstanceOf(OrderConflictException.class)
                .hasMessageContaining("already been rated");
    }

    @Test
    void submitRating_succeedsAndMarksOrderRated() {
        Pharmacy p = pharmacy(1L);
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(p));
        when(detailsFeignClient.getDetails(1L)).thenReturn(new DetailsDTO());

        Orders o = order(500L, OrderStatusEnum.DELIVERED);
        o.setPharmacyId(1L);
        when(orderRepository.findById(500L)).thenReturn(Optional.of(o));

        pharmacyService.submitRating(1L, 500L, new BigDecimal("4.5"));

        assertThat(p.getRating()).isEqualByComparingTo("4.50");
        assertThat(p.getRatingCount()).isEqualTo(1);
        assertThat(o.getPharmacyRated()).isTrue();
        verify(orderRepository).save(o);
    }

    @Test
    void submitRating_averagesCorrectlyOnSecondRating() {
        Pharmacy p = pharmacy(1L);
        p.setRating(new BigDecimal("4.00"));
        p.setRatingCount(1);
        when(pharmacyRepository.findById(1L)).thenReturn(Optional.of(p));
        when(detailsFeignClient.getDetails(1L)).thenReturn(new DetailsDTO());

        Orders o = order(500L, OrderStatusEnum.DELIVERED);
        o.setPharmacyId(1L);
        when(orderRepository.findById(500L)).thenReturn(Optional.of(o));

        pharmacyService.submitRating(1L, 500L, new BigDecimal("5.00"));

        // (4.00*1 + 5.00) / 2 = 4.50
        assertThat(p.getRating()).isEqualByComparingTo("4.50");
        assertThat(p.getRatingCount()).isEqualTo(2);
    }

    // ---- Dashboard / reports ----

    @Test
    void getDashboard_countsNewAndProcessingOrdersCorrectly() {
        Orders newOrder = order(1L, OrderStatusEnum.CONFIRMED); // no delivery partner => "new"
        Orders processing = order(2L, OrderStatusEnum.OUT_FOR_DELIVERY);
        when(orderRepository.findByPharmacyId(1L)).thenReturn(List.of(newOrder, processing));

        PharmacyDashboardDTO dto = pharmacyService.getDashboard(1L);

        assertThat(dto.getNewOrders()).isEqualTo(1);
        assertThat(dto.getProcessingOrders()).isEqualTo(2);
    }

    @Test
    void getDeliverySuccessRate_zeroWhenNoTerminalOrders() {
        when(orderRepository.findByPharmacyId(1L)).thenReturn(List.of(order(1L, OrderStatusEnum.PENDING)));

        assertThat(pharmacyService.getDeliverySuccessRate(1L)).isEqualTo(0.0);
    }

    @Test
    void getDeliverySuccessRate_computesPercentageOfDelivered() {
        when(orderRepository.findByPharmacyId(1L)).thenReturn(List.of(
                order(1L, OrderStatusEnum.DELIVERED),
                order(2L, OrderStatusEnum.DELIVERED),
                order(3L, OrderStatusEnum.CANCELLED)));

        assertThat(pharmacyService.getDeliverySuccessRate(1L)).isEqualTo(200.0 / 3, org.assertj.core.data.Offset.offset(0.01));
    }

    @Test
    void getOrderHistory_onlyIncludesDeliveredAndCancelled() {
        when(orderRepository.findByPharmacyId(1L)).thenReturn(List.of(
                order(1L, OrderStatusEnum.DELIVERED),
                order(2L, OrderStatusEnum.CANCELLED),
                order(3L, OrderStatusEnum.PENDING)));
        when(orderItemRepository.findByOrderId(anyLong())).thenReturn(List.of());
        when(detailsFeignClient.getDetails(anyLong())).thenReturn(new DetailsDTO());

        List<OrderSummaryDTO> history = pharmacyService.getOrderHistory(1L);

        assertThat(history).hasSize(2);
    }

    // ---- Order lifecycle: accept / reject / cancel ----

    @Test
    void acceptOrder_throwsWhenNoItems() {
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());

        assertThatThrownBy(() -> pharmacyService.acceptOrder(1L, 10L, new PharmacyAcceptRequestDTO()))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void acceptOrder_throwsWhenOrderNotFoundForPriorityCheck() {
        OrderItem item = new OrderItem(1L, "Paracetamol", 2, null);
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item));
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> pharmacyService.acceptOrder(1L, 10L, new PharmacyAcceptRequestDTO()))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void acceptOrder_propagatesHospitalPriorityRejection() {
        OrderItem item = new OrderItem(1L, "Paracetamol", 2, null);
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item));
        Orders hospitalOrder = order(1L, OrderStatusEnum.PENDING);
        hospitalOrder.setHospitalId(99L);
        hospitalOrder.setPatientGeoAddress("13.09,80.27");
        when(orderRepository.findById(1L)).thenReturn(Optional.of(hospitalOrder));

        org.mockito.Mockito.doThrow(new OrderConflictException("reserved for hospital pharmacy"))
                .when(pharmacyRoutingService).assertPharmacyCanAcceptOrder(hospitalOrder, 10L);

        assertThatThrownBy(() -> pharmacyService.acceptOrder(1L, 10L, new PharmacyAcceptRequestDTO()))
                .isInstanceOf(OrderConflictException.class)
                .hasMessageContaining("reserved for hospital pharmacy");

        verify(orderRepository, never()).acceptOrderByPharmacy(any(), any(), any(), any(), any());
    }

    @Test
    void acceptOrder_throwsWhenPriceMissingForAnItem() {
        OrderItem item = new OrderItem(1L, "Paracetamol", 2, null);
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order(1L, OrderStatusEnum.PENDING)));

        PharmacyAcceptRequestDTO request = new PharmacyAcceptRequestDTO();
        request.setItemPrices(List.of()); // no prices supplied at all

        assertThatThrownBy(() -> pharmacyService.acceptOrder(1L, 10L, request))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void acceptOrder_throwsConflictWhenAnotherPharmacyAlreadyClaimed() {
        OrderItem item = new OrderItem(1L, "Paracetamol", 2, null);
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order(1L, OrderStatusEnum.PENDING)));

        PharmacyAcceptItemDTO priceDto = new PharmacyAcceptItemDTO();
        priceDto.setMedicineName("Paracetamol");
        priceDto.setPrice(new BigDecimal("20.00"));
        PharmacyAcceptRequestDTO request = new PharmacyAcceptRequestDTO();
        request.setItemPrices(List.of(priceDto));

        when(orderRepository.acceptOrderByPharmacy(
                eq(1L), eq(10L), any(BigDecimal.class), any(), any())).thenReturn(0);

        assertThatThrownBy(() -> pharmacyService.acceptOrder(1L, 10L, request))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void acceptOrder_computesTotalAndPersistsPricesOnSuccess() {
        OrderItem item = new OrderItem(1L, "Paracetamol", 2, null);
        item.setItemId(1L);
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order(1L, OrderStatusEnum.PENDING)))
                .thenReturn(Optional.of(withTotal(order(1L, OrderStatusEnum.CONFIRMED), "40.00")));

        PharmacyAcceptItemDTO priceDto = new PharmacyAcceptItemDTO();
        priceDto.setMedicineName("Paracetamol");
        priceDto.setPrice(new BigDecimal("20.00"));
        PharmacyAcceptRequestDTO request = new PharmacyAcceptRequestDTO();
        request.setItemPrices(List.of(priceDto));

        when(orderRepository.acceptOrderByPharmacy(
                eq(1L), eq(10L), eq(new BigDecimal("40.00")), any(), any())).thenReturn(1);

        OrderResponseDTO result = pharmacyService.acceptOrder(1L, 10L, request);

        assertThat(result.getTotalAmount()).isEqualByComparingTo("40.00");
        verify(orderItemRepository).save(item);
        verify(deliveryRoutingService).broadcastOrder(1L);
        verify(eventPublisher).publishEvent(any());
    }

    private Orders withTotal(Orders o, String amount) {
        o.setTotalAmount(new BigDecimal(amount));
        return o;
    }

    @Test
    void rejectOrder_doesNotDuplicateExistingRejection() {
        when(orderPharmacyRejectionRepository.existsById(any())).thenReturn(true);

        pharmacyService.rejectOrder(1L, 10L);

        verify(orderPharmacyRejectionRepository, never()).save(any());
    }

    @Test
    void rejectOrder_savesNewRejectionRowAndDoesNotPublishEvent() {
        when(orderPharmacyRejectionRepository.existsById(any())).thenReturn(false);

        pharmacyService.rejectOrder(1L, 10L);

        verify(orderPharmacyRejectionRepository).save(any());
        // Reject is deliberately NOT newsworthy - no email/event for it.
        verify(eventPublisher, never()).publishEvent(any());
    }

    @Test
    void cancelAcceptedOrder_throwsWhenNotHeldByThisPharmacy() {
        Orders o = order(1L, OrderStatusEnum.CONFIRMED);
        o.setPharmacyId(99L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));

        assertThatThrownBy(() -> pharmacyService.cancelAcceptedOrder(1L, 10L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void cancelAcceptedOrder_throwsWhenDeliveryPartnerAlreadyAssigned() {
        Orders o = order(1L, OrderStatusEnum.CONFIRMED);
        o.setPharmacyId(10L);
        o.setDeliveryPartnerId(50L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));

        assertThatThrownBy(() -> pharmacyService.cancelAcceptedOrder(1L, 10L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void cancelAcceptedOrder_resetsOrderRebroadcastsAndDoesNotPublishEvent() {
        Orders o = order(1L, OrderStatusEnum.CONFIRMED);
        o.setPharmacyId(10L);
        o.setTotalAmount(new BigDecimal("40.00"));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        OrderItem item = new OrderItem(1L, "Paracetamol", 2, new BigDecimal("20.00"));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(item));

        boolean result = pharmacyService.cancelAcceptedOrder(1L, 10L);

        assertThat(result).isTrue();
        assertThat(o.getPharmacyId()).isNull();
        assertThat(o.getStatus()).isEqualTo(OrderStatusEnum.PENDING);
        assertThat(item.getPrice()).isNull();
        verify(pharmacyRoutingService).rebroadcastOrder(1L);
        // Fluctuation, not newsworthy - no email/event.
        verify(eventPublisher, never()).publishEvent(any());
    }
}
