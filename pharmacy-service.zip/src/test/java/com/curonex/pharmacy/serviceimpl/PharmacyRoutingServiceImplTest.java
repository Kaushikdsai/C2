package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.util.DistanceUtil;
import com.curonex.pharmacy.util.GeoAddressUtil;

/**
 * findNearbyPharmacies / isWithinRadius are private helpers now (previously
 * unused REST endpoints, no external caller) - exercised indirectly through
 * broadcastOrder() and getAvailableOrdersForPharmacy() below using real
 * (non-mocked) distance math, so radius filtering is genuinely verified.
 *
 * assignHospitalPharmacy was briefly deleted as "dead code" in an earlier
 * pass - that was wrong: the hospital-priority rule is a real requirement,
 * it just was never wired into the actual broadcast/availability flow. It's
 * back as a private helper (findActiveHospitalPharmacyInRange) driving the
 * priority-window logic tested below.
 */
@ExtendWith(MockitoExtension.class)
class PharmacyRoutingServiceImplTest {

    @Mock private PharmacyRepository pharmacyRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private OrderItemRepository orderItemRepository;
    @Mock private DetailsFeignClient detailsFeignClient;
    @Mock private OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;

    private final DistanceUtil distanceUtil = new DistanceUtil();
    private final GeoAddressUtil geoAddressUtil = new GeoAddressUtil();

    private PharmacyRoutingServiceImpl service;

    private static final String CHENNAI = "13.0827,80.2707";
    private static final String DELHI = "28.6139,77.2090";

    @BeforeEach
    void setUp() {
        service = new PharmacyRoutingServiceImpl(
                pharmacyRepository, orderRepository, orderItemRepository,
                detailsFeignClient, geoAddressUtil, distanceUtil, orderPharmacyRejectionRepository);
    }

    private Pharmacy pharmacy(Long id, String geo) {
        Pharmacy p = new Pharmacy();
        p.setId(id);
        p.setGeoAddress(geo);
        p.setStatus(PharmacyStatusEnum.ACTIVE);
        p.setIsDeleted(false);
        return p;
    }

    @Test
    void broadcastOrder_skipsWhenGeoAddressBlank() {
        service.broadcastOrder(1L, "");

        org.mockito.Mockito.verifyNoInteractions(pharmacyRepository);
    }

    @Test
    void broadcastOrder_skipsWhenGeoAddressNull() {
        service.broadcastOrder(1L, null);

        org.mockito.Mockito.verifyNoInteractions(pharmacyRepository);
    }

    @Test
    void broadcastOrder_searchesNearbyPharmaciesWhenGeoAddressPresent() {
        when(pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE))
                .thenReturn(List.of(pharmacy(1L, CHENNAI), pharmacy(2L, DELHI)));

        service.broadcastOrder(1L, CHENNAI);

        org.mockito.Mockito.verify(pharmacyRepository).findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE);
    }

    @Test
    void rebroadcastOrder_doesNothingWhenOrderMissing() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        service.rebroadcastOrder(1L);

        org.mockito.Mockito.verifyNoInteractions(pharmacyRepository);
    }

    @Test
    void rebroadcastOrder_usesOrdersStoredGeoAddress() {
        Orders o = new Orders();
        o.setOrderId(1L);
        o.setPatientGeoAddress(CHENNAI);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        when(pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE)).thenReturn(List.of());

        service.rebroadcastOrder(1L);

        org.mockito.Mockito.verify(pharmacyRepository).findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE);
    }

    @Test
    void getAvailableOrdersForPharmacy_emptyWhenPharmacyMissing() {
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.empty());

        assertThat(service.getAvailableOrdersForPharmacy(1L)).isEmpty();
    }

    @Test
    void getAvailableOrdersForPharmacy_excludesRejectedOrders() {
        Pharmacy p = pharmacy(1L, CHENNAI);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.of(p));

        Orders rejected = new Orders();
        rejected.setOrderId(10L);
        rejected.setPatientGeoAddress(CHENNAI);
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(rejected));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 1L)).thenReturn(true);

        assertThat(service.getAvailableOrdersForPharmacy(1L)).isEmpty();
    }

    @Test
    void getAvailableOrdersForPharmacy_excludesOrdersBeyondRadius() {
        // Pharmacy in Chennai, order placed from a patient in Delhi - real
        // distance math (not mocked) proves the 10km filter actually works.
        Pharmacy p = pharmacy(1L, CHENNAI);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.of(p));

        Orders farOrder = new Orders();
        farOrder.setOrderId(10L);
        farOrder.setPatientGeoAddress(DELHI);
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(farOrder));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 1L)).thenReturn(false);

        assertThat(service.getAvailableOrdersForPharmacy(1L)).isEmpty();
    }

    @Test
    void getAvailableOrdersForPharmacy_includesUnrejectedNearbyOrder() {
        Pharmacy p = pharmacy(1L, CHENNAI);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.of(p));

        Orders order = new Orders();
        order.setOrderId(10L);
        order.setPatientGeoAddress(CHENNAI);
        order.setUserId(5L);
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(order));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 1L)).thenReturn(false);
        when(orderItemRepository.findByOrderId(10L)).thenReturn(List.of());
        when(detailsFeignClient.getDetails(5L)).thenReturn(new DetailsDTO());

        List<OrderSummaryDTO> result = service.getAvailableOrdersForPharmacy(1L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getOrderId()).isEqualTo(10L);
    }

    @Test
    void getAvailableOrdersForPharmacy_includesOrderWithNoLocation() {
        Pharmacy p = pharmacy(1L, CHENNAI);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.of(p));

        Orders order = new Orders();
        order.setOrderId(10L);
        order.setPatientGeoAddress(null);
        order.setUserId(5L);
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(order));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 1L)).thenReturn(false);
        when(orderItemRepository.findByOrderId(10L)).thenReturn(List.of());
        when(detailsFeignClient.getDetails(5L)).thenReturn(new DetailsDTO());

        List<OrderSummaryDTO> result = service.getAvailableOrdersForPharmacy(1L);

        assertThat(result).hasSize(1);
    }

    // ---- Hospital-priority window ----

    private Orders hospitalOrder(Long id, long minutesAgo) {
        Orders o = new Orders();
        o.setOrderId(id);
        o.setPatientGeoAddress(CHENNAI);
        o.setUserId(5L);
        o.setHospitalId(99L);
        o.setOrderDatetime(java.sql.Timestamp.from(java.time.Instant.now().minusSeconds(minutesAgo * 60)));
        return o;
    }

    @Test
    void hospitalOrder_visibleImmediatelyToTheHospitalsOwnPharmacy() {
        Pharmacy hospitalPharmacy = pharmacy(1L, CHENNAI);
        hospitalPharmacy.setHospitalId(99L);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.of(hospitalPharmacy));
        when(pharmacyRepository.findByStatusAndHospitalIdAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE, 99L))
                .thenReturn(List.of(hospitalPharmacy));

        Orders order = hospitalOrder(10L, 0); // just placed, well within the priority window
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(order));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 1L)).thenReturn(false);
        when(orderItemRepository.findByOrderId(10L)).thenReturn(List.of());
        when(detailsFeignClient.getDetails(5L)).thenReturn(new DetailsDTO());

        List<OrderSummaryDTO> result = service.getAvailableOrdersForPharmacy(1L);

        assertThat(result).hasSize(1);
    }

    @Test
    void hospitalOrder_hiddenFromOtherPharmaciesDuringPriorityWindow() {
        Pharmacy hospitalPharmacy = pharmacy(1L, CHENNAI);
        hospitalPharmacy.setHospitalId(99L);
        Pharmacy otherPharmacy = pharmacy(2L, CHENNAI); // also in Chennai, but not the hospital's own

        when(pharmacyRepository.findByIdAndIsDeletedFalse(2L)).thenReturn(Optional.of(otherPharmacy));
        when(pharmacyRepository.findByStatusAndHospitalIdAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE, 99L))
                .thenReturn(List.of(hospitalPharmacy));

        Orders order = hospitalOrder(10L, 1); // 1 minute old, still inside the 2-minute window
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(order));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 2L)).thenReturn(false);

        List<OrderSummaryDTO> result = service.getAvailableOrdersForPharmacy(2L);

        assertThat(result).isEmpty();
    }

    @Test
    void hospitalOrder_opensToOtherPharmaciesAfterPriorityWindowElapses() {
        Pharmacy hospitalPharmacy = pharmacy(1L, CHENNAI);
        hospitalPharmacy.setHospitalId(99L);
        Pharmacy otherPharmacy = pharmacy(2L, CHENNAI);

        when(pharmacyRepository.findByIdAndIsDeletedFalse(2L)).thenReturn(Optional.of(otherPharmacy));
        when(pharmacyRepository.findByStatusAndHospitalIdAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE, 99L))
                .thenReturn(List.of(hospitalPharmacy));

        Orders order = hospitalOrder(10L, 3); // 3 minutes old - the 2-minute window has elapsed
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(order));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 2L)).thenReturn(false);
        when(orderItemRepository.findByOrderId(10L)).thenReturn(List.of());
        when(detailsFeignClient.getDetails(5L)).thenReturn(new DetailsDTO());

        List<OrderSummaryDTO> result = service.getAvailableOrdersForPharmacy(2L);

        assertThat(result).hasSize(1);
    }

    @Test
    void hospitalOrder_noPriorityAppliedWhenHospitalHasNoPharmacyInRange() {
        Pharmacy otherPharmacy = pharmacy(2L, CHENNAI);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(2L)).thenReturn(Optional.of(otherPharmacy));
        // Hospital 99 has no ACTIVE pharmacy at all in range.
        when(pharmacyRepository.findByStatusAndHospitalIdAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE, 99L))
                .thenReturn(List.of());

        Orders order = hospitalOrder(10L, 0); // brand new, would be inside the window if a hospital pharmacy existed
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(order));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 2L)).thenReturn(false);
        when(orderItemRepository.findByOrderId(10L)).thenReturn(List.of());
        when(detailsFeignClient.getDetails(5L)).thenReturn(new DetailsDTO());

        List<OrderSummaryDTO> result = service.getAvailableOrdersForPharmacy(2L);

        assertThat(result).hasSize(1);
    }

    @Test
    void nonHospitalOrder_unaffectedByPriorityLogic() {
        Pharmacy p = pharmacy(1L, CHENNAI);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.of(p));

        Orders order = new Orders();
        order.setOrderId(10L);
        order.setPatientGeoAddress(CHENNAI);
        order.setUserId(5L);
        order.setHospitalId(null); // no hospital association at all
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(order));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 1L)).thenReturn(false);
        when(orderItemRepository.findByOrderId(10L)).thenReturn(List.of());
        when(detailsFeignClient.getDetails(5L)).thenReturn(new DetailsDTO());

        List<OrderSummaryDTO> result = service.getAvailableOrdersForPharmacy(1L);

        assertThat(result).hasSize(1);
    }
}
