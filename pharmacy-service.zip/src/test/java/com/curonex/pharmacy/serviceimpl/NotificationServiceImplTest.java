package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.util.ReflectionTestUtils;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.repository.OrderRepository;

@ExtendWith(MockitoExtension.class)
class NotificationServiceImplTest {

    @Mock private JavaMailSender mailSender;
    @Mock private OrderRepository orderRepository;
    @Mock private DetailsFeignClient detailsFeignClient;

    private NotificationServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new NotificationServiceImpl(mailSender, orderRepository, detailsFeignClient);
        ReflectionTestUtils.setField(service, "fromAddress", "no-reply@curonex.example.com");
    }

    private Orders order(Long id, Long userId) {
        Orders o = new Orders();
        o.setOrderId(id);
        o.setUserId(userId);
        return o;
    }

    @Test
    void notifyOrderStatusChange_skipsWhenOrderMissing() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        service.notifyOrderStatusChange(1L, OrderStatusEnum.PENDING, "Order placed");

        verify(mailSender, never()).send(any(SimpleMailMessage.class));
    }

    @Test
    void notifyOrderStatusChange_skipsWhenUserIdMissing() {
        Orders o = order(1L, null);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));

        service.notifyOrderStatusChange(1L, OrderStatusEnum.PENDING, "Order placed");

        verify(mailSender, never()).send(any(SimpleMailMessage.class));
    }

    @Test
    void notifyOrderStatusChange_skipsWhenFeignThrows() {
        Orders o = order(1L, 5L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        when(detailsFeignClient.getDetails(5L)).thenThrow(new RuntimeException("feign down"));

        service.notifyOrderStatusChange(1L, OrderStatusEnum.PENDING, "Order placed");

        verify(mailSender, never()).send(any(SimpleMailMessage.class));
    }

    @Test
    void notifyOrderStatusChange_skipsWhenNoEmailOnFile() {
        Orders o = order(1L, 5L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        DetailsDTO details = new DetailsDTO();
        details.setName("Kaushik");
        details.setEmail(null);
        when(detailsFeignClient.getDetails(5L)).thenReturn(details);

        service.notifyOrderStatusChange(1L, OrderStatusEnum.PENDING, "Order placed");

        verify(mailSender, never()).send(any(SimpleMailMessage.class));
    }

    @Test
    void notifyOrderStatusChange_skipsWhenEmailBlank() {
        Orders o = order(1L, 5L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        DetailsDTO details = new DetailsDTO();
        details.setEmail("   ");
        when(detailsFeignClient.getDetails(5L)).thenReturn(details);

        service.notifyOrderStatusChange(1L, OrderStatusEnum.PENDING, "Order placed");

        verify(mailSender, never()).send(any(SimpleMailMessage.class));
    }

    @Test
    void notifyOrderStatusChange_sendsEmailWhenEverythingResolves() {
        Orders o = order(1L, 5L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        DetailsDTO details = new DetailsDTO();
        details.setName("Kaushik");
        details.setEmail("kaushik@example.com");
        when(detailsFeignClient.getDetails(5L)).thenReturn(details);

        service.notifyOrderStatusChange(1L, OrderStatusEnum.DELIVERED, "Order delivered");

        verify(mailSender).send(any(SimpleMailMessage.class));
    }

    @Test
    void notifyOrderStatusChange_toleratesMailSendFailure() {
        Orders o = order(1L, 5L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        DetailsDTO details = new DetailsDTO();
        details.setEmail("kaushik@example.com");
        when(detailsFeignClient.getDetails(5L)).thenReturn(details);
        org.mockito.Mockito.doThrow(new RuntimeException("smtp down"))
                .when(mailSender).send(any(SimpleMailMessage.class));

        assertThatCode(() -> service.notifyOrderStatusChange(1L, OrderStatusEnum.CONFIRMED, "Order confirmed"))
                .doesNotThrowAnyException();
    }

    @Test
    void notifyOrderStatusChange_coversEveryStatusSubjectBranch() {
        Orders o = order(1L, 5L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        DetailsDTO details = new DetailsDTO();
        details.setEmail("kaushik@example.com");
        when(detailsFeignClient.getDetails(5L)).thenReturn(details);

        for (OrderStatusEnum status : OrderStatusEnum.values()) {
            assertThatCode(() -> service.notifyOrderStatusChange(1L, status, "msg for " + status))
                    .doesNotThrowAnyException();
        }
    }
}
