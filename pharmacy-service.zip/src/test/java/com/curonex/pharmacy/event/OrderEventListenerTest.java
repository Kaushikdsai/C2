package com.curonex.pharmacy.event;

import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.service.NotificationService;

@ExtendWith(MockitoExtension.class)
class OrderEventListenerTest {

    @Mock private NotificationService notificationService;

    private OrderEventListener listener;

    @BeforeEach
    void setUp() {
        listener = new OrderEventListener(notificationService);
    }

    @Test
    void onOrderStatusChanged_delegatesToNotificationService() {
        OrderStatusChangedEvent event = new OrderStatusChangedEvent(1L, OrderStatusEnum.CONFIRMED, "test message");

        listener.onOrderStatusChanged(event);

        verify(notificationService).notifyOrderStatusChange(1L, OrderStatusEnum.CONFIRMED, "test message");
    }

    @Test
    void onOrderStatusChanged_handlesNullMessageGracefully() {
        OrderStatusChangedEvent event = new OrderStatusChangedEvent(1L, OrderStatusEnum.PENDING, null);

        listener.onOrderStatusChanged(event);

        verify(notificationService).notifyOrderStatusChange(1L, OrderStatusEnum.PENDING, null);
    }
}
