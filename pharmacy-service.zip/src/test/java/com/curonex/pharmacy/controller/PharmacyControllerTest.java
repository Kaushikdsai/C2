package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyDTO;
import com.curonex.pharmacy.dto.PharmacyDashboardDTO;
import com.curonex.pharmacy.dto.PharmacyProfileDTO;
import com.curonex.pharmacy.dto.RatingRequestDTO;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import com.curonex.pharmacy.service.PharmacyService;

@ExtendWith(MockitoExtension.class)
class PharmacyControllerTest {

    @Mock private PharmacyService service;
    @Mock private PharmacyRoutingService pharmacyRoutingService;

    private PharmacyController controller;

    @BeforeEach
    void setUp() {
        controller = new PharmacyController(service, pharmacyRoutingService);
    }

    @Test
    void addPharmacy_delegates() {
        PharmacyDTO dto = new PharmacyDTO();
        when(service.addPharmacy(dto)).thenReturn(dto);

        assertThat(controller.addPharmacy(dto).getBody()).isEqualTo(dto);
    }

    @Test
    void getPharmacyById_delegates() {
        PharmacyDTO dto = new PharmacyDTO();
        when(service.getPharmacyById(1L)).thenReturn(dto);

        assertThat(controller.getPharmacyById(1L).getBody()).isEqualTo(dto);
    }

    @Test
    void getAllPharmacies_delegates() {
        when(service.getAllPharmacies()).thenReturn(List.of(new PharmacyDTO()));

        assertThat(controller.getAllPharmacies().getBody()).hasSize(1);
    }

    @Test
    void updatePharmacy_delegates() {
        PharmacyDTO dto = new PharmacyDTO();
        when(service.updatePharmacy(1L, dto)).thenReturn(dto);

        assertThat(controller.updatePharmacy(1L, dto).getBody()).isEqualTo(dto);
    }

    @Test
    void deletePharmacy_returns204() {
        ResponseEntity<Void> result = controller.deletePharmacy(1L);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.NO_CONTENT);
        verify(service).deletePharmacy(1L);
    }

    @Test
    void getActivePharmacies_delegates() {
        when(service.getActivePharmacies()).thenReturn(List.of(new PharmacyDTO()));

        assertThat(controller.getActivePharmacies().getBody()).hasSize(1);
    }

    @Test
    void getProfile_delegates() {
        PharmacyProfileDTO dto = new PharmacyProfileDTO();
        when(service.getPharmacyProfile(1L)).thenReturn(dto);

        assertThat(controller.getProfile(1L).getBody()).isEqualTo(dto);
    }

    @Test
    void updateProfile_delegates() {
        PharmacyProfileDTO dto = new PharmacyProfileDTO();
        when(service.updatePharmacyProfile(1L, dto)).thenReturn(dto);

        assertThat(controller.updateProfile(1L, dto).getBody()).isEqualTo(dto);
    }

    @Test
    void submitRating_delegates() {
        RatingRequestDTO request = new RatingRequestDTO();
        request.setOrderId(500L);
        request.setRating(new BigDecimal("4.5"));
        PharmacyProfileDTO dto = new PharmacyProfileDTO();
        when(service.submitRating(1L, 500L, new BigDecimal("4.5"))).thenReturn(dto);

        assertThat(controller.submitRating(1L, request).getBody()).isEqualTo(dto);
    }

    @Test
    void getDashboard_delegates() {
        PharmacyDashboardDTO dto = new PharmacyDashboardDTO();
        when(service.getDashboard(1L)).thenReturn(dto);

        assertThat(controller.getDashboard(1L).getBody()).isEqualTo(dto);
    }

    @Test
    void getOrdersByStatus_delegates() {
        when(service.getOrdersByStatus(1L, OrderStatusEnum.CONFIRMED)).thenReturn(List.of(new OrderSummaryDTO()));

        assertThat(controller.getOrdersByStatus(1L, OrderStatusEnum.CONFIRMED).getBody()).hasSize(1);
    }

    @Test
    void getAvailableOrders_delegatesToRoutingService() {
        when(pharmacyRoutingService.getAvailableOrdersForPharmacy(1L)).thenReturn(List.of(new OrderSummaryDTO()));

        assertThat(controller.getAvailableOrders(1L).getBody()).hasSize(1);
    }

    @Test
    void getOrderHistory_delegates() {
        when(service.getOrderHistory(1L)).thenReturn(List.of(new OrderSummaryDTO()));

        assertThat(controller.getOrderHistory(1L).getBody()).hasSize(1);
    }

    @Test
    void getDeliverySuccessRate_delegates() {
        when(service.getDeliverySuccessRate(1L)).thenReturn(75.0);

        assertThat(controller.getDeliverySuccessRate(1L).getBody()).isEqualTo(75.0);
    }

    @Test
    void getOrdersThisMonth_delegates() {
        when(service.getOrdersThisMonth(1L)).thenReturn(42L);

        assertThat(controller.getOrdersThisMonth(1L).getBody()).isEqualTo(42L);
    }

    @Test
    void acceptOrder_delegates() {
        PharmacyAcceptRequestDTO request = new PharmacyAcceptRequestDTO();
        OrderResponseDTO response = new OrderResponseDTO();
        when(service.acceptOrder(1L, 10L, request)).thenReturn(response);

        assertThat(controller.acceptOrder(1L, 10L, request).getBody()).isEqualTo(response);
    }

    @Test
    void rejectOrder_delegates() {
        ResponseEntity<String> result = controller.rejectOrder(1L, 10L);

        assertThat(result.getBody()).isEqualTo("Order declined");
        verify(service).rejectOrder(1L, 10L);
    }

    @Test
    void cancelAcceptedOrder_delegates() {
        when(service.cancelAcceptedOrder(1L, 10L)).thenReturn(true);

        assertThat(controller.cancelAcceptedOrder(1L, 10L).getBody()).isTrue();
    }
}
