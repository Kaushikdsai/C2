package com.curonex.pharmacy.exceptions;

public class HospitalPublicKeyNotFoundException extends RuntimeException {
    public HospitalPublicKeyNotFoundException(String message) {
        super(message);
    }
}
