package com.curonex.pharmacy.entity;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class PrescriptionMedicineId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "prescription_id")
    private Long prescriptionId;

    /** Medicine name is now part of the composite key - no Medicine catalog to reference by ID. */
    @Column(name = "medicine_name")
    private String medicineName;

    public PrescriptionMedicineId() {
    }

    public PrescriptionMedicineId(Long prescriptionId, String medicineName) {
        this.prescriptionId = prescriptionId;
        this.medicineName = medicineName;
    }

    public Long getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(Long prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PrescriptionMedicineId)) return false;
        PrescriptionMedicineId that = (PrescriptionMedicineId) o;
        return Objects.equals(prescriptionId, that.prescriptionId) && Objects.equals(medicineName, that.medicineName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(prescriptionId, medicineName);
    }
}
