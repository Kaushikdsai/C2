package com.curonex.pharmacy.entity;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/**
 * Mirrors OrderPharmacyRejection - records that a given delivery partner
 * declined a given order, so it stops appearing in that partner's
 * "available orders" list. Many-to-many by nature, same reasoning as the
 * pharmacy version.
 */
@Entity
@Table(name = "order_delivery_partner_rejection")
public class OrderDeliveryPartnerRejection {

    @EmbeddedId
    private OrderDeliveryPartnerRejectionId id;

    @Column(name = "rejected_at")
    private Timestamp rejectedAt;

    public OrderDeliveryPartnerRejection() {
    }

    public OrderDeliveryPartnerRejection(OrderDeliveryPartnerRejectionId id, Timestamp rejectedAt) {
        this.id = id;
        this.rejectedAt = rejectedAt;
    }

    public OrderDeliveryPartnerRejectionId getId() {
        return id;
    }

    public void setId(OrderDeliveryPartnerRejectionId id) {
        this.id = id;
    }

    public Timestamp getRejectedAt() {
        return rejectedAt;
    }

    public void setRejectedAt(Timestamp rejectedAt) {
        this.rejectedAt = rejectedAt;
    }
}
