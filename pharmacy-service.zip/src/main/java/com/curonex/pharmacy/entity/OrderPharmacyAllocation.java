package com.curonex.pharmacy.entity;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * One row per pharmacy pickup stop on an order. A single-pharmacy order
 * (the common case) always gets exactly one row (sequence=1) too - created
 * uniformly by PharmacyServiceImpl.acceptOrder(), not just the partial
 * path - so pickup/OTP tracking (DeliveryRoutingServiceImpl) never has to
 * special-case "was this order ever partial". A 2-pharmacy order has
 * sequence 1 (the first/primary pharmacy, still also mirrored on
 * Orders.pharmacyId for backward compatibility with existing pharmacy
 * dashboard queries) and sequence 2 (the pharmacy that completed the
 * remaining medicines).
 */
@Entity
@Table(name = "order_pharmacy_allocations", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"order_id", "pharmacy_id"})
})
public class OrderPharmacyAllocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "allocation_id")
    private Long allocationId;

    @Column(name = "order_id", nullable = false)
    private Long orderId;

    @Column(name = "pharmacy_id", nullable = false)
    private Long pharmacyId;

    /** Pickup order for the delivery partner's multi-stop route: 1 then 2. */
    @Column(name = "sequence_no", nullable = false)
    private Integer sequenceNo;

    @Column(name = "created_at", nullable = false)
    private Timestamp createdAt;

    /** Set by the delivery partner when they physically collect the medicines from THIS pharmacy - see DeliveryRoutingServiceImpl.pickupFromPharmacy(). */
    @Column(name = "picked_up_at")
    private Timestamp pickedUpAt;

    public Long getAllocationId() {
        return allocationId;
    }

    public void setAllocationId(Long allocationId) {
        this.allocationId = allocationId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getPharmacyId() {
        return pharmacyId;
    }

    public void setPharmacyId(Long pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    public Integer getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(Integer sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getPickedUpAt() {
        return pickedUpAt;
    }

    public void setPickedUpAt(Timestamp pickedUpAt) {
        this.pickedUpAt = pickedUpAt;
    }
}
