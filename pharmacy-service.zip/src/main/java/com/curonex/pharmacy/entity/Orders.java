package com.curonex.pharmacy.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.curonex.pharmacy.converter.OrderStatusEnumConverter;
import com.curonex.pharmacy.enums.OrderStatusEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "orders")
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "orders_order_id_seq_gen")
    @SequenceGenerator(
        name = "orders_order_id_seq_gen",
        sequenceName = "orders_order_id_seq",
        allocationSize = 1
    )
    @Column(name = "order_id")
    private Long orderId;

    @Column(name = "pharmacy_id")
    private Long pharmacyId;

    /**
     * Read-only relationship view of pharmacyId. Writes still go through
     * the plain pharmacyId column (and the atomic conditional UPDATE
     * queries in OrderRepository) - a real @ManyToOne would fight those
     * conditional claim queries, since Hibernate would try to manage the
     * FK itself. This gives you real object-graph traversal
     * (order.getPharmacy().getGeoAddress()) without touching that
     * concurrency-critical write path.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pharmacy_id", insertable = false, updatable = false)
    private Pharmacy pharmacy;

    @Column(name = "delivery_partner_id")
    private Long deliveryPartnerId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "delivery_partner_id", insertable = false, updatable = false)
    private DeliveryPartners deliveryPartner;

    @Column(name = "user_id")
    private Long userId;

    /**
     * The prescription this order was created from. Previously threaded
     * through OrderCreateRequestDTO only at creation time (to read
     * hospitalId and the quantity ceiling) and then discarded - never
     * persisted on the order itself, so there was no way to trace an order
     * back to its source prescription afterwards. Nullable for any
     * historical rows created before this column existed.
     */
    @Column(name = "prescription_id")
    private Long prescriptionId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "prescription_id", insertable = false, updatable = false)
    private Prescriptions prescription;

    /**
     * Patient the order is FOR - deliberately separate from userId (who is
     * ORDERING). Set when the patient is a registered Curonex user, so
     * their live contact details can be resolved via DetailsFeignClient
     * (see OrderServiceImpl.resolvePatientDetails()). Null when ordering
     * for someone with no account - patientName/patientPhone below carry
     * the details instead. Never required to equal userId.
     */
    @Column(name = "patient_user_id")
    private Long patientUserId;

    /** Always populated (whichever source), so the pharmacy/delivery-partner side never has to branch on patientUserId being null. */
    @Column(name = "patient_name")
    private String patientName;

    @Column(name = "patient_age")
    private Integer patientAge;

    @Column(name = "patient_phone")
    private String patientPhone;

    /** Free text - e.g. "Self", "Mother", "Father", "Child", "Spouse", "Other". Not an enum: this is display-only, nothing branches on it. */
    @Column(name = "patient_relationship")
    private String patientRelationship;

    @Convert(converter = OrderStatusEnumConverter.class)
    @Column(name = "status")
    private OrderStatusEnum status;

    @Column(name = "order_datetime")
    private Timestamp orderDatetime;

    @Column(name = "total_amount")
    private BigDecimal totalAmount;

    /** "13.0980,81.0890" - captured once at checkout from the browser's geolocation prompt. */
    @Column(name = "patient_geo_address")
    private String patientGeoAddress;

    /**
     * Always set from the linked Prescriptions record at order creation
     * time (never trusted directly from the client) - drives the
     * "hospital pharmacy gets first priority" rule in
     * PharmacyRoutingServiceImpl. Null only if the prescription itself has
     * no hospital association.
     */
    @Column(name = "hospital_id")
    private Long hospitalId;

    @Column(name = "confirmed_at")
    private Timestamp confirmedAt;

    @Column(name = "picked_up_at")
    private Timestamp pickedUpAt;

    @Column(name = "delivered_at")
    private Timestamp deliveredAt;

    @Column(name = "cancelled_at")
    private Timestamp cancelledAt;

    /**
     * Rating abuse guard: a rating can only be submitted once per order,
     * per party (pharmacy/partner). Set true the moment a valid rating is
     * accepted for this order - see PharmacyServiceImpl/DeliveryPartnersServiceImpl#submitRating.
     */
    @Column(name = "pharmacy_rated")
    private Boolean pharmacyRated;

    @Column(name = "delivery_partner_rated")
    private Boolean deliveryPartnerRated;

    /**
     * How many times PharmacyRoutingService has rebroadcast this order to a
     * fresh set of pharmacies with no acceptance. Capped (see
     * OrderRetryScheduler in Phase 2) - after the configured max, the order
     * moves to FULFILLMENT_FAILED instead of rebroadcasting indefinitely.
     */
    @Column(name = "pharmacy_rebroadcast_count")
    private Integer pharmacyRebroadcastCount;

    /** Same idea as pharmacyRebroadcastCount, for the delivery-partner search phase. */
    @Column(name = "delivery_rebroadcast_count")
    private Integer deliveryRebroadcastCount;

    /** Optional free-text note from the patient at checkout, shown to the delivery partner alongside the order. */
    @Column(name = "delivery_note", length = 500)
    private String deliveryNote;

    /** Straight-line-distance estimate, set once a delivery partner accepts the order. Null before that. */
    @Column(name = "estimated_delivery_minutes")
    private Integer estimatedDeliveryMinutes;

    /** Deadline for the patient to accept the final price once pharmacy fulfillment is complete. Null until that point is reached. */
    @Column(name = "price_confirmation_deadline")
    private Timestamp priceConfirmationDeadline;

    @Column(name = "price_accepted_at")
    private Timestamp priceAcceptedAt;

    @OneToMany(mappedBy = "order", fetch = FetchType.LAZY)
    @OrderBy("itemId ASC")
    private List<OrderItem> items = new ArrayList<>();

    @OneToMany(mappedBy = "order", fetch = FetchType.LAZY)
    @OrderBy("changedAt ASC")
    private List<OrderStatusHistory> statusHistory = new ArrayList<>();

    public Orders() {
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getPharmacyId() {
        return pharmacyId;
    }

    public void setPharmacyId(Long pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    public Pharmacy getPharmacy() {
        return pharmacy;
    }

    public Long getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(Long deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public DeliveryPartners getDeliveryPartner() {
        return deliveryPartner;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(Long prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public Prescriptions getPrescription() {
        return prescription;
    }

    public Long getPatientUserId() {
        return patientUserId;
    }

    public void setPatientUserId(Long patientUserId) {
        this.patientUserId = patientUserId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public Integer getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(Integer patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientPhone() {
        return patientPhone;
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    public String getPatientRelationship() {
        return patientRelationship;
    }

    public void setPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
    }

    public OrderStatusEnum getStatus() {
        return status;
    }

    public void setStatus(OrderStatusEnum status) {
        this.status = status;
    }

    public Timestamp getOrderDatetime() {
        return orderDatetime;
    }

    public void setOrderDatetime(Timestamp orderDatetime) {
        this.orderDatetime = orderDatetime;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getPatientGeoAddress() {
        return patientGeoAddress;
    }

    public void setPatientGeoAddress(String patientGeoAddress) {
        this.patientGeoAddress = patientGeoAddress;
    }

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public Timestamp getConfirmedAt() {
        return confirmedAt;
    }

    public void setConfirmedAt(Timestamp confirmedAt) {
        this.confirmedAt = confirmedAt;
    }

    public Timestamp getPickedUpAt() {
        return pickedUpAt;
    }

    public void setPickedUpAt(Timestamp pickedUpAt) {
        this.pickedUpAt = pickedUpAt;
    }

    public Timestamp getDeliveredAt() {
        return deliveredAt;
    }

    public void setDeliveredAt(Timestamp deliveredAt) {
        this.deliveredAt = deliveredAt;
    }

    public Timestamp getCancelledAt() {
        return cancelledAt;
    }

    public void setCancelledAt(Timestamp cancelledAt) {
        this.cancelledAt = cancelledAt;
    }

    public Boolean getPharmacyRated() {
        return pharmacyRated;
    }

    public void setPharmacyRated(Boolean pharmacyRated) {
        this.pharmacyRated = pharmacyRated;
    }

    public Boolean getDeliveryPartnerRated() {
        return deliveryPartnerRated;
    }

    public void setDeliveryPartnerRated(Boolean deliveryPartnerRated) {
        this.deliveryPartnerRated = deliveryPartnerRated;
    }

    public Integer getPharmacyRebroadcastCount() {
        return pharmacyRebroadcastCount;
    }

    public void setPharmacyRebroadcastCount(Integer pharmacyRebroadcastCount) {
        this.pharmacyRebroadcastCount = pharmacyRebroadcastCount;
    }

    public Integer getDeliveryRebroadcastCount() {
        return deliveryRebroadcastCount;
    }

    public void setDeliveryRebroadcastCount(Integer deliveryRebroadcastCount) {
        this.deliveryRebroadcastCount = deliveryRebroadcastCount;
    }

    public String getDeliveryNote() {
        return deliveryNote;
    }

    public void setDeliveryNote(String deliveryNote) {
        this.deliveryNote = deliveryNote;
    }

    public Integer getEstimatedDeliveryMinutes() {
        return estimatedDeliveryMinutes;
    }

    public void setEstimatedDeliveryMinutes(Integer estimatedDeliveryMinutes) {
        this.estimatedDeliveryMinutes = estimatedDeliveryMinutes;
    }

    public Timestamp getPriceConfirmationDeadline() {
        return priceConfirmationDeadline;
    }

    public void setPriceConfirmationDeadline(Timestamp priceConfirmationDeadline) {
        this.priceConfirmationDeadline = priceConfirmationDeadline;
    }

    public Timestamp getPriceAcceptedAt() {
        return priceAcceptedAt;
    }

    public void setPriceAcceptedAt(Timestamp priceAcceptedAt) {
        this.priceAcceptedAt = priceAcceptedAt;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public List<OrderStatusHistory> getStatusHistory() {
        return statusHistory;
    }
}
