package com.curonex.pharmacy.entity;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class OrderDeliveryPartnerRejectionId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "order_id")
    private Long orderId;

    @Column(name = "delivery_partner_id")
    private Long deliveryPartnerId;

    public OrderDeliveryPartnerRejectionId() {
    }

    public OrderDeliveryPartnerRejectionId(Long orderId, Long deliveryPartnerId) {
        this.orderId = orderId;
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(Long deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OrderDeliveryPartnerRejectionId)) return false;
        OrderDeliveryPartnerRejectionId that = (OrderDeliveryPartnerRejectionId) o;
        return Objects.equals(orderId, that.orderId) && Objects.equals(deliveryPartnerId, that.deliveryPartnerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId, deliveryPartnerId);
    }
}
