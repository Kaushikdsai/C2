package com.curonex.pharmacy.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * One combined feedback page, submitted once per delivered order - rates
 * AND leaves free-text feedback for the pharmacy and the delivery partner
 * together, instead of two separate flows. pharmacyId/deliveryPartnerId are
 * denormalized copies captured at submission time (same pattern as
 * Orders.hospitalId) purely so the pharmacy/delivery-partner dashboards can
 * query their own feedback with a single indexed lookup, no join needed.
 *
 * The numeric ratings still flow through the existing
 * PharmacyService.submitRating()/DeliveryPartnersService.submitRating()
 * calls (see OrderFeedbackServiceImpl) so the running-average logic on
 * Pharmacy.rating/DeliveryPartners.rating is never duplicated - this table
 * only adds the free-text side and a single combined submission point.
 */
@Entity
@Table(name = "order_feedback")
public class OrderFeedback {

    @Id
    @Column(name = "order_id")
    private Long orderId;

    @Column(name = "pharmacy_id")
    private Long pharmacyId;

    @Column(name = "delivery_partner_id")
    private Long deliveryPartnerId;

    @Column(name = "pharmacy_rating")
    private BigDecimal pharmacyRating;

    @Column(name = "pharmacy_feedback", length = 1000)
    private String pharmacyFeedback;

    @Column(name = "delivery_rating")
    private BigDecimal deliveryRating;

    @Column(name = "delivery_feedback", length = 1000)
    private String deliveryFeedback;

    @Column(name = "submitted_at", nullable = false)
    private Timestamp submittedAt;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getPharmacyId() {
        return pharmacyId;
    }

    public void setPharmacyId(Long pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    public Long getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(Long deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public BigDecimal getPharmacyRating() {
        return pharmacyRating;
    }

    public void setPharmacyRating(BigDecimal pharmacyRating) {
        this.pharmacyRating = pharmacyRating;
    }

    public String getPharmacyFeedback() {
        return pharmacyFeedback;
    }

    public void setPharmacyFeedback(String pharmacyFeedback) {
        this.pharmacyFeedback = pharmacyFeedback;
    }

    public BigDecimal getDeliveryRating() {
        return deliveryRating;
    }

    public void setDeliveryRating(BigDecimal deliveryRating) {
        this.deliveryRating = deliveryRating;
    }

    public String getDeliveryFeedback() {
        return deliveryFeedback;
    }

    public void setDeliveryFeedback(String deliveryFeedback) {
        this.deliveryFeedback = deliveryFeedback;
    }

    public Timestamp getSubmittedAt() {
        return submittedAt;
    }

    public void setSubmittedAt(Timestamp submittedAt) {
        this.submittedAt = submittedAt;
    }
}
