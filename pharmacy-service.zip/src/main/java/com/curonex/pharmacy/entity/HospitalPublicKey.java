package com.curonex.pharmacy.entity;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/**
 * A hospital's PUBLIC key only - the matching private key lives entirely on
 * the hospital's own prescription-generation system and is never sent to
 * or stored in Curonex. This table is what makes key rotation possible:
 * a hospital can register a new keyVersion without invalidating
 * prescriptions already signed under an older one, as long as the older
 * row's `active` flag stays true.
 *
 * "active" here is scoped to THIS record (has Curonex's admin/System Admin
 * role approved this specific hospital+keyVersion for signature
 * verification) - it is deliberately NOT a live call to hospital-service to
 * check the hospital's own operational status, since pharmacy-service does
 * not own the Hospital entity. If you also want "is this hospital
 * currently active in the hospital directory" enforced, that's a second,
 * separate check against hospital-service and is not part of this table.
 */
@Entity
@Table(name = "hospital_public_keys")
public class HospitalPublicKey {

    @EmbeddedId
    private HospitalPublicKeyId id;

    /** Base64-encoded X.509 SubjectPublicKeyInfo bytes - the standard portable format for an RSA public key. */
    @Column(name = "public_key_base64", length = 2000, nullable = false)
    private String publicKeyBase64;

    /** Always "SHA256withRSA" for now - a column instead of a constant only so a future algorithm change doesn't require a schema migration. */
    @Column(name = "algorithm", nullable = false)
    private String algorithm = "SHA256withRSA";

    @Column(name = "active", nullable = false)
    private Boolean active;

    @Column(name = "registered_at", nullable = false)
    private Timestamp registeredAt;

    public HospitalPublicKeyId getId() {
        return id;
    }

    public void setId(HospitalPublicKeyId id) {
        this.id = id;
    }

    public String getPublicKeyBase64() {
        return publicKeyBase64;
    }

    public void setPublicKeyBase64(String publicKeyBase64) {
        this.publicKeyBase64 = publicKeyBase64;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Timestamp getRegisteredAt() {
        return registeredAt;
    }

    public void setRegisteredAt(Timestamp registeredAt) {
        this.registeredAt = registeredAt;
    }
}
