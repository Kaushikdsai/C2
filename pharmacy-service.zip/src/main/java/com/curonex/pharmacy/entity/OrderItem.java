package com.curonex.pharmacy.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "order_items")
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private Long itemId;

    @Column(name = "order_id")
    private Long orderId;

    /**
     * Which pharmacy pickup stop covers this line item - see
     * OrderPharmacyAllocation. Set once the pharmacy fulfilling it is
     * known; every item must belong to an allocation before an order can
     * reach PHARMACY_CONFIRMED (see PharmacyServiceImpl).
     */
    @Column(name = "allocation_id")
    private Long allocationId;

    /**
     * Read-only relationship view (mappedBy target for Orders.items).
     * insertable/updatable = false: the plain orderId column above stays
     * the single source of truth for writes, exactly like the
     * pharmacy/deliveryPartner relationships on Orders - avoids Hibernate
     * fighting the existing constructor-based insert path used throughout
     * OrderServiceImpl.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", insertable = false, updatable = false)
    private Orders order;

    /**
     * The medicine catalog was removed - there's no Medicine table to key
     * against anymore. The name extracted from the prescription PDF (or
     * edited by the patient) travels directly through PrescriptionMedicines
     * -> OrderItem -> the order response, with no ID lookup step. See
     * OrderServiceImpl for how quantity-ceiling validation compares names.
     */
    @Column(name = "medicine_name")
    private String medicineName;

    @Column(name = "quantity")
    private Integer quantity;

    @Column(name = "price")
    private BigDecimal price;

    public OrderItem() {
    }

    public OrderItem(Long orderId, String medicineName, Integer quantity, BigDecimal price) {
        this.orderId = orderId;
        this.medicineName = medicineName;
        this.quantity = quantity;
        this.price = price;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Orders getOrder() {
        return order;
    }

    public Long getAllocationId() {
        return allocationId;
    }

    public void setAllocationId(Long allocationId) {
        this.allocationId = allocationId;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}
