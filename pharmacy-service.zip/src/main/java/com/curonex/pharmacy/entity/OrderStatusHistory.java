package com.curonex.pharmacy.entity;

import java.sql.Timestamp;

import com.curonex.pharmacy.converter.OrderStatusEnumConverter;
import com.curonex.pharmacy.enums.OrderStatusEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Append-only audit trail: one row per status transition. Populated purely
 * by OrderStatusHistoryListener reacting to OrderStatusChangedEvent - no
 * service class writes to this table directly, so this can never drift out
 * of sync with "did we remember to log this transition".
 */
@Entity
@Table(name = "order_status_history")
public class OrderStatusHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "history_id")
    private Long historyId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false, insertable = false, updatable = false)
    private Orders order;

    @Column(name = "order_id", nullable = false)
    private Long orderId;

    @Convert(converter = OrderStatusEnumConverter.class)
    @Column(name = "previous_status")
    private OrderStatusEnum previousStatus;

    @Convert(converter = OrderStatusEnumConverter.class)
    @Column(name = "new_status", nullable = false)
    private OrderStatusEnum newStatus;

    @Column(name = "changed_at", nullable = false)
    private Timestamp changedAt;

    @Column(name = "note", length = 500)
    private String note;

    public Long getHistoryId() {
        return historyId;
    }

    public void setHistoryId(Long historyId) {
        this.historyId = historyId;
    }

    public Orders getOrder() {
        return order;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public OrderStatusEnum getPreviousStatus() {
        return previousStatus;
    }

    public void setPreviousStatus(OrderStatusEnum previousStatus) {
        this.previousStatus = previousStatus;
    }

    public OrderStatusEnum getNewStatus() {
        return newStatus;
    }

    public void setNewStatus(OrderStatusEnum newStatus) {
        this.newStatus = newStatus;
    }

    public Timestamp getChangedAt() {
        return changedAt;
    }

    public void setChangedAt(Timestamp changedAt) {
        this.changedAt = changedAt;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
