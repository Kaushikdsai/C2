package com.curonex.pharmacy.entity;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class HospitalPublicKeyId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "hospital_id")
    private Long hospitalId;

    /** e.g. "v1", "v2" - lets a hospital rotate keys without invalidating prescriptions signed under the old one. */
    @Column(name = "key_version")
    private String keyVersion;

    public HospitalPublicKeyId() {
    }

    public HospitalPublicKeyId(Long hospitalId, String keyVersion) {
        this.hospitalId = hospitalId;
        this.keyVersion = keyVersion;
    }

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getKeyVersion() {
        return keyVersion;
    }

    public void setKeyVersion(String keyVersion) {
        this.keyVersion = keyVersion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HospitalPublicKeyId)) return false;
        HospitalPublicKeyId that = (HospitalPublicKeyId) o;
        return Objects.equals(hospitalId, that.hospitalId) && Objects.equals(keyVersion, that.keyVersion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(hospitalId, keyVersion);
    }
}
