package com.curonex.pharmacy.entity;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "prescriptions")
public class Prescriptions {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "prescription_id")
    private Long prescriptionId;

    @Column(name = "user_id")
    private Long userId;

    /**
     * Patient this prescription is FOR - separate from userId (who
     * uploaded it). Same family-ordering model as Orders.patientUserId:
     * null when the patient has no Curonex account, in which case
     * patientName/patientPhone carry the details instead. Set at upload
     * time and copied onto the Order when it's created, so the order keeps
     * its own snapshot even if these details are edited later on a fresh
     * prescription.
     */
    @Column(name = "patient_user_id")
    private Long patientUserId;

    @Column(name = "patient_name")
    private String patientName;

    @Column(name = "patient_age")
    private Integer patientAge;

    @Column(name = "patient_phone")
    private String patientPhone;

    @Column(name = "patient_relationship")
    private String patientRelationship;

    @Column(name = "hospital_id")
    private Long hospitalId;

    @Column(name = "doctor_id")
    private Long doctorId;

    @Column(name = "prescription_datetime")
    private Timestamp prescriptionDatetime;

    /** Soft-delete flag. Prescriptions are medical records and should not be hard-deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted;

    @OneToMany(mappedBy = "prescription", fetch = FetchType.LAZY)
    private List<Orders> orders = new ArrayList<>();

    public Long getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(Long prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getPatientUserId() {
        return patientUserId;
    }

    public void setPatientUserId(Long patientUserId) {
        this.patientUserId = patientUserId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public Integer getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(Integer patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientPhone() {
        return patientPhone;
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    public String getPatientRelationship() {
        return patientRelationship;
    }

    public void setPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
    }

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public Timestamp getPrescriptionDatetime() {
        return prescriptionDatetime;
    }

    public void setPrescriptionDatetime(Timestamp prescriptionDatetime) {
        this.prescriptionDatetime = prescriptionDatetime;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public List<Orders> getOrders() {
        return orders;
    }
}
