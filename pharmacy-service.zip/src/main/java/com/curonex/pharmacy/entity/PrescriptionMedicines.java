package com.curonex.pharmacy.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "prescription_medicines")
public class PrescriptionMedicines {

    @EmbeddedId
    private PrescriptionMedicineId id;

    /**
     * Immutable ceiling. Set exactly once, when the medicine is first
     * extracted/added from the prescription PDF - never touched again after
     * that. This is the value OrderServiceImpl enforces order quantities
     * against. Previously the code reused the same "quantity" column for
     * both this ceiling AND the patient's editable selection, so reducing
     * the selected amount permanently lowered the ceiling itself and the
     * patient could never raise it back up. Splitting the two fixes that.
     */
    @Column(name = "prescribed_quantity")
    private Integer prescribedQuantity;

    /**
     * Mutable. What the patient currently wants to order for this medicine.
     * Defaults to prescribedQuantity when first extracted. Can be edited up
     * or down freely by the patient, but must always satisfy
     * 0 <= selectedQuantity <= prescribedQuantity - enforced in
     * PrescriptionMedicinesServiceImpl.updateMedicine(), not just at order
     * creation, so the preview page can give immediate feedback.
     */
    @Column(name = "selected_quantity")
    private Integer selectedQuantity;

    public PrescriptionMedicineId getId() {
        return id;
    }

    public void setId(PrescriptionMedicineId id) {
        this.id = id;
    }

    public Integer getPrescribedQuantity() {
        return prescribedQuantity;
    }

    public void setPrescribedQuantity(Integer prescribedQuantity) {
        this.prescribedQuantity = prescribedQuantity;
    }

    public Integer getSelectedQuantity() {
        return selectedQuantity;
    }

    public void setSelectedQuantity(Integer selectedQuantity) {
        this.selectedQuantity = selectedQuantity;
    }
}
