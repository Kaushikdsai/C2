package com.curonex.pharmacy.dto;

/**
 * Internal - the parsed contents of the CURONEX-VERIFY text block embedded
 * in the prescription PDF by the hospital's generation system, before any
 * cryptographic check has happened. Never returned directly from any
 * controller.
 */
public class PrescriptionVerificationBlockDTO {

    private Long hospitalId;
    private String doctorId;
    private String patientId;
    private String prescriptionId;
    private String issuedAt;
    private String keyVersion;
    private String signatureBase64;

    /** hospitalId|doctorId|patientId|prescriptionId|issuedAt|keyVersion - exactly what the hospital's private key signed. Reconstructed here field-by-field, never taken as raw text, so an attacker can't smuggle extra characters into what gets verified. */
    private String canonicalPayload;

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(String prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public String getIssuedAt() {
        return issuedAt;
    }

    public void setIssuedAt(String issuedAt) {
        this.issuedAt = issuedAt;
    }

    public String getKeyVersion() {
        return keyVersion;
    }

    public void setKeyVersion(String keyVersion) {
        this.keyVersion = keyVersion;
    }

    public String getSignatureBase64() {
        return signatureBase64;
    }

    public void setSignatureBase64(String signatureBase64) {
        this.signatureBase64 = signatureBase64;
    }

    public String getCanonicalPayload() {
        return canonicalPayload;
    }

    public void setCanonicalPayload(String canonicalPayload) {
        this.canonicalPayload = canonicalPayload;
    }
}
