package com.curonex.pharmacy.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * One combined submission for both the pharmacy and the delivery partner
 * that fulfilled an order - the single feedback page shown to the patient
 * after delivery. Both halves are required: an order only reaches
 * DELIVERED after both a pharmacy and a delivery partner were involved, so
 * there's no legitimate case where only one half would be rated here.
 */
public class OrderFeedbackRequestDTO {

    @NotNull(message = "pharmacyRating is required")
    @DecimalMin(value = "0.0", message = "pharmacyRating must be at least 0")
    @DecimalMax(value = "5.0", message = "pharmacyRating must be at most 5")
    private BigDecimal pharmacyRating;

    @Size(max = 1000, message = "pharmacyFeedback must be 1000 characters or fewer")
    private String pharmacyFeedback;

    @NotNull(message = "deliveryRating is required")
    @DecimalMin(value = "0.0", message = "deliveryRating must be at least 0")
    @DecimalMax(value = "5.0", message = "deliveryRating must be at most 5")
    private BigDecimal deliveryRating;

    @Size(max = 1000, message = "deliveryFeedback must be 1000 characters or fewer")
    private String deliveryFeedback;

    public BigDecimal getPharmacyRating() {
        return pharmacyRating;
    }

    public void setPharmacyRating(BigDecimal pharmacyRating) {
        this.pharmacyRating = pharmacyRating;
    }

    public String getPharmacyFeedback() {
        return pharmacyFeedback;
    }

    public void setPharmacyFeedback(String pharmacyFeedback) {
        this.pharmacyFeedback = pharmacyFeedback;
    }

    public BigDecimal getDeliveryRating() {
        return deliveryRating;
    }

    public void setDeliveryRating(BigDecimal deliveryRating) {
        this.deliveryRating = deliveryRating;
    }

    public String getDeliveryFeedback() {
        return deliveryFeedback;
    }

    public void setDeliveryFeedback(String deliveryFeedback) {
        this.deliveryFeedback = deliveryFeedback;
    }
}
