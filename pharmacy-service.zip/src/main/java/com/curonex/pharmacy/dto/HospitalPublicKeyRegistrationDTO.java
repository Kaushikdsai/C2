package com.curonex.pharmacy.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Admin-only registration/rotation endpoint. The private key is never part
 * of this request and never will be - only the hospital ever has it.
 */
public class HospitalPublicKeyRegistrationDTO {

    @NotNull(message = "hospitalId is required")
    private Long hospitalId;

    @NotBlank(message = "keyVersion is required")
    private String keyVersion;

    /** Base64-encoded X.509 SubjectPublicKeyInfo bytes (standard "-----BEGIN PUBLIC KEY-----" PEM body, base64 only, no headers). */
    @NotBlank(message = "publicKeyBase64 is required")
    private String publicKeyBase64;

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getKeyVersion() {
        return keyVersion;
    }

    public void setKeyVersion(String keyVersion) {
        this.keyVersion = keyVersion;
    }

    public String getPublicKeyBase64() {
        return publicKeyBase64;
    }

    public void setPublicKeyBase64(String publicKeyBase64) {
        this.publicKeyBase64 = publicKeyBase64;
    }
}
