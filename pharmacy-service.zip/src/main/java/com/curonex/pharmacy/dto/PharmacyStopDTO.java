package com.curonex.pharmacy.dto;

/** One pickup stop on a delivery partner's route. A single-pharmacy order has exactly one of these; a 2-pharmacy partial-fulfillment order has two, in pickup order (sequenceNo 1 then 2). */
public class PharmacyStopDTO {

    private Long pharmacyId;
    private String pharmacyName;
    private String pharmacyGeoAddress;
    private Integer sequenceNo;
    private boolean pickedUp;

    /**
     * SAMPLE OTP ONLY - shown directly on screen so the delivery partner
     * can "verify" pickup without needing a real SMS/OTP provider (not
     * permitted for this project). Deterministically derived from the
     * order and pharmacy IDs so it isn't literally the same 4 digits for
     * every order, but it is NOT a secret and NOT cryptographically
     * generated - do not treat this as real verification in a production
     * deployment.
     */
    private String pickupOtp;

    public Long getPharmacyId() {
        return pharmacyId;
    }

    public void setPharmacyId(Long pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    public String getPharmacyName() {
        return pharmacyName;
    }

    public void setPharmacyName(String pharmacyName) {
        this.pharmacyName = pharmacyName;
    }

    public String getPharmacyGeoAddress() {
        return pharmacyGeoAddress;
    }

    public void setPharmacyGeoAddress(String pharmacyGeoAddress) {
        this.pharmacyGeoAddress = pharmacyGeoAddress;
    }

    public Integer getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(Integer sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    public boolean isPickedUp() {
        return pickedUp;
    }

    public void setPickedUp(boolean pickedUp) {
        this.pickedUp = pickedUp;
    }

    public String getPickupOtp() {
        return pickupOtp;
    }

    public void setPickupOtp(String pickupOtp) {
        this.pickupOtp = pickupOtp;
    }
}
