package com.curonex.pharmacy.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class OrderCreateRequestDTO {

    @NotNull(message = "userId is required")
    private Long userId;

    /** "13.0980,81.0890" - captured from the browser geolocation prompt at checkout. Required: the whole broadcast/priority model depends on it. */
    @NotNull(message = "patientGeoAddress is required")
    @Pattern(regexp = "^-?\\d{1,3}\\.\\d+,-?\\d{1,3}\\.\\d+$", message = "patientGeoAddress must be in 'lat,lon' format")
    private String patientGeoAddress;

    /**
     * Required. Every order must trace back to a saved Prescriptions record
     * (created from POST /api/prescriptions + POST /api/prescriptions/{id}/medicines
     * after PDF extraction). This is the source of truth for three things:
     *   1. hospitalId - read from the prescription, never trusted from the
     *      client directly, so a caller can't spoof hospital-priority.
     *   2. the per-medicine quantity ceiling - a patient can reduce quantity
     *      or drop an item entirely, but can never order more of a medicine
     *      than was actually prescribed.
     *   3. who the order is FOR (patientName/patientPhone/etc) - also read
     *      from the prescription, never accepted directly on this request,
     *      so a caller can't silently reassign an order to a different
     *      patient than the one the prescription (and its QR/PDF
     *      verification) was actually issued for.
     */
    @NotNull(message = "prescriptionId is required")
    private Long prescriptionId;

    @NotEmpty(message = "items must not be empty")
    @Valid
    private List<OrderCreateItemDTO> items;

    /** Optional free-text note from the patient, shown to the delivery partner alongside the order (e.g. "Leave at the gate"). */
    @Size(max = 500, message = "deliveryNote must be 500 characters or fewer")
    private String deliveryNote;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getPatientGeoAddress() {
        return patientGeoAddress;
    }

    public void setPatientGeoAddress(String patientGeoAddress) {
        this.patientGeoAddress = patientGeoAddress;
    }

    public Long getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(Long prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public List<OrderCreateItemDTO> getItems() {
        return items;
    }

    public void setItems(List<OrderCreateItemDTO> items) {
        this.items = items;
    }

    public String getDeliveryNote() {
        return deliveryNote;
    }

    public void setDeliveryNote(String deliveryNote) {
        this.deliveryNote = deliveryNote;
    }
}
