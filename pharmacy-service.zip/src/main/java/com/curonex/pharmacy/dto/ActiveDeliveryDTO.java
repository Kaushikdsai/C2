package com.curonex.pharmacy.dto;

import java.math.BigDecimal;

import com.curonex.pharmacy.enums.OrderStatusEnum;

public class ActiveDeliveryDTO {

    private Long orderId;
    private OrderStatusEnum status;

    // Patient the medicines are FOR - this used to be wrongly resolved from
    // the ORDERER's account (order.getUserId()), which broke the moment
    // someone ordered for a parent/family member. Now sourced from the
    // order's own patient snapshot (see Orders.patientName etc.), which is
    // correct regardless of who placed the order.
    private String patientName;
    private Integer patientAge;
    private String patientPhone;
    private String patientRelationship;
    private String patientAddress;

    // Whoever placed the order, shown separately so a partner isn't
    // confused when it doesn't match the patient (e.g. "Ordered by Kaushik
    // for his mother").
    private String orderedByName;
    private String orderedByPhone;

    private String pharmacyName;
    private Integer itemCount;
    private BigDecimal totalAmount;
    private String deliveryNote;
    private Integer estimatedDeliveryMinutes;

    /** All pickup stops on this order's route, in pickup order - one for a single-pharmacy order, two for a 2-pharmacy partial-fulfillment order. */
    private java.util.List<PharmacyStopDTO> pharmacyStops;

    /** SAMPLE OTP ONLY, shown on screen for the final patient hand-off - see PharmacyStopDTO for the same caveat on the pickup side. */
    private String deliveryOtp;

    // "lat,lng" strings, needed to build Google Maps direction links.
    private String pharmacyGeoAddress;
    private String patientGeoAddress;
    private String partnerGeoAddress;

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public OrderStatusEnum getStatus() { return status; }
    public void setStatus(OrderStatusEnum status) { this.status = status; }

    public String getPatientName() { return patientName; }
    public void setPatientName(String patientName) { this.patientName = patientName; }

    public Integer getPatientAge() { return patientAge; }
    public void setPatientAge(Integer patientAge) { this.patientAge = patientAge; }

    public String getPatientPhone() { return patientPhone; }
    public void setPatientPhone(String patientPhone) { this.patientPhone = patientPhone; }

    public String getPatientRelationship() { return patientRelationship; }
    public void setPatientRelationship(String patientRelationship) { this.patientRelationship = patientRelationship; }

    public String getPatientAddress() { return patientAddress; }
    public void setPatientAddress(String patientAddress) { this.patientAddress = patientAddress; }

    public String getOrderedByName() { return orderedByName; }
    public void setOrderedByName(String orderedByName) { this.orderedByName = orderedByName; }

    public String getOrderedByPhone() { return orderedByPhone; }
    public void setOrderedByPhone(String orderedByPhone) { this.orderedByPhone = orderedByPhone; }

    public String getPharmacyName() { return pharmacyName; }
    public void setPharmacyName(String pharmacyName) { this.pharmacyName = pharmacyName; }

    public Integer getItemCount() { return itemCount; }
    public void setItemCount(Integer itemCount) { this.itemCount = itemCount; }

    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }

    public String getDeliveryNote() { return deliveryNote; }
    public void setDeliveryNote(String deliveryNote) { this.deliveryNote = deliveryNote; }

    public Integer getEstimatedDeliveryMinutes() { return estimatedDeliveryMinutes; }
    public void setEstimatedDeliveryMinutes(Integer estimatedDeliveryMinutes) { this.estimatedDeliveryMinutes = estimatedDeliveryMinutes; }

    public java.util.List<PharmacyStopDTO> getPharmacyStops() { return pharmacyStops; }
    public void setPharmacyStops(java.util.List<PharmacyStopDTO> pharmacyStops) { this.pharmacyStops = pharmacyStops; }

    public String getDeliveryOtp() { return deliveryOtp; }
    public void setDeliveryOtp(String deliveryOtp) { this.deliveryOtp = deliveryOtp; }

    public String getPharmacyGeoAddress() { return pharmacyGeoAddress; }
    public void setPharmacyGeoAddress(String pharmacyGeoAddress) { this.pharmacyGeoAddress = pharmacyGeoAddress; }

    public String getPatientGeoAddress() { return patientGeoAddress; }
    public void setPatientGeoAddress(String patientGeoAddress) { this.patientGeoAddress = patientGeoAddress; }

    public String getPartnerGeoAddress() { return partnerGeoAddress; }
    public void setPartnerGeoAddress(String partnerGeoAddress) { this.partnerGeoAddress = partnerGeoAddress; }
}
