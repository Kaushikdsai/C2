package com.curonex.pharmacy.dto;

import java.sql.Timestamp;

import com.curonex.pharmacy.enums.OrderStatusEnum;

public class OrderStatusHistoryDTO {

    private OrderStatusEnum previousStatus;
    private OrderStatusEnum newStatus;
    private Timestamp changedAt;
    private String note;

    public OrderStatusEnum getPreviousStatus() {
        return previousStatus;
    }

    public void setPreviousStatus(OrderStatusEnum previousStatus) {
        this.previousStatus = previousStatus;
    }

    public OrderStatusEnum getNewStatus() {
        return newStatus;
    }

    public void setNewStatus(OrderStatusEnum newStatus) {
        this.newStatus = newStatus;
    }

    public Timestamp getChangedAt() {
        return changedAt;
    }

    public void setChangedAt(Timestamp changedAt) {
        this.changedAt = changedAt;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
