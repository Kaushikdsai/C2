package com.curonex.pharmacy.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * Order-level "order for someone else" edit, used once an order already
 * exists (before it's picked up). For edits BEFORE the order is created,
 * use PUT /api/prescriptions/{id} instead - the prescription's patient
 * fields are what createOrder() snapshots onto the new order.
 */
public class PatientDetailsUpdateDTO {

    /** Null if the patient has no Curonex account. */
    private Long patientUserId;

    @NotBlank(message = "patientName is required")
    private String patientName;

    private Integer patientAge;

    @NotBlank(message = "patientPhone is required")
    private String patientPhone;

    private String patientRelationship;

    public Long getPatientUserId() {
        return patientUserId;
    }

    public void setPatientUserId(Long patientUserId) {
        this.patientUserId = patientUserId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public Integer getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(Integer patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientPhone() {
        return patientPhone;
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    public String getPatientRelationship() {
        return patientRelationship;
    }

    public void setPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
    }
}
