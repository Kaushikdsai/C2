package com.curonex.pharmacy.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

/**
 * Used against the SAME endpoint for two different moments in the partial-
 * fulfillment flow (PharmacyServiceImpl.acceptPartialOrder decides which
 * based on the order's current status):
 *   - order is PENDING: this pharmacy is claiming SOME of the medicines
 *     (must be >= curonex.fulfillment.partial-threshold-percent of the
 *     line items) - becomes the "first partial pharmacy".
 *   - order is PARTIALLY_ALLOCATED: this pharmacy must cover exactly the
 *     medicines still unallocated - becomes the "second pharmacy" and the
 *     order is fully allocated.
 * Either way, only the medicines THIS pharmacy can supply go in
 * itemPrices - never the full order's item list.
 */
public class PharmacyPartialAcceptRequestDTO {

    @NotEmpty(message = "itemPrices must not be empty")
    @Valid
    private List<PharmacyAcceptItemDTO> itemPrices;

    public List<PharmacyAcceptItemDTO> getItemPrices() {
        return itemPrices;
    }

    public void setItemPrices(List<PharmacyAcceptItemDTO> itemPrices) {
        this.itemPrices = itemPrices;
    }
}
