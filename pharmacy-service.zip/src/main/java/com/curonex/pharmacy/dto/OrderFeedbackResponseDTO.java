package com.curonex.pharmacy.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class OrderFeedbackResponseDTO {

    private Long orderId;
    private Long pharmacyId;
    private Long deliveryPartnerId;
    private BigDecimal pharmacyRating;
    private String pharmacyFeedback;
    private BigDecimal deliveryRating;
    private String deliveryFeedback;
    private Timestamp submittedAt;

    /** Denormalized for display convenience on the pharmacy/delivery-partner feedback list screens. */
    private String patientName;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getPharmacyId() {
        return pharmacyId;
    }

    public void setPharmacyId(Long pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    public Long getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(Long deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public BigDecimal getPharmacyRating() {
        return pharmacyRating;
    }

    public void setPharmacyRating(BigDecimal pharmacyRating) {
        this.pharmacyRating = pharmacyRating;
    }

    public String getPharmacyFeedback() {
        return pharmacyFeedback;
    }

    public void setPharmacyFeedback(String pharmacyFeedback) {
        this.pharmacyFeedback = pharmacyFeedback;
    }

    public BigDecimal getDeliveryRating() {
        return deliveryRating;
    }

    public void setDeliveryRating(BigDecimal deliveryRating) {
        this.deliveryRating = deliveryRating;
    }

    public String getDeliveryFeedback() {
        return deliveryFeedback;
    }

    public void setDeliveryFeedback(String deliveryFeedback) {
        this.deliveryFeedback = deliveryFeedback;
    }

    public Timestamp getSubmittedAt() {
        return submittedAt;
    }

    public void setSubmittedAt(Timestamp submittedAt) {
        this.submittedAt = submittedAt;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }
}
