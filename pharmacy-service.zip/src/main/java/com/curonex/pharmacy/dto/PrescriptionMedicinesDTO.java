package com.curonex.pharmacy.dto;

public class PrescriptionMedicinesDTO {

    private Long prescriptionId;
    private String medicineName;

    /**
     * Read-only in responses. Only ever set server-side, at extraction
     * time. Requests to updateMedicine() must NOT be able to change this -
     * see PrescriptionMedicinesServiceImpl.
     */
    private Integer prescribedQuantity;

    /** What the patient wants to order right now. This is the only field updateMedicine() may change. */
    private Integer selectedQuantity;

    public Long getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(Long prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public Integer getPrescribedQuantity() {
        return prescribedQuantity;
    }

    public void setPrescribedQuantity(Integer prescribedQuantity) {
        this.prescribedQuantity = prescribedQuantity;
    }

    public Integer getSelectedQuantity() {
        return selectedQuantity;
    }

    public void setSelectedQuantity(Integer selectedQuantity) {
        this.selectedQuantity = selectedQuantity;
    }
}
