package com.curonex.pharmacy.dto;

import java.sql.Timestamp;
import java.util.List;

/**
 * A PARTIALLY_ALLOCATED order that this pharmacy is close enough (within
 * curonex.fulfillment.missing-item-search-radius-km of the first
 * pharmacy) to potentially complete. Shown on a dedicated tab/section
 * distinct from the ordinary "available orders" (full-order) list, since
 * accepting one of these means covering exactly missingItems, not choosing
 * a price for the whole order.
 */
public class AvailablePartialOrderDTO {

    private Long orderId;
    private List<MissingItemDTO> missingItems;
    private Timestamp orderDatetime;
    private String patientName;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public List<MissingItemDTO> getMissingItems() {
        return missingItems;
    }

    public void setMissingItems(List<MissingItemDTO> missingItems) {
        this.missingItems = missingItems;
    }

    public Timestamp getOrderDatetime() {
        return orderDatetime;
    }

    public void setOrderDatetime(Timestamp orderDatetime) {
        this.orderDatetime = orderDatetime;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }
}
