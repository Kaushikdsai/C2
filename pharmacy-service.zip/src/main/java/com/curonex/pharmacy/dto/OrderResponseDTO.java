package com.curonex.pharmacy.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import com.curonex.pharmacy.enums.OrderStatusEnum;

public class OrderResponseDTO {

    private Long orderId;
    private Long pharmacyId;
    private Long deliveryPartnerId;
    private Long userId;
    private Long prescriptionId;
    private Long hospitalId;
    private OrderStatusEnum status;
    private Timestamp orderDatetime;
    private BigDecimal totalAmount;
    private List<OrderItemDTO> items;

    /** Who placed the order - may differ from the patient (e.g. ordering for a parent). */
    private String orderedByName;
    private String orderedByPhone;

    /** Who the order is FOR. Always populated regardless of whether the patient has a Curonex account. */
    private Long patientUserId;
    private String patientName;
    private Integer patientAge;
    private String patientPhone;
    private String patientRelationship;

    private String deliveryNote;
    private Integer estimatedDeliveryMinutes;

    /** Set once pharmacy fulfillment is 100% and price is fixed - patient must accept before this (item 11). Null otherwise. */
    private Timestamp priceConfirmationDeadline;

    private Timestamp confirmedAt;
    private Timestamp pickedUpAt;
    private Timestamp deliveredAt;
    private Timestamp cancelledAt;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getPharmacyId() {
        return pharmacyId;
    }

    public void setPharmacyId(Long pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    public Long getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(Long deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(Long prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public OrderStatusEnum getStatus() {
        return status;
    }

    public void setStatus(OrderStatusEnum status) {
        this.status = status;
    }

    public Timestamp getOrderDatetime() {
        return orderDatetime;
    }

    public void setOrderDatetime(Timestamp orderDatetime) {
        this.orderDatetime = orderDatetime;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public List<OrderItemDTO> getItems() {
        return items;
    }

    public void setItems(List<OrderItemDTO> items) {
        this.items = items;
    }

    public String getOrderedByName() {
        return orderedByName;
    }

    public void setOrderedByName(String orderedByName) {
        this.orderedByName = orderedByName;
    }

    public String getOrderedByPhone() {
        return orderedByPhone;
    }

    public void setOrderedByPhone(String orderedByPhone) {
        this.orderedByPhone = orderedByPhone;
    }

    public Long getPatientUserId() {
        return patientUserId;
    }

    public void setPatientUserId(Long patientUserId) {
        this.patientUserId = patientUserId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public Integer getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(Integer patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientPhone() {
        return patientPhone;
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    public String getPatientRelationship() {
        return patientRelationship;
    }

    public void setPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
    }

    public String getDeliveryNote() {
        return deliveryNote;
    }

    public void setDeliveryNote(String deliveryNote) {
        this.deliveryNote = deliveryNote;
    }

    public Integer getEstimatedDeliveryMinutes() {
        return estimatedDeliveryMinutes;
    }

    public void setEstimatedDeliveryMinutes(Integer estimatedDeliveryMinutes) {
        this.estimatedDeliveryMinutes = estimatedDeliveryMinutes;
    }

    public Timestamp getPriceConfirmationDeadline() {
        return priceConfirmationDeadline;
    }

    public void setPriceConfirmationDeadline(Timestamp priceConfirmationDeadline) {
        this.priceConfirmationDeadline = priceConfirmationDeadline;
    }

    public Timestamp getConfirmedAt() {
        return confirmedAt;
    }

    public void setConfirmedAt(Timestamp confirmedAt) {
        this.confirmedAt = confirmedAt;
    }

    public Timestamp getPickedUpAt() {
        return pickedUpAt;
    }

    public void setPickedUpAt(Timestamp pickedUpAt) {
        this.pickedUpAt = pickedUpAt;
    }

    public Timestamp getDeliveredAt() {
        return deliveredAt;
    }

    public void setDeliveredAt(Timestamp deliveredAt) {
        this.deliveredAt = deliveredAt;
    }

    public Timestamp getCancelledAt() {
        return cancelledAt;
    }

    public void setCancelledAt(Timestamp cancelledAt) {
        this.cancelledAt = cancelledAt;
    }
}
