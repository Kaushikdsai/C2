package com.curonex.pharmacy.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;

import com.curonex.pharmacy.enums.OrderStatusEnum;

public class OrderTrackingDTO {

    private Long orderId;
    private OrderStatusEnum status;
    private Timestamp orderDatetime;
    private Integer itemCount;
    private BigDecimal totalAmount;

    private String pharmacyName;
    private String pharmacyGeoAddress;

    private String deliveryPartnerName;
    private String deliveryPartnerPhone;
    private Integer estimatedDeliveryMinutes;

    /** Who the order is FOR (may differ from whoever is viewing/tracking it). */
    private String patientName;
    private Integer patientAge;
    private String patientPhone;
    private String patientRelationship;

    private String deliveryNote;

    /** Set once pharmacy fulfillment is 100% complete and price is fixed - the patient has until this moment to accept the price (item 11) before it auto-cancels. Null before/after that window. */
    private Timestamp priceConfirmationDeadline;

    private Timestamp confirmedAt;
    private Timestamp pickedUpAt;
    private Timestamp deliveredAt;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public OrderStatusEnum getStatus() {
        return status;
    }

    public void setStatus(OrderStatusEnum status) {
        this.status = status;
    }

    public Timestamp getOrderDatetime() {
        return orderDatetime;
    }

    public void setOrderDatetime(Timestamp orderDatetime) {
        this.orderDatetime = orderDatetime;
    }

    public Integer getItemCount() {
        return itemCount;
    }

    public void setItemCount(Integer itemCount) {
        this.itemCount = itemCount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getPharmacyName() {
        return pharmacyName;
    }

    public void setPharmacyName(String pharmacyName) {
        this.pharmacyName = pharmacyName;
    }

    public String getPharmacyGeoAddress() {
        return pharmacyGeoAddress;
    }

    public void setPharmacyGeoAddress(String pharmacyGeoAddress) {
        this.pharmacyGeoAddress = pharmacyGeoAddress;
    }

    public String getDeliveryPartnerName() {
        return deliveryPartnerName;
    }

    public void setDeliveryPartnerName(String deliveryPartnerName) {
        this.deliveryPartnerName = deliveryPartnerName;
    }

    public String getDeliveryPartnerPhone() {
        return deliveryPartnerPhone;
    }

    public void setDeliveryPartnerPhone(String deliveryPartnerPhone) {
        this.deliveryPartnerPhone = deliveryPartnerPhone;
    }

    public Integer getEstimatedDeliveryMinutes() {
        return estimatedDeliveryMinutes;
    }

    public void setEstimatedDeliveryMinutes(Integer estimatedDeliveryMinutes) {
        this.estimatedDeliveryMinutes = estimatedDeliveryMinutes;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public Integer getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(Integer patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientPhone() {
        return patientPhone;
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    public String getPatientRelationship() {
        return patientRelationship;
    }

    public void setPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
    }

    public String getDeliveryNote() {
        return deliveryNote;
    }

    public void setDeliveryNote(String deliveryNote) {
        this.deliveryNote = deliveryNote;
    }

    public Timestamp getPriceConfirmationDeadline() {
        return priceConfirmationDeadline;
    }

    public void setPriceConfirmationDeadline(Timestamp priceConfirmationDeadline) {
        this.priceConfirmationDeadline = priceConfirmationDeadline;
    }

    public Timestamp getConfirmedAt() {
        return confirmedAt;
    }

    public void setConfirmedAt(Timestamp confirmedAt) {
        this.confirmedAt = confirmedAt;
    }

    public Timestamp getPickedUpAt() {
        return pickedUpAt;
    }

    public void setPickedUpAt(Timestamp pickedUpAt) {
        this.pickedUpAt = pickedUpAt;
    }

    public Timestamp getDeliveredAt() {
        return deliveredAt;
    }

    public void setDeliveredAt(Timestamp deliveredAt) {
        this.deliveredAt = deliveredAt;
    }
}
