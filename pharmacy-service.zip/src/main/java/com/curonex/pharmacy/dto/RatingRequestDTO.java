package com.curonex.pharmacy.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

public class RatingRequestDTO {

    /**
     * Required. Ties the rating to a real completed order so it can be
     * validated: the order must be DELIVERED, must belong to the
     * pharmacy/partner being rated, and must not have already been rated -
     * closes the abuse case where a rating could previously be submitted
     * with no connection to an actual transaction.
     */
    @NotNull(message = "orderId is required")
    private Long orderId;

    @NotNull(message = "rating is required")
    @DecimalMin(value = "0.0", message = "rating must be at least 0")
    @DecimalMax(value = "5.0", message = "rating must be at most 5")
    private BigDecimal rating;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public BigDecimal getRating() {
        return rating;
    }

    public void setRating(BigDecimal rating) {
        this.rating = rating;
    }
}
