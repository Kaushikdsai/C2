package com.curonex.pharmacy.dto;

import java.util.List;

import com.curonex.pharmacy.enums.PrescriptionVerificationStatusEnum;

public class PrescriptionVerificationResultDTO {

    private PrescriptionVerificationStatusEnum status;

    /** Always one of a fixed set of safe, non-technical messages - see PrescriptionVerificationServiceImpl.REASON_*. Never a raw exception message. */
    private String reason;

    private Long hospitalId;
    private String prescriptionReference;

    /** Only populated when status == VERIFIED. */
    private String extractedText;
    private List<ExtractedMedicineDTO> medicines;

    public PrescriptionVerificationStatusEnum getStatus() {
        return status;
    }

    public void setStatus(PrescriptionVerificationStatusEnum status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getPrescriptionReference() {
        return prescriptionReference;
    }

    public void setPrescriptionReference(String prescriptionReference) {
        this.prescriptionReference = prescriptionReference;
    }

    public String getExtractedText() {
        return extractedText;
    }

    public void setExtractedText(String extractedText) {
        this.extractedText = extractedText;
    }

    public List<ExtractedMedicineDTO> getMedicines() {
        return medicines;
    }

    public void setMedicines(List<ExtractedMedicineDTO> medicines) {
        this.medicines = medicines;
    }
}
