package com.curonex.pharmacy.dto;

public class MissingItemDTO {

    private String medicineName;
    private Integer quantity;

    public MissingItemDTO() {
    }

    public MissingItemDTO(String medicineName, Integer quantity) {
        this.medicineName = medicineName;
        this.quantity = quantity;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
