package com.curonex.pharmacy.dto;

import java.sql.Timestamp;

public class PrescriptionsDTO {

    private Long prescriptionId;
    private Long userId;

    /** Registered Curonex user this prescription is for, if any. Null when the patient has no account. */
    private Long patientUserId;

    /** Always required, regardless of patientUserId - the display name to use everywhere (preview, pharmacy, delivery partner). */
    private String patientName;

    private Integer patientAge;

    /** Always required - the contact number the pharmacy/delivery partner should use for this order. */
    private String patientPhone;

    /** e.g. "Self", "Mother", "Father", "Child", "Spouse", "Other". Free text, display-only. */
    private String patientRelationship;

    private Long hospitalId;
    private Long doctorId;
    private Timestamp prescriptionDatetime;

    public Long getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(Long prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getPatientUserId() {
        return patientUserId;
    }

    public void setPatientUserId(Long patientUserId) {
        this.patientUserId = patientUserId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public Integer getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(Integer patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientPhone() {
        return patientPhone;
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    public String getPatientRelationship() {
        return patientRelationship;
    }

    public void setPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
    }

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public Timestamp getPrescriptionDatetime() {
        return prescriptionDatetime;
    }

    public void setPrescriptionDatetime(Timestamp prescriptionDatetime) {
        this.prescriptionDatetime = prescriptionDatetime;
    }
}
