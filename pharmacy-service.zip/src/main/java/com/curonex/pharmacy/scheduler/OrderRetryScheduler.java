package com.curonex.pharmacy.scheduler;

import java.time.Instant;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.event.OrderStatusChangedEvent;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import org.springframework.context.ApplicationEventPublisher;

/**
 * Item 9: requests used to stay open on both sides indefinitely because
 * rebroadcasting never stopped. Both sweeps below now count attempts on the
 * order itself (pharmacyRebroadcastCount / deliveryRebroadcastCount) and
 * give up after curonex.fulfillment.max-rebroadcasts, moving the order to
 * FULFILLMENT_FAILED - which is also what makes it disappear from both the
 * pharmacy and delivery-partner dashboards, since those only ever query
 * for PENDING/PARTIALLY_ALLOCATED/CONFIRMED-family orders.
 */
@Component
public class OrderRetryScheduler {

    private static final Logger log = LoggerFactory.getLogger(OrderRetryScheduler.class);

    private static final long PHARMACY_TIMEOUT_MINUTES = 5;
    private static final long DELIVERY_TIMEOUT_MINUTES = 10;

    private final OrderRepository orderRepository;
    private final PharmacyRoutingService pharmacyRoutingService;
    private final DeliveryRoutingService deliveryRoutingService;
    private final ApplicationEventPublisher eventPublisher;

    @Value("${curonex.fulfillment.max-rebroadcasts:3}")
    private int maxRebroadcasts;

    public OrderRetryScheduler(
            OrderRepository orderRepository,
            PharmacyRoutingService pharmacyRoutingService,
            DeliveryRoutingService deliveryRoutingService,
            ApplicationEventPublisher eventPublisher) {
        this.orderRepository = orderRepository;
        this.pharmacyRoutingService = pharmacyRoutingService;
        this.deliveryRoutingService = deliveryRoutingService;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Still PENDING (no pharmacy at all) or PARTIALLY_ALLOCATED (stuck
     * looking for a second pharmacy) after 5 minutes -> rebroadcast. After
     * maxRebroadcasts attempts with no full coverage, fail the order
     * instead of rebroadcasting again.
     */
    @Scheduled(fixedRate = 60000)
    public void retryUnclaimedPharmacyOrders() {
        List<Orders> pendingOrders = orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING);
        List<Orders> partiallyAllocatedOrders = orderRepository.findByStatus(OrderStatusEnum.PARTIALLY_ALLOCATED);

        for (Orders order : pendingOrders) {
            handlePharmacySearchTimeout(order);
        }
        for (Orders order : partiallyAllocatedOrders) {
            handlePharmacySearchTimeout(order);
        }
    }

    private void handlePharmacySearchTimeout(Orders order) {
        if (order.getOrderDatetime() == null) {
            return;
        }
        long minutesElapsed = (Instant.now().toEpochMilli() - order.getOrderDatetime().getTime()) / 60000;
        if (minutesElapsed < PHARMACY_TIMEOUT_MINUTES) {
            return;
        }

        int attemptsSoFar = order.getPharmacyRebroadcastCount() != null ? order.getPharmacyRebroadcastCount() : 0;
        if (attemptsSoFar >= maxRebroadcasts) {
            int rowsAffected = orderRepository.markPharmacySearchFailed(
                    order.getOrderId(), OrderStatusEnum.FULFILLMENT_FAILED, OrderStatusEnum.PENDING, OrderStatusEnum.PARTIALLY_ALLOCATED);
            if (rowsAffected > 0) {
                log.info("Order {} failed pharmacy fulfillment after {} rebroadcasts - no delivery will start",
                        order.getOrderId(), attemptsSoFar);
                eventPublisher.publishEvent(new OrderStatusChangedEvent(
                        order.getOrderId(), order.getStatus(), OrderStatusEnum.FULFILLMENT_FAILED,
                        "Could not fully fulfill this order after " + attemptsSoFar + " attempts - no pharmacy combination reached 100% coverage"));
            }
            return;
        }

        log.info("Order {} unclaimed after {} min - rebroadcasting (attempt {}/{})",
                order.getOrderId(), minutesElapsed, attemptsSoFar + 1, maxRebroadcasts);
        orderRepository.incrementPharmacyRebroadcastCount(order.getOrderId());
        pharmacyRoutingService.rebroadcastOrder(order.getOrderId());
    }

    /**
     * Item 11: PHARMACY_CONFIRMED orders whose price-acceptance window has
     * lapsed with no patient action -> auto-cancel (PAYMENT_WINDOW_EXPIRED),
     * per your answer that the order should auto-cancel rather than retry.
     */
    @Scheduled(fixedRate = 60000)
    public void expirePriceAcceptanceWindows() {
        int expiredCount = orderRepository.expirePriceWindows(
                OrderStatusEnum.PAYMENT_WINDOW_EXPIRED, OrderStatusEnum.PHARMACY_CONFIRMED);
        if (expiredCount > 0) {
            log.info("{} order(s) auto-cancelled - price acceptance window expired", expiredCount);
        }
    }

    /**
     * CONFIRMED but no delivery partner after 10 minutes -> rebroadcast.
     * Same maxRebroadcasts cap as the pharmacy side, using
     * deliveryRebroadcastCount independently.
     */
    @Scheduled(fixedRate = 60000)
    public void retryUnclaimedDeliveryOrders() {
        List<Orders> confirmedOrders =
                orderRepository.findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum.CONFIRMED);

        for (Orders order : confirmedOrders) {
            if (order.getOrderDatetime() == null) {
                continue;
            }
            long minutesElapsed = (Instant.now().toEpochMilli() - order.getOrderDatetime().getTime()) / 60000;
            if (minutesElapsed < DELIVERY_TIMEOUT_MINUTES) {
                continue;
            }

            int attemptsSoFar = order.getDeliveryRebroadcastCount() != null ? order.getDeliveryRebroadcastCount() : 0;
            if (attemptsSoFar >= maxRebroadcasts) {
                int rowsAffected = orderRepository.markDeliverySearchFailed(
                        order.getOrderId(), OrderStatusEnum.FULFILLMENT_FAILED, OrderStatusEnum.CONFIRMED);
                if (rowsAffected > 0) {
                    log.info("Order {} failed delivery-partner search after {} rebroadcasts",
                            order.getOrderId(), attemptsSoFar);
                    eventPublisher.publishEvent(new OrderStatusChangedEvent(
                            order.getOrderId(), OrderStatusEnum.CONFIRMED, OrderStatusEnum.FULFILLMENT_FAILED,
                            "No delivery partner accepted this order after " + attemptsSoFar + " attempts"));
                }
                continue;
            }

            log.info("Order {} unclaimed by any delivery partner after {} min - rebroadcasting (attempt {}/{})",
                    order.getOrderId(), minutesElapsed, attemptsSoFar + 1, maxRebroadcasts);
            orderRepository.incrementDeliveryRebroadcastCount(order.getOrderId());
            deliveryRoutingService.rebroadcastOrder(order.getOrderId());
        }
    }
}
