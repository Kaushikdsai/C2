package com.curonex.pharmacy.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.curonex.pharmacy.dto.PrescriptionMedicinesDTO;
import com.curonex.pharmacy.entity.PrescriptionMedicineId;
import com.curonex.pharmacy.entity.PrescriptionMedicines;
import com.curonex.pharmacy.exceptions.PrescriptionQuantityExceededException;
import com.curonex.pharmacy.repository.PrescriptionMedicinesRepository;
import com.curonex.pharmacy.service.PrescriptionMedicinesService;

@Service
public class PrescriptionMedicinesServiceImpl implements PrescriptionMedicinesService {

    private final PrescriptionMedicinesRepository prescriptionMedicineRepository;

    public PrescriptionMedicinesServiceImpl(PrescriptionMedicinesRepository prescriptionMedicineRepository) {
        this.prescriptionMedicineRepository = prescriptionMedicineRepository;
    }

    /**
     * Extraction-time creation. prescribedQuantity is the ceiling and is
     * set once, here, from what was actually read off the prescription.
     * selectedQuantity starts out equal to it (patient hasn't edited
     * anything yet) and is the only thing later edits are allowed to touch.
     */
    @Override
    public PrescriptionMedicinesDTO addMedicine(Long prescriptionId, PrescriptionMedicinesDTO dto) {
        if (dto.getPrescribedQuantity() == null || dto.getPrescribedQuantity() < 0) {
            throw new IllegalArgumentException("prescribedQuantity must be a non-negative value read from the prescription");
        }

        PrescriptionMedicineId id = new PrescriptionMedicineId(prescriptionId, dto.getMedicineName());

        PrescriptionMedicines medicine = new PrescriptionMedicines();
        medicine.setId(id);
        medicine.setPrescribedQuantity(dto.getPrescribedQuantity());
        medicine.setSelectedQuantity(dto.getPrescribedQuantity());

        return convertToDTO(prescriptionMedicineRepository.save(medicine));
    }

    @Override
    public List<PrescriptionMedicinesDTO> getMedicinesByPrescription(Long prescriptionId) {
        return prescriptionMedicineRepository.findByIdPrescriptionId(prescriptionId)
                .stream().map(this::convertToDTO).toList();
    }

    /**
     * Patient-facing edit (preview page "adjust quantity" control). This
     * MUST NEVER touch prescribedQuantity - that field is the ceiling and
     * is immutable after creation. Only selectedQuantity moves, and it is
     * clamped to [0, prescribedQuantity] so a patient can freely go up and
     * down (e.g. correct a mistaken decrease) without ever being able to
     * exceed what was actually prescribed.
     */
    @Override
    public PrescriptionMedicinesDTO updateMedicine(Long prescriptionId, String medicineName, PrescriptionMedicinesDTO dto) {
        PrescriptionMedicineId id = new PrescriptionMedicineId(prescriptionId, medicineName);

        PrescriptionMedicines medicine = prescriptionMedicineRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Medicine not found"));

        Integer requested = dto.getSelectedQuantity();
        if (requested == null || requested < 0) {
            throw new IllegalArgumentException("selectedQuantity must be zero or a positive value");
        }
        if (requested > medicine.getPrescribedQuantity()) {
            throw new PrescriptionQuantityExceededException(
                    "Quantity for \"" + medicineName + "\" (" + requested
                            + ") exceeds the prescribed amount (" + medicine.getPrescribedQuantity() + ")");
        }

        medicine.setSelectedQuantity(requested);

        return convertToDTO(prescriptionMedicineRepository.save(medicine));
    }

    @Override
    public void deleteMedicine(Long prescriptionId, String medicineName) {
        PrescriptionMedicineId id = new PrescriptionMedicineId(prescriptionId, medicineName);
        prescriptionMedicineRepository.deleteById(id);
    }

    private PrescriptionMedicinesDTO convertToDTO(PrescriptionMedicines medicine) {
        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setPrescriptionId(medicine.getId().getPrescriptionId());
        dto.setMedicineName(medicine.getId().getMedicineName());
        dto.setPrescribedQuantity(medicine.getPrescribedQuantity());
        dto.setSelectedQuantity(medicine.getSelectedQuantity());
        return dto;
    }
}
