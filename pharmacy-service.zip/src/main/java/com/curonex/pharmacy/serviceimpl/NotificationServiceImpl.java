package com.curonex.pharmacy.serviceimpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.service.NotificationService;

/**
 * Sends a real email to the patient on genuinely order-defining transitions.
 * Scope is deliberately narrow - only the call sites in OrderServiceImpl /
 * PharmacyServiceImpl / DeliveryRoutingServiceImpl that publish
 * OrderStatusChangedEvent reach this listener at all; non-newsworthy
 * fluctuations (a single pharmacy/partner declining, a pharmacy backing out
 * post-accept) were removed from the publish call sites entirely, so this
 * class doesn't need its own filtering logic - every event it receives is
 * meant to be emailed.
 */
@Service
public class NotificationServiceImpl implements NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationServiceImpl.class);

    private final JavaMailSender mailSender;
    private final OrderRepository orderRepository;
    private final DetailsFeignClient detailsFeignClient;

    @Value("${notification.mail.from}")
    private String fromAddress;

    public NotificationServiceImpl(
            JavaMailSender mailSender, OrderRepository orderRepository, DetailsFeignClient detailsFeignClient) {
        this.mailSender = mailSender;
        this.orderRepository = orderRepository;
        this.detailsFeignClient = detailsFeignClient;
    }

    @Override
    public void notifyOrderStatusChange(Long orderId, OrderStatusEnum status, String message) {
        Orders order = orderRepository.findById(orderId).orElse(null);
        if (order == null || order.getUserId() == null) {
            log.warn("Cannot notify for order {} - order or userId missing", orderId);
            return;
        }

        DetailsDTO patientDetails;
        try {
            patientDetails = detailsFeignClient.getDetails(order.getUserId());
        } catch (Exception ex) {
            log.warn("Could not resolve patient details for order {} - skipping email", orderId, ex);
            return;
        }

        if (patientDetails == null || patientDetails.getEmail() == null || patientDetails.getEmail().isBlank()) {
            log.warn("No email on file for user {} - skipping notification for order {}", order.getUserId(), orderId);
            return;
        }

        try {
            SimpleMailMessage mail = new SimpleMailMessage();
            mail.setFrom(fromAddress);
            mail.setTo(patientDetails.getEmail());
            mail.setSubject(subjectFor(orderId, status));
            mail.setText(bodyFor(patientDetails.getName(), orderId, status, message));
            mailSender.send(mail);
        } catch (Exception ex) {
            // Notification failure must never break the order-lifecycle
            // transaction that triggered it - log and move on.
            log.error("Failed to send notification email for order {}", orderId, ex);
        }
    }

    private String subjectFor(Long orderId, OrderStatusEnum status) {
        return switch (status) {
            case PENDING -> "Curonex: Order #" + orderId + " placed";
            case CONFIRMED -> "Curonex: Order #" + orderId + " confirmed";
            case OUT_FOR_DELIVERY -> "Curonex: Order #" + orderId + " is out for delivery";
            case DELIVERED -> "Curonex: Order #" + orderId + " delivered";
            case CANCELLED -> "Curonex: Order #" + orderId + " cancelled";
        };
    }

    private String bodyFor(String patientName, Long orderId, OrderStatusEnum status, String message) {
        String greeting = (patientName != null && !patientName.isBlank()) ? "Hi " + patientName + "," : "Hi,";
        return greeting + "\n\n" + message + "\n\nOrder ID: " + orderId + "\nStatus: " + status
                + "\n\n- Curonex";
    }
}
