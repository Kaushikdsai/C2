package com.curonex.pharmacy.serviceimpl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.curonex.pharmacy.dto.PrescriptionVerificationBlockDTO;
import com.curonex.pharmacy.dto.PrescriptionVerificationResultDTO;
import com.curonex.pharmacy.entity.HospitalPublicKey;
import com.curonex.pharmacy.enums.PrescriptionVerificationStatusEnum;
import com.curonex.pharmacy.service.DigitalSignatureService;
import com.curonex.pharmacy.service.HospitalPublicKeyService;
import com.curonex.pharmacy.service.PrescriptionVerificationBlockService;
import com.curonex.pharmacy.service.PrescriptionVerificationService;
import com.curonex.pharmacy.util.PrescriptionParserUtil;

/**
 * Orchestrates the flow described in the architecture doc:
 *
 *     Controller -> PrescriptionVerificationService -> PrescriptionVerificationBlockService
 *                -> HospitalPublicKeyService -> DigitalSignatureService
 *                -> PDFBox text (already extracted once, reused) -> cross-check
 *                -> PrescriptionParserUtil (medicine extraction, only on VERIFIED)
 *
 * KNOWN LIMITATIONS - documented rather than silently skipped:
 *   1. Step "doctor belongs to hospital" is NOT implemented. pharmacy-
 *      service does not own doctor/hospital data (that lives in
 *      appointment-service / user-service per the existing architecture) -
 *      doing this properly needs a new Feign client to appointment-service
 *      exposing something like GET /api/doctors/{doctorId}?hospitalId=.
 *      Wire that in and call it from verify() below once that endpoint
 *      exists; until then, doctorId is cross-checked textually against the
 *      PDF body (see labeled-field check) but never validated against real
 *      doctor records.
 *   2. "hospital is active" is checked against HospitalPublicKey.active
 *      only (Curonex's own key-registry approval), NOT a live status
 *      lookup against the hospital directory itself - same reason as #1.
 */
@Service
public class PrescriptionVerificationServiceImpl implements PrescriptionVerificationService {

    private static final Logger log = LoggerFactory.getLogger(PrescriptionVerificationServiceImpl.class);

    private static final String REASON_INVALID_QR = "Invalid QR";
    private static final String REASON_UNKNOWN_HOSPITAL = "Unknown hospital";
    private static final String REASON_INVALID_SIGNATURE = "Invalid signature";
    private static final String REASON_EXPIRED_CREDENTIAL = "Expired credential";
    private static final String REASON_DATA_MISMATCH = "Prescription data mismatch";
    private static final String REASON_INVALID_FORMAT = "Invalid prescription format";
    private static final String REASON_MANUAL_REVIEW = "Could not automatically confirm all prescription details - manual review required";

    private final PrescriptionVerificationBlockService blockService;
    private final HospitalPublicKeyService hospitalPublicKeyService;
    private final DigitalSignatureService digitalSignatureService;

    @Value("${curonex.prescription.verification.max-age-days:30}")
    private long maxAgeDays;

    public PrescriptionVerificationServiceImpl(
            PrescriptionVerificationBlockService blockService,
            HospitalPublicKeyService hospitalPublicKeyService,
            DigitalSignatureService digitalSignatureService) {
        this.blockService = blockService;
        this.hospitalPublicKeyService = hospitalPublicKeyService;
        this.digitalSignatureService = digitalSignatureService;
    }

    @Override
    public PrescriptionVerificationResultDTO verify(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Prescription file is required.");
        }
        String fileName = file.getOriginalFilename();
        if (fileName == null || !fileName.toLowerCase().endsWith(".pdf")) {
            throw new IllegalArgumentException("Only PDF prescriptions are supported.");
        }

        String pdfText;
        try {
            PDDocument document = Loader.loadPDF(file.getBytes());
            PDFTextStripper stripper = new PDFTextStripper();
            pdfText = stripper.getText(document);
            document.close();
        } catch (Exception ex) {
            return invalid(REASON_INVALID_FORMAT);
        }

        Optional<PrescriptionVerificationBlockDTO> blockOpt = blockService.extractBlock(pdfText);
        if (blockOpt.isEmpty()) {
            return invalid(REASON_INVALID_QR);
        }
        PrescriptionVerificationBlockDTO block = blockOpt.get();

        Optional<HospitalPublicKey> keyOpt =
                hospitalPublicKeyService.findActiveKey(block.getHospitalId(), block.getKeyVersion());
        if (keyOpt.isEmpty()) {
            return invalid(REASON_UNKNOWN_HOSPITAL);
        }
        HospitalPublicKey key = keyOpt.get();

        if (!isWithinValidityWindow(block.getIssuedAt())) {
            return invalid(REASON_EXPIRED_CREDENTIAL);
        }

        boolean signatureValid = digitalSignatureService.verify(
                block.getCanonicalPayload(), block.getSignatureBase64(), key.getPublicKeyBase64());
        if (!signatureValid) {
            return invalid(REASON_INVALID_SIGNATURE);
        }

        // Cross-check: everything the signature just proved authentic must
        // also match what's printed in plain text elsewhere on the same
        // document - this is what stops someone taking a genuinely signed
        // block from one prescription and pasting it onto a different,
        // altered one.
        Map<String, String> labeled = blockService.extractLabeledFields(pdfText);
        String mismatch = findMismatch(block, labeled);
        if (mismatch != null) {
            return invalid(REASON_DATA_MISMATCH);
        }
        if (labeled.size() < 4) {
            // Signature is valid but we couldn't confirm every field
            // in plain text (e.g. hospital's layout doesn't print one of
            // the labels we look for) - route to a human rather than
            // silently trusting an incomplete cross-check.
            PrescriptionVerificationResultDTO manualReview = new PrescriptionVerificationResultDTO();
            manualReview.setStatus(PrescriptionVerificationStatusEnum.MANUAL_REVIEW);
            manualReview.setReason(REASON_MANUAL_REVIEW);
            manualReview.setHospitalId(block.getHospitalId());
            manualReview.setPrescriptionReference(block.getPrescriptionId());
            return manualReview;
        }

        PrescriptionVerificationResultDTO verified = new PrescriptionVerificationResultDTO();
        verified.setStatus(PrescriptionVerificationStatusEnum.VERIFIED);
        verified.setReason("Verified");
        verified.setHospitalId(block.getHospitalId());
        verified.setPrescriptionReference(block.getPrescriptionId());
        verified.setExtractedText(pdfText);
        verified.setMedicines(PrescriptionParserUtil.parseMedicines(pdfText));
        return verified;
    }

    private boolean isWithinValidityWindow(String issuedAt) {
        try {
            LocalDateTime issued = LocalDateTime.parse(issuedAt, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            return !issued.isBefore(LocalDateTime.now().minusDays(maxAgeDays)) && !issued.isAfter(LocalDateTime.now());
        } catch (DateTimeParseException ex) {
            return false;
        }
    }

    /** Returns a description of the first mismatch found, or null if every labeled field present agrees with the signed block. */
    private String findMismatch(PrescriptionVerificationBlockDTO block, Map<String, String> labeled) {
        if (labeled.containsKey("hospitalId") && !Objects.equals(labeled.get("hospitalId"), String.valueOf(block.getHospitalId()))) {
            return "hospitalId";
        }
        if (labeled.containsKey("doctorId") && !Objects.equals(labeled.get("doctorId"), block.getDoctorId())) {
            return "doctorId";
        }
        if (labeled.containsKey("patientId") && !Objects.equals(labeled.get("patientId"), block.getPatientId())) {
            return "patientId";
        }
        if (labeled.containsKey("prescriptionId") && !Objects.equals(labeled.get("prescriptionId"), block.getPrescriptionId())) {
            return "prescriptionId";
        }
        return null;
    }

    private PrescriptionVerificationResultDTO invalid(String reason) {
        PrescriptionVerificationResultDTO dto = new PrescriptionVerificationResultDTO();
        dto.setStatus(PrescriptionVerificationStatusEnum.INVALID);
        dto.setReason(reason);
        return dto;
    }
}
