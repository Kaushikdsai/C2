package com.curonex.pharmacy.serviceimpl;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Pure java.security (JDK standard library, not a third-party dependency).
 * SHA256withRSA end to end:
 *
 *     prescription metadata (canonical string)
 *              |
 *           SHA-256
 *              |
 *      hospital PRIVATE key   <- happens entirely on the hospital's system, never here
 *              |
 *        digital signature
 *
 *     Curonex verifies:
 *     canonical string + signature + hospital PUBLIC key -> Signature.verify() -> boolean
 */
@Service
public class DigitalSignatureServiceImpl implements com.curonex.pharmacy.service.DigitalSignatureService {

    private static final Logger log = LoggerFactory.getLogger(DigitalSignatureServiceImpl.class);
    private static final String ALGORITHM = "SHA256withRSA";
    private static final String KEY_ALGORITHM = "RSA";

    @Override
    public boolean verify(String canonicalPayload, String signatureBase64, String publicKeyBase64) {
        if (canonicalPayload == null || signatureBase64 == null || publicKeyBase64 == null) {
            return false;
        }
        try {
            PublicKey publicKey = decodePublicKey(publicKeyBase64);
            byte[] signatureBytes = Base64.getDecoder().decode(signatureBase64);

            Signature signature = Signature.getInstance(ALGORITHM);
            signature.initVerify(publicKey);
            signature.update(canonicalPayload.getBytes(StandardCharsets.UTF_8));

            return signature.verify(signatureBytes);
        } catch (Exception ex) {
            // Deliberately swallow the specific exception type (bad
            // base64, wrong key format, tampered signature all land here)
            // - the caller only ever needs a boolean, and logging the
            // exact reason at INFO is enough for debugging without
            // leaking cryptographic detail into any API response.
            log.info("Signature verification failed: {}", ex.getMessage());
            return false;
        }
    }

    private static PublicKey decodePublicKey(String publicKeyBase64) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(publicKeyBase64);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        return keyFactory.generatePublic(spec);
    }

    /**
     * Used only at key-registration time (HospitalPublicKeyServiceImpl) to
     * reject an obviously malformed key immediately with a clear error,
     * rather than only discovering it's unusable the first time a
     * prescription needs verifying.
     */
    static void validatePublicKeyFormat(String publicKeyBase64) {
        try {
            decodePublicKey(publicKeyBase64);
        } catch (Exception ex) {
            throw new IllegalArgumentException(
                    "publicKeyBase64 is not a valid Base64-encoded X.509 RSA public key: " + ex.getMessage());
        }
    }
}
