package com.curonex.pharmacy.serviceimpl;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

import com.curonex.pharmacy.dto.PrescriptionVerificationBlockDTO;
import com.curonex.pharmacy.service.PrescriptionVerificationBlockService;

/**
 * Reads the hospital-signed data directly out of the PDF's TEXT layer via
 * PDFBox (see PrescriptionVerificationServiceImpl for where the text comes
 * from) instead of decoding a scanned QR image - deliberate choice given
 * this project cannot add a QR-decoding library (e.g. ZXing) beyond
 * PDFBox. The hospital's prescription-generation system is expected to
 * print one line in this exact machine-readable format anywhere on the
 * document:
 *
 *     CURONEX-VERIFY:<hospitalId>|<doctorId>|<patientId>|<prescriptionId>|<issuedAt>|<keyVersion>::<signatureBase64>
 *
 * Example:
 *     CURONEX-VERIFY:12|501|PAT900|RX78291|2026-08-15T08:30:00|v1::MEUCIQDx...
 *
 * The 6 pipe-separated fields before "::" are exactly what the hospital's
 * private key signed (see canonical payload contract below) - reordering,
 * renaming, or adding fields on either side breaks every existing
 * signature, so this format should be treated as a stable contract once a
 * hospital integration goes live.
 */
@Service
public class PrescriptionVerificationBlockServiceImpl implements PrescriptionVerificationBlockService {

    private static final Pattern VERIFY_BLOCK_PATTERN =
            Pattern.compile("CURONEX-VERIFY:([^:\\r\\n]+)::([A-Za-z0-9+/=]+)");

    // Best-effort labeled-field patterns for the human-readable part of the
    // prescription (separate from the signed block). Case-insensitive,
    // tolerant of ":" or no separator, captures the first token/word after
    // the label. Adjust these to match whatever format the hospital
    // integration actually prints once that's finalized - this is a
    // reasonable default, not a fixed external standard.
    private static final Pattern HOSPITAL_LABEL = Pattern.compile("Hospital\\s*(?:ID)?\\s*:?\\s*([A-Za-z0-9_-]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern DOCTOR_LABEL = Pattern.compile("Doctor\\s*(?:ID)?\\s*:?\\s*([A-Za-z0-9_-]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATIENT_LABEL = Pattern.compile("Patient\\s*(?:ID)?\\s*:?\\s*([A-Za-z0-9_-]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern PRESCRIPTION_REF_LABEL = Pattern.compile("Prescription\\s*(?:Ref(?:erence)?|ID)?\\s*:?\\s*([A-Za-z0-9_-]+)", Pattern.CASE_INSENSITIVE);

    @Override
    public Optional<PrescriptionVerificationBlockDTO> extractBlock(String pdfText) {
        if (pdfText == null) {
            return Optional.empty();
        }
        Matcher matcher = VERIFY_BLOCK_PATTERN.matcher(pdfText);
        if (!matcher.find()) {
            return Optional.empty();
        }

        String canonicalPayload = matcher.group(1);
        String signatureBase64 = matcher.group(2);

        String[] fields = canonicalPayload.split("\\|", -1);
        if (fields.length != 6) {
            return Optional.empty();
        }

        PrescriptionVerificationBlockDTO dto = new PrescriptionVerificationBlockDTO();
        try {
            dto.setHospitalId(Long.parseLong(fields[0].trim()));
        } catch (NumberFormatException ex) {
            return Optional.empty();
        }
        dto.setDoctorId(fields[1].trim());
        dto.setPatientId(fields[2].trim());
        dto.setPrescriptionId(fields[3].trim());
        dto.setIssuedAt(fields[4].trim());
        dto.setKeyVersion(fields[5].trim());
        dto.setSignatureBase64(signatureBase64);
        // Reconstructed from the parsed fields, NOT matcher.group(1) as-is,
        // so verification always checks exactly what we parsed and trust
        // downstream - not whatever raw bytes happened to sit between the
        // delimiters (defends against stray whitespace changing the
        // canonical string without changing the visible fields).
        dto.setCanonicalPayload(String.join("|",
                String.valueOf(dto.getHospitalId()), dto.getDoctorId(), dto.getPatientId(),
                dto.getPrescriptionId(), dto.getIssuedAt(), dto.getKeyVersion()));

        return Optional.of(dto);
    }

    @Override
    public Map<String, String> extractLabeledFields(String pdfText) {
        Map<String, String> fields = new HashMap<>();
        if (pdfText == null) {
            return fields;
        }
        putIfFound(fields, "hospitalId", HOSPITAL_LABEL, pdfText);
        putIfFound(fields, "doctorId", DOCTOR_LABEL, pdfText);
        putIfFound(fields, "patientId", PATIENT_LABEL, pdfText);
        putIfFound(fields, "prescriptionId", PRESCRIPTION_REF_LABEL, pdfText);
        return fields;
    }

    private void putIfFound(Map<String, String> fields, String key, Pattern pattern, String text) {
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            fields.put(key, matcher.group(1).trim());
        }
    }
}
