package com.curonex.pharmacy.serviceimpl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderCreateItemDTO;
import com.curonex.pharmacy.dto.OrderCreateRequestDTO;
import com.curonex.pharmacy.dto.OrderItemDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderTrackingDTO;
import com.curonex.pharmacy.dto.PatientDetailsUpdateDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.PrescriptionMedicines;
import com.curonex.pharmacy.entity.Prescriptions;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.event.OrderStatusChangedEvent;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.exceptions.PrescriptionNotFoundException;
import com.curonex.pharmacy.exceptions.PrescriptionQuantityExceededException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.OrderDeliveryPartnerRejectionRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.repository.PrescriptionMedicinesRepository;
import com.curonex.pharmacy.repository.PrescriptionsRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.OrderService;
import com.curonex.pharmacy.service.PharmacyRoutingService;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final PharmacyRepository pharmacyRepository;
    private final DeliveryPartnerRepository deliveryPartnerRepository;
    private final PrescriptionsRepository prescriptionsRepository;
    private final PrescriptionMedicinesRepository prescriptionMedicinesRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final PharmacyRoutingService pharmacyRoutingService;
    private final DeliveryRoutingService deliveryRoutingService;
    private final OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;
    private final OrderDeliveryPartnerRejectionRepository orderDeliveryPartnerRejectionRepository;
    private final ApplicationEventPublisher eventPublisher;

    public OrderServiceImpl(
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            PharmacyRepository pharmacyRepository,
            DeliveryPartnerRepository deliveryPartnerRepository,
            PrescriptionsRepository prescriptionsRepository,
            PrescriptionMedicinesRepository prescriptionMedicinesRepository,
            DetailsFeignClient detailsFeignClient,
            PharmacyRoutingService pharmacyRoutingService,
            DeliveryRoutingService deliveryRoutingService,
            OrderPharmacyRejectionRepository orderPharmacyRejectionRepository,
            OrderDeliveryPartnerRejectionRepository orderDeliveryPartnerRejectionRepository,
            ApplicationEventPublisher eventPublisher) {

        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.pharmacyRepository = pharmacyRepository;
        this.deliveryPartnerRepository = deliveryPartnerRepository;
        this.prescriptionsRepository = prescriptionsRepository;
        this.prescriptionMedicinesRepository = prescriptionMedicinesRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.pharmacyRoutingService = pharmacyRoutingService;
        this.deliveryRoutingService = deliveryRoutingService;
        this.orderPharmacyRejectionRepository = orderPharmacyRejectionRepository;
        this.orderDeliveryPartnerRejectionRepository = orderDeliveryPartnerRejectionRepository;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Comparison-only normalization (trim + lowercase) so "Paracetamol",
     * " paracetamol", and "PARACETAMOL" are treated as the same medicine
     * when checking the prescribed-quantity ceiling. The original text the
     * caller sent is what actually gets stored - this never changes stored
     * data, only how two names are compared.
     */
    private String normalize(String medicineName) {
        return medicineName == null ? null : medicineName.trim().toLowerCase();
    }

    @Override
    @Transactional
    public OrderResponseDTO createOrder(OrderCreateRequestDTO request) {

        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one medicine");
        }

        Prescriptions prescription = prescriptionsRepository.findById(request.getPrescriptionId())
                .orElseThrow(() -> new PrescriptionNotFoundException(
                        "Prescription not found with id: " + request.getPrescriptionId()));

        // Ceiling per medicine name = what was actually prescribed (X). A
        // patient may order less (down to dropping the item entirely) but
        // never more - enforced here server-side, name-matched case/whitespace-insensitively.
        Map<String, Integer> prescribedQuantityByName = new HashMap<>();
        for (PrescriptionMedicines pm : prescriptionMedicinesRepository.findByIdPrescriptionId(request.getPrescriptionId())) {
            prescribedQuantityByName.put(normalize(pm.getId().getMedicineName()), pm.getPrescribedQuantity());
        }

        for (OrderCreateItemDTO item : request.getItems()) {
            Integer prescribedQuantity = prescribedQuantityByName.get(normalize(item.getMedicineName()));
            if (prescribedQuantity == null) {
                throw new PrescriptionQuantityExceededException(
                        "Medicine \"" + item.getMedicineName() + "\" is not part of prescription " + request.getPrescriptionId());
            }
            if (item.getQuantity() > prescribedQuantity) {
                throw new PrescriptionQuantityExceededException(
                        "Quantity for \"" + item.getMedicineName() + "\" (" + item.getQuantity()
                                + ") exceeds the prescribed amount (" + prescribedQuantity + ")");
            }
        }

        Orders order = new Orders();
        order.setUserId(request.getUserId());
        order.setPrescriptionId(prescription.getPrescriptionId());
        order.setStatus(OrderStatusEnum.PENDING);
        order.setOrderDatetime(Timestamp.from(Instant.now()));
        order.setPatientGeoAddress(request.getPatientGeoAddress());
        // hospitalId comes from the prescription record, never trusted directly
        // from the client - prevents spoofing hospital-priority.
        order.setHospitalId(prescription.getHospitalId());

        // Patient snapshot: always copied from the prescription, never
        // accepted directly from the client on this request - same
        // never-trust-the-client rule as hospitalId above, and it means an
        // order keeps its own frozen copy even if the prescription (or a
        // later prescription reusing the same patient) is edited afterwards.
        order.setPatientUserId(prescription.getPatientUserId());
        order.setPatientName(prescription.getPatientName());
        order.setPatientAge(prescription.getPatientAge());
        order.setPatientPhone(prescription.getPatientPhone());
        order.setPatientRelationship(prescription.getPatientRelationship());

        order.setDeliveryNote(request.getDeliveryNote());

        order.setPharmacyRated(false);
        order.setDeliveryPartnerRated(false);
        order.setPharmacyRebroadcastCount(0);
        order.setDeliveryRebroadcastCount(0);
        order = orderRepository.save(order);

        for (OrderCreateItemDTO item : request.getItems()) {
            OrderItem orderItem = new OrderItem(order.getOrderId(), item.getMedicineName(), item.getQuantity(), null);
            orderItemRepository.save(orderItem);
        }

        pharmacyRoutingService.broadcastOrder(order.getOrderId(), request.getPatientGeoAddress());

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                order.getOrderId(), null, OrderStatusEnum.PENDING, "Order created and broadcast to nearby pharmacies"));

        return toResponseDTO(order);
    }

    @Override
    public OrderResponseDTO getOrderById(Long orderId) {
        return toResponseDTO(findOrderOrThrow(orderId));
    }

    @Override
    public List<OrderResponseDTO> getOrdersByUser(Long userId) {
        return orderRepository.findByUserId(userId).stream().map(this::toResponseDTO).toList();
    }

    @Override
    public List<OrderResponseDTO> getAllOrders() {
        return orderRepository.findAll().stream().map(this::toResponseDTO).toList();
    }

    @Override
    public Page<OrderResponseDTO> getAllOrders(Pageable pageable) {
        return orderRepository.findAll(pageable).map(this::toResponseDTO);
    }

    /**
     * Hard delete is intentionally NOT exposed via the controller - orders
     * are financial/audit records. CANCELLED is the correct "soft delete"
     * state for an order (see cancelOrder()). Kept for admin/test tooling
     * only, still cleans up dependent rows correctly if ever invoked.
     */
    @Override
    @Transactional
    public void deleteOrder(Long orderId) {
        Orders order = findOrderOrThrow(orderId);
        orderItemRepository.deleteByOrderId(orderId);
        orderPharmacyRejectionRepository.deleteByIdOrderId(orderId);
        orderDeliveryPartnerRejectionRepository.deleteByIdOrderId(orderId);
        orderRepository.delete(order);
    }

    @Override
    public OrderTrackingDTO getOrderTracking(Long orderId) {
        Orders order = findOrderOrThrow(orderId);
        List<OrderItem> items = orderItemRepository.findByOrderId(orderId);

        OrderTrackingDTO dto = new OrderTrackingDTO();
        dto.setOrderId(order.getOrderId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setItemCount(items.size());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());
        dto.setEstimatedDeliveryMinutes(order.getEstimatedDeliveryMinutes());
        dto.setPriceConfirmationDeadline(order.getPriceConfirmationDeadline());
        dto.setDeliveryNote(order.getDeliveryNote());

        // Patient the order is FOR - read directly from the order's own
        // snapshot, never re-resolved from userId (see ActiveDeliveryDTO
        // comment for why that used to be wrong).
        dto.setPatientName(order.getPatientName());
        dto.setPatientAge(order.getPatientAge());
        dto.setPatientPhone(order.getPatientPhone());
        dto.setPatientRelationship(order.getPatientRelationship());

        if (order.getPharmacyId() != null) {
            pharmacyRepository.findById(order.getPharmacyId()).ifPresent(pharmacy -> {
                dto.setPharmacyGeoAddress(pharmacy.getGeoAddress());
                DetailsDTO pharmacyDetails = safeFetchDetails(pharmacy.getId());
                dto.setPharmacyName(pharmacyDetails != null ? pharmacyDetails.getName() : null);
            });
        }

        if (order.getDeliveryPartnerId() != null) {
            DeliveryPartners partner = deliveryPartnerRepository.findById(order.getDeliveryPartnerId()).orElse(null);
            if (partner != null) {
                dto.setDeliveryPartnerName(partner.getName());
                dto.setDeliveryPartnerPhone(partner.getMobileNumber());
            }
        }

        return dto;
    }

    /**
     * "Order for someone else" edit, item 2. Only permitted while the
     * order is still PENDING (no pharmacy has accepted it yet) - once a
     * pharmacy has committed to fulfilling the order, silently changing
     * who it's for could desynchronize what the pharmacy/delivery partner
     * already see. To change the patient after that point, cancel and
     * re-order.
     */
    @Override
    @Transactional
    public OrderResponseDTO updatePatientDetails(Long orderId, PatientDetailsUpdateDTO dto) {
        Orders order = findOrderOrThrow(orderId);
        if (order.getStatus() != OrderStatusEnum.PENDING) {
            throw new OrderConflictException(
                    "Patient details can only be edited while the order is still pending pharmacy confirmation.");
        }

        order.setPatientUserId(dto.getPatientUserId());
        order.setPatientName(dto.getPatientName());
        order.setPatientAge(dto.getPatientAge());
        order.setPatientPhone(dto.getPatientPhone());
        order.setPatientRelationship(dto.getPatientRelationship());

        return toResponseDTO(orderRepository.save(order));
    }

    /**
     * Item 11: patient accepts the price shown once pharmacy fulfillment
     * hit 100% (order is PHARMACY_CONFIRMED). This is the ONLY thing that
     * triggers the delivery-partner broadcast now - acceptOrder() on the
     * pharmacy side deliberately stopped doing that (see
     * PharmacyServiceImpl.acceptOrder). Atomic guard: only succeeds if the
     * window (priceConfirmationDeadline) hasn't already lapsed - if the
     * scheduler's expiry sweep won the race, this throws instead of
     * silently confirming an order the patient took too long on.
     */
    @Override
    @Transactional
    public OrderResponseDTO acceptPrice(Long orderId) {
        int rowsAffected = orderRepository.acceptPriceByPatient(
                orderId, OrderStatusEnum.CONFIRMED, OrderStatusEnum.PHARMACY_CONFIRMED);

        if (rowsAffected == 0) {
            throw new OrderConflictException(
                    "Order is not awaiting price acceptance, or the acceptance window has already expired.");
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.PHARMACY_CONFIRMED, OrderStatusEnum.CONFIRMED,
                "Patient accepted the price - broadcasting to delivery partners"));

        deliveryRoutingService.broadcastOrder(orderId);

        return toResponseDTO(findOrderOrThrow(orderId));
    }

    @Override
    @Transactional
    public OrderResponseDTO cancelOrder(Long orderId) {
        int rowsAffected = orderRepository.cancelOrder(orderId, OrderStatusEnum.CANCELLED, OrderStatusEnum.DELIVERED);
        if (rowsAffected == 0) {
            throw new OrderConflictException("Order cannot be cancelled - it is already delivered or already cancelled.");
        }

        // A fully cancelled order is done - clear any rejection history for
        // it (both pharmacy and delivery-partner side) so it doesn't linger
        // pointlessly in either table.
        orderPharmacyRejectionRepository.deleteByIdOrderId(orderId);
        orderDeliveryPartnerRejectionRepository.deleteByIdOrderId(orderId);

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, null, OrderStatusEnum.CANCELLED, "Order cancelled"));

        return toResponseDTO(findOrderOrThrow(orderId));
    }

    private DetailsDTO safeFetchDetails(Long id) {
        try {
            return detailsFeignClient.getDetails(id);
        } catch (Exception ex) {
            return null;
        }
    }

    private Orders findOrderOrThrow(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
    }

    private OrderResponseDTO toResponseDTO(Orders order) {
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderId(order.getOrderId());
        dto.setPharmacyId(order.getPharmacyId());
        dto.setDeliveryPartnerId(order.getDeliveryPartnerId());
        dto.setUserId(order.getUserId());
        dto.setPrescriptionId(order.getPrescriptionId());
        dto.setHospitalId(order.getHospitalId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());
        dto.setCancelledAt(order.getCancelledAt());
        dto.setDeliveryNote(order.getDeliveryNote());
        dto.setEstimatedDeliveryMinutes(order.getEstimatedDeliveryMinutes());
        dto.setPriceConfirmationDeadline(order.getPriceConfirmationDeadline());

        dto.setPatientUserId(order.getPatientUserId());
        dto.setPatientName(order.getPatientName());
        dto.setPatientAge(order.getPatientAge());
        dto.setPatientPhone(order.getPatientPhone());
        dto.setPatientRelationship(order.getPatientRelationship());

        // Whoever placed the order - shown separately from the patient so
        // the preview page can display "Ordering for: <patient>" alongside
        // "Ordered by: <you>" without the two ever being conflated.
        DetailsDTO ordererDetails = safeFetchDetails(order.getUserId());
        dto.setOrderedByName(ordererDetails != null ? ordererDetails.getName() : null);
        dto.setOrderedByPhone(ordererDetails != null ? ordererDetails.getPhone() : null);

        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
        List<OrderItemDTO> itemDTOs = items.stream().map(item -> {
            OrderItemDTO itemDTO = new OrderItemDTO();
            itemDTO.setItemId(item.getItemId());
            itemDTO.setMedicineName(item.getMedicineName());
            itemDTO.setQuantity(item.getQuantity());
            itemDTO.setPrice(item.getPrice());
            return itemDTO;
        }).toList();

        dto.setItems(itemDTOs);
        return dto;
    }
}
