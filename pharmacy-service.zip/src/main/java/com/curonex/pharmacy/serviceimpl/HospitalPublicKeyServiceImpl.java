package com.curonex.pharmacy.serviceimpl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.curonex.pharmacy.dto.HospitalPublicKeyDTO;
import com.curonex.pharmacy.dto.HospitalPublicKeyRegistrationDTO;
import com.curonex.pharmacy.entity.HospitalPublicKey;
import com.curonex.pharmacy.entity.HospitalPublicKeyId;
import com.curonex.pharmacy.exceptions.HospitalPublicKeyNotFoundException;
import com.curonex.pharmacy.repository.HospitalPublicKeyRepository;
import com.curonex.pharmacy.service.HospitalPublicKeyService;

@Service
public class HospitalPublicKeyServiceImpl implements HospitalPublicKeyService {

    private final HospitalPublicKeyRepository hospitalPublicKeyRepository;

    public HospitalPublicKeyServiceImpl(HospitalPublicKeyRepository hospitalPublicKeyRepository) {
        this.hospitalPublicKeyRepository = hospitalPublicKeyRepository;
    }

    @Override
    public HospitalPublicKeyDTO registerKey(HospitalPublicKeyRegistrationDTO request) {
        // Basic sanity check ONLY (well-formed base64, right key type) -
        // never logs or exposes the decoded bytes anywhere beyond this
        // validation. The actual cryptographic use of this key happens in
        // DigitalSignatureServiceImpl.
        DigitalSignatureServiceImpl.validatePublicKeyFormat(request.getPublicKeyBase64());

        HospitalPublicKeyId id = new HospitalPublicKeyId(request.getHospitalId(), request.getKeyVersion());
        HospitalPublicKey key = hospitalPublicKeyRepository.findById(id).orElse(new HospitalPublicKey());
        key.setId(id);
        key.setPublicKeyBase64(request.getPublicKeyBase64());
        key.setAlgorithm("SHA256withRSA");
        key.setActive(true);
        key.setRegisteredAt(Timestamp.from(Instant.now()));

        return toDTO(hospitalPublicKeyRepository.save(key));
    }

    @Override
    public List<HospitalPublicKeyDTO> getKeysForHospital(Long hospitalId) {
        return hospitalPublicKeyRepository.findByIdHospitalId(hospitalId).stream().map(this::toDTO).toList();
    }

    @Override
    public HospitalPublicKeyDTO deactivateKey(Long hospitalId, String keyVersion) {
        HospitalPublicKey key = hospitalPublicKeyRepository.findByIdHospitalIdAndIdKeyVersion(hospitalId, keyVersion)
                .orElseThrow(() -> new HospitalPublicKeyNotFoundException(
                        "No key version \"" + keyVersion + "\" registered for hospital " + hospitalId));
        key.setActive(false);
        return toDTO(hospitalPublicKeyRepository.save(key));
    }

    @Override
    public Optional<HospitalPublicKey> findActiveKey(Long hospitalId, String keyVersion) {
        return hospitalPublicKeyRepository.findByIdHospitalIdAndIdKeyVersion(hospitalId, keyVersion)
                .filter(key -> Boolean.TRUE.equals(key.getActive()));
    }

    private HospitalPublicKeyDTO toDTO(HospitalPublicKey key) {
        HospitalPublicKeyDTO dto = new HospitalPublicKeyDTO();
        dto.setHospitalId(key.getId().getHospitalId());
        dto.setKeyVersion(key.getId().getKeyVersion());
        dto.setAlgorithm(key.getAlgorithm());
        dto.setActive(key.getActive());
        dto.setRegisteredAt(key.getRegisteredAt());
        return dto;
    }
}
