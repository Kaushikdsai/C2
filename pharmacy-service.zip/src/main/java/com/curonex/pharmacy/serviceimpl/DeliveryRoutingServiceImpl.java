package com.curonex.pharmacy.serviceimpl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.ActiveDeliveryDTO;
import com.curonex.pharmacy.dto.AvailableOrderDTO;
import com.curonex.pharmacy.dto.CoordinateDTO;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderItemDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.PharmacyStopDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.OrderDeliveryPartnerRejection;
import com.curonex.pharmacy.entity.OrderDeliveryPartnerRejectionId;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.OrderPharmacyAllocation;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.event.OrderStatusChangedEvent;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.OrderDeliveryPartnerRejectionRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyAllocationRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.util.DistanceUtil;
import com.curonex.pharmacy.util.GeoAddressUtil;

@Service
public class DeliveryRoutingServiceImpl implements DeliveryRoutingService {

    private static final double DEFAULT_DELIVERY_RADIUS_KM = 5.0;

    private final DeliveryPartnerRepository deliveryPartnerRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final PharmacyRepository pharmacyRepository;
    private final OrderPharmacyAllocationRepository orderPharmacyAllocationRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final DistanceUtil distanceUtil;
    private final GeoAddressUtil geoAddressUtil;
    private final OrderDeliveryPartnerRejectionRepository orderDeliveryPartnerRejectionRepository;
    private final ApplicationEventPublisher eventPublisher;

    /** Assumed average delivery speed used for the item 8 ETA estimate - a straight-line-distance approximation, not a real routing engine. */
    @Value("${curonex.delivery.assumed-average-speed-kmph:25}")
    private double assumedAverageSpeedKmph;

    public DeliveryRoutingServiceImpl(
            DeliveryPartnerRepository deliveryPartnerRepository,
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            PharmacyRepository pharmacyRepository,
            OrderPharmacyAllocationRepository orderPharmacyAllocationRepository,
            DetailsFeignClient detailsFeignClient,
            DistanceUtil distanceUtil,
            GeoAddressUtil geoAddressUtil,
            OrderDeliveryPartnerRejectionRepository orderDeliveryPartnerRejectionRepository,
            ApplicationEventPublisher eventPublisher) {

        this.deliveryPartnerRepository = deliveryPartnerRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.pharmacyRepository = pharmacyRepository;
        this.orderPharmacyAllocationRepository = orderPharmacyAllocationRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.distanceUtil = distanceUtil;
        this.geoAddressUtil = geoAddressUtil;
        this.orderDeliveryPartnerRejectionRepository = orderDeliveryPartnerRejectionRepository;
        this.eventPublisher = eventPublisher;
    }

    private List<DeliveryPartners> findNearbyDeliveryPartners(String geoAddress, double radiusKm) {
        CoordinateDTO source = geoAddressUtil.parse(geoAddress);

        return deliveryPartnerRepository.findByStatus(DeliveryPartnerStatusEnum.AVAILABLE).stream()
                .filter(partner -> {
                    if (partner.getGeoAddress() == null) {
                        return false;
                    }
                    CoordinateDTO destination = geoAddressUtil.parse(partner.getGeoAddress());
                    double distance = distanceUtil.calculateDistance(
                            source.getLatitude(), source.getLongitude(),
                            destination.getLatitude(), destination.getLongitude());
                    return distance <= radiusKm;
                })
                .toList();
    }

    private double distanceKm(String fromGeo, String toGeo) {
        CoordinateDTO from = geoAddressUtil.parse(fromGeo);
        CoordinateDTO to = geoAddressUtil.parse(toGeo);
        return distanceUtil.calculateDistance(from.getLatitude(), from.getLongitude(), to.getLatitude(), to.getLongitude());
    }

    @Override
    @Transactional
    public boolean acceptDelivery(Long orderId, Long deliveryPartnerId) {
        int rowsAffected = orderRepository.acceptOrderByDeliveryPartner(
                orderId, deliveryPartnerId, OrderStatusEnum.CONFIRMED);

        if (rowsAffected == 0) {
            throw new OrderConflictException("Order has already been claimed by another delivery partner.");
        }

        DeliveryPartners partner = deliveryPartnerRepository.findById(deliveryPartnerId)
                .orElseThrow(() -> new OrderNotFoundException("Delivery partner not found: " + deliveryPartnerId));
        partner.setStatus(DeliveryPartnerStatusEnum.ON_DELIVERY);
        deliveryPartnerRepository.save(partner);

        // ETA (item 8): sum of straight-line hops partner -> pharmacy stop 1
        // [-> pharmacy stop 2] -> patient, divided by an assumed average
        // speed. Deliberately not a real routing/traffic engine - see the
        // config comment on assumedAverageSpeedKmph.
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found: " + orderId));
        Integer eta = estimateDeliveryMinutes(order, partner);
        order.setEstimatedDeliveryMinutes(eta);
        orderRepository.save(order);

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.CONFIRMED, "Delivery partner " + deliveryPartnerId + " assigned"));

        return true;
    }

    private Integer estimateDeliveryMinutes(Orders order, DeliveryPartners partner) {
        if (partner.getGeoAddress() == null || order.getPatientGeoAddress() == null) {
            return null;
        }
        List<OrderPharmacyAllocation> allocations =
                orderPharmacyAllocationRepository.findByOrderIdOrderBySequenceNoAsc(order.getOrderId());
        if (allocations.isEmpty()) {
            return null;
        }

        String currentGeo = partner.getGeoAddress();
        double totalKm = 0;
        for (OrderPharmacyAllocation allocation : allocations) {
            Pharmacy pharmacy = pharmacyRepository.findById(allocation.getPharmacyId()).orElse(null);
            if (pharmacy == null || pharmacy.getGeoAddress() == null) {
                return null;
            }
            totalKm += distanceKm(currentGeo, pharmacy.getGeoAddress());
            currentGeo = pharmacy.getGeoAddress();
        }
        totalKm += distanceKm(currentGeo, order.getPatientGeoAddress());

        if (assumedAverageSpeedKmph <= 0) {
            return null;
        }
        double hours = totalKm / assumedAverageSpeedKmph;
        return (int) Math.max(1, Math.round(hours * 60));
    }

    @Override
    @Transactional
    public boolean cancelDelivery(Long orderId, Long deliveryPartnerId) {
        int rowsAffected = orderRepository.releaseOrderFromDeliveryPartner(
                orderId, deliveryPartnerId, OrderStatusEnum.CONFIRMED);

        if (rowsAffected == 0) {
            throw new OrderConflictException(
                    "Order is not currently assigned to delivery partner " + deliveryPartnerId + ", or has moved past CONFIRMED.");
        }

        DeliveryPartners partner = deliveryPartnerRepository.findById(deliveryPartnerId).orElse(null);
        if (partner != null) {
            partner.setStatus(DeliveryPartnerStatusEnum.AVAILABLE);
            deliveryPartnerRepository.save(partner);
        }

        rebroadcastOrder(orderId);

        return true;
    }

    @Override
    @Transactional
    public void rejectDelivery(Long orderId, Long deliveryPartnerId) {
        OrderDeliveryPartnerRejectionId id = new OrderDeliveryPartnerRejectionId(orderId, deliveryPartnerId);
        if (!orderDeliveryPartnerRejectionRepository.existsById(id)) {
            orderDeliveryPartnerRejectionRepository.save(
                    new OrderDeliveryPartnerRejection(id, Timestamp.from(Instant.now())));
        }
    }

    /**
     * Marks one pharmacy stop's pickup as done. Order only transitions to
     * OUT_FOR_DELIVERY once every allocation on it has been picked up - for
     * the common single-pharmacy case that's immediate (one allocation,
     * one call); for a 2-pharmacy order the partner must visit both stops
     * first.
     */
    @Override
    @Transactional
    public boolean pickupFromPharmacy(Long orderId, Long deliveryPartnerId, Long pharmacyId) {
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found: " + orderId));
        if (order.getDeliveryPartnerId() == null || !order.getDeliveryPartnerId().equals(deliveryPartnerId)) {
            throw new OrderConflictException("Order is not assigned to delivery partner " + deliveryPartnerId);
        }
        if (order.getStatus() != OrderStatusEnum.CONFIRMED && order.getStatus() != OrderStatusEnum.OUT_FOR_DELIVERY) {
            throw new OrderConflictException("Order is not in a pickup-eligible state.");
        }

        OrderPharmacyAllocation allocation = orderPharmacyAllocationRepository
                .findByOrderIdAndPharmacyId(orderId, pharmacyId)
                .orElseThrow(() -> new OrderConflictException("Pharmacy " + pharmacyId + " has no allocation on order " + orderId));

        if (allocation.getPickedUpAt() == null) {
            allocation.setPickedUpAt(Timestamp.from(Instant.now()));
            orderPharmacyAllocationRepository.save(allocation);
        }

        boolean anyStopStillPending = orderPharmacyAllocationRepository.existsByOrderIdAndPickedUpAtIsNull(orderId);
        if (anyStopStillPending) {
            // Not all stops collected yet - order stays CONFIRMED, just this allocation is marked picked up.
            return true;
        }

        int rowsAffected = orderRepository.pickupOrderByDeliveryPartner(
                orderId, deliveryPartnerId, OrderStatusEnum.OUT_FOR_DELIVERY, OrderStatusEnum.CONFIRMED);
        if (rowsAffected == 0 && order.getStatus() != OrderStatusEnum.OUT_FOR_DELIVERY) {
            throw new OrderConflictException("Order cannot be picked up - check assignment/status.");
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.OUT_FOR_DELIVERY, "All pickups complete - order picked up by partner " + deliveryPartnerId));

        return true;
    }

    @Override
    @Transactional
    public boolean markDelivered(Long orderId, Long deliveryPartnerId) {
        int rowsAffected = orderRepository.markDeliveredByDeliveryPartner(
                orderId, deliveryPartnerId, OrderStatusEnum.DELIVERED, OrderStatusEnum.OUT_FOR_DELIVERY);

        if (rowsAffected == 0) {
            throw new OrderConflictException("Order cannot be marked delivered - check assignment/status.");
        }

        DeliveryPartners partner = deliveryPartnerRepository.findById(deliveryPartnerId).orElse(null);
        if (partner != null) {
            partner.setStatus(DeliveryPartnerStatusEnum.AVAILABLE);
            deliveryPartnerRepository.save(partner);
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.DELIVERED, "Order delivered by partner " + deliveryPartnerId));

        return true;
    }

    /**
     * Broadcasts to delivery partners near EVERY pharmacy stop on the
     * order (one for a single-pharmacy order, the union of both pharmacies'
     * areas for a 2-pharmacy order) - called from OrderServiceImpl.acceptPrice()
     * once the patient accepts the price, NOT from the pharmacy-accept path
     * anymore (item 11 moved that trigger).
     */
    @Override
    public void broadcastOrder(Long orderId) {
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found: " + orderId));

        List<OrderPharmacyAllocation> allocations =
                orderPharmacyAllocationRepository.findByOrderIdOrderBySequenceNoAsc(orderId);
        if (allocations.isEmpty()) {
            return;
        }

        Set<Long> partnerIds = new LinkedHashSet<>();
        int totalNotified = 0;
        for (OrderPharmacyAllocation allocation : allocations) {
            Pharmacy pharmacy = pharmacyRepository.findById(allocation.getPharmacyId()).orElse(null);
            if (pharmacy == null || pharmacy.getGeoAddress() == null) {
                continue;
            }
            for (DeliveryPartners partner : findNearbyDeliveryPartners(pharmacy.getGeoAddress(), DEFAULT_DELIVERY_RADIUS_KM)) {
                if (partnerIds.add(partner.getDeliveryPartnerId())) {
                    totalNotified++;
                }
            }
        }

        org.slf4j.LoggerFactory.getLogger(DeliveryRoutingServiceImpl.class)
                .info("Order {} broadcast to {} nearby delivery partners across {} pharmacy stop(s)",
                        orderId, totalNotified, allocations.size());
    }

    @Override
    public void rebroadcastOrder(Long orderId) {
        broadcastOrder(orderId);
    }

    @Override
    public List<AvailableOrderDTO> getAvailableOrdersForPartner(Long deliveryPartnerId) {
        DeliveryPartners partner = deliveryPartnerRepository.findById(deliveryPartnerId).orElse(null);
        if (partner == null || partner.getGeoAddress() == null) {
            return List.of();
        }

        List<Orders> unclaimedOrders =
                orderRepository.findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum.CONFIRMED);

        return unclaimedOrders.stream()
                .filter(order -> order.getPharmacyId() != null)
                .filter(order -> !orderDeliveryPartnerRejectionRepository
                        .existsByIdOrderIdAndIdDeliveryPartnerId(order.getOrderId(), deliveryPartnerId))
                .map(order -> {
                    Pharmacy pharmacy = pharmacyRepository.findById(order.getPharmacyId()).orElse(null);
                    if (pharmacy == null || pharmacy.getGeoAddress() == null) {
                        return null;
                    }
                    double distanceKm = distanceKm(partner.getGeoAddress(), pharmacy.getGeoAddress());
                    if (distanceKm > DEFAULT_DELIVERY_RADIUS_KM) {
                        return null;
                    }

                    List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
                    DetailsDTO pharmacyDetails = safeFetchDetails(pharmacy.getId());

                    AvailableOrderDTO dto = new AvailableOrderDTO();
                    dto.setOrderId(order.getOrderId());
                    dto.setPharmacyName(pharmacyDetails != null ? pharmacyDetails.getName() : null);
                    dto.setPharmacyGeoAddress(pharmacy.getGeoAddress());
                    dto.setItemCount(items.size());
                    dto.setTotalAmount(order.getTotalAmount());
                    dto.setDistanceKm(distanceKm);
                    return dto;
                })
                .filter(java.util.Objects::nonNull)
                .sorted((a, b) -> Double.compare(a.getDistanceKm(), b.getDistanceKm()))
                .toList();
    }

    @Override
    public List<ActiveDeliveryDTO> getActiveDeliveriesForPartner(Long deliveryPartnerId) {
        List<Orders> orders = orderRepository.findByDeliveryPartnerId(deliveryPartnerId).stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.CONFIRMED || o.getStatus() == OrderStatusEnum.OUT_FOR_DELIVERY)
                .toList();

        DeliveryPartners partner = deliveryPartnerRepository.findById(deliveryPartnerId).orElse(null);

        return orders.stream().map(order -> {
            List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
            DetailsDTO ordererDetails = safeFetchDetails(order.getUserId());
            List<OrderPharmacyAllocation> allocations =
                    orderPharmacyAllocationRepository.findByOrderIdOrderBySequenceNoAsc(order.getOrderId());

            DetailsDTO patientAccountDetails = order.getPatientUserId() != null
                    ? safeFetchDetails(order.getPatientUserId())
                    : null;

            ActiveDeliveryDTO dto = new ActiveDeliveryDTO();
            dto.setOrderId(order.getOrderId());
            dto.setStatus(order.getStatus());

            dto.setPatientName(order.getPatientName());
            dto.setPatientAge(order.getPatientAge());
            dto.setPatientPhone(order.getPatientPhone());
            dto.setPatientRelationship(order.getPatientRelationship());
            dto.setPatientAddress(patientAccountDetails != null ? patientAccountDetails.getAddress() : null);

            dto.setOrderedByName(ordererDetails != null ? ordererDetails.getName() : null);
            dto.setOrderedByPhone(ordererDetails != null ? ordererDetails.getPhone() : null);

            // First stop's pharmacy kept as the "headline" pharmacyName/
            // pharmacyGeoAddress for backward compatibility with any
            // existing UI reading those two fields directly; the full
            // multi-stop route is in pharmacyStops below.
            List<PharmacyStopDTO> stops = allocations.stream().map(allocation -> {
                Pharmacy stopPharmacy = pharmacyRepository.findById(allocation.getPharmacyId()).orElse(null);
                DetailsDTO stopDetails = stopPharmacy != null ? safeFetchDetails(stopPharmacy.getId()) : null;

                PharmacyStopDTO stopDTO = new PharmacyStopDTO();
                stopDTO.setPharmacyId(allocation.getPharmacyId());
                stopDTO.setPharmacyName(stopDetails != null ? stopDetails.getName() : null);
                stopDTO.setPharmacyGeoAddress(stopPharmacy != null ? stopPharmacy.getGeoAddress() : null);
                stopDTO.setSequenceNo(allocation.getSequenceNo());
                stopDTO.setPickedUp(allocation.getPickedUpAt() != null);
                stopDTO.setPickupOtp(sampleOtp(order.getOrderId() * 37 + allocation.getPharmacyId() * 13));
                return stopDTO;
            }).toList();
            dto.setPharmacyStops(stops);
            dto.setDeliveryOtp(sampleOtp(order.getOrderId() * 53));

            if (!stops.isEmpty()) {
                dto.setPharmacyName(stops.get(0).getPharmacyName());
                dto.setPharmacyGeoAddress(stops.get(0).getPharmacyGeoAddress());
            }

            dto.setItemCount(items.size());
            dto.setTotalAmount(order.getTotalAmount());
            dto.setDeliveryNote(order.getDeliveryNote());
            dto.setEstimatedDeliveryMinutes(order.getEstimatedDeliveryMinutes());

            dto.setPatientGeoAddress(order.getPatientGeoAddress());
            dto.setPartnerGeoAddress(partner != null ? partner.getGeoAddress() : null);

            return dto;
        }).toList();
    }

    /**
     * SAMPLE OTP ONLY - see PharmacyStopDTO/ActiveDeliveryDTO javadoc. Not
     * cryptographically generated, not sent via SMS, not secret - purely a
     * deterministic 4-digit display value so the reviewer sees something
     * other than a hardcoded "1234" on every single order.
     */
    private String sampleOtp(long seed) {
        long value = Math.floorMod(seed, 10000);
        return String.format("%04d", value);
    }

    @Override
    public List<OrderResponseDTO> getDeliveryHistoryForPartner(Long deliveryPartnerId) {
        List<Orders> orders = orderRepository.findByDeliveryPartnerIdAndStatus(deliveryPartnerId, OrderStatusEnum.DELIVERED);
        return orders.stream().map(this::toResponseDTO).toList();
    }

    private OrderResponseDTO toResponseDTO(Orders order) {
        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());

        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderId(order.getOrderId());
        dto.setPharmacyId(order.getPharmacyId());
        dto.setDeliveryPartnerId(order.getDeliveryPartnerId());
        dto.setUserId(order.getUserId());
        dto.setPrescriptionId(order.getPrescriptionId());
        dto.setHospitalId(order.getHospitalId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());
        dto.setCancelledAt(order.getCancelledAt());
        dto.setDeliveryNote(order.getDeliveryNote());
        dto.setEstimatedDeliveryMinutes(order.getEstimatedDeliveryMinutes());
        dto.setPriceConfirmationDeadline(order.getPriceConfirmationDeadline());

        dto.setPatientUserId(order.getPatientUserId());
        dto.setPatientName(order.getPatientName());
        dto.setPatientAge(order.getPatientAge());
        dto.setPatientPhone(order.getPatientPhone());
        dto.setPatientRelationship(order.getPatientRelationship());

        List<OrderItemDTO> itemDTOs = items.stream().map(item -> {
            OrderItemDTO itemDTO = new OrderItemDTO();
            itemDTO.setItemId(item.getItemId());
            itemDTO.setMedicineName(item.getMedicineName());
            itemDTO.setQuantity(item.getQuantity());
            itemDTO.setPrice(item.getPrice());
            return itemDTO;
        }).toList();

        dto.setItems(itemDTOs);
        return dto;
    }

    private DetailsDTO safeFetchDetails(Long id) {
        try {
            return detailsFeignClient.getDetails(id);
        } catch (Exception ex) {
            return null;
        }
    }
}
