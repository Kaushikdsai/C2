package com.curonex.pharmacy.serviceimpl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.dto.PrescriptionsDTO;
import com.curonex.pharmacy.entity.Prescriptions;
import com.curonex.pharmacy.exceptions.PrescriptionNotFoundException;
import com.curonex.pharmacy.repository.PrescriptionsRepository;
import com.curonex.pharmacy.service.PrescriptionsService;

@Service
public class PrescriptionsServiceImpl implements PrescriptionsService {

    private final PrescriptionsRepository prescriptionRepository;

    public PrescriptionsServiceImpl(PrescriptionsRepository prescriptionRepository) {
        this.prescriptionRepository = prescriptionRepository;
    }

    @Override
    public PrescriptionsDTO addPrescription(PrescriptionsDTO dto) {
        validatePatientDetails(dto);
        Prescriptions prescription = new Prescriptions();
        BeanUtils.copyProperties(dto, prescription);
        prescription.setIsDeleted(false);
        return convertToDTO(prescriptionRepository.save(prescription));
    }

    @Override
    public PrescriptionsDTO getPrescriptionById(Long prescriptionId) {
        return convertToDTO(prescriptionRepository.findById(prescriptionId)
                .orElseThrow(() -> new PrescriptionNotFoundException("Prescription not found with id: " + prescriptionId)));
    }

    @Override
    public List<PrescriptionsDTO> getAllPrescriptions() {
        return prescriptionRepository.findByIsDeletedFalse().stream().map(this::convertToDTO).toList();
    }

    /**
     * This is also the "order for someone else" edit endpoint (preview
     * page). Patient details are deliberately editable right up until the
     * order is created from this prescription - after that, the order
     * keeps its own snapshot (see Orders.patientName etc.) and further
     * edits go through the order-level patient update instead, so a
     * prescription edit can never silently change a pharmacy/delivery
     * partner's view of an order already in flight.
     */
    @Override
    public PrescriptionsDTO updatePrescription(Long prescriptionId, PrescriptionsDTO dto) {
        validatePatientDetails(dto);
        Prescriptions prescription = prescriptionRepository.findById(prescriptionId)
                .orElseThrow(() -> new PrescriptionNotFoundException("Prescription not found with id: " + prescriptionId));

        prescription.setUserId(dto.getUserId());
        prescription.setHospitalId(dto.getHospitalId());
        prescription.setDoctorId(dto.getDoctorId());
        prescription.setPrescriptionDatetime(dto.getPrescriptionDatetime());
        prescription.setPatientUserId(dto.getPatientUserId());
        prescription.setPatientName(dto.getPatientName());
        prescription.setPatientAge(dto.getPatientAge());
        prescription.setPatientPhone(dto.getPatientPhone());
        prescription.setPatientRelationship(dto.getPatientRelationship());

        return convertToDTO(prescriptionRepository.save(prescription));
    }

    /**
     * Soft delete only. Prescriptions are medical records and are expected
     * to remain auditable even after a patient "removes" one from view.
     */
    @Override
    @Transactional
    public void deletePrescription(Long prescriptionId) {
        Prescriptions prescription = prescriptionRepository.findById(prescriptionId)
                .orElseThrow(() -> new PrescriptionNotFoundException("Prescription not found with id: " + prescriptionId));
        prescription.setIsDeleted(true);
        prescriptionRepository.save(prescription);
    }

    @Override
    public List<PrescriptionsDTO> getPrescriptionsByUser(Long userId) {
        return prescriptionRepository.findByUserIdAndIsDeletedFalse(userId).stream().map(this::convertToDTO).toList();
    }

    /**
     * patientName/patientPhone must always be present regardless of whether
     * patientUserId is set - the pharmacy/delivery-partner side reads these
     * two fields directly and should never have to branch on "is this a
     * registered patient or not".
     */
    private void validatePatientDetails(PrescriptionsDTO dto) {
        if (dto.getPatientName() == null || dto.getPatientName().isBlank()) {
            throw new IllegalArgumentException("patientName is required");
        }
        if (dto.getPatientPhone() == null || dto.getPatientPhone().isBlank()) {
            throw new IllegalArgumentException("patientPhone is required");
        }
    }

    private PrescriptionsDTO convertToDTO(Prescriptions prescription) {
        PrescriptionsDTO dto = new PrescriptionsDTO();
        BeanUtils.copyProperties(prescription, dto);
        return dto;
    }
}
