package com.curonex.pharmacy.serviceimpl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DeliveryPartnerDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerDashboardDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerProfileDTO;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.exceptions.DeliveryPartnerNotFoundException;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.service.DeliveryPartnersService;

@Service
public class DeliveryPartnersServiceImpl implements DeliveryPartnersService {

    private final DeliveryPartnerRepository deliveryPartnerRepository;
    private final OrderRepository orderRepository;
    private final DetailsFeignClient detailsFeignClient;

    @Value("${delivery.commission-rate}")
    private BigDecimal commissionRate;

    public DeliveryPartnersServiceImpl(
            DeliveryPartnerRepository deliveryPartnerRepository,
            OrderRepository orderRepository,
            DetailsFeignClient detailsFeignClient) {

        this.deliveryPartnerRepository = deliveryPartnerRepository;
        this.orderRepository = orderRepository;
        this.detailsFeignClient = detailsFeignClient;
    }

    @Override
    public DeliveryPartnerDTO addDeliveryPartner(DeliveryPartnerDTO dto) {
        if (deliveryPartnerRepository.existsByMobileNumber(dto.getMobileNumber())) {
            throw new IllegalArgumentException("Delivery partner already exists");
        }
        DeliveryPartners partner = new DeliveryPartners();
        BeanUtils.copyProperties(dto, partner);
        partner.setRating(BigDecimal.ZERO);
        partner.setRatingCount(0);
        partner.setIsDeleted(false);
        return toDTO(deliveryPartnerRepository.save(partner));
    }

    @Override
    public DeliveryPartnerDTO getDeliveryPartnerById(Long deliveryPartnerId) {
        return toDTO(findPartnerOrThrow(deliveryPartnerId));
    }

    @Override
    public List<DeliveryPartnerDTO> getAllDeliveryPartners() {
        return deliveryPartnerRepository.findByIsDeletedFalse().stream().map(this::toDTO).toList();
    }

    @Override
    public DeliveryPartnerDTO updateDeliveryPartner(Long deliveryPartnerId, DeliveryPartnerDTO dto) {
        DeliveryPartners partner = findPartnerOrThrow(deliveryPartnerId);
        partner.setName(dto.getName());
        partner.setMobileNumber(dto.getMobileNumber());
        partner.setGeoAddress(dto.getGeoAddress());
        partner.setStatus(dto.getStatus());
        return toDTO(deliveryPartnerRepository.save(partner));
    }

    /**
     * Soft delete only. Partners are referenced by historical orders
     * (orders.delivery_partner_id) and delivery history - a hard delete
     * would break the ability to show who delivered a past order.
     */
    @Override
    @Transactional
    public void deleteDeliveryPartner(Long deliveryPartnerId) {
        DeliveryPartners partner = findPartnerOrThrow(deliveryPartnerId);
        partner.setIsDeleted(true);
        deliveryPartnerRepository.save(partner);
    }

    @Override
    public List<DeliveryPartnerDTO> getAvailableDeliveryPartners() {
        return deliveryPartnerRepository.findByStatusAndIsDeletedFalse(DeliveryPartnerStatusEnum.AVAILABLE)
                .stream().map(this::toDTO).toList();
    }

    @Override
    public boolean markAvailable(Long deliveryPartnerId) {
        DeliveryPartners partner = findPartnerOrThrow(deliveryPartnerId);
        partner.setStatus(DeliveryPartnerStatusEnum.AVAILABLE);
        deliveryPartnerRepository.save(partner);
        return true;
    }

    @Override
    public boolean markOnDelivery(Long deliveryPartnerId) {
        DeliveryPartners partner = findPartnerOrThrow(deliveryPartnerId);
        partner.setStatus(DeliveryPartnerStatusEnum.ON_DELIVERY);
        deliveryPartnerRepository.save(partner);
        return true;
    }

    @Override
    public boolean markOffline(Long deliveryPartnerId) {
        DeliveryPartners partner = findPartnerOrThrow(deliveryPartnerId);
        partner.setStatus(DeliveryPartnerStatusEnum.OFFLINE);
        deliveryPartnerRepository.save(partner);
        return true;
    }

    @Override
    public DeliveryPartnerProfileDTO getPartnerProfile(Long deliveryPartnerId) {
        DeliveryPartners partner = findPartnerOrThrow(deliveryPartnerId);

        DeliveryPartnerProfileDTO dto = new DeliveryPartnerProfileDTO();
        dto.setDeliveryPartnerId(partner.getDeliveryPartnerId());
        dto.setMobileNumber(partner.getMobileNumber());
        dto.setGeoAddress(partner.getGeoAddress());
        dto.setStatus(partner.getStatus());
        dto.setRating(partner.getRating());
        dto.setRatingCount(partner.getRatingCount());

        DetailsDTO details = detailsFeignClient.getDetails(deliveryPartnerId);
        if (details != null) {
            dto.setName(details.getName());
            dto.setEmail(details.getEmail());
            dto.setAddress(details.getAddress());
            dto.setPincode(details.getPincode());
            dto.setCity(details.getCity());
            dto.setState(details.getState());
        }
        return dto;
    }

    @Override
    public DeliveryPartnerProfileDTO updatePartnerProfile(Long deliveryPartnerId, DeliveryPartnerProfileDTO dto) {
        DeliveryPartners partner = findPartnerOrThrow(deliveryPartnerId);
        partner.setMobileNumber(dto.getMobileNumber());
        partner.setGeoAddress(dto.getGeoAddress());
        deliveryPartnerRepository.save(partner);

        DetailsDTO detailsUpdate = new DetailsDTO();
        detailsUpdate.setId(deliveryPartnerId);
        detailsUpdate.setName(dto.getName());
        detailsUpdate.setEmail(dto.getEmail());
        detailsUpdate.setAddress(dto.getAddress());
        detailsUpdate.setPincode(dto.getPincode());
        detailsUpdate.setCity(dto.getCity());
        detailsUpdate.setState(dto.getState());
        detailsFeignClient.updateDetails(deliveryPartnerId, detailsUpdate);

        return getPartnerProfile(deliveryPartnerId);
    }

    /**
     * Rating is now tied to a real completed order, same reasoning as the
     * pharmacy side: order must exist, be DELIVERED, actually belong to
     * this delivery partner, and not have already been rated.
     */
    @Override
    @Transactional
    public DeliveryPartnerProfileDTO submitRating(Long deliveryPartnerId, Long orderId, BigDecimal rating) {
        DeliveryPartners partner = findPartnerOrThrow(deliveryPartnerId);

        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));

        if (order.getStatus() != OrderStatusEnum.DELIVERED) {
            throw new OrderConflictException("Order must be DELIVERED before it can be rated.");
        }
        if (order.getDeliveryPartnerId() == null || !order.getDeliveryPartnerId().equals(deliveryPartnerId)) {
            throw new OrderConflictException("Order " + orderId + " was not delivered by partner " + deliveryPartnerId);
        }
        if (Boolean.TRUE.equals(order.getDeliveryPartnerRated())) {
            throw new OrderConflictException("Order " + orderId + " has already been rated for this delivery partner.");
        }

        int previousCount = partner.getRatingCount() != null ? partner.getRatingCount() : 0;
        BigDecimal previousAverage = partner.getRating() != null ? partner.getRating() : BigDecimal.ZERO;

        BigDecimal newCount = BigDecimal.valueOf(previousCount + 1);
        BigDecimal newAverage = previousAverage.multiply(BigDecimal.valueOf(previousCount))
                .add(rating)
                .divide(newCount, 2, RoundingMode.HALF_UP);

        partner.setRating(newAverage);
        partner.setRatingCount(previousCount + 1);
        deliveryPartnerRepository.save(partner);

        order.setDeliveryPartnerRated(true);
        orderRepository.save(order);

        return getPartnerProfile(deliveryPartnerId);
    }

    @Override
    public DeliveryPartnerDashboardDTO getDashboard(Long deliveryPartnerId) {
        DeliveryPartners partner = findPartnerOrThrow(deliveryPartnerId);
        List<Orders> partnerOrders = orderRepository.findByDeliveryPartnerId(deliveryPartnerId);
        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        LocalDate weekStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate monthStart = today.with(TemporalAdjusters.firstDayOfMonth());

        DeliveryPartnerDashboardDTO dto = new DeliveryPartnerDashboardDTO();

        long todaysDeliveries = partnerOrders.stream()
                .filter(o -> o.getOrderDatetime() != null
                        && o.getOrderDatetime().toLocalDateTime().toLocalDate().equals(today))
                .count();
        dto.setTodaysDeliveries(todaysDeliveries);

        long pendingPickups = partnerOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.CONFIRMED)
                .count();
        dto.setPendingPickups(pendingPickups);

        List<Orders> deliveredOrders = partnerOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED && o.getDeliveredAt() != null)
                .toList();

        long completedToday = deliveredOrders.stream()
                .filter(o -> o.getDeliveredAt().toLocalDateTime().toLocalDate().equals(today))
                .count();
        dto.setCompletedDeliveries(completedToday);

        dto.setAcceptedCount(pendingPickups);
        long outForDelivery = partnerOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.OUT_FOR_DELIVERY)
                .count();
        dto.setOutForDeliveryCount(outForDelivery);
        dto.setCompletedCount(deliveredOrders.size());

        BigDecimal todaysEarnings = sumEarnings(deliveredOrders, o ->
                o.getDeliveredAt().toLocalDateTime().toLocalDate().equals(today));
        BigDecimal weekEarnings = sumEarnings(deliveredOrders, o ->
                !o.getDeliveredAt().toLocalDateTime().toLocalDate().isBefore(weekStart));
        BigDecimal monthEarnings = sumEarnings(deliveredOrders, o ->
                !o.getDeliveredAt().toLocalDateTime().toLocalDate().isBefore(monthStart));

        dto.setTodaysEarnings(todaysEarnings);
        dto.setWeekEarnings(weekEarnings);
        dto.setMonthEarnings(monthEarnings);

        dto.setRating(partner.getRating());
        dto.setRatingCount(partner.getRatingCount());

        return dto;
    }

    private BigDecimal sumEarnings(List<Orders> deliveredOrders, java.util.function.Predicate<Orders> filter) {
        BigDecimal partnerShare = BigDecimal.ONE.subtract(commissionRate);
        return deliveredOrders.stream()
                .filter(filter)
                .map(Orders::getTotalAmount)
                .filter(java.util.Objects::nonNull)
                .map(amount -> amount.multiply(partnerShare))
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);
    }

    private DeliveryPartners findPartnerOrThrow(Long deliveryPartnerId) {
        return deliveryPartnerRepository.findById(deliveryPartnerId)
                .orElseThrow(() -> new DeliveryPartnerNotFoundException(
                        "Delivery partner not found with id: " + deliveryPartnerId));
    }

    private DeliveryPartnerDTO toDTO(DeliveryPartners partner) {
        DeliveryPartnerDTO dto = new DeliveryPartnerDTO();
        BeanUtils.copyProperties(partner, dto);
        return dto;
    }
}
