package com.curonex.pharmacy.serviceimpl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderItemDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptItemDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyDTO;
import com.curonex.pharmacy.dto.PharmacyDashboardDTO;
import com.curonex.pharmacy.dto.PharmacyPartialAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyProfileDTO;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.OrderPharmacyAllocation;
import com.curonex.pharmacy.entity.OrderPharmacyRejection;
import com.curonex.pharmacy.entity.OrderPharmacyRejectionId;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;
import com.curonex.pharmacy.event.OrderStatusChangedEvent;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.exceptions.PharmacyNotFoundException;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyAllocationRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import com.curonex.pharmacy.service.PharmacyService;

@Service
public class PharmacyServiceImpl implements PharmacyService {

    private final PharmacyRepository pharmacyRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final OrderPharmacyAllocationRepository orderPharmacyAllocationRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final PharmacyRoutingService pharmacyRoutingService;
    private final DeliveryRoutingService deliveryRoutingService;
    private final OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;
    private final ApplicationEventPublisher eventPublisher;

    /** Line-item coverage a pharmacy must claim to become the "first partial pharmacy" - item 5. */
    @Value("${curonex.fulfillment.partial-threshold-percent:50}")
    private int partialThresholdPercent;

    /** How long the patient has to accept the final price once pharmacy fulfillment is 100% - item 11. */
    @Value("${curonex.fulfillment.price-acceptance-window-minutes:10}")
    private long priceAcceptanceWindowMinutes;

    public PharmacyServiceImpl(
            PharmacyRepository pharmacyRepository,
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            OrderPharmacyAllocationRepository orderPharmacyAllocationRepository,
            DetailsFeignClient detailsFeignClient,
            PharmacyRoutingService pharmacyRoutingService,
            DeliveryRoutingService deliveryRoutingService,
            OrderPharmacyRejectionRepository orderPharmacyRejectionRepository,
            ApplicationEventPublisher eventPublisher) {

        this.pharmacyRepository = pharmacyRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.orderPharmacyAllocationRepository = orderPharmacyAllocationRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.pharmacyRoutingService = pharmacyRoutingService;
        this.deliveryRoutingService = deliveryRoutingService;
        this.orderPharmacyRejectionRepository = orderPharmacyRejectionRepository;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public PharmacyDTO addPharmacy(PharmacyDTO dto) {
        Pharmacy pharmacy = new Pharmacy();
        BeanUtils.copyProperties(dto, pharmacy);
        pharmacy.setRating(BigDecimal.ZERO);
        pharmacy.setRatingCount(0);
        pharmacy.setIsDeleted(false);
        return toDTO(pharmacyRepository.save(pharmacy));
    }

    @Override
    public PharmacyDTO getPharmacyById(Long id) {
        return toDTO(findPharmacyOrThrow(id));
    }

    @Override
    public List<PharmacyDTO> getAllPharmacies() {
        return pharmacyRepository.findByIsDeletedFalse().stream().map(this::toDTO).toList();
    }

    @Override
    public PharmacyDTO updatePharmacy(Long id, PharmacyDTO dto) {
        Pharmacy pharmacy = findPharmacyOrThrow(id);
        pharmacy.setLicenseNo(dto.getLicenseNo());
        pharmacy.setGeoAddress(dto.getGeoAddress());
        pharmacy.setStatus(dto.getStatus());
        pharmacy.setHospitalId(dto.getHospitalId());
        return toDTO(pharmacyRepository.save(pharmacy));
    }

    /**
     * Soft delete only. Pharmacies are referenced by historical orders
     * (orders.pharmacy_id), so a hard delete would orphan every past order's
     * ability to show who fulfilled it.
     */
    @Override
    @Transactional
    public void deletePharmacy(Long id) {
        Pharmacy pharmacy = findPharmacyOrThrow(id);
        pharmacy.setIsDeleted(true);
        pharmacyRepository.save(pharmacy);
    }

    @Override
    public List<PharmacyDTO> getActivePharmacies() {
        return pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE)
                .stream().map(this::toDTO).toList();
    }

    @Override
    public PharmacyProfileDTO getPharmacyProfile(Long pharmacyId) {
        Pharmacy pharmacy = findPharmacyOrThrow(pharmacyId);
        PharmacyProfileDTO dto = new PharmacyProfileDTO();
        dto.setPharmacyId(pharmacy.getId());
        dto.setLicenseNo(pharmacy.getLicenseNo());
        dto.setGeoAddress(pharmacy.getGeoAddress());
        dto.setStatus(pharmacy.getStatus());
        dto.setHospitalId(pharmacy.getHospitalId());
        dto.setRating(pharmacy.getRating());
        dto.setRatingCount(pharmacy.getRatingCount());

        DetailsDTO details = detailsFeignClient.getDetails(pharmacyId);
        if (details != null) {
            dto.setName(details.getName());
            dto.setEmail(details.getEmail());
            dto.setPhone(details.getPhone());
            dto.setAddress(details.getAddress());
            dto.setPincode(details.getPincode());
            dto.setCity(details.getCity());
            dto.setState(details.getState());
        }
        return dto;
    }

    @Override
    public PharmacyProfileDTO updatePharmacyProfile(Long pharmacyId, PharmacyProfileDTO dto) {
        Pharmacy pharmacy = findPharmacyOrThrow(pharmacyId);
        pharmacy.setLicenseNo(dto.getLicenseNo());
        pharmacy.setGeoAddress(dto.getGeoAddress());
        pharmacyRepository.save(pharmacy);

        DetailsDTO detailsUpdate = new DetailsDTO();
        detailsUpdate.setId(pharmacyId);
        detailsUpdate.setName(dto.getName());
        detailsUpdate.setEmail(dto.getEmail());
        detailsUpdate.setPhone(dto.getPhone());
        detailsUpdate.setAddress(dto.getAddress());
        detailsUpdate.setPincode(dto.getPincode());
        detailsUpdate.setCity(dto.getCity());
        detailsUpdate.setState(dto.getState());
        detailsFeignClient.updateDetails(pharmacyId, detailsUpdate);

        return getPharmacyProfile(pharmacyId);
    }

    @Override
    @Transactional
    public PharmacyProfileDTO submitRating(Long pharmacyId, Long orderId, BigDecimal rating) {
        Pharmacy pharmacy = findPharmacyOrThrow(pharmacyId);

        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));

        if (order.getStatus() != OrderStatusEnum.DELIVERED) {
            throw new OrderConflictException("Order must be DELIVERED before it can be rated.");
        }
        boolean fulfilledByThisPharmacy = (order.getPharmacyId() != null && order.getPharmacyId().equals(pharmacyId))
                || orderPharmacyAllocationRepository.findByOrderIdAndPharmacyId(orderId, pharmacyId).isPresent();
        if (!fulfilledByThisPharmacy) {
            throw new OrderConflictException("Order " + orderId + " was not fulfilled by pharmacy " + pharmacyId);
        }
        if (Boolean.TRUE.equals(order.getPharmacyRated())) {
            throw new OrderConflictException("Order " + orderId + " has already been rated for this pharmacy.");
        }

        int previousCount = pharmacy.getRatingCount() != null ? pharmacy.getRatingCount() : 0;
        BigDecimal previousAverage = pharmacy.getRating() != null ? pharmacy.getRating() : BigDecimal.ZERO;

        BigDecimal newCount = BigDecimal.valueOf(previousCount + 1);
        BigDecimal newAverage = previousAverage.multiply(BigDecimal.valueOf(previousCount))
                .add(rating)
                .divide(newCount, 2, java.math.RoundingMode.HALF_UP);

        pharmacy.setRating(newAverage);
        pharmacy.setRatingCount(previousCount + 1);
        pharmacyRepository.save(pharmacy);

        order.setPharmacyRated(true);
        orderRepository.save(order);

        return getPharmacyProfile(pharmacyId);
    }

    @Override
    public PharmacyDashboardDTO getDashboard(Long pharmacyId) {
        List<Orders> pharmacyOrders = findAllOrdersInvolvingPharmacy(pharmacyId);

        PharmacyDashboardDTO dto = new PharmacyDashboardDTO();
        dto.setNewOrders(pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.PHARMACY_CONFIRMED && o.getDeliveryPartnerId() == null)
                .count());
        dto.setProcessingOrders(pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.CONFIRMED || o.getStatus() == OrderStatusEnum.OUT_FOR_DELIVERY)
                .count());

        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        long todaysDeliveries = pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED)
                .filter(o -> o.getDeliveredAt() != null
                        && o.getDeliveredAt().toLocalDateTime().toLocalDate().equals(today))
                .count();
        dto.setTodaysDeliveries(todaysDeliveries);

        BigDecimal todaysRevenue = pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED)
                .filter(o -> o.getDeliveredAt() != null
                        && o.getDeliveredAt().toLocalDateTime().toLocalDate().equals(today))
                .map(Orders::getTotalAmount)
                .filter(java.util.Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        dto.setTodaysRevenue(todaysRevenue);

        return dto;
    }

    @Override
    public List<OrderSummaryDTO> getOrdersByStatus(Long pharmacyId, OrderStatusEnum status) {
        return findAllOrdersInvolvingPharmacy(pharmacyId).stream()
                .filter(o -> o.getStatus() == status)
                .map(this::toSummaryDTO)
                .toList();
    }

    @Override
    public List<OrderSummaryDTO> getOrderHistory(Long pharmacyId) {
        return findAllOrdersInvolvingPharmacy(pharmacyId).stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED || o.getStatus() == OrderStatusEnum.CANCELLED)
                .map(this::toSummaryDTO)
                .toList();
    }

    @Override
    public double getDeliverySuccessRate(Long pharmacyId) {
        List<Orders> orders = findAllOrdersInvolvingPharmacy(pharmacyId);
        long total = orders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED || o.getStatus() == OrderStatusEnum.CANCELLED)
                .count();
        if (total == 0) {
            return 0.0;
        }
        long delivered = orders.stream().filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED).count();
        return (delivered * 100.0) / total;
    }

    @Override
    public long getOrdersThisMonth(Long pharmacyId) {
        LocalDate firstOfMonth = LocalDate.now(ZoneId.systemDefault()).with(TemporalAdjusters.firstDayOfMonth());
        return findAllOrdersInvolvingPharmacy(pharmacyId).stream()
                .filter(o -> o.getOrderDatetime() != null
                        && !o.getOrderDatetime().toLocalDateTime().toLocalDate().isBefore(firstOfMonth))
                .count();
    }

    /**
     * Union of "orders where I'm the primary pharmacy" (Orders.pharmacyId,
     * covers every single-pharmacy order and the first pharmacy of a
     * 2-pharmacy order) and "orders where I hold a second allocation"
     * (OrderPharmacyAllocation) - without this, the second pharmacy on a
     * 2-pharmacy partial order would never see that order in its own
     * dashboard/history/reports, even though it fulfilled part of it.
     */
    private List<Orders> findAllOrdersInvolvingPharmacy(Long pharmacyId) {
        List<Orders> primary = orderRepository.findByPharmacyId(pharmacyId);
        List<Long> secondaryOrderIds = orderPharmacyAllocationRepository.findByPharmacyId(pharmacyId).stream()
                .map(OrderPharmacyAllocation::getOrderId)
                .toList();

        if (secondaryOrderIds.isEmpty()) {
            return primary;
        }

        Set<Long> seen = primary.stream().map(Orders::getOrderId).collect(Collectors.toCollection(HashSet::new));
        List<Orders> combined = new java.util.ArrayList<>(primary);
        for (Orders secondary : orderRepository.findAllById(secondaryOrderIds)) {
            if (seen.add(secondary.getOrderId())) {
                combined.add(secondary);
            }
        }
        return combined;
    }

    /**
     * Full-order accept. Succeeds from PENDING (the common case) OR from
     * PARTIALLY_ALLOCATED (this pharmacy's complete offer overrides an
     * existing partial allocation - item 5's "if a second pharmacy
     * independently has 100%, use that pharmacy directly instead"). Lands
     * on PHARMACY_CONFIRMED, not CONFIRMED - delivery broadcast no longer
     * happens here, it happens once the patient accepts the price (see
     * OrderServiceImpl.acceptPrice) - item 11.
     */
    @Override
    @Transactional
    public OrderResponseDTO acceptOrder(Long orderId, Long pharmacyId, PharmacyAcceptRequestDTO request) {

        List<OrderItem> items = orderItemRepository.findByOrderId(orderId);
        if (items.isEmpty()) {
            throw new OrderNotFoundException("No items found for order id: " + orderId);
        }

        Orders orderForPriorityCheck = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
        pharmacyRoutingService.assertPharmacyCanAcceptOrder(orderForPriorityCheck, pharmacyId);

        boolean wasPartiallyAllocated = orderForPriorityCheck.getStatus() == OrderStatusEnum.PARTIALLY_ALLOCATED;

        Map<String, BigDecimal> priceByMedicineName = request.getItemPrices().stream()
                .collect(Collectors.toMap(
                        p -> normalize(p.getMedicineName()), PharmacyAcceptItemDTO::getPrice));

        BigDecimal totalAmount = BigDecimal.ZERO;
        for (OrderItem item : items) {
            BigDecimal price = priceByMedicineName.get(normalize(item.getMedicineName()));
            if (price == null) {
                throw new IllegalArgumentException("Missing price for medicine: " + item.getMedicineName());
            }
            totalAmount = totalAmount.add(price.multiply(BigDecimal.valueOf(item.getQuantity())));
        }

        Timestamp deadline = Timestamp.from(Instant.now().plusSeconds(priceAcceptanceWindowMinutes * 60));

        // Atomic compare-and-swap: only the FIRST caller whose UPDATE
        // actually matches wins. Two attempts, tried in order: the common
        // case (order is unclaimed) first, then the override case (order is
        // held as a partial allocation by someone else) second. Only one of
        // these can ever succeed for a given order.
        int rowsAffected = orderRepository.acceptOrderByPharmacy(
                orderId, pharmacyId, totalAmount, OrderStatusEnum.PHARMACY_CONFIRMED, OrderStatusEnum.PENDING);
        if (rowsAffected == 0) {
            rowsAffected = orderRepository.acceptOrderByPharmacyOverridingPartial(
                    orderId, pharmacyId, totalAmount, OrderStatusEnum.PHARMACY_CONFIRMED, OrderStatusEnum.PARTIALLY_ALLOCATED);
        }

        if (rowsAffected == 0) {
            throw new OrderConflictException("Order has already been accepted by another pharmacy or is not open for offers.");
        }

        Orders updated = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
        updated.setPriceConfirmationDeadline(deadline);
        orderRepository.save(updated);

        if (wasPartiallyAllocated) {
            // This full offer displaces whatever partial allocation existed -
            // release it entirely so the earlier partial pharmacy's claim
            // doesn't linger as stale data.
            orderPharmacyAllocationRepository.deleteByOrderId(orderId);
            for (OrderItem item : items) {
                item.setAllocationId(null);
            }
        }

        OrderPharmacyAllocation allocation = new OrderPharmacyAllocation();
        allocation.setOrderId(orderId);
        allocation.setPharmacyId(pharmacyId);
        allocation.setSequenceNo(1);
        allocation.setCreatedAt(Timestamp.from(Instant.now()));
        allocation = orderPharmacyAllocationRepository.save(allocation);

        for (OrderItem item : items) {
            item.setPrice(priceByMedicineName.get(normalize(item.getMedicineName())));
            item.setAllocationId(allocation.getAllocationId());
            orderItemRepository.save(item);
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.PHARMACY_CONFIRMED,
                "Order fully accepted by pharmacy " + pharmacyId + " - awaiting patient price acceptance"));

        return toResponseDTO(updated, items);
    }

    /**
     * Partial fulfillment (item 5/7). Two moments, same method:
     *   1) order is PENDING -> this pharmacy becomes the first partial
     *      pharmacy, IF its declared items cover >= partialThresholdPercent
     *      of the order's line items.
     *   2) order is PARTIALLY_ALLOCATED -> this pharmacy must cover EXACTLY
     *      the remaining unallocated items (no more, no less) to complete
     *      the order - moves straight to PHARMACY_CONFIRMED.
     * Enforcing "exactly the remainder" on the second call is what
     * structurally caps this at 2 pharmacies - there's never a valid
     * partial-of-a-partial to accept a third time.
     */
    @Override
    @Transactional
    public OrderResponseDTO acceptPartialOrder(Long orderId, Long pharmacyId, PharmacyPartialAcceptRequestDTO request) {
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
        List<OrderItem> allItems = orderItemRepository.findByOrderId(orderId);
        if (allItems.isEmpty()) {
            throw new OrderNotFoundException("No items found for order id: " + orderId);
        }

        Map<String, BigDecimal> declaredPrices = request.getItemPrices().stream()
                .collect(Collectors.toMap(p -> normalize(p.getMedicineName()), PharmacyAcceptItemDTO::getPrice));

        if (order.getStatus() == OrderStatusEnum.PENDING) {
            return claimFirstPartial(order, pharmacyId, allItems, declaredPrices);
        }
        if (order.getStatus() == OrderStatusEnum.PARTIALLY_ALLOCATED) {
            return completeSecondPartial(order, pharmacyId, allItems, declaredPrices);
        }
        throw new OrderConflictException("Order is not open for partial fulfillment (current status: " + order.getStatus() + ").");
    }

    private OrderResponseDTO claimFirstPartial(
            Orders order, Long pharmacyId, List<OrderItem> allItems, Map<String, BigDecimal> declaredPrices) {

        pharmacyRoutingService.assertPharmacyCanAcceptOrder(order, pharmacyId);

        Set<String> declaredNames = declaredPrices.keySet();
        for (String name : declaredNames) {
            boolean matchesOrderItem = allItems.stream().anyMatch(item -> normalize(item.getMedicineName()).equals(name));
            if (!matchesOrderItem) {
                throw new IllegalArgumentException("\"" + name + "\" is not part of order " + order.getOrderId());
            }
        }

        double coveragePercent = (declaredNames.size() * 100.0) / allItems.size();
        if (coveragePercent < partialThresholdPercent) {
            throw new OrderConflictException(
                    "Partial claim must cover at least " + partialThresholdPercent
                            + "% of the order's medicines (this offer covers " + Math.round(coveragePercent) + "%).");
        }

        int rowsAffected = orderRepository.claimPartialOrder(
                order.getOrderId(), pharmacyId, OrderStatusEnum.PARTIALLY_ALLOCATED, OrderStatusEnum.PENDING);
        if (rowsAffected == 0) {
            throw new OrderConflictException("Order has already been claimed (fully or partially) by another pharmacy.");
        }

        OrderPharmacyAllocation allocation = new OrderPharmacyAllocation();
        allocation.setOrderId(order.getOrderId());
        allocation.setPharmacyId(pharmacyId);
        allocation.setSequenceNo(1);
        allocation.setCreatedAt(Timestamp.from(Instant.now()));
        allocation = orderPharmacyAllocationRepository.save(allocation);

        for (OrderItem item : allItems) {
            String name = normalize(item.getMedicineName());
            if (declaredPrices.containsKey(name)) {
                item.setPrice(declaredPrices.get(name));
                item.setAllocationId(allocation.getAllocationId());
                orderItemRepository.save(item);
            }
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                order.getOrderId(), OrderStatusEnum.PARTIALLY_ALLOCATED,
                "Pharmacy " + pharmacyId + " partially accepted " + declaredNames.size() + "/" + allItems.size() + " medicines"));

        Orders updated = orderRepository.findById(order.getOrderId()).orElseThrow();
        return toResponseDTO(updated, allItems);
    }

    private OrderResponseDTO completeSecondPartial(
            Orders order, Long pharmacyId, List<OrderItem> allItems, Map<String, BigDecimal> declaredPrices) {

        if (order.getPharmacyId() != null && order.getPharmacyId().equals(pharmacyId)) {
            throw new OrderConflictException("This pharmacy already holds the first allocation on this order.");
        }

        Set<String> unallocatedNames = allItems.stream()
                .filter(item -> item.getAllocationId() == null)
                .map(item -> normalize(item.getMedicineName()))
                .collect(Collectors.toSet());

        if (!declaredPrices.keySet().equals(unallocatedNames)) {
            throw new IllegalArgumentException(
                    "To complete this order you must cover exactly the remaining medicines: " + unallocatedNames);
        }

        BigDecimal totalAmount = BigDecimal.ZERO;
        for (OrderItem item : allItems) {
            BigDecimal price = item.getAllocationId() != null
                    ? item.getPrice()
                    : declaredPrices.get(normalize(item.getMedicineName()));
            totalAmount = totalAmount.add(price.multiply(BigDecimal.valueOf(item.getQuantity())));
        }

        Timestamp deadline = Timestamp.from(Instant.now().plusSeconds(priceAcceptanceWindowMinutes * 60));

        int rowsAffected = orderRepository.completeWithSecondPharmacy(
                order.getOrderId(), totalAmount, deadline, OrderStatusEnum.PHARMACY_CONFIRMED, OrderStatusEnum.PARTIALLY_ALLOCATED);
        if (rowsAffected == 0) {
            throw new OrderConflictException(
                    "Order is no longer available for completion - it may have already been completed, or overridden by a full offer.");
        }

        OrderPharmacyAllocation allocation = new OrderPharmacyAllocation();
        allocation.setOrderId(order.getOrderId());
        allocation.setPharmacyId(pharmacyId);
        allocation.setSequenceNo(2);
        allocation.setCreatedAt(Timestamp.from(Instant.now()));
        allocation = orderPharmacyAllocationRepository.save(allocation);

        for (OrderItem item : allItems) {
            if (item.getAllocationId() == null) {
                item.setPrice(declaredPrices.get(normalize(item.getMedicineName())));
                item.setAllocationId(allocation.getAllocationId());
                orderItemRepository.save(item);
            }
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                order.getOrderId(), OrderStatusEnum.PHARMACY_CONFIRMED,
                "Pharmacy " + pharmacyId + " completed the remaining medicines - order fully allocated"));

        Orders updated = orderRepository.findById(order.getOrderId()).orElseThrow();
        return toResponseDTO(updated, allItems);
    }

    @Override
    @Transactional
    public void rejectOrder(Long orderId, Long pharmacyId) {
        OrderPharmacyRejectionId id = new OrderPharmacyRejectionId(orderId, pharmacyId);
        if (!orderPharmacyRejectionRepository.existsById(id)) {
            orderPharmacyRejectionRepository.save(
                    new OrderPharmacyRejection(id, Timestamp.from(Instant.now())));
        }
    }

    @Override
    @Transactional
    public boolean cancelAcceptedOrder(Long orderId, Long pharmacyId) {
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));

        if (order.getPharmacyId() == null || !order.getPharmacyId().equals(pharmacyId)) {
            throw new OrderConflictException("Order is not currently held by pharmacy " + pharmacyId);
        }
        if (order.getStatus() != OrderStatusEnum.PHARMACY_CONFIRMED || order.getDeliveryPartnerId() != null) {
            throw new OrderConflictException("Order can only be cancelled before a delivery partner is assigned.");
        }

        order.setPharmacyId(null);
        order.setStatus(OrderStatusEnum.PENDING);
        order.setTotalAmount(null);
        order.setConfirmedAt(null);
        order.setPriceConfirmationDeadline(null);
        orderRepository.save(order);

        orderPharmacyAllocationRepository.deleteByOrderId(orderId);
        for (OrderItem item : orderItemRepository.findByOrderId(orderId)) {
            item.setPrice(null);
            item.setAllocationId(null);
            orderItemRepository.save(item);
        }

        pharmacyRoutingService.rebroadcastOrder(orderId);

        return true;
    }

    private String normalize(String medicineName) {
        return medicineName == null ? null : medicineName.trim().toLowerCase();
    }

    private Pharmacy findPharmacyOrThrow(Long id) {
        return pharmacyRepository.findById(id)
                .orElseThrow(() -> new PharmacyNotFoundException("Pharmacy not found with id: " + id));
    }

    private PharmacyDTO toDTO(Pharmacy pharmacy) {
        PharmacyDTO dto = new PharmacyDTO();
        BeanUtils.copyProperties(pharmacy, dto);
        return dto;
    }

    private OrderSummaryDTO toSummaryDTO(Orders order) {
        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());

        OrderSummaryDTO dto = new OrderSummaryDTO();
        dto.setOrderId(order.getOrderId());
        dto.setItemCount(items.size());
        dto.setMedicinesSummary(items.stream().map(OrderItem::getMedicineName).collect(Collectors.joining(", ")));
        dto.setTotalAmount(order.getTotalAmount());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setPatientName(order.getPatientName());
        return dto;
    }

    private OrderResponseDTO toResponseDTO(Orders order, List<OrderItem> items) {
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderId(order.getOrderId());
        dto.setPharmacyId(order.getPharmacyId());
        dto.setDeliveryPartnerId(order.getDeliveryPartnerId());
        dto.setUserId(order.getUserId());
        dto.setPrescriptionId(order.getPrescriptionId());
        dto.setHospitalId(order.getHospitalId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());
        dto.setCancelledAt(order.getCancelledAt());
        dto.setDeliveryNote(order.getDeliveryNote());
        dto.setEstimatedDeliveryMinutes(order.getEstimatedDeliveryMinutes());
        dto.setPriceConfirmationDeadline(order.getPriceConfirmationDeadline());

        dto.setPatientUserId(order.getPatientUserId());
        dto.setPatientName(order.getPatientName());
        dto.setPatientAge(order.getPatientAge());
        dto.setPatientPhone(order.getPatientPhone());
        dto.setPatientRelationship(order.getPatientRelationship());

        List<OrderItemDTO> itemDTOs = items.stream().map(item -> {
            OrderItemDTO itemDTO = new OrderItemDTO();
            itemDTO.setItemId(item.getItemId());
            itemDTO.setMedicineName(item.getMedicineName());
            itemDTO.setQuantity(item.getQuantity());
            itemDTO.setPrice(item.getPrice());
            return itemDTO;
        }).toList();

        dto.setItems(itemDTOs);
        return dto;
    }
}
