package com.curonex.pharmacy.serviceimpl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.dto.OrderFeedbackRequestDTO;
import com.curonex.pharmacy.dto.OrderFeedbackResponseDTO;
import com.curonex.pharmacy.entity.OrderFeedback;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.OrderFeedbackRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.service.DeliveryPartnersService;
import com.curonex.pharmacy.service.OrderFeedbackService;
import com.curonex.pharmacy.service.PharmacyService;

@Service
public class OrderFeedbackServiceImpl implements OrderFeedbackService {

    private final OrderFeedbackRepository orderFeedbackRepository;
    private final OrderRepository orderRepository;
    private final PharmacyService pharmacyService;
    private final DeliveryPartnersService deliveryPartnersService;

    public OrderFeedbackServiceImpl(
            OrderFeedbackRepository orderFeedbackRepository,
            OrderRepository orderRepository,
            PharmacyService pharmacyService,
            DeliveryPartnersService deliveryPartnersService) {
        this.orderFeedbackRepository = orderFeedbackRepository;
        this.orderRepository = orderRepository;
        this.pharmacyService = pharmacyService;
        this.deliveryPartnersService = deliveryPartnersService;
    }

    /**
     * Single combined submission. The numeric ratings are delegated to the
     * existing PharmacyService/DeliveryPartnersService#submitRating() calls
     * - those already own the running-average update AND the
     * already-rated/not-yet-delivered/wrong-pharmacy abuse guards (see
     * PharmacyServiceImpl.submitRating), so none of that is duplicated
     * here. This method only adds: doing both halves in one call, and
     * persisting the free-text feedback neither of those calls has
     * anywhere to put. @Transactional means if either half fails validation
     * (e.g. already rated), nothing is saved - no partial feedback.
     */
    @Override
    @Transactional
    public OrderFeedbackResponseDTO submitFeedback(Long orderId, OrderFeedbackRequestDTO request) {
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));

        if (order.getStatus() != OrderStatusEnum.DELIVERED) {
            throw new OrderConflictException("Feedback can only be submitted after the order has been delivered.");
        }
        if (order.getPharmacyId() == null || order.getDeliveryPartnerId() == null) {
            throw new OrderConflictException("Order " + orderId + " is missing a pharmacy or delivery partner assignment.");
        }

        pharmacyService.submitRating(order.getPharmacyId(), orderId, request.getPharmacyRating());
        deliveryPartnersService.submitRating(order.getDeliveryPartnerId(), orderId, request.getDeliveryRating());

        OrderFeedback feedback = new OrderFeedback();
        feedback.setOrderId(orderId);
        feedback.setPharmacyId(order.getPharmacyId());
        feedback.setDeliveryPartnerId(order.getDeliveryPartnerId());
        feedback.setPharmacyRating(request.getPharmacyRating());
        feedback.setPharmacyFeedback(request.getPharmacyFeedback());
        feedback.setDeliveryRating(request.getDeliveryRating());
        feedback.setDeliveryFeedback(request.getDeliveryFeedback());
        feedback.setSubmittedAt(Timestamp.from(Instant.now()));

        return toResponseDTO(orderFeedbackRepository.save(feedback), order.getPatientName());
    }

    @Override
    public OrderFeedbackResponseDTO getFeedbackForOrder(Long orderId) {
        OrderFeedback feedback = orderFeedbackRepository.findByOrderId(orderId)
                .orElseThrow(() -> new OrderNotFoundException("No feedback found for order " + orderId));
        Orders order = orderRepository.findById(orderId).orElse(null);
        return toResponseDTO(feedback, order != null ? order.getPatientName() : null);
    }

    @Override
    public List<OrderFeedbackResponseDTO> getFeedbackForPharmacy(Long pharmacyId) {
        return orderFeedbackRepository.findByPharmacyIdOrderBySubmittedAtDesc(pharmacyId).stream()
                .map(fb -> toResponseDTO(fb, patientNameFor(fb.getOrderId())))
                .toList();
    }

    @Override
    public List<OrderFeedbackResponseDTO> getFeedbackForDeliveryPartner(Long deliveryPartnerId) {
        return orderFeedbackRepository.findByDeliveryPartnerIdOrderBySubmittedAtDesc(deliveryPartnerId).stream()
                .map(fb -> toResponseDTO(fb, patientNameFor(fb.getOrderId())))
                .toList();
    }

    private String patientNameFor(Long orderId) {
        return orderRepository.findById(orderId).map(Orders::getPatientName).orElse(null);
    }

    private OrderFeedbackResponseDTO toResponseDTO(OrderFeedback feedback, String patientName) {
        OrderFeedbackResponseDTO dto = new OrderFeedbackResponseDTO();
        dto.setOrderId(feedback.getOrderId());
        dto.setPharmacyId(feedback.getPharmacyId());
        dto.setDeliveryPartnerId(feedback.getDeliveryPartnerId());
        dto.setPharmacyRating(feedback.getPharmacyRating());
        dto.setPharmacyFeedback(feedback.getPharmacyFeedback());
        dto.setDeliveryRating(feedback.getDeliveryRating());
        dto.setDeliveryFeedback(feedback.getDeliveryFeedback());
        dto.setSubmittedAt(feedback.getSubmittedAt());
        dto.setPatientName(patientName);
        return dto;
    }
}
