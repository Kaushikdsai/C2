package com.curonex.pharmacy.service;

import java.util.List;
import java.util.Optional;

import com.curonex.pharmacy.dto.HospitalPublicKeyDTO;
import com.curonex.pharmacy.dto.HospitalPublicKeyRegistrationDTO;
import com.curonex.pharmacy.entity.HospitalPublicKey;

public interface HospitalPublicKeyService {

    /** Registers a new key version, or re-registers (rotates the bytes of) an existing one. Always starts active. */
    HospitalPublicKeyDTO registerKey(HospitalPublicKeyRegistrationDTO request);

    List<HospitalPublicKeyDTO> getKeysForHospital(Long hospitalId);

    /** Deactivates a compromised/retired key version without deleting the audit record. */
    HospitalPublicKeyDTO deactivateKey(Long hospitalId, String keyVersion);

    /** Raw entity lookup for internal use by PrescriptionVerificationServiceImpl - includes the active flag check. */
    Optional<HospitalPublicKey> findActiveKey(Long hospitalId, String keyVersion);
}
