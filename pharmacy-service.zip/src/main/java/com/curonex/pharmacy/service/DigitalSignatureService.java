package com.curonex.pharmacy.service;

public interface DigitalSignatureService {

    /**
     * Verifies that `signatureBase64` is a valid SHA256withRSA signature of
     * `canonicalPayload`, produced by the private key matching
     * `publicKeyBase64`. Returns false for ANY failure mode (malformed
     * key, malformed signature, mismatched payload) - callers should treat
     * false as "reject the prescription", never inspect the reason beyond
     * that, since the exact failure mode is not safe to expose to the
     * patient (see PrescriptionVerificationServiceImpl).
     */
    boolean verify(String canonicalPayload, String signatureBase64, String publicKeyBase64);
}
