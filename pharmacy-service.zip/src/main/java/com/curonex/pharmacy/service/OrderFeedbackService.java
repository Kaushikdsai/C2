package com.curonex.pharmacy.service;

import java.util.List;

import com.curonex.pharmacy.dto.OrderFeedbackRequestDTO;
import com.curonex.pharmacy.dto.OrderFeedbackResponseDTO;

public interface OrderFeedbackService {

    /** The single combined feedback page - rates and reviews the pharmacy AND the delivery partner for one delivered order in one call. */
    OrderFeedbackResponseDTO submitFeedback(Long orderId, OrderFeedbackRequestDTO request);

    OrderFeedbackResponseDTO getFeedbackForOrder(Long orderId);

    /** Shown on the pharmacy admin portal. */
    List<OrderFeedbackResponseDTO> getFeedbackForPharmacy(Long pharmacyId);

    /** Shown on the delivery partner portal. */
    List<OrderFeedbackResponseDTO> getFeedbackForDeliveryPartner(Long deliveryPartnerId);
}
