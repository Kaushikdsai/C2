package com.curonex.pharmacy.service;

import java.util.Map;
import java.util.Optional;

import com.curonex.pharmacy.dto.PrescriptionVerificationBlockDTO;

public interface PrescriptionVerificationBlockService {

    /**
     * Looks for a line matching CURONEX-VERIFY:<payload>::<signature> in
     * the extracted PDF text. Empty Optional means no verification block
     * was found at all (treated as INVALID, not MANUAL_REVIEW - a
     * prescription with no signature block at all is exactly the
     * "some random guy generated it" case this feature exists to catch).
     */
    Optional<PrescriptionVerificationBlockDTO> extractBlock(String pdfText);

    /**
     * Best-effort extraction of the human-readable labeled fields printed
     * elsewhere on the prescription (e.g. "Hospital: 12", "Doctor: 501",
     * "Patient ID: PAT900", "Prescription Ref: RX78291"), used to
     * cross-check against the signed block. Returns whatever labels it
     * could find - missing labels are reported as MANUAL_REVIEW by
     * PrescriptionVerificationServiceImpl, not silently ignored.
     */
    Map<String, String> extractLabeledFields(String pdfText);
}
