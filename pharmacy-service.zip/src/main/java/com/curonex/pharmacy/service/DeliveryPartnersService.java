package com.curonex.pharmacy.service;

import java.math.BigDecimal;
import java.util.List;

import com.curonex.pharmacy.dto.DeliveryPartnerDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerDashboardDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerProfileDTO;

public interface DeliveryPartnersService {

    DeliveryPartnerDTO addDeliveryPartner(DeliveryPartnerDTO dto);

    DeliveryPartnerDTO getDeliveryPartnerById(Long deliveryPartnerId);

    List<DeliveryPartnerDTO> getAllDeliveryPartners();

    DeliveryPartnerDTO updateDeliveryPartner(Long deliveryPartnerId, DeliveryPartnerDTO dto);

    void deleteDeliveryPartner(Long deliveryPartnerId);

    List<DeliveryPartnerDTO> getAvailableDeliveryPartners();

    boolean markAvailable(Long deliveryPartnerId);

    boolean markOnDelivery(Long deliveryPartnerId);

    boolean markOffline(Long deliveryPartnerId);

    DeliveryPartnerProfileDTO getPartnerProfile(Long deliveryPartnerId);

    DeliveryPartnerProfileDTO updatePartnerProfile(Long deliveryPartnerId, DeliveryPartnerProfileDTO dto);

    /** orderId ties the rating to a real, DELIVERED, matching, not-already-rated order. */
    DeliveryPartnerProfileDTO submitRating(Long deliveryPartnerId, Long orderId, BigDecimal rating);

    DeliveryPartnerDashboardDTO getDashboard(Long deliveryPartnerId);
}
