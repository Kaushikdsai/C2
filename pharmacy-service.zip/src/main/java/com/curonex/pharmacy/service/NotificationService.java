package com.curonex.pharmacy.service;

import com.curonex.pharmacy.enums.OrderStatusEnum;

/**
 * Real notification delivery - actual email, not just a log line. Resolves
 * the patient's email itself via orderId (order -> userId -> details-service),
 * so callers (the event listener) only need to pass what changed.
 */
public interface NotificationService {

    void notifyOrderStatusChange(Long orderId, OrderStatusEnum status, String message);
}
