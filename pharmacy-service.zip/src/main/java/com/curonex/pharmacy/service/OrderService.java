package com.curonex.pharmacy.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.curonex.pharmacy.dto.OrderCreateRequestDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderTrackingDTO;
import com.curonex.pharmacy.dto.PatientDetailsUpdateDTO;

public interface OrderService {

    OrderResponseDTO createOrder(OrderCreateRequestDTO request);

    OrderResponseDTO getOrderById(Long orderId);

    List<OrderResponseDTO> getOrdersByUser(Long userId);

    List<OrderResponseDTO> getAllOrders();

    Page<OrderResponseDTO> getAllOrders(Pageable pageable);

    void deleteOrder(Long orderId);

    OrderTrackingDTO getOrderTracking(Long orderId);

    /** "Order for someone else" edit - only allowed while the order is still PENDING. */
    OrderResponseDTO updatePatientDetails(Long orderId, PatientDetailsUpdateDTO dto);

    /**
     * Item 11: the patient accepts the price shown once pharmacy
     * fulfillment is 100% complete (order is PHARMACY_CONFIRMED). This is
     * what actually triggers the delivery-partner broadcast - fails with
     * OrderConflictException if the acceptance window has already lapsed
     * (see OrderRetryScheduler, which sweeps expired windows to
     * PAYMENT_WINDOW_EXPIRED on its own cadence).
     */
    OrderResponseDTO acceptPrice(Long orderId);

    /** Cancels an order that isn't already DELIVERED or already CANCELLED. */
    OrderResponseDTO cancelOrder(Long orderId);
}
