package com.curonex.pharmacy.service;

import java.util.List;

import com.curonex.pharmacy.dto.ActiveDeliveryDTO;
import com.curonex.pharmacy.dto.AvailableOrderDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;

/**
 * findNearbyDeliveryPartners used to be public here (and REST-exposed via
 * DeliveryPartnersController) but had no caller anywhere outside this
 * service - broadcastOrder() uses it internally, and that's the only real
 * consumer. Kept as a private helper in the impl instead.
 */
public interface DeliveryRoutingService {

    /** Atomic accept: fails with OrderConflictException if another partner already claimed it. Also computes and stores the ETA (item 8) at the moment of acceptance. */
    boolean acceptDelivery(Long orderId, Long deliveryPartnerId);

    boolean cancelDelivery(Long orderId, Long deliveryPartnerId);

    /** This partner declines - order stays open for others, hidden from this partner going forward. Mirrors PharmacyService#rejectOrder. */
    void rejectDelivery(Long orderId, Long deliveryPartnerId);

    /**
     * Marks the pickup from ONE specific pharmacy stop as complete. For a
     * single-pharmacy order this is the only stop and the order moves
     * straight to OUT_FOR_DELIVERY. For a 2-pharmacy partial-fulfillment
     * order, the order only moves to OUT_FOR_DELIVERY once BOTH stops are
     * picked up - see OrderPharmacyAllocation.
     */
    boolean pickupFromPharmacy(Long orderId, Long deliveryPartnerId, Long pharmacyId);

    boolean markDelivered(Long orderId, Long deliveryPartnerId);

    void broadcastOrder(Long orderId);

    void rebroadcastOrder(Long orderId);

    List<AvailableOrderDTO> getAvailableOrdersForPartner(Long deliveryPartnerId);

    List<ActiveDeliveryDTO> getActiveDeliveriesForPartner(Long deliveryPartnerId);

    List<OrderResponseDTO> getDeliveryHistoryForPartner(Long deliveryPartnerId);
}
