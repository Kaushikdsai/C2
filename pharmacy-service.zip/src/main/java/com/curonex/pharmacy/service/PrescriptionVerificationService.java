package com.curonex.pharmacy.service;

import org.springframework.web.multipart.MultipartFile;

import com.curonex.pharmacy.dto.PrescriptionVerificationResultDTO;

public interface PrescriptionVerificationService {

    /**
     * Full pipeline: read PDF -> extract signed block -> verify signature
     * -> cross-check against the human-readable fields on the document ->
     * (if all pass) extract medicines. Never throws for a prescription
     * that simply fails verification - that's a normal INVALID/
     * MANUAL_REVIEW result, not an exception. Only throws for genuinely
     * malformed input (not a PDF, empty file).
     */
    PrescriptionVerificationResultDTO verify(MultipartFile file);
}
