package com.curonex.pharmacy.service;

import java.math.BigDecimal;
import java.util.List;

import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyDTO;
import com.curonex.pharmacy.dto.PharmacyDashboardDTO;
import com.curonex.pharmacy.dto.PharmacyPartialAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyProfileDTO;
import com.curonex.pharmacy.enums.OrderStatusEnum;

public interface PharmacyService {

    PharmacyDTO addPharmacy(PharmacyDTO dto);

    PharmacyDTO getPharmacyById(Long id);

    List<PharmacyDTO> getAllPharmacies();

    PharmacyDTO updatePharmacy(Long id, PharmacyDTO dto);

    void deletePharmacy(Long id);

    List<PharmacyDTO> getActivePharmacies();

    PharmacyProfileDTO getPharmacyProfile(Long pharmacyId);

    PharmacyProfileDTO updatePharmacyProfile(Long pharmacyId, PharmacyProfileDTO dto);

    /** orderId ties the rating to a real, DELIVERED, matching, not-already-rated order. */
    PharmacyProfileDTO submitRating(Long pharmacyId, Long orderId, BigDecimal rating);

    PharmacyDashboardDTO getDashboard(Long pharmacyId);

    List<OrderSummaryDTO> getOrdersByStatus(Long pharmacyId, OrderStatusEnum status);

    List<OrderSummaryDTO> getOrderHistory(Long pharmacyId);

    double getDeliverySuccessRate(Long pharmacyId);

    long getOrdersThisMonth(Long pharmacyId);

    /**
     * Atomic accept of the COMPLETE order. Fails with OrderConflictException
     * if another pharmacy already fully claimed it. Also succeeds when the
     * order is currently PARTIALLY_ALLOCATED (another pharmacy holds part
     * of it) - in that case THIS pharmacy's full-order offer wins outright,
     * the earlier partial allocation is released, per "if a second pharmacy
     * independently has 100%, use that pharmacy directly instead" (item 5).
     */
    OrderResponseDTO acceptOrder(Long orderId, Long pharmacyId, PharmacyAcceptRequestDTO request);

    /**
     * Partial fulfillment (item 5/7). Same endpoint covers two different
     * moments - see PharmacyPartialAcceptRequestDTO:
     *   - order PENDING: this pharmacy claims >= the configured threshold
     *     of the line items, becoming the "first partial pharmacy".
     *   - order PARTIALLY_ALLOCATED: this pharmacy must cover exactly the
     *     remaining unallocated items, completing the order to 100% across
     *     the two pharmacies (order moves to PHARMACY_CONFIRMED).
     * Throws OrderConflictException on any status/coverage mismatch.
     */
    OrderResponseDTO acceptPartialOrder(Long orderId, Long pharmacyId, PharmacyPartialAcceptRequestDTO request);

    /** This pharmacy declines - order stays open for others. */
    void rejectOrder(Long orderId, Long pharmacyId);

    /** Pharmacy backs out after accepting - order reopens and is rebroadcast. */
    boolean cancelAcceptedOrder(Long orderId, Long pharmacyId);
}
