package com.curonex.pharmacy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.OrderFeedback;

@Repository
public interface OrderFeedbackRepository extends JpaRepository<OrderFeedback, Long> {

    Optional<OrderFeedback> findByOrderId(Long orderId);

    /** Pharmacy admin portal: all feedback left for a given pharmacy, newest first. */
    List<OrderFeedback> findByPharmacyIdOrderBySubmittedAtDesc(Long pharmacyId);

    /** Delivery partner portal: all feedback left for a given partner, newest first. */
    List<OrderFeedback> findByDeliveryPartnerIdOrderBySubmittedAtDesc(Long deliveryPartnerId);
}
