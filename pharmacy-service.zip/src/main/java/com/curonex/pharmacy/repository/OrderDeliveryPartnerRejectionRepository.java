package com.curonex.pharmacy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.OrderDeliveryPartnerRejection;
import com.curonex.pharmacy.entity.OrderDeliveryPartnerRejectionId;

@Repository
public interface OrderDeliveryPartnerRejectionRepository
        extends JpaRepository<OrderDeliveryPartnerRejection, OrderDeliveryPartnerRejectionId> {

    boolean existsByIdOrderIdAndIdDeliveryPartnerId(Long orderId, Long deliveryPartnerId);

    @Modifying
    @Query("DELETE FROM OrderDeliveryPartnerRejection r WHERE r.id.orderId = :orderId")
    void deleteByIdOrderId(@Param("orderId") Long orderId);
}
