package com.curonex.pharmacy.repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;

@Repository
public interface OrderRepository extends JpaRepository<Orders, Long> {

    List<Orders> findByUserId(Long userId);

    List<Orders> findByPharmacyId(Long pharmacyId);

    List<Orders> findByStatus(OrderStatusEnum status);

    List<Orders> findByPharmacyIdAndStatus(Long pharmacyId, OrderStatusEnum status);

    List<Orders> findByDeliveryPartnerId(Long deliveryPartnerId);

    List<Orders> findByDeliveryPartnerIdAndStatus(Long deliveryPartnerId, OrderStatusEnum status);

    List<Orders> findByStatusAndPharmacyIdIsNull(OrderStatusEnum status);

    List<Orders> findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum status);

    /**
     * Atomic pharmacy-accept: also stamps confirmedAt. Only succeeds if
     * unclaimed. NOTE: this alone does NOT enforce the hospital-priority
     * window - that's checked by PharmacyRoutingService.assertPharmacyCanAcceptOrder()
     * BEFORE this is called (see PharmacyServiceImpl.acceptOrder()), since
     * priority depends on hospitalId/geoAddress/timing, not just claim state.
     */
    @Modifying
    @Query("UPDATE Orders o SET o.pharmacyId = :pharmacyId, o.status = :newStatus, o.totalAmount = :totalAmount, "
            + "o.confirmedAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.pharmacyId IS NULL AND o.status = :requiredStatus")
    int acceptOrderByPharmacy(
            @Param("orderId") Long orderId,
            @Param("pharmacyId") Long pharmacyId,
            @Param("totalAmount") BigDecimal totalAmount,
            @Param("newStatus") OrderStatusEnum newStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    /**
     * Same as acceptOrderByPharmacy but WITHOUT the "pharmacyId IS NULL"
     * guard - used exactly once, for the "full offer overrides an existing
     * partial allocation" case (item 5's "if a second pharmacy
     * independently has 100%, use that pharmacy directly instead"). A
     * PARTIALLY_ALLOCATED order always already has a pharmacyId set (the
     * first partial pharmacy), so reusing acceptOrderByPharmacy here would
     * never match anything - this query intentionally allows overwriting
     * it. Still guarded by :requiredStatus = PARTIALLY_ALLOCATED, so it can
     * never fire against a PENDING or already-CONFIRMED order.
     */
    @Modifying
    @Query("UPDATE Orders o SET o.pharmacyId = :pharmacyId, o.status = :newStatus, o.totalAmount = :totalAmount, "
            + "o.confirmedAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.status = :requiredStatus")
    int acceptOrderByPharmacyOverridingPartial(
            @Param("orderId") Long orderId,
            @Param("pharmacyId") Long pharmacyId,
            @Param("totalAmount") BigDecimal totalAmount,
            @Param("newStatus") OrderStatusEnum newStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    @Modifying
    @Query("UPDATE Orders o SET o.deliveryPartnerId = :partnerId "
            + "WHERE o.orderId = :orderId AND o.deliveryPartnerId IS NULL AND o.status = :requiredStatus")
    int acceptOrderByDeliveryPartner(
            @Param("orderId") Long orderId,
            @Param("partnerId") Long partnerId,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    @Modifying
    @Query("UPDATE Orders o SET o.deliveryPartnerId = NULL "
            + "WHERE o.orderId = :orderId AND o.deliveryPartnerId = :partnerId AND o.status = :requiredStatus")
    int releaseOrderFromDeliveryPartner(
            @Param("orderId") Long orderId,
            @Param("partnerId") Long partnerId,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    @Modifying
    @Query("UPDATE Orders o SET o.status = :newStatus, o.pickedUpAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.deliveryPartnerId = :partnerId AND o.status = :requiredStatus")
    int pickupOrderByDeliveryPartner(
            @Param("orderId") Long orderId,
            @Param("partnerId") Long partnerId,
            @Param("newStatus") OrderStatusEnum newStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    @Modifying
    @Query("UPDATE Orders o SET o.status = :newStatus, o.deliveredAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.deliveryPartnerId = :partnerId AND o.status = :requiredStatus")
    int markDeliveredByDeliveryPartner(
            @Param("orderId") Long orderId,
            @Param("partnerId") Long partnerId,
            @Param("newStatus") OrderStatusEnum newStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    /** Cancels an order that hasn't been delivered or already cancelled yet. Stamps cancelledAt. */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :cancelledStatus, o.cancelledAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.status <> :deliveredStatus AND o.status <> :cancelledStatus")
    int cancelOrder(
            @Param("orderId") Long orderId,
            @Param("cancelledStatus") OrderStatusEnum cancelledStatus,
            @Param("deliveredStatus") OrderStatusEnum deliveredStatus);

    // ── Partial pharmacy fulfillment (item 5/7) ─────────────────────────

    /**
     * First pharmacy claims >=50% of the order. Same atomic
     * compare-and-swap pattern as acceptOrderByPharmacy - only the first
     * caller whose UPDATE actually matches wins; every later caller gets
     * rowsAffected == 0 and is told to retry against whatever the order's
     * real state has become.
     */
    @Modifying
    @Query("UPDATE Orders o SET o.pharmacyId = :pharmacyId, o.status = :newStatus "
            + "WHERE o.orderId = :orderId AND o.pharmacyId IS NULL AND o.status = :requiredStatus")
    int claimPartialOrder(
            @Param("orderId") Long orderId,
            @Param("pharmacyId") Long pharmacyId,
            @Param("newStatus") OrderStatusEnum newStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    /**
     * Second pharmacy completes the remaining medicines - order moves
     * straight to PHARMACY_CONFIRMED (100% allocated, price now fixed,
     * awaiting patient acceptance). PharmacyServiceImpl guarantees the
     * second pharmacy's declared items are an exact match for whatever was
     * still unallocated BEFORE calling this - this query only guards the
     * order's status, not item coverage.
     */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :newStatus, o.totalAmount = :totalAmount, "
            + "o.priceConfirmationDeadline = :deadline "
            + "WHERE o.orderId = :orderId AND o.status = :requiredStatus")
    int completeWithSecondPharmacy(
            @Param("orderId") Long orderId,
            @Param("totalAmount") BigDecimal totalAmount,
            @Param("deadline") Timestamp deadline,
            @Param("newStatus") OrderStatusEnum newStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    /** Patient accepts the shown price within the window - this is what actually triggers the delivery-partner broadcast (see OrderServiceImpl.acceptPrice). */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :confirmedStatus, o.priceAcceptedAt = CURRENT_TIMESTAMP "
            + "WHERE o.orderId = :orderId AND o.status = :requiredStatus AND o.priceConfirmationDeadline >= CURRENT_TIMESTAMP")
    int acceptPriceByPatient(
            @Param("orderId") Long orderId,
            @Param("confirmedStatus") OrderStatusEnum confirmedStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    /** Bulk sweep (scheduler): any PHARMACY_CONFIRMED order whose window has lapsed with no patient acceptance. */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :expiredStatus "
            + "WHERE o.status = :requiredStatus AND o.priceConfirmationDeadline < CURRENT_TIMESTAMP")
    int expirePriceWindows(
            @Param("expiredStatus") OrderStatusEnum expiredStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    /** Terminal failure for the pharmacy-search phase (item 9's rebroadcast cap) - order was PENDING or PARTIALLY_ALLOCATED and never reached full coverage. */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :failedStatus "
            + "WHERE o.orderId = :orderId AND (o.status = :pendingStatus OR o.status = :partiallyAllocatedStatus)")
    int markPharmacySearchFailed(
            @Param("orderId") Long orderId,
            @Param("failedStatus") OrderStatusEnum failedStatus,
            @Param("pendingStatus") OrderStatusEnum pendingStatus,
            @Param("partiallyAllocatedStatus") OrderStatusEnum partiallyAllocatedStatus);

    /** Terminal failure for the delivery-partner-search phase (item 9's rebroadcast cap on the other side). */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :failedStatus "
            + "WHERE o.orderId = :orderId AND o.status = :requiredStatus")
    int markDeliverySearchFailed(
            @Param("orderId") Long orderId,
            @Param("failedStatus") OrderStatusEnum failedStatus,
            @Param("requiredStatus") OrderStatusEnum requiredStatus);

    @Modifying
    @Query("UPDATE Orders o SET o.pharmacyRebroadcastCount = o.pharmacyRebroadcastCount + 1 WHERE o.orderId = :orderId")
    void incrementPharmacyRebroadcastCount(@Param("orderId") Long orderId);

    @Modifying
    @Query("UPDATE Orders o SET o.deliveryRebroadcastCount = o.deliveryRebroadcastCount + 1 WHERE o.orderId = :orderId")
    void incrementDeliveryRebroadcastCount(@Param("orderId") Long orderId);

    List<Orders> findByStatusAndPharmacyIdIsNotNullAndDeliveryPartnerIdIsNull(OrderStatusEnum status);
}
