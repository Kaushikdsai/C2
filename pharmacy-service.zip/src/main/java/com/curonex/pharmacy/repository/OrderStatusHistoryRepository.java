package com.curonex.pharmacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.OrderStatusHistory;

@Repository
public interface OrderStatusHistoryRepository extends JpaRepository<OrderStatusHistory, Long> {

    /** Ordered oldest-first so a timeline UI can render it directly with no client-side sort. */
    List<OrderStatusHistory> findByOrderIdOrderByChangedAtAsc(Long orderId);
}
