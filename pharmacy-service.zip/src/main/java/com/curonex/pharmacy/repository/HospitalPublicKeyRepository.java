package com.curonex.pharmacy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.HospitalPublicKey;
import com.curonex.pharmacy.entity.HospitalPublicKeyId;

@Repository
public interface HospitalPublicKeyRepository extends JpaRepository<HospitalPublicKey, HospitalPublicKeyId> {

    List<HospitalPublicKey> findByIdHospitalId(Long hospitalId);

    Optional<HospitalPublicKey> findByIdHospitalIdAndIdKeyVersion(Long hospitalId, String keyVersion);
}
