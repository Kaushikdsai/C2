package com.curonex.pharmacy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.OrderPharmacyAllocation;

@Repository
public interface OrderPharmacyAllocationRepository extends JpaRepository<OrderPharmacyAllocation, Long> {

    List<OrderPharmacyAllocation> findByOrderIdOrderBySequenceNoAsc(Long orderId);

    Optional<OrderPharmacyAllocation> findByOrderIdAndPharmacyId(Long orderId, Long pharmacyId);

    /** Used to build a pharmacy's "my orders" list alongside the primary-pharmacy query on OrderRepository, so a second/secondary pharmacy still sees its own orders. */
    List<OrderPharmacyAllocation> findByPharmacyId(Long pharmacyId);

    boolean existsByOrderIdAndPickedUpAtIsNull(Long orderId);

    void deleteByOrderId(Long orderId);
}
