package com.curonex.pharmacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.PrescriptionMedicineId;
import com.curonex.pharmacy.entity.PrescriptionMedicines;

@Repository
public interface PrescriptionMedicinesRepository
        extends JpaRepository<PrescriptionMedicines, PrescriptionMedicineId> {

    List<PrescriptionMedicines> findByIdPrescriptionId(Long prescriptionId);

    List<PrescriptionMedicines> findByIdMedicineName(String medicineName);

    boolean existsByIdPrescriptionIdAndIdMedicineName(Long prescriptionId, String medicineName);
}
