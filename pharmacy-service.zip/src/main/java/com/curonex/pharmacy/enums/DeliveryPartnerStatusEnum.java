package com.curonex.pharmacy.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum DeliveryPartnerStatusEnum {
    AVAILABLE("available"),
    ON_DELIVERY("on_delivery"),
    OFFLINE("offline");

    private final String dbValue;

    DeliveryPartnerStatusEnum(String dbValue) {
        this.dbValue = dbValue;
    }

    @JsonValue
    public String getDbValue() {
        return dbValue;
    }

    @JsonCreator
    public static DeliveryPartnerStatusEnum fromDbValue(String dbValue) {
        for (DeliveryPartnerStatusEnum value : values()) {
            if (value.dbValue.equalsIgnoreCase(dbValue)) {
                return value;
            }
        }
        throw new IllegalArgumentException("Unknown DeliveryPartnerStatusEnum db value: " + dbValue);
    }
}
