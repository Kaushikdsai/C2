package com.curonex.pharmacy.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum OrderStatusEnum {
    /** Broadcast to nearby pharmacies, no one has accepted (fully or partially) yet. */
    PENDING("pending"),

    /**
     * Exactly one pharmacy has claimed >=50% of the order (the
     * "first partial pharmacy"). Curonex is now searching within
     * curonex.fulfillment.missing-item-search-radius-km of THAT pharmacy
     * for the remaining medicines. A full-order offer from any OTHER
     * pharmacy can still override this at any point (see
     * PharmacyServiceImpl.acceptOrder) - partial allocation never blocks a
     * better, complete offer from winning instead.
     */
    PARTIALLY_ALLOCATED("partially_allocated"),

    /**
     * 100% of the order is allocated (one pharmacy, or two under the
     * partial-fulfillment path) and priced. Not yet broadcast to delivery
     * partners - waiting on the patient to accept the final price within
     * the configured window (see priceConfirmationDeadline).
     */
    PHARMACY_CONFIRMED("pharmacy_confirmed"),

    /** Patient accepted the price - broadcast to delivery partners happens the instant this is set. */
    CONFIRMED("confirmed"),
    OUT_FOR_DELIVERY("out_for_delivery"),
    DELIVERED("delivered"),
    CANCELLED("cancelled"),

    /** No pharmacy combination reached 100% fulfillment within the configured rebroadcast limit, OR no delivery partner accepted within the same limit. Terminal - no delivery starts. */
    FULFILLMENT_FAILED("fulfillment_failed"),

    /** Patient did not accept the price within the acceptance window. Terminal. */
    PAYMENT_WINDOW_EXPIRED("payment_window_expired");

    private final String dbValue;

    OrderStatusEnum(String dbValue) {
        this.dbValue = dbValue;
    }

    @JsonValue
    public String getDbValue() {
        return dbValue;
    }

    @JsonCreator
    public static OrderStatusEnum fromDbValue(String dbValue) {
        for (OrderStatusEnum value : values()) {
            if (value.dbValue.equalsIgnoreCase(dbValue)) {
                return value;
            }
        }
        throw new IllegalArgumentException("Unknown OrderStatusEnum db value: " + dbValue);
    }
}
