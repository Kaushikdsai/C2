package com.curonex.pharmacy.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum PharmacyStatusEnum {
    ACTIVE("active"),
    INACTIVE("inactive"),
    SUSPENDED("suspended");

    private final String dbValue;

    PharmacyStatusEnum(String dbValue) {
        this.dbValue = dbValue;
    }

    @JsonValue
    public String getDbValue() {
        return dbValue;
    }

    @JsonCreator
    public static PharmacyStatusEnum fromDbValue(String dbValue) {
        for (PharmacyStatusEnum value : values()) {
            if (value.dbValue.equalsIgnoreCase(dbValue)) {
                return value;
            }
        }
        throw new IllegalArgumentException("Unknown PharmacyStatusEnum value: " + dbValue);
    }
}
