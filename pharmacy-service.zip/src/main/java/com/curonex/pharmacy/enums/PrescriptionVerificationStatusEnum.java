package com.curonex.pharmacy.enums;

public enum PrescriptionVerificationStatusEnum {
    VERIFIED,
    INVALID,
    MANUAL_REVIEW
}
