package com.curonex.pharmacy.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.curonex.pharmacy.service.NotificationService;

/**
 * Sends a real patient email via NotificationService - this used to just
 * log the event; that placeholder period is over. The seam this class
 * provides is still useful, though: adding a second listener (SMS, push,
 * an audit table) still requires zero changes to any service's business
 * logic, only a new @EventListener class.
 */
@Component
public class OrderEventListener {

    private static final Logger log = LoggerFactory.getLogger(OrderEventListener.class);

    private final NotificationService notificationService;

    public OrderEventListener(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @EventListener
    public void onOrderStatusChanged(OrderStatusChangedEvent event) {
        log.info("Order {} -> {} : {}", event.getOrderId(), event.getStatus(), event.getMessage());
        notificationService.notifyOrderStatusChange(event.getOrderId(), event.getStatus(), event.getMessage());
    }
}
