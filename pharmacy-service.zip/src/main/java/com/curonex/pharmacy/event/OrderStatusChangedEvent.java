package com.curonex.pharmacy.event;

import com.curonex.pharmacy.enums.OrderStatusEnum;

/**
 * Published on every meaningful order-lifecycle change. A future
 * WebSocket/push-notification layer can subscribe to this without any
 * change to service logic - just add another @EventListener. As of Phase 1
 * this is also how OrderStatusHistoryListener builds the audit trail, so
 * every call site that transitions an order's status should publish this
 * (previousStatus included whenever the caller already has it in hand -
 * pass null only when it genuinely isn't known, e.g. bulk/system events).
 */
public class OrderStatusChangedEvent {

    private final Long orderId;
    private final OrderStatusEnum previousStatus;
    private final OrderStatusEnum status;
    private final String message;

    public OrderStatusChangedEvent(Long orderId, OrderStatusEnum status, String message) {
        this(orderId, null, status, message);
    }

    public OrderStatusChangedEvent(Long orderId, OrderStatusEnum previousStatus, OrderStatusEnum status, String message) {
        this.orderId = orderId;
        this.previousStatus = previousStatus;
        this.status = status;
        this.message = message;
    }

    public Long getOrderId() {
        return orderId;
    }

    public OrderStatusEnum getPreviousStatus() {
        return previousStatus;
    }

    public OrderStatusEnum getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}
