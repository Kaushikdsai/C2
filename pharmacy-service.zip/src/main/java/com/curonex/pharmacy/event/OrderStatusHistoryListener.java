package com.curonex.pharmacy.event;

import java.sql.Timestamp;
import java.time.Instant;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.curonex.pharmacy.entity.OrderStatusHistory;
import com.curonex.pharmacy.repository.OrderStatusHistoryRepository;

/**
 * Builds the order audit trail (item: "order status audit trail table").
 * Deliberately separate from OrderEventListener (which sends
 * notifications) - each listener has exactly one job, and neither can break
 * the other. Every status-changing call in OrderServiceImpl /
 * PharmacyRoutingServiceImpl / DeliveryRoutingServiceImpl already publishes
 * OrderStatusChangedEvent (that publishing was pre-existing, only the
 * previousStatus field is new - see OrderStatusChangedEvent), so this
 * required zero changes to business logic.
 */
@Component
public class OrderStatusHistoryListener {

    private final OrderStatusHistoryRepository orderStatusHistoryRepository;

    public OrderStatusHistoryListener(OrderStatusHistoryRepository orderStatusHistoryRepository) {
        this.orderStatusHistoryRepository = orderStatusHistoryRepository;
    }

    @EventListener
    public void onOrderStatusChanged(OrderStatusChangedEvent event) {
        OrderStatusHistory history = new OrderStatusHistory();
        history.setOrderId(event.getOrderId());
        history.setPreviousStatus(event.getPreviousStatus());
        history.setNewStatus(event.getStatus());
        history.setChangedAt(Timestamp.from(Instant.now()));
        history.setNote(event.getMessage());
        orderStatusHistoryRepository.save(history);
    }
}
