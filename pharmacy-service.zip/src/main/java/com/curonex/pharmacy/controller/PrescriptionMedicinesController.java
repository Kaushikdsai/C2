package com.curonex.pharmacy.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curonex.pharmacy.dto.PrescriptionMedicinesDTO;
import com.curonex.pharmacy.service.PrescriptionMedicinesService;

@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionMedicinesController {

    private final PrescriptionMedicinesService prescriptionMedicinesService;

    public PrescriptionMedicinesController(PrescriptionMedicinesService prescriptionMedicinesService) {
        this.prescriptionMedicinesService = prescriptionMedicinesService;
    }

    @PostMapping("/{prescriptionId}/medicines")
    public ResponseEntity<PrescriptionMedicinesDTO> addMedicine(
            @PathVariable Long prescriptionId, @RequestBody PrescriptionMedicinesDTO dto) {
        return ResponseEntity.ok(prescriptionMedicinesService.addMedicine(prescriptionId, dto));
    }

    @GetMapping("/{prescriptionId}/medicines")
    public ResponseEntity<List<PrescriptionMedicinesDTO>> getMedicinesByPrescription(
            @PathVariable Long prescriptionId) {
        return ResponseEntity.ok(prescriptionMedicinesService.getMedicinesByPrescription(prescriptionId));
    }

    @PutMapping("/{prescriptionId}/medicines/{medicineName}")
    public ResponseEntity<PrescriptionMedicinesDTO> updateMedicine(
            @PathVariable Long prescriptionId,
            @PathVariable String medicineName,
            @RequestBody PrescriptionMedicinesDTO dto) {
        return ResponseEntity.ok(prescriptionMedicinesService.updateMedicine(prescriptionId, medicineName, dto));
    }

    @DeleteMapping("/{prescriptionId}/medicines/{medicineName}")
    public ResponseEntity<Void> deleteMedicine(@PathVariable Long prescriptionId, @PathVariable String medicineName) {
        prescriptionMedicinesService.deleteMedicine(prescriptionId, medicineName);
        return ResponseEntity.noContent().build();
    }
}
