package com.curonex.pharmacy.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;

@RestController
@RequestMapping("/api/users")
public class UserDetailsController {

    private final DetailsFeignClient detailsFeignClient;

    public UserDetailsController(DetailsFeignClient detailsFeignClient) {
        this.detailsFeignClient = detailsFeignClient;
    }

    /**
     * Thin passthrough to the separate details-service, for the one case
     * the frontend genuinely needs it directly - patient details on Order
     * Preview. Returns whatever the details-service has for this userId,
     * including null fields if that service has no record at all.
     */
    @GetMapping("/{userId}/details")
    public DetailsDTO getUserDetails(@PathVariable Long userId) {
        try {
            return detailsFeignClient.getDetails(userId);
        } catch (Exception ex) {
            return null;
        }
    }
}

