package com.curonex.pharmacy.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.curonex.pharmacy.dto.PrescriptionExtractionResponseDTO;
import com.curonex.pharmacy.service.PrescriptionExtractionService;

@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionExtractionController {

    private final PrescriptionExtractionService prescriptionExtractionService;

    public PrescriptionExtractionController(PrescriptionExtractionService prescriptionExtractionService) {
        this.prescriptionExtractionService = prescriptionExtractionService;
    }

    /** pharmacy_home.html "Upload Prescription" flow. */
    @PostMapping(value = "/extract", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PrescriptionExtractionResponseDTO> extractPrescription(
            @RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(prescriptionExtractionService.extractMedicines(file));
    }
}