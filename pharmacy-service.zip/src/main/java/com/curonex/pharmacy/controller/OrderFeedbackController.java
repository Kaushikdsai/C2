package com.curonex.pharmacy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curonex.pharmacy.dto.OrderFeedbackRequestDTO;
import com.curonex.pharmacy.dto.OrderFeedbackResponseDTO;
import com.curonex.pharmacy.service.OrderFeedbackService;

@RestController
public class OrderFeedbackController {

    private final OrderFeedbackService orderFeedbackService;

    public OrderFeedbackController(OrderFeedbackService orderFeedbackService) {
        this.orderFeedbackService = orderFeedbackService;
    }

    /** The one combined feedback page, shown to the patient after successful delivery. */
    @PostMapping("/api/orders/{orderId}/feedback")
    public ResponseEntity<OrderFeedbackResponseDTO> submitFeedback(
            @PathVariable Long orderId,
            @jakarta.validation.Valid @RequestBody OrderFeedbackRequestDTO request) {
        return new ResponseEntity<>(orderFeedbackService.submitFeedback(orderId, request), HttpStatus.CREATED);
    }

    @GetMapping("/api/orders/{orderId}/feedback")
    public ResponseEntity<OrderFeedbackResponseDTO> getFeedbackForOrder(@PathVariable Long orderId) {
        return ResponseEntity.ok(orderFeedbackService.getFeedbackForOrder(orderId));
    }

    /** Pharmacy admin portal: reviews/ratings left for this pharmacy. */
    @GetMapping("/api/pharmacies/{pharmacyId}/feedback")
    public ResponseEntity<List<OrderFeedbackResponseDTO>> getFeedbackForPharmacy(@PathVariable Long pharmacyId) {
        return ResponseEntity.ok(orderFeedbackService.getFeedbackForPharmacy(pharmacyId));
    }

    /** Delivery partner portal: reviews/ratings left for this partner. */
    @GetMapping("/api/delivery-partners/{deliveryPartnerId}/feedback")
    public ResponseEntity<List<OrderFeedbackResponseDTO>> getFeedbackForDeliveryPartner(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(orderFeedbackService.getFeedbackForDeliveryPartner(deliveryPartnerId));
    }
}
