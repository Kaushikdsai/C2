package com.curonex.pharmacy.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.curonex.pharmacy.dto.PrescriptionVerificationResultDTO;
import com.curonex.pharmacy.service.PrescriptionVerificationService;

/**
 * Hospital-verified prescription upload. This is a SEPARATE endpoint from
 * the existing POST /api/prescriptions/extract (PrescriptionExtractionController)
 * - that one extracts medicines unconditionally with no signature check at
 * all. Point your "Upload Prescription" UI at THIS endpoint if you want
 * verification to gate extraction; the old /extract endpoint is left
 * untouched for backward compatibility with anything already using it.
 *
 * The response's `status` field is always one of VERIFIED / INVALID /
 * MANUAL_REVIEW - never an HTTP error for a prescription that simply fails
 * verification (only a genuinely malformed upload, e.g. not a PDF, is a
 * 400).
 */
@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionVerificationController {

    private final PrescriptionVerificationService prescriptionVerificationService;

    public PrescriptionVerificationController(PrescriptionVerificationService prescriptionVerificationService) {
        this.prescriptionVerificationService = prescriptionVerificationService;
    }

    @PostMapping(value = "/verify", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PrescriptionVerificationResultDTO> verify(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(prescriptionVerificationService.verify(file));
    }
}
