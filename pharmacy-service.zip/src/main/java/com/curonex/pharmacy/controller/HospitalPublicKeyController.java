package com.curonex.pharmacy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curonex.pharmacy.dto.HospitalPublicKeyDTO;
import com.curonex.pharmacy.dto.HospitalPublicKeyRegistrationDTO;
import com.curonex.pharmacy.service.HospitalPublicKeyService;

/**
 * Admin-only in intent (wire up your existing System Admin auth/role guard
 * on this controller the same way it's applied elsewhere in the gateway -
 * nothing here does its own authorization check). Registers the PUBLIC key
 * a hospital's prescription-generation system uses to sign prescriptions -
 * the private key never appears anywhere near this API.
 */
@RestController
@RequestMapping("/api/hospitals/{hospitalId}/public-keys")
public class HospitalPublicKeyController {

    private final HospitalPublicKeyService hospitalPublicKeyService;

    public HospitalPublicKeyController(HospitalPublicKeyService hospitalPublicKeyService) {
        this.hospitalPublicKeyService = hospitalPublicKeyService;
    }

    @PostMapping
    public ResponseEntity<HospitalPublicKeyDTO> registerKey(
            @PathVariable Long hospitalId,
            @jakarta.validation.Valid @RequestBody HospitalPublicKeyRegistrationDTO request) {
        request.setHospitalId(hospitalId);
        return new ResponseEntity<>(hospitalPublicKeyService.registerKey(request), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<HospitalPublicKeyDTO>> getKeysForHospital(@PathVariable Long hospitalId) {
        return ResponseEntity.ok(hospitalPublicKeyService.getKeysForHospital(hospitalId));
    }

    @DeleteMapping("/{keyVersion}")
    public ResponseEntity<HospitalPublicKeyDTO> deactivateKey(
            @PathVariable Long hospitalId, @PathVariable String keyVersion) {
        return ResponseEntity.ok(hospitalPublicKeyService.deactivateKey(hospitalId, keyVersion));
    }
}
