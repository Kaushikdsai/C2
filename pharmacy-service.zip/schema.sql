-- Run this against your existing Curonex Postgres schema BEFORE starting the
-- application. spring.jpa.hibernate.ddl-auto=validate will refuse to boot if
-- these columns/tables are missing, since the entities now map to them.

-- Orders: geoAddress capture + hospital linkage (priority routing) +
-- per-status timestamps + rating-abuse guards
ALTER TABLE orders ADD COLUMN IF NOT EXISTS patient_geo_address VARCHAR(50);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS hospital_id BIGINT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS confirmed_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS picked_up_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS pharmacy_rated BOOLEAN DEFAULT FALSE;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_partner_rated BOOLEAN DEFAULT FALSE;
-- NOTE: no is_returned / returned_at / return_picked_up_at columns - the
-- return feature was fully removed by design (too complicated to get right
-- for this scope). If it ever needs to come back, treat it as a fresh
-- design, not a resurrection of this earlier attempt.

-- Order Items: medicine catalog removed - the name extracted from the
-- prescription PDF travels directly here instead of a medicine_id lookup.
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS medicine_name VARCHAR(255);
-- If you had an existing medicine_id foreign key/column here, it's no
-- longer used by the application. Safe to drop once confirmed unused:
--   ALTER TABLE order_items DROP COLUMN IF EXISTS medicine_id;

-- Prescription Medicines: same change - medicine_name is now part of the
-- composite primary key (prescription_id, medicine_name) instead of
-- (prescription_id, medicine_id).
ALTER TABLE prescription_medicines ADD COLUMN IF NOT EXISTS medicine_name VARCHAR(255);
-- Once migrated and confirmed, update the primary key and drop medicine_id:
--   ALTER TABLE prescription_medicines DROP CONSTRAINT IF EXISTS prescription_medicines_pkey;
--   ALTER TABLE prescription_medicines ADD PRIMARY KEY (prescription_id, medicine_name);
--   ALTER TABLE prescription_medicines DROP COLUMN IF EXISTS medicine_id;

-- The medicine table itself is no longer referenced by this application at
-- all. Safe to drop once confirmed no other Curonex module depends on it:
--   DROP TABLE IF EXISTS medicine;

-- Pharmacy: ratings + soft delete
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS rating NUMERIC(3,2) DEFAULT 0;
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Delivery Partners: ratings + soft delete
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS rating NUMERIC(3,2) DEFAULT 0;
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Prescriptions: soft delete (medical records, never hard-deleted)
ALTER TABLE prescriptions ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Tracks which pharmacies declined which orders. Many-to-many by nature -
-- one order can be rejected by several pharmacies; one pharmacy can reject
-- many orders.
CREATE TABLE IF NOT EXISTS order_pharmacy_rejection (
    order_id BIGINT NOT NULL,
    pharmacy_id BIGINT NOT NULL,
    rejected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (order_id, pharmacy_id)
);

-- Same as above, delivery-partner side. Mirrors the pharmacy rejection
-- table exactly.
CREATE TABLE IF NOT EXISTS order_delivery_partner_rejection (
    order_id BIGINT NOT NULL,
    delivery_partner_id BIGINT NOT NULL,
    rejected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (order_id, delivery_partner_id)
);

-- Backfill: existing rows must not be left NULL for boolean flags, since
-- the entities read them as non-null Boolean and downstream filtering
-- (findByIsDeletedFalse) treats NULL as neither true nor false in SQL.
UPDATE pharmacy SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE delivery_partners SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE prescriptions SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE orders SET pharmacy_rated = FALSE WHERE pharmacy_rated IS NULL;
UPDATE orders SET delivery_partner_rated = FALSE WHERE delivery_partner_rated IS NULL;

-- If you previously ran an earlier version of this schema.sql that added
-- is_returned / returned_at / return_picked_up_at, they're no longer used
-- by the application. Safe to drop once you've confirmed nothing else
-- depends on them:
--   ALTER TABLE orders DROP COLUMN IF EXISTS is_returned;
--   ALTER TABLE orders DROP COLUMN IF EXISTS returned_at;
--   ALTER TABLE orders DROP COLUMN IF EXISTS return_picked_up_at;

-- ============================================================================
-- Below: pharmacy + delivery module upgrade (relationships/patient details/
-- feedback/QR verification). Run this section BEFORE starting the app with
-- the updated entities - ddl-auto=validate means it will refuse to boot
-- otherwise.
-- ============================================================================

-- Prescription Medicines: split the quantity ceiling (immutable) from the
-- patient's editable selection. Fixes the bug where decreasing quantity on
-- the preview page permanently lowered the prescribed ceiling itself, so a
-- patient could never raise it back up.
ALTER TABLE prescription_medicines RENAME COLUMN quantity TO prescribed_quantity;
ALTER TABLE prescription_medicines ADD COLUMN IF NOT EXISTS selected_quantity INTEGER;
UPDATE prescription_medicines SET selected_quantity = prescribed_quantity WHERE selected_quantity IS NULL;
ALTER TABLE prescription_medicines ALTER COLUMN selected_quantity SET NOT NULL;

-- Prescriptions: who the prescription is FOR (may differ from who uploaded
-- it - family ordering, e.g. a son uploading his mother's prescription).
ALTER TABLE prescriptions ADD COLUMN IF NOT EXISTS patient_user_id BIGINT;
ALTER TABLE prescriptions ADD COLUMN IF NOT EXISTS patient_name VARCHAR(255);
ALTER TABLE prescriptions ADD COLUMN IF NOT EXISTS patient_age INTEGER;
ALTER TABLE prescriptions ADD COLUMN IF NOT EXISTS patient_phone VARCHAR(20);
ALTER TABLE prescriptions ADD COLUMN IF NOT EXISTS patient_relationship VARCHAR(50);
-- Backfill for existing rows so patient_name/patient_phone are never NULL -
-- there was no family-ordering concept before this migration, so "Self" is
-- the only safe assumption; adjust manually for any records where that's
-- known to be wrong.
UPDATE prescriptions SET patient_relationship = 'Self' WHERE patient_relationship IS NULL;

-- Orders: prescription linkage (previously threaded through at creation
-- time but never persisted) + patient snapshot + fields used by the
-- delivery-note/ETA/price-window/rebroadcast-cap phases.
ALTER TABLE orders ADD COLUMN IF NOT EXISTS prescription_id BIGINT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS patient_user_id BIGINT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS patient_name VARCHAR(255);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS patient_age INTEGER;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS patient_phone VARCHAR(20);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS patient_relationship VARCHAR(50);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS pharmacy_rebroadcast_count INTEGER DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_rebroadcast_count INTEGER DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_note VARCHAR(500);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS estimated_delivery_minutes INTEGER;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS price_confirmation_deadline TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS price_accepted_at TIMESTAMP;
UPDATE orders SET pharmacy_rebroadcast_count = 0 WHERE pharmacy_rebroadcast_count IS NULL;
UPDATE orders SET delivery_rebroadcast_count = 0 WHERE delivery_rebroadcast_count IS NULL;

-- Order status audit trail - append-only, one row per transition, written
-- purely by OrderStatusHistoryListener reacting to the existing
-- OrderStatusChangedEvent (no service writes here directly).
CREATE TABLE IF NOT EXISTS order_status_history (
    history_id      BIGSERIAL PRIMARY KEY,
    order_id        BIGINT NOT NULL REFERENCES orders(order_id),
    previous_status VARCHAR(40),
    new_status      VARCHAR(40) NOT NULL,
    changed_at      TIMESTAMP NOT NULL,
    note            VARCHAR(500)
);
CREATE INDEX IF NOT EXISTS idx_order_status_history_order_id ON order_status_history(order_id);

-- Combined pharmacy + delivery-partner feedback, one row per delivered
-- order (one page, both ratings + both free-text reviews at once).
CREATE TABLE IF NOT EXISTS order_feedback (
    order_id              BIGINT PRIMARY KEY REFERENCES orders(order_id),
    pharmacy_id           BIGINT,
    delivery_partner_id   BIGINT,
    pharmacy_rating       NUMERIC(2,1),
    pharmacy_feedback     VARCHAR(1000),
    delivery_rating       NUMERIC(2,1),
    delivery_feedback     VARCHAR(1000),
    submitted_at          TIMESTAMP NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_order_feedback_pharmacy_id ON order_feedback(pharmacy_id);
CREATE INDEX IF NOT EXISTS idx_order_feedback_delivery_partner_id ON order_feedback(delivery_partner_id);

-- Hospital-verified prescription QR (item 4): registry of each hospital's
-- PUBLIC key only. The matching private key never appears in this schema
-- or anywhere in Curonex - it stays entirely on the hospital's own
-- prescription-generation system.
CREATE TABLE IF NOT EXISTS hospital_public_keys (
    hospital_id       BIGINT NOT NULL,
    key_version       VARCHAR(20) NOT NULL,
    public_key_base64 VARCHAR(2000) NOT NULL,
    algorithm         VARCHAR(50) NOT NULL DEFAULT 'SHA256withRSA',
    active            BOOLEAN NOT NULL DEFAULT TRUE,
    registered_at     TIMESTAMP NOT NULL,
    PRIMARY KEY (hospital_id, key_version)
);

-- Partial pharmacy fulfillment (item 5/7): one row per pharmacy pickup
-- stop on an order. A single-pharmacy order still gets exactly one row
-- (sequence 1) - created uniformly, not just for the partial case - so
-- pickup/OTP tracking never has to special-case "was this ever partial".
CREATE TABLE IF NOT EXISTS order_pharmacy_allocations (
    allocation_id  BIGSERIAL PRIMARY KEY,
    order_id       BIGINT NOT NULL REFERENCES orders(order_id),
    pharmacy_id    BIGINT NOT NULL,
    sequence_no    INTEGER NOT NULL,
    created_at     TIMESTAMP NOT NULL,
    picked_up_at   TIMESTAMP,
    CONSTRAINT uq_order_pharmacy_allocations_order_pharmacy UNIQUE (order_id, pharmacy_id)
);
CREATE INDEX IF NOT EXISTS idx_order_pharmacy_allocations_order_id ON order_pharmacy_allocations(order_id);
CREATE INDEX IF NOT EXISTS idx_order_pharmacy_allocations_pharmacy_id ON order_pharmacy_allocations(pharmacy_id);

-- Which pharmacy stop covers each line item - required once a 2-pharmacy
-- order needs to know which items belong to which pickup.
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS allocation_id BIGINT REFERENCES order_pharmacy_allocations(allocation_id);

-- Indexes the routing/scheduler services hit on every broadcast/rebroadcast
-- cycle - missing these is the single biggest scalability risk once order
-- volume grows past a handful of test rows.
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_pharmacy_id ON orders(pharmacy_id);
CREATE INDEX IF NOT EXISTS idx_orders_delivery_partner_id ON orders(delivery_partner_id);
CREATE INDEX IF NOT EXISTS idx_orders_prescription_id ON orders(prescription_id);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
