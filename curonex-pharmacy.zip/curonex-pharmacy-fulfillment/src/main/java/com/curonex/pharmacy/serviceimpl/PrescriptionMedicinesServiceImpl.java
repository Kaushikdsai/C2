package com.curonex.pharmacy.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.curonex.pharmacy.dto.PrescriptionMedicinesDTO;
import com.curonex.pharmacy.entity.PrescriptionMedicineId;
import com.curonex.pharmacy.entity.PrescriptionMedicines;
import com.curonex.pharmacy.repository.PrescriptionMedicinesRepository;
import com.curonex.pharmacy.service.PrescriptionMedicinesService;

@Service
public class PrescriptionMedicinesServiceImpl implements PrescriptionMedicinesService {

    private final PrescriptionMedicinesRepository prescriptionMedicineRepository;

    public PrescriptionMedicinesServiceImpl(PrescriptionMedicinesRepository prescriptionMedicineRepository) {
        this.prescriptionMedicineRepository = prescriptionMedicineRepository;
    }

    @Override
    public PrescriptionMedicinesDTO addMedicine(Long prescriptionId, PrescriptionMedicinesDTO dto) {
        PrescriptionMedicineId id = new PrescriptionMedicineId(prescriptionId, dto.getMedicineName());

        PrescriptionMedicines medicine = new PrescriptionMedicines();
        medicine.setId(id);
        medicine.setQuantity(dto.getQuantity());

        return convertToDTO(prescriptionMedicineRepository.save(medicine));
    }

    @Override
    public List<PrescriptionMedicinesDTO> getMedicinesByPrescription(Long prescriptionId) {
        return prescriptionMedicineRepository.findByIdPrescriptionId(prescriptionId)
                .stream().map(this::convertToDTO).toList();
    }

    @Override
    public PrescriptionMedicinesDTO updateMedicine(Long prescriptionId, String medicineName, PrescriptionMedicinesDTO dto) {
        PrescriptionMedicineId id = new PrescriptionMedicineId(prescriptionId, medicineName);

        PrescriptionMedicines medicine = prescriptionMedicineRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Medicine not found"));

        medicine.setQuantity(dto.getQuantity());

        return convertToDTO(prescriptionMedicineRepository.save(medicine));
    }

    @Override
    public void deleteMedicine(Long prescriptionId, String medicineName) {
        PrescriptionMedicineId id = new PrescriptionMedicineId(prescriptionId, medicineName);
        prescriptionMedicineRepository.deleteById(id);
    }

    private PrescriptionMedicinesDTO convertToDTO(PrescriptionMedicines medicine) {
        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setPrescriptionId(medicine.getId().getPrescriptionId());
        dto.setMedicineName(medicine.getId().getMedicineName());
        dto.setQuantity(medicine.getQuantity());
        return dto;
    }
}
