package com.curonex.pharmacy.service;

import java.math.BigDecimal;
import java.util.List;

import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyDTO;
import com.curonex.pharmacy.dto.PharmacyDashboardDTO;
import com.curonex.pharmacy.dto.PharmacyProfileDTO;
import com.curonex.pharmacy.enums.OrderStatusEnum;

public interface PharmacyService {

    PharmacyDTO addPharmacy(PharmacyDTO dto);

    PharmacyDTO getPharmacyById(Long id);

    List<PharmacyDTO> getAllPharmacies();

    PharmacyDTO updatePharmacy(Long id, PharmacyDTO dto);

    void deletePharmacy(Long id);

    List<PharmacyDTO> getActivePharmacies();

    PharmacyProfileDTO getPharmacyProfile(Long pharmacyId);

    PharmacyProfileDTO updatePharmacyProfile(Long pharmacyId, PharmacyProfileDTO dto);

    /** orderId ties the rating to a real, DELIVERED, matching, not-already-rated order. */
    PharmacyProfileDTO submitRating(Long pharmacyId, Long orderId, BigDecimal rating);

    PharmacyDashboardDTO getDashboard(Long pharmacyId);

    List<OrderSummaryDTO> getOrdersByStatus(Long pharmacyId, OrderStatusEnum status);

    List<OrderSummaryDTO> getOrderHistory(Long pharmacyId);

    double getDeliverySuccessRate(Long pharmacyId);

    long getOrdersThisMonth(Long pharmacyId);

    /** Atomic accept: fails with OrderConflictException if another pharmacy already claimed it. */
    OrderResponseDTO acceptOrder(Long orderId, Long pharmacyId, PharmacyAcceptRequestDTO request);

    /** This pharmacy declines - order stays open for others. */
    void rejectOrder(Long orderId, Long pharmacyId);

    /** Pharmacy backs out after accepting - order reopens and is rebroadcast. */
    boolean cancelAcceptedOrder(Long orderId, Long pharmacyId);
}
