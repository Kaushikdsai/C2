package com.curonex.pharmacy.serviceimpl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderItemDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptItemDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyDTO;
import com.curonex.pharmacy.dto.PharmacyDashboardDTO;
import com.curonex.pharmacy.dto.PharmacyProfileDTO;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;
import com.curonex.pharmacy.event.OrderStatusChangedEvent;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.exceptions.PharmacyNotFoundException;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import com.curonex.pharmacy.service.PharmacyService;
import com.curonex.pharmacy.entity.OrderPharmacyRejection;
import com.curonex.pharmacy.entity.OrderPharmacyRejectionId;

@Service
public class PharmacyServiceImpl implements PharmacyService {

    private final PharmacyRepository pharmacyRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final PharmacyRoutingService pharmacyRoutingService;
    private final DeliveryRoutingService deliveryRoutingService;
    private final OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;
    private final ApplicationEventPublisher eventPublisher;

    public PharmacyServiceImpl(
            PharmacyRepository pharmacyRepository,
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            DetailsFeignClient detailsFeignClient,
            PharmacyRoutingService pharmacyRoutingService,
            DeliveryRoutingService deliveryRoutingService,
            OrderPharmacyRejectionRepository orderPharmacyRejectionRepository,
            ApplicationEventPublisher eventPublisher) {

        this.pharmacyRepository = pharmacyRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.pharmacyRoutingService = pharmacyRoutingService;
        this.deliveryRoutingService = deliveryRoutingService;
        this.orderPharmacyRejectionRepository = orderPharmacyRejectionRepository;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public PharmacyDTO addPharmacy(PharmacyDTO dto) {
        Pharmacy pharmacy = new Pharmacy();
        BeanUtils.copyProperties(dto, pharmacy);
        pharmacy.setRating(BigDecimal.ZERO);
        pharmacy.setRatingCount(0);
        pharmacy.setIsDeleted(false);
        return toDTO(pharmacyRepository.save(pharmacy));
    }

    @Override
    public PharmacyDTO getPharmacyById(Long id) {
        return toDTO(findPharmacyOrThrow(id));
    }

    @Override
    public List<PharmacyDTO> getAllPharmacies() {
        return pharmacyRepository.findByIsDeletedFalse().stream().map(this::toDTO).toList();
    }

    @Override
    public PharmacyDTO updatePharmacy(Long id, PharmacyDTO dto) {
        Pharmacy pharmacy = findPharmacyOrThrow(id);
        pharmacy.setLicenseNo(dto.getLicenseNo());
        pharmacy.setGeoAddress(dto.getGeoAddress());
        pharmacy.setStatus(dto.getStatus());
        pharmacy.setHospitalId(dto.getHospitalId());
        return toDTO(pharmacyRepository.save(pharmacy));
    }

    /**
     * Soft delete only. Pharmacies are referenced by historical orders
     * (orders.pharmacy_id), so a hard delete would orphan every past order's
     * ability to show who fulfilled it.
     */
    @Override
    @Transactional
    public void deletePharmacy(Long id) {
        Pharmacy pharmacy = findPharmacyOrThrow(id);
        pharmacy.setIsDeleted(true);
        pharmacyRepository.save(pharmacy);
    }

    @Override
    public List<PharmacyDTO> getActivePharmacies() {
        return pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE)
                .stream().map(this::toDTO).toList();
    }

    @Override
    public PharmacyProfileDTO getPharmacyProfile(Long pharmacyId) {
        Pharmacy pharmacy = findPharmacyOrThrow(pharmacyId);
        PharmacyProfileDTO dto = new PharmacyProfileDTO();
        dto.setPharmacyId(pharmacy.getId());
        dto.setLicenseNo(pharmacy.getLicenseNo());
        dto.setGeoAddress(pharmacy.getGeoAddress());
        dto.setStatus(pharmacy.getStatus());
        dto.setHospitalId(pharmacy.getHospitalId());
        dto.setRating(pharmacy.getRating());
        dto.setRatingCount(pharmacy.getRatingCount());

        DetailsDTO details = detailsFeignClient.getDetails(pharmacyId);
        if (details != null) {
            dto.setName(details.getName());
            dto.setEmail(details.getEmail());
            dto.setPhone(details.getPhone());
            dto.setAddress(details.getAddress());
            dto.setPincode(details.getPincode());
            dto.setCity(details.getCity());
            dto.setState(details.getState());
        }
        return dto;
    }

    @Override
    public PharmacyProfileDTO updatePharmacyProfile(Long pharmacyId, PharmacyProfileDTO dto) {
        Pharmacy pharmacy = findPharmacyOrThrow(pharmacyId);
        pharmacy.setLicenseNo(dto.getLicenseNo());
        pharmacy.setGeoAddress(dto.getGeoAddress());
        pharmacyRepository.save(pharmacy);

        DetailsDTO detailsUpdate = new DetailsDTO();
        detailsUpdate.setId(pharmacyId);
        detailsUpdate.setName(dto.getName());
        detailsUpdate.setEmail(dto.getEmail());
        detailsUpdate.setPhone(dto.getPhone());
        detailsUpdate.setAddress(dto.getAddress());
        detailsUpdate.setPincode(dto.getPincode());
        detailsUpdate.setCity(dto.getCity());
        detailsUpdate.setState(dto.getState());
        detailsFeignClient.updateDetails(pharmacyId, detailsUpdate);

        return getPharmacyProfile(pharmacyId);
    }

    /**
     * Rating is now tied to a real completed order (orderId on the
     * request), not just a free-floating number. Validates: the order
     * exists, is DELIVERED, actually belongs to this pharmacy, and hasn't
     * already been rated - closes the earlier gap where any caller could
     * submit any rating with no connection to a real transaction, repeatedly.
     */
    @Override
    @Transactional
    public PharmacyProfileDTO submitRating(Long pharmacyId, Long orderId, BigDecimal rating) {
        Pharmacy pharmacy = findPharmacyOrThrow(pharmacyId);

        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));

        if (order.getStatus() != OrderStatusEnum.DELIVERED) {
            throw new OrderConflictException("Order must be DELIVERED before it can be rated.");
        }
        if (order.getPharmacyId() == null || !order.getPharmacyId().equals(pharmacyId)) {
            throw new OrderConflictException("Order " + orderId + " was not fulfilled by pharmacy " + pharmacyId);
        }
        if (Boolean.TRUE.equals(order.getPharmacyRated())) {
            throw new OrderConflictException("Order " + orderId + " has already been rated for this pharmacy.");
        }

        int previousCount = pharmacy.getRatingCount() != null ? pharmacy.getRatingCount() : 0;
        BigDecimal previousAverage = pharmacy.getRating() != null ? pharmacy.getRating() : BigDecimal.ZERO;

        BigDecimal newCount = BigDecimal.valueOf(previousCount + 1);
        BigDecimal newAverage = previousAverage.multiply(BigDecimal.valueOf(previousCount))
                .add(rating)
                .divide(newCount, 2, RoundingMode.HALF_UP);

        pharmacy.setRating(newAverage);
        pharmacy.setRatingCount(previousCount + 1);
        pharmacyRepository.save(pharmacy);

        order.setPharmacyRated(true);
        orderRepository.save(order);

        return getPharmacyProfile(pharmacyId);
    }

    @Override
    public PharmacyDashboardDTO getDashboard(Long pharmacyId) {
        List<Orders> pharmacyOrders = orderRepository.findByPharmacyId(pharmacyId);

        PharmacyDashboardDTO dto = new PharmacyDashboardDTO();
        dto.setNewOrders(pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.CONFIRMED && o.getDeliveryPartnerId() == null)
                .count());
        dto.setProcessingOrders(pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.CONFIRMED || o.getStatus() == OrderStatusEnum.OUT_FOR_DELIVERY)
                .count());

        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        long todaysDeliveries = pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED)
                .filter(o -> o.getDeliveredAt() != null
                        && o.getDeliveredAt().toLocalDateTime().toLocalDate().equals(today))
                .count();
        dto.setTodaysDeliveries(todaysDeliveries);

        BigDecimal todaysRevenue = pharmacyOrders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED)
                .filter(o -> o.getDeliveredAt() != null
                        && o.getDeliveredAt().toLocalDateTime().toLocalDate().equals(today))
                .map(Orders::getTotalAmount)
                .filter(java.util.Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        dto.setTodaysRevenue(todaysRevenue);

        return dto;
    }

    @Override
    public List<OrderSummaryDTO> getOrdersByStatus(Long pharmacyId, OrderStatusEnum status) {
        return orderRepository.findByPharmacyIdAndStatus(pharmacyId, status).stream()
                .map(this::toSummaryDTO)
                .toList();
    }

    @Override
    public List<OrderSummaryDTO> getOrderHistory(Long pharmacyId) {
        return orderRepository.findByPharmacyId(pharmacyId).stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED || o.getStatus() == OrderStatusEnum.CANCELLED)
                .map(this::toSummaryDTO)
                .toList();
    }

    @Override
    public double getDeliverySuccessRate(Long pharmacyId) {
        List<Orders> orders = orderRepository.findByPharmacyId(pharmacyId);
        long total = orders.stream()
                .filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED || o.getStatus() == OrderStatusEnum.CANCELLED)
                .count();
        if (total == 0) {
            return 0.0;
        }
        long delivered = orders.stream().filter(o -> o.getStatus() == OrderStatusEnum.DELIVERED).count();
        return (delivered * 100.0) / total;
    }

    @Override
    public long getOrdersThisMonth(Long pharmacyId) {
        LocalDate firstOfMonth = LocalDate.now(ZoneId.systemDefault()).with(TemporalAdjusters.firstDayOfMonth());
        return orderRepository.findByPharmacyId(pharmacyId).stream()
                .filter(o -> o.getOrderDatetime() != null
                        && !o.getOrderDatetime().toLocalDateTime().toLocalDate().isBefore(firstOfMonth))
                .count();
    }

    @Override
    @Transactional
    public OrderResponseDTO acceptOrder(Long orderId, Long pharmacyId, PharmacyAcceptRequestDTO request) {

        List<OrderItem> items = orderItemRepository.findByOrderId(orderId);
        if (items.isEmpty()) {
            throw new OrderNotFoundException("No items found for order id: " + orderId);
        }

        // Enforce the hospital-priority window HERE, not just in the
        // "available orders" listing - a pharmacy that already knows the
        // orderId could otherwise call this endpoint directly and bypass
        // the window entirely. Throws OrderConflictException if this
        // pharmacy isn't allowed to accept yet.
        Orders orderForPriorityCheck = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
        pharmacyRoutingService.assertPharmacyCanAcceptOrder(orderForPriorityCheck, pharmacyId);

        Map<String, BigDecimal> priceByMedicineName = request.getItemPrices().stream()
                .collect(Collectors.toMap(
                        p -> normalize(p.getMedicineName()), PharmacyAcceptItemDTO::getPrice));

        BigDecimal totalAmount = BigDecimal.ZERO;
        for (OrderItem item : items) {
            BigDecimal price = priceByMedicineName.get(normalize(item.getMedicineName()));
            if (price == null) {
                throw new IllegalArgumentException("Missing price for medicine: " + item.getMedicineName());
            }
            totalAmount = totalAmount.add(price.multiply(BigDecimal.valueOf(item.getQuantity())));
        }

        // Atomic compare-and-swap: only the FIRST pharmacy whose UPDATE actually
        // matches "pharmacyId IS NULL AND status = PENDING" wins.
        int rowsAffected = orderRepository.acceptOrderByPharmacy(
                orderId, pharmacyId, totalAmount, OrderStatusEnum.CONFIRMED, OrderStatusEnum.PENDING);

        if (rowsAffected == 0) {
            throw new OrderConflictException("Order has already been accepted by another pharmacy or is not pending.");
        }

        for (OrderItem item : items) {
            item.setPrice(priceByMedicineName.get(normalize(item.getMedicineName())));
            orderItemRepository.save(item);
        }

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.CONFIRMED, "Order accepted by pharmacy " + pharmacyId));

        deliveryRoutingService.broadcastOrder(orderId);

        Orders updated = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
        return toResponseDTO(updated, items);
    }

    @Override
    @Transactional
    public void rejectOrder(Long orderId, Long pharmacyId) {
        // Persisted (order_pharmacy_rejection table). Deliberately NOT
        // publishing an event/email here - with every nearby pharmacy
        // broadcast the same order at once, one declining isn't real news
        // to the patient (someone else may still accept); a "pharmacy
        // declined" email would be noise or actively alarming for no reason.
        OrderPharmacyRejectionId id = new OrderPharmacyRejectionId(orderId, pharmacyId);
        if (!orderPharmacyRejectionRepository.existsById(id)) {
            orderPharmacyRejectionRepository.save(
                    new OrderPharmacyRejection(id, java.sql.Timestamp.from(java.time.Instant.now())));
        }
    }

    @Override
    @Transactional
    public boolean cancelAcceptedOrder(Long orderId, Long pharmacyId) {
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));

        if (order.getPharmacyId() == null || !order.getPharmacyId().equals(pharmacyId)) {
            throw new OrderConflictException("Order is not currently held by pharmacy " + pharmacyId);
        }
        if (order.getStatus() != OrderStatusEnum.CONFIRMED || order.getDeliveryPartnerId() != null) {
            throw new OrderConflictException("Order can only be cancelled before a delivery partner is assigned.");
        }

        order.setPharmacyId(null);
        order.setStatus(OrderStatusEnum.PENDING);
        order.setTotalAmount(null);
        order.setConfirmedAt(null);
        orderRepository.save(order);

        for (OrderItem item : orderItemRepository.findByOrderId(orderId)) {
            item.setPrice(null);
            orderItemRepository.save(item);
        }

        // Deliberately NOT publishing an event here either - a pharmacy
        // backing out and the order reopening is a normal operational
        // fluctuation, not news worth emailing the patient about, same
        // reasoning as rejectOrder() above.
        pharmacyRoutingService.rebroadcastOrder(orderId);

        return true;
    }

    private String normalize(String medicineName) {
        return medicineName == null ? null : medicineName.trim().toLowerCase();
    }

    private Pharmacy findPharmacyOrThrow(Long id) {
        return pharmacyRepository.findById(id)
                .orElseThrow(() -> new PharmacyNotFoundException("Pharmacy not found with id: " + id));
    }

    private PharmacyDTO toDTO(Pharmacy pharmacy) {
        PharmacyDTO dto = new PharmacyDTO();
        BeanUtils.copyProperties(pharmacy, dto);
        return dto;
    }

    private OrderSummaryDTO toSummaryDTO(Orders order) {
        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());

        OrderSummaryDTO dto = new OrderSummaryDTO();
        dto.setOrderId(order.getOrderId());
        dto.setItemCount(items.size());
        dto.setMedicinesSummary(items.stream().map(OrderItem::getMedicineName).collect(Collectors.joining(", ")));
        dto.setTotalAmount(order.getTotalAmount());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());

        DetailsDTO patientDetails = safeFetchDetails(order.getUserId());
        dto.setPatientName(patientDetails != null ? patientDetails.getName() : null);
        return dto;
    }

    private OrderResponseDTO toResponseDTO(Orders order, List<OrderItem> items) {
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderId(order.getOrderId());
        dto.setPharmacyId(order.getPharmacyId());
        dto.setDeliveryPartnerId(order.getDeliveryPartnerId());
        dto.setUserId(order.getUserId());
        dto.setHospitalId(order.getHospitalId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());
        dto.setCancelledAt(order.getCancelledAt());

        List<OrderItemDTO> itemDTOs = items.stream().map(item -> {
            OrderItemDTO itemDTO = new OrderItemDTO();
            itemDTO.setItemId(item.getItemId());
            itemDTO.setMedicineName(item.getMedicineName());
            itemDTO.setQuantity(item.getQuantity());
            itemDTO.setPrice(item.getPrice());
            return itemDTO;
        }).toList();

        dto.setItems(itemDTOs);
        return dto;
    }

    private DetailsDTO safeFetchDetails(Long id) {
        try {
            return detailsFeignClient.getDetails(id);
        } catch (Exception ex) {
            return null;
        }
    }
}
