package com.curonex.pharmacy.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.dto.PharmacyAcceptRequestDTO;
import com.curonex.pharmacy.dto.PharmacyDTO;
import com.curonex.pharmacy.dto.PharmacyDashboardDTO;
import com.curonex.pharmacy.dto.PharmacyProfileDTO;
import com.curonex.pharmacy.dto.RatingRequestDTO;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import com.curonex.pharmacy.service.PharmacyService;

@RestController
@RequestMapping("/api/pharmacies")
public class PharmacyController {

    private final PharmacyService service;
    private final PharmacyRoutingService pharmacyRoutingService;

    public PharmacyController(PharmacyService service, PharmacyRoutingService pharmacyRoutingService) {
        this.service = service;
        this.pharmacyRoutingService = pharmacyRoutingService;
    }

    /*
     * Pharmacy CRUD
     */

    @PostMapping
    public ResponseEntity<PharmacyDTO> addPharmacy(@RequestBody PharmacyDTO dto) {
        return ResponseEntity.ok(service.addPharmacy(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<PharmacyDTO> getPharmacyById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getPharmacyById(id));
    }

    @GetMapping
    public ResponseEntity<List<PharmacyDTO>> getAllPharmacies() {
        return ResponseEntity.ok(service.getAllPharmacies());
    }

    @PutMapping("/{id}")
    public ResponseEntity<PharmacyDTO> updatePharmacy(@PathVariable Long id, @RequestBody PharmacyDTO dto) {
        return ResponseEntity.ok(service.updatePharmacy(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePharmacy(@PathVariable Long id) {
        service.deletePharmacy(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/active")
    public ResponseEntity<List<PharmacyDTO>> getActivePharmacies() {
        return ResponseEntity.ok(service.getActivePharmacies());
    }

    /*
     * Pharmacy Profile (pharmacy_admin.html "Pharmacy Profile" tab)
     */

    @GetMapping("/{pharmacyId}/profile")
    public ResponseEntity<PharmacyProfileDTO> getProfile(@PathVariable Long pharmacyId) {
        return ResponseEntity.ok(service.getPharmacyProfile(pharmacyId));
    }

    @PutMapping("/{pharmacyId}/profile")
    public ResponseEntity<PharmacyProfileDTO> updateProfile(
            @PathVariable Long pharmacyId, @RequestBody PharmacyProfileDTO dto) {
        return ResponseEntity.ok(service.updatePharmacyProfile(pharmacyId, dto));
    }

    /** Called after a delivered order, from the patient side, to rate the pharmacy. Request carries orderId for validation. */
    @PutMapping("/{pharmacyId}/rating")
    public ResponseEntity<PharmacyProfileDTO> submitRating(
            @PathVariable Long pharmacyId,
            @jakarta.validation.Valid @RequestBody RatingRequestDTO request) {
        return ResponseEntity.ok(service.submitRating(pharmacyId, request.getOrderId(), request.getRating()));
    }

    /*
     * Dashboard (pharmacy_admin.html "Pharmacy Dashboard" tab)
     */

    @GetMapping("/{pharmacyId}/dashboard")
    public ResponseEntity<PharmacyDashboardDTO> getDashboard(@PathVariable Long pharmacyId) {
        return ResponseEntity.ok(service.getDashboard(pharmacyId));
    }

    /*
     * Medicine Orders tab - filterable by status (New / Completed / Cancelled)
     */

    @GetMapping("/{pharmacyId}/orders")
    public ResponseEntity<List<OrderSummaryDTO>> getOrdersByStatus(
            @PathVariable Long pharmacyId, @RequestParam OrderStatusEnum status) {
        return ResponseEntity.ok(service.getOrdersByStatus(pharmacyId, status));
    }

    /** Orders broadcast to this pharmacy that no one has accepted yet. */
    @GetMapping("/{pharmacyId}/orders/available")
    public ResponseEntity<List<OrderSummaryDTO>> getAvailableOrders(@PathVariable Long pharmacyId) {
        return ResponseEntity.ok(pharmacyRoutingService.getAvailableOrdersForPharmacy(pharmacyId));
    }

    /*
     * Order History tab
     */

    @GetMapping("/{pharmacyId}/orders/history")
    public ResponseEntity<List<OrderSummaryDTO>> getOrderHistory(@PathVariable Long pharmacyId) {
        return ResponseEntity.ok(service.getOrderHistory(pharmacyId));
    }

    /*
     * Reports & Analytics tab
     */

    @GetMapping("/{pharmacyId}/reports/success-rate")
    public ResponseEntity<Double> getDeliverySuccessRate(@PathVariable Long pharmacyId) {
        return ResponseEntity.ok(service.getDeliverySuccessRate(pharmacyId));
    }

    @GetMapping("/{pharmacyId}/reports/orders-this-month")
    public ResponseEntity<Long> getOrdersThisMonth(@PathVariable Long pharmacyId) {
        return ResponseEntity.ok(service.getOrdersThisMonth(pharmacyId));
    }

    /*
     * Order lifecycle actions
     */

    /** Accept requires per-medicine pricing since prescriptions only carry name+qty. */
    @PutMapping("/orders/{orderId}/accept/{pharmacyId}")
    public ResponseEntity<OrderResponseDTO> acceptOrder(
            @PathVariable Long orderId,
            @PathVariable Long pharmacyId,
            @jakarta.validation.Valid @RequestBody PharmacyAcceptRequestDTO request) {
        return ResponseEntity.ok(service.acceptOrder(orderId, pharmacyId, request));
    }

    @PutMapping("/orders/{orderId}/reject/{pharmacyId}")
    public ResponseEntity<String> rejectOrder(@PathVariable Long orderId, @PathVariable Long pharmacyId) {
        service.rejectOrder(orderId, pharmacyId);
        return ResponseEntity.ok("Order declined");
    }

    @PutMapping("/orders/{orderId}/cancel/{pharmacyId}")
    public ResponseEntity<Boolean> cancelAcceptedOrder(@PathVariable Long orderId, @PathVariable Long pharmacyId) {
        return ResponseEntity.ok(service.cancelAcceptedOrder(orderId, pharmacyId));
    }
}
