package com.curonex.pharmacy.serviceimpl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderCreateItemDTO;
import com.curonex.pharmacy.dto.OrderCreateRequestDTO;
import com.curonex.pharmacy.dto.OrderItemDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderTrackingDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.PrescriptionMedicines;
import com.curonex.pharmacy.entity.Prescriptions;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.event.OrderStatusChangedEvent;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.exceptions.PrescriptionNotFoundException;
import com.curonex.pharmacy.exceptions.PrescriptionQuantityExceededException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.OrderDeliveryPartnerRejectionRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.repository.PrescriptionMedicinesRepository;
import com.curonex.pharmacy.repository.PrescriptionsRepository;
import com.curonex.pharmacy.service.OrderService;
import com.curonex.pharmacy.service.PharmacyRoutingService;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final PharmacyRepository pharmacyRepository;
    private final DeliveryPartnerRepository deliveryPartnerRepository;
    private final PrescriptionsRepository prescriptionsRepository;
    private final PrescriptionMedicinesRepository prescriptionMedicinesRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final PharmacyRoutingService pharmacyRoutingService;
    private final OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;
    private final OrderDeliveryPartnerRejectionRepository orderDeliveryPartnerRejectionRepository;
    private final ApplicationEventPublisher eventPublisher;

    public OrderServiceImpl(
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            PharmacyRepository pharmacyRepository,
            DeliveryPartnerRepository deliveryPartnerRepository,
            PrescriptionsRepository prescriptionsRepository,
            PrescriptionMedicinesRepository prescriptionMedicinesRepository,
            DetailsFeignClient detailsFeignClient,
            PharmacyRoutingService pharmacyRoutingService,
            OrderPharmacyRejectionRepository orderPharmacyRejectionRepository,
            OrderDeliveryPartnerRejectionRepository orderDeliveryPartnerRejectionRepository,
            ApplicationEventPublisher eventPublisher) {

        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.pharmacyRepository = pharmacyRepository;
        this.deliveryPartnerRepository = deliveryPartnerRepository;
        this.prescriptionsRepository = prescriptionsRepository;
        this.prescriptionMedicinesRepository = prescriptionMedicinesRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.pharmacyRoutingService = pharmacyRoutingService;
        this.orderPharmacyRejectionRepository = orderPharmacyRejectionRepository;
        this.orderDeliveryPartnerRejectionRepository = orderDeliveryPartnerRejectionRepository;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Comparison-only normalization (trim + lowercase) so "Paracetamol",
     * " paracetamol", and "PARACETAMOL" are treated as the same medicine
     * when checking the prescribed-quantity ceiling. The original text the
     * caller sent is what actually gets stored - this never changes stored
     * data, only how two names are compared.
     */
    private String normalize(String medicineName) {
        return medicineName == null ? null : medicineName.trim().toLowerCase();
    }

    @Override
    @Transactional
    public OrderResponseDTO createOrder(OrderCreateRequestDTO request) {

        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one medicine");
        }

        Prescriptions prescription = prescriptionsRepository.findById(request.getPrescriptionId())
                .orElseThrow(() -> new PrescriptionNotFoundException(
                        "Prescription not found with id: " + request.getPrescriptionId()));

        // Ceiling per medicine name = what was actually prescribed (X). A
        // patient may order less (down to dropping the item entirely) but
        // never more - enforced here server-side, name-matched case/whitespace-insensitively.
        Map<String, Integer> prescribedQuantityByName = new HashMap<>();
        for (PrescriptionMedicines pm : prescriptionMedicinesRepository.findByIdPrescriptionId(request.getPrescriptionId())) {
            prescribedQuantityByName.put(normalize(pm.getId().getMedicineName()), pm.getQuantity());
        }

        for (OrderCreateItemDTO item : request.getItems()) {
            Integer prescribedQuantity = prescribedQuantityByName.get(normalize(item.getMedicineName()));
            if (prescribedQuantity == null) {
                throw new PrescriptionQuantityExceededException(
                        "Medicine \"" + item.getMedicineName() + "\" is not part of prescription " + request.getPrescriptionId());
            }
            if (item.getQuantity() > prescribedQuantity) {
                throw new PrescriptionQuantityExceededException(
                        "Quantity for \"" + item.getMedicineName() + "\" (" + item.getQuantity()
                                + ") exceeds the prescribed amount (" + prescribedQuantity + ")");
            }
        }

        Orders order = new Orders();
        order.setUserId(request.getUserId());
        order.setStatus(OrderStatusEnum.PENDING);
        order.setOrderDatetime(Timestamp.from(Instant.now()));
        order.setPatientGeoAddress(request.getPatientGeoAddress());
        // hospitalId comes from the prescription record, never trusted directly
        // from the client - prevents spoofing hospital-priority.
        order.setHospitalId(prescription.getHospitalId());
        order.setPharmacyRated(false);
        order.setDeliveryPartnerRated(false);
        order = orderRepository.save(order);

        for (OrderCreateItemDTO item : request.getItems()) {
            OrderItem orderItem = new OrderItem(order.getOrderId(), item.getMedicineName(), item.getQuantity(), null);
            orderItemRepository.save(orderItem);
        }

        pharmacyRoutingService.broadcastOrder(order.getOrderId(), request.getPatientGeoAddress());

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                order.getOrderId(), OrderStatusEnum.PENDING, "Order created and broadcast to nearby pharmacies"));

        return toResponseDTO(order);
    }

    @Override
    public OrderResponseDTO getOrderById(Long orderId) {
        return toResponseDTO(findOrderOrThrow(orderId));
    }

    @Override
    public List<OrderResponseDTO> getOrdersByUser(Long userId) {
        return orderRepository.findByUserId(userId).stream().map(this::toResponseDTO).toList();
    }

    @Override
    public List<OrderResponseDTO> getAllOrders() {
        return orderRepository.findAll().stream().map(this::toResponseDTO).toList();
    }

    @Override
    public Page<OrderResponseDTO> getAllOrders(Pageable pageable) {
        return orderRepository.findAll(pageable).map(this::toResponseDTO);
    }

    /**
     * Hard delete is intentionally NOT exposed via the controller - orders
     * are financial/audit records. CANCELLED is the correct "soft delete"
     * state for an order (see cancelOrder()). Kept for admin/test tooling
     * only, still cleans up dependent rows correctly if ever invoked.
     */
    @Override
    @Transactional
    public void deleteOrder(Long orderId) {
        Orders order = findOrderOrThrow(orderId);
        orderItemRepository.deleteByOrderId(orderId);
        orderPharmacyRejectionRepository.deleteByIdOrderId(orderId);
        orderDeliveryPartnerRejectionRepository.deleteByIdOrderId(orderId);
        orderRepository.delete(order);
    }

    @Override
    public OrderTrackingDTO getOrderTracking(Long orderId) {
        Orders order = findOrderOrThrow(orderId);
        List<OrderItem> items = orderItemRepository.findByOrderId(orderId);

        OrderTrackingDTO dto = new OrderTrackingDTO();
        dto.setOrderId(order.getOrderId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setItemCount(items.size());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());

        if (order.getPharmacyId() != null) {
            pharmacyRepository.findById(order.getPharmacyId()).ifPresent(pharmacy -> {
                dto.setPharmacyGeoAddress(pharmacy.getGeoAddress());
                DetailsDTO pharmacyDetails = safeFetchDetails(pharmacy.getId());
                dto.setPharmacyName(pharmacyDetails != null ? pharmacyDetails.getName() : null);
            });
        }

        if (order.getDeliveryPartnerId() != null) {
            DeliveryPartners partner = deliveryPartnerRepository.findById(order.getDeliveryPartnerId()).orElse(null);
            if (partner != null) {
                dto.setDeliveryPartnerName(partner.getName());
                dto.setDeliveryPartnerPhone(partner.getMobileNumber());
            }
        }

        return dto;
    }

    @Override
    @Transactional
    public OrderResponseDTO cancelOrder(Long orderId) {
        int rowsAffected = orderRepository.cancelOrder(orderId, OrderStatusEnum.CANCELLED, OrderStatusEnum.DELIVERED);
        if (rowsAffected == 0) {
            throw new OrderConflictException("Order cannot be cancelled - it is already delivered or already cancelled.");
        }

        // A fully cancelled order is done - clear any rejection history for
        // it (both pharmacy and delivery-partner side) so it doesn't linger
        // pointlessly in either table.
        orderPharmacyRejectionRepository.deleteByIdOrderId(orderId);
        orderDeliveryPartnerRejectionRepository.deleteByIdOrderId(orderId);

        eventPublisher.publishEvent(new OrderStatusChangedEvent(
                orderId, OrderStatusEnum.CANCELLED, "Order cancelled"));

        return toResponseDTO(findOrderOrThrow(orderId));
    }

    private DetailsDTO safeFetchDetails(Long id) {
        try {
            return detailsFeignClient.getDetails(id);
        } catch (Exception ex) {
            return null;
        }
    }

    private Orders findOrderOrThrow(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
    }

    private OrderResponseDTO toResponseDTO(Orders order) {
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderId(order.getOrderId());
        dto.setPharmacyId(order.getPharmacyId());
        dto.setDeliveryPartnerId(order.getDeliveryPartnerId());
        dto.setUserId(order.getUserId());
        dto.setHospitalId(order.getHospitalId());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setConfirmedAt(order.getConfirmedAt());
        dto.setPickedUpAt(order.getPickedUpAt());
        dto.setDeliveredAt(order.getDeliveredAt());
        dto.setCancelledAt(order.getCancelledAt());

        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
        List<OrderItemDTO> itemDTOs = items.stream().map(item -> {
            OrderItemDTO itemDTO = new OrderItemDTO();
            itemDTO.setItemId(item.getItemId());
            itemDTO.setMedicineName(item.getMedicineName());
            itemDTO.setQuantity(item.getQuantity());
            itemDTO.setPrice(item.getPrice());
            return itemDTO;
        }).toList();

        dto.setItems(itemDTOs);
        return dto;
    }
}
