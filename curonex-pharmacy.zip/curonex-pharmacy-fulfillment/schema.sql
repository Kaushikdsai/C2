-- Run this against your existing Curonex Postgres schema BEFORE starting the
-- application. spring.jpa.hibernate.ddl-auto=validate will refuse to boot if
-- these columns/tables are missing, since the entities now map to them.

-- Orders: geoAddress capture + hospital linkage (priority routing) +
-- per-status timestamps + rating-abuse guards
ALTER TABLE orders ADD COLUMN IF NOT EXISTS patient_geo_address VARCHAR(50);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS hospital_id BIGINT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS confirmed_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS picked_up_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS pharmacy_rated BOOLEAN DEFAULT FALSE;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_partner_rated BOOLEAN DEFAULT FALSE;
-- NOTE: no is_returned / returned_at / return_picked_up_at columns - the
-- return feature was fully removed by design (too complicated to get right
-- for this scope). If it ever needs to come back, treat it as a fresh
-- design, not a resurrection of this earlier attempt.

-- Order Items: medicine catalog removed - the name extracted from the
-- prescription PDF travels directly here instead of a medicine_id lookup.
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS medicine_name VARCHAR(255);
-- If you had an existing medicine_id foreign key/column here, it's no
-- longer used by the application. Safe to drop once confirmed unused:
--   ALTER TABLE order_items DROP COLUMN IF EXISTS medicine_id;

-- Prescription Medicines: same change - medicine_name is now part of the
-- composite primary key (prescription_id, medicine_name) instead of
-- (prescription_id, medicine_id).
ALTER TABLE prescription_medicines ADD COLUMN IF NOT EXISTS medicine_name VARCHAR(255);
-- Once migrated and confirmed, update the primary key and drop medicine_id:
--   ALTER TABLE prescription_medicines DROP CONSTRAINT IF EXISTS prescription_medicines_pkey;
--   ALTER TABLE prescription_medicines ADD PRIMARY KEY (prescription_id, medicine_name);
--   ALTER TABLE prescription_medicines DROP COLUMN IF EXISTS medicine_id;

-- The medicine table itself is no longer referenced by this application at
-- all. Safe to drop once confirmed no other Curonex module depends on it:
--   DROP TABLE IF EXISTS medicine;

-- Pharmacy: ratings + soft delete
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS rating NUMERIC(3,2) DEFAULT 0;
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Delivery Partners: ratings + soft delete
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS rating NUMERIC(3,2) DEFAULT 0;
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Prescriptions: soft delete (medical records, never hard-deleted)
ALTER TABLE prescriptions ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Tracks which pharmacies declined which orders. Many-to-many by nature -
-- one order can be rejected by several pharmacies; one pharmacy can reject
-- many orders.
CREATE TABLE IF NOT EXISTS order_pharmacy_rejection (
    order_id BIGINT NOT NULL,
    pharmacy_id BIGINT NOT NULL,
    rejected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (order_id, pharmacy_id)
);

-- Same as above, delivery-partner side. Mirrors the pharmacy rejection
-- table exactly.
CREATE TABLE IF NOT EXISTS order_delivery_partner_rejection (
    order_id BIGINT NOT NULL,
    delivery_partner_id BIGINT NOT NULL,
    rejected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (order_id, delivery_partner_id)
);

-- Backfill: existing rows must not be left NULL for boolean flags, since
-- the entities read them as non-null Boolean and downstream filtering
-- (findByIsDeletedFalse) treats NULL as neither true nor false in SQL.
UPDATE pharmacy SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE delivery_partners SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE prescriptions SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE orders SET pharmacy_rated = FALSE WHERE pharmacy_rated IS NULL;
UPDATE orders SET delivery_partner_rated = FALSE WHERE delivery_partner_rated IS NULL;

-- If you previously ran an earlier version of this schema.sql that added
-- is_returned / returned_at / return_picked_up_at, they're no longer used
-- by the application. Safe to drop once you've confirmed nothing else
-- depends on them:
--   ALTER TABLE orders DROP COLUMN IF EXISTS is_returned;
--   ALTER TABLE orders DROP COLUMN IF EXISTS returned_at;
--   ALTER TABLE orders DROP COLUMN IF EXISTS return_picked_up_at;
