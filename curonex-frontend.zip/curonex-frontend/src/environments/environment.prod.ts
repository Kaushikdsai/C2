export const environment = {
  production: true,
  apiBaseUrl: 'https://api.curonex.example.com'
};
