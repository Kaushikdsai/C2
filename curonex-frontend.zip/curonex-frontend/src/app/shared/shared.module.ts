import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { ToastComponent } from './components/toast/toast.component';
import { LoaderComponent } from './loader/loader.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ClickOutsideDirective } from './directives/click-outside.directive';

@NgModule({
  declarations: [ToastComponent, LoaderComponent, NavbarComponent, ClickOutsideDirective],
  imports: [CommonModule, FormsModule, RouterModule],
  exports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ToastComponent,
    LoaderComponent,
    NavbarComponent,
    ClickOutsideDirective
  ]
})
export class SharedModule {}
