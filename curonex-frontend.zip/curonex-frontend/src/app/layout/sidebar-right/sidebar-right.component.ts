import { Component, Input } from '@angular/core';
import { SideCard } from '../../core/models/side-card.model';

@Component({
  selector: 'app-sidebar-right',
  templateUrl: './sidebar-right.component.html',
  styleUrls: ['./sidebar-right.component.scss']
})
export class SidebarRightComponent {
  @Input() cards: SideCard[] = [];
}
