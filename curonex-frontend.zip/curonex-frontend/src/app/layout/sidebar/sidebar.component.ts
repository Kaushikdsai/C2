import { Component, Input } from '@angular/core';
import { NavItem } from '../../core/models/nav-item.model';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  @Input() variant: 'simple' | 'card' = 'card';
  @Input() items: NavItem[] = [];
  @Input() showHelp = true;
  @Input() supportRoute = '/support';
}
