import { Component, Input } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';

interface Notification {
  title: string;
  desc: string;
  time: string;
}

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  @Input() userName = 'Kaushik T';
  @Input() notificationCount = 2;
  @Input() notifications: Notification[] = [
    { title: 'Order Delivered', desc: 'Order #MC5247891 has been delivered.', time: '2h ago' },
    { title: 'Prescription Approved', desc: 'Your uploaded prescription was verified.', time: '5h ago' }
  ];
  @Input() profileRoute = '/user/profile';
  @Input() logoutRoute = '/login';

  notifOpen = false;
  userMenuOpen = false;

  constructor(private auth: AuthService, private toast: ToastService) {}

  toggleNotif(): void {
    this.notifOpen = !this.notifOpen;
    this.userMenuOpen = false;
  }

  toggleUserMenu(): void {
    this.userMenuOpen = !this.userMenuOpen;
    this.notifOpen = false;
  }

  logout(): void {
    this.auth.logout();
    this.toast.show('Logged out', 'info');
  }
}
