import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { SidebarRightComponent } from './sidebar-right/sidebar-right.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [HeaderComponent, SidebarComponent, SidebarRightComponent, FooterComponent],
  imports: [SharedModule],
  exports: [HeaderComponent, SidebarComponent, SidebarRightComponent, FooterComponent]
})
export class LayoutModule {}
