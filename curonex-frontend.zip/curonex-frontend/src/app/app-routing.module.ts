import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'user/pharmacy', pathMatch: 'full' },
  {
    path: 'user',
    loadChildren: () =>
      import('./features/user/user-layout/user-layout.module').then(m => m.UserLayoutModule)
  },
  {
    path: 'admin',
    loadChildren: () =>
      import('./features/admin/admin-layout/admin-layout.module').then(m => m.AdminLayoutModule)
  },
  { path: '**', redirectTo: 'user/pharmacy' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
