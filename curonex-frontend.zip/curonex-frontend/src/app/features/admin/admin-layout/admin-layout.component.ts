import { Component } from '@angular/core';
import { NavItem } from '../../../core/models/nav-item.model';

@Component({
  selector: 'app-admin-layout',
  templateUrl: './admin-layout.component.html',
  styleUrls: ['./admin-layout.component.scss']
})
export class AdminLayoutComponent {
  navItems: NavItem[] = [
    { label: 'Dashboard', icon: 'assets/icons/dashboard.png', route: '/admin/dashboard' },
    { label: 'Pharmacy Management', icon: 'assets/icons/pharmacy.png', route: '/admin/pharmacy-management' },
    { label: 'Delivery Management', icon: 'assets/icons/delivery.png', route: '/admin/delivery-management' }
  ];
}
