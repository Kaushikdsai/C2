import { NgModule } from '@angular/core';
import { SharedModule } from '../../../shared/shared.module';
import { LayoutModule } from '../../../layout/layout.module';
import { AdminLayoutComponent } from './admin-layout.component';
import { AdminLayoutRoutingModule } from './admin-layout-routing.module';

@NgModule({
  declarations: [AdminLayoutComponent],
  imports: [SharedModule, LayoutModule, AdminLayoutRoutingModule]
})
export class AdminLayoutModule {}
