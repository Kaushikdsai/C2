import { NgModule } from '@angular/core';
import { SharedModule } from '../../../shared/shared.module';
import { LayoutModule } from '../../../layout/layout.module';
import { UserLayoutComponent } from './user-layout.component';
import { UserLayoutRoutingModule } from './user-layout-routing.module';

@NgModule({
  declarations: [UserLayoutComponent],
  imports: [SharedModule, LayoutModule, UserLayoutRoutingModule]
})
export class UserLayoutModule {}
