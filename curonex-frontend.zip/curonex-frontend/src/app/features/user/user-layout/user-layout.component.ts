import { Component } from '@angular/core';
import { NavItem } from '../../../core/models/nav-item.model';

@Component({
  selector: 'app-user-layout',
  templateUrl: './user-layout.component.html',
  styleUrls: ['./user-layout.component.scss']
})
export class UserLayoutComponent {
  navItems: NavItem[] = [
    { label: 'Appointment Scheduling', icon: 'assets/icons/calendar.png', route: '/user/appointment' },
    { label: 'Pharmacy', icon: 'assets/icons/pharmacy.png', route: '/user/pharmacy' },
    { label: 'Medical Camp', icon: 'assets/icons/refugee-camp.png', route: '/user/camp' }
  ];
}
