import { NgModule } from '@angular/core';
import { SharedModule } from '../../../shared/shared.module';
import { LayoutModule } from '../../../layout/layout.module';
import { PharmacyRoutingModule } from './pharmacy-routing.module';

import { PharmacyHomeComponent } from './pages/pharmacy-home/pharmacy-home.component';
import { OrderPreviewComponent } from './pages/order-preview/order-preview.component';
import { DeliveryTrackingComponent } from './pages/delivery-tracking/delivery-tracking.component';

@NgModule({
  declarations: [PharmacyHomeComponent, OrderPreviewComponent, DeliveryTrackingComponent],
  imports: [SharedModule, LayoutModule, PharmacyRoutingModule]
})
export class PharmacyModule {}
