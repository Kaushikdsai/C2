import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PharmacyHomeComponent } from './pages/pharmacy-home/pharmacy-home.component';
import { OrderPreviewComponent } from './pages/order-preview/order-preview.component';
import { DeliveryTrackingComponent } from './pages/delivery-tracking/delivery-tracking.component';

const routes: Routes = [
  { path: '', component: PharmacyHomeComponent },
  { path: 'preview', component: OrderPreviewComponent },
  { path: 'delivery', component: DeliveryTrackingComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PharmacyRoutingModule {}
