export interface PreviewMedicine {
  id: string;
  name: string;
  sub: string;
  thumbLabel: string;
  thumbClass: string;
  quantity: number;
  removed: boolean;
}
