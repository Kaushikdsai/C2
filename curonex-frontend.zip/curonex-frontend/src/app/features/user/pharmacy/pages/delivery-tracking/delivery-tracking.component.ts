import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastService } from '../../../../../core/services/toast.service';
import { OrderService } from '../../../../../core/services/order.service';
import { SideCard } from '../../../../../core/models/side-card.model';
import { OrderStatus } from '../../../../../core/models/order-status.enum';
import { OrderTrackingDTO } from '../../../../../core/models/order.model';
import { PharmacyOrderStateService } from '../../services/pharmacy-order-state.service';

interface TrackStep {
  label: string;
  time: string;
  active: boolean;
}

const STATUS_STEP_INDEX: Record<OrderStatus, number> = {
  [OrderStatus.PENDING]: 0,
  [OrderStatus.CONFIRMED]: 0,
  [OrderStatus.OUT_FOR_DELIVERY]: 1,
  [OrderStatus.DELIVERED]: 2,
  [OrderStatus.CANCELLED]: -1
};

const POLL_INTERVAL_MS = 15000;

@Component({
  selector: 'app-delivery-tracking',
  templateUrl: './delivery-tracking.component.html',
  styleUrls: ['./delivery-tracking.component.scss']
})
export class DeliveryTrackingComponent implements OnInit, OnDestroy {
  private pollHandle?: ReturnType<typeof setInterval>;

  loading = true;
  cancelled = false;
  delivered = false;

  orderPlacedAt = '';

  steps: TrackStep[] = [
    { label: 'Delivery Partner Assigned', time: '---', active: false },
    { label: 'Out for Delivery', time: '---', active: false },
    { label: 'Delivered', time: '---', active: false }
  ];

  partnerName = '';
  partnerPhone = '';

  orderId: number | null = null;
  itemCount = 0;
  totalAmount: number | null = null;
  pharmacyName = '';

  rightSideCards: SideCard[] = [
    {
      title: 'Order History',
      sub: 'View your past orders',
      route: '/user/pharmacy/order-history',
      iconSvg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
    },
    {
      title: 'Report an Issue',
      sub: 'Something wrong with this order?',
      route: '/user/pharmacy/report-issue',
      iconSvg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="13"/><circle cx="12" cy="16" r="0.5" fill="currentColor"/></svg>'
    }
  ];

  constructor(
    private toast: ToastService,
    private router: Router,
    private orderService: OrderService,
    private orderState: PharmacyOrderStateService
  ) {}

  ngOnInit(): void {
    if (!this.orderState.orderId) {
      this.toast.show('No active order to track.', 'error');
      this.router.navigate(['/user/pharmacy']);
      return;
    }
    this.orderId = this.orderState.orderId;
    this.fetchTracking();
    this.pollHandle = setInterval(() => this.fetchTracking(), POLL_INTERVAL_MS);
  }

  ngOnDestroy(): void {
    if (this.pollHandle) clearInterval(this.pollHandle);
  }

  private fetchTracking(): void {
    if (!this.orderId) return;

    this.orderService.getOrderTracking(this.orderId).subscribe({
      next: (tracking) => {
        this.loading = false;
        this.applyTracking(tracking);
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  private applyTracking(tracking: OrderTrackingDTO): void {
    this.orderPlacedAt = tracking.orderDatetime
      ? new Date(tracking.orderDatetime).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })
      : '';
    this.itemCount = tracking.itemCount ?? 0;
    this.totalAmount = tracking.totalAmount ?? null;
    this.pharmacyName = tracking.pharmacyName ?? '';
    this.partnerName = tracking.deliveryPartnerName ?? '';
    this.partnerPhone = tracking.deliveryPartnerPhone ?? '';

    const status = tracking.status;

    if (status === OrderStatus.CANCELLED) {
      this.cancelled = true;
      if (this.pollHandle) clearInterval(this.pollHandle);
      return;
    }

    const activeIndex = STATUS_STEP_INDEX[status];
    this.steps.forEach((step, i) => {
      if (i <= activeIndex && !step.active) {
        step.active = true;
        step.time = this.timestampFor(i, tracking);
      }
    });

    const wasDelivered = this.delivered;
    this.delivered = status === OrderStatus.DELIVERED;
    if (this.delivered && !wasDelivered) {
      this.toast.show('Your order has been delivered!', 'success');
      if (this.pollHandle) clearInterval(this.pollHandle);
    }
  }

  private timestampFor(stepIndex: number, tracking: OrderTrackingDTO): string {
    const raw =
      stepIndex === 0 ? tracking.confirmedAt : stepIndex === 1 ? tracking.pickedUpAt : tracking.deliveredAt;
    return raw ? new Date(raw).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '---';
  }

  callPartner(): void {
    if (!this.partnerPhone) return;
    window.location.href = `tel:${this.partnerPhone.replace(/\s+/g, '')}`;
  }
}
