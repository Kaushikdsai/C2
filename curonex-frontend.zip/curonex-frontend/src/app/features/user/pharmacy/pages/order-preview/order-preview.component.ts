import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { finalize } from 'rxjs';
import { ToastService } from '../../../../../core/services/toast.service';
import { AuthService } from '../../../../../core/services/auth.service';
import { PrescriptionService } from '../../../../../core/services/prescription.service';
import { OrderService } from '../../../../../core/services/order.service';
import { SideCard } from '../../../../../core/models/side-card.model';
import { OrderCreateItemDTO } from '../../../../../core/models/order.model';
import { PharmacyOrderStateService } from '../../services/pharmacy-order-state.service';
import { PreviewMedicine } from '../../models/medicine.model';

@Component({
  selector: 'app-order-preview',
  templateUrl: './order-preview.component.html',
  styleUrls: ['./order-preview.component.scss']
})
export class OrderPreviewComponent implements OnInit {
  editing = false;
  orderProcessing = false;

  patientName = '';
  patientPhone = '';
  patientAddress = '';

  medicines: PreviewMedicine[] = [];

  rightSideCards: SideCard[] = [
    {
      title: 'Order History',
      sub: 'View your past orders',
      route: '/user/pharmacy/order-history',
      iconSvg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
    }
  ];

  constructor(
    private toast: ToastService,
    private router: Router,
    private location: Location,
    private auth: AuthService,
    private prescriptionService: PrescriptionService,
    private orderService: OrderService,
    private orderState: PharmacyOrderStateService
  ) {}

  ngOnInit(): void {
    if (!this.orderState.extractedMedicines || this.orderState.extractedMedicines.length === 0) {
      this.toast.show('No prescription found. Please upload one first.', 'error');
      this.router.navigate(['/user/pharmacy']);
      return;
    }

    this.medicines = this.orderState.extractedMedicines.map((med, index) => ({
      id: `m${index}`,
      name: med.medicineName,
      sub: '',
      thumbLabel: med.medicineName.split(' ')[0].toUpperCase().slice(0, 8),
      thumbClass: this.thumbClassFor(index),
      quantity: med.quantity,
      removed: false
    }));

    this.captureGeoAddress();
  }

  private thumbClassFor(index: number): string {
    const classes = ['thumb-paracetamol', 'thumb-cetirizine', 'thumb-azithromycin', 'thumb-omeprazole'];
    return classes[index % classes.length];
  }

  private captureGeoAddress(): void {
    if (!navigator.geolocation) {
      this.toast.show('Location access is required to find nearby pharmacies.', 'error');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        this.orderState.patientGeoAddress = `${position.coords.latitude},${position.coords.longitude}`;
      },
      () => {
        this.toast.show('Could not get your location. Please enable location access.', 'error');
      }
    );
  }

  get medicineCount(): number {
    return this.medicines.length;
  }

  goBack(): void {
    this.location.back();
  }

  toggleEdit(): void {
    this.editing = !this.editing;
    if (!this.editing) {
      this.toast.show('Patient details updated.', 'success');
    }
  }

  decreaseQty(med: PreviewMedicine): void {
    if (med.quantity > 0) {
      med.quantity -= 1;
    } else {
      this.toast.show('Quantity cannot be less than 0.', 'error');
    }
  }

  increaseQty(): void {
    this.toast.show('Quantity cannot be increased beyond what was prescribed.', 'error');
  }

  toggleRemove(med: PreviewMedicine): void {
    med.removed = !med.removed;
    this.toast.show(
      med.removed ? `${med.name} marked for removal.` : `${med.name} restored.`,
      med.removed ? 'info' : 'success'
    );
  }

  confirmOrder(): void {
    if (this.orderProcessing) return;

    const validMedicines = this.medicines.filter(m => !m.removed && m.quantity > 0);
    if (validMedicines.length === 0) {
      this.toast.show('At least one medicine with quantity greater than 0 is required.', 'error');
      return;
    }

    if (!this.orderState.patientGeoAddress) {
      this.toast.show('Your location is required before placing the order.', 'error');
      return;
    }

    const proceed = window.confirm(
      `Confirm order with ${validMedicines.length} medicine${validMedicines.length > 1 ? 's' : ''}?`
    );
    if (!proceed) return;

    this.orderProcessing = true;
    const userId = this.auth.getUserId();

    this.prescriptionService
      .createFullPrescription(
        userId,
        this.orderState.hospitalId,
        this.orderState.doctorId,
        validMedicines.map(m => ({ medicineName: m.name, quantity: m.quantity }))
      )
      .subscribe({
        next: (prescription) => {
          this.orderState.prescriptionId = prescription.prescriptionId;
          this.createOrder(userId, validMedicines);
        },
        error: () => {
          this.orderProcessing = false;
        }
      });
  }

  private createOrder(userId: number, validMedicines: PreviewMedicine[]): void {
    const items: OrderCreateItemDTO[] = validMedicines.map(m => ({
      medicineName: m.name,
      quantity: m.quantity
    }));

    this.orderService
      .createOrder({
        userId,
        prescriptionId: this.orderState.prescriptionId as number,
        patientGeoAddress: this.orderState.patientGeoAddress as string,
        items
      })
      .pipe(finalize(() => (this.orderProcessing = false)))
      .subscribe({
        next: (order) => {
          this.orderState.orderId = order.orderId;
          this.toast.show(
            `Order confirmed successfully (${validMedicines.length} medicine${validMedicines.length > 1 ? 's' : ''}).`,
            'success'
          );
          this.router.navigate(['/user/pharmacy/delivery']);
        }
      });
  }

  cancelOrder(): void {
    if (this.orderProcessing) return;
    if (!window.confirm('Are you sure you want to cancel this order?')) return;

    this.orderState.reset();
    this.toast.show('Order cancelled.', 'error');
    this.router.navigate(['/user/pharmacy']);
  }
}
