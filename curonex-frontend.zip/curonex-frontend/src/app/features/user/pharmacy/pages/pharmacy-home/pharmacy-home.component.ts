import { Component, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { finalize } from 'rxjs';
import { ToastService } from '../../../../../core/services/toast.service';
import { PrescriptionService } from '../../../../../core/services/prescription.service';
import { SideCard } from '../../../../../core/models/side-card.model';
import { PharmacyOrderStateService } from '../../services/pharmacy-order-state.service';

const ALLOWED_TYPES = ['application/pdf'];
const MAX_SIZE_MB = 5;

@Component({
  selector: 'app-pharmacy-home',
  templateUrl: './pharmacy-home.component.html',
  styleUrls: ['./pharmacy-home.component.scss']
})
export class PharmacyHomeComponent {
  @ViewChild('fileInput') fileInputRef!: ElementRef<HTMLInputElement>;

  uploadedFile: File | null = null;
  isDragging = false;
  isExtracting = false;
  extractionSucceeded = false;

  supportText = 'Supports: PDF (Max size: 5MB)';
  placeOrderNote = 'Upload prescription to place your medicine order';

  rightSideCards: SideCard[] = [
    {
      title: 'Order History',
      sub: 'View your past orders',
      route: '/user/pharmacy/order-history',
      iconSvg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
    },
    {
      title: 'Active Prescriptions',
      sub: 'Manage saved prescriptions',
      route: '/user/pharmacy/prescriptions',
      iconSvg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="4" rx="1"/><path d="M9 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-3"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="16" x2="15" y2="16"/></svg>'
    }
  ];

  constructor(
    private toast: ToastService,
    private router: Router,
    private prescriptionService: PrescriptionService,
    private orderState: PharmacyOrderStateService
  ) {
    this.orderState.reset();
  }

  get placeOrderDisabled(): boolean {
    return !this.uploadedFile || this.isExtracting || !this.extractionSucceeded;
  }

  openFilePicker(): void {
    this.fileInputRef.nativeElement.click();
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.handleFile(input.files[0]);
    }
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = true;
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;
    const file = event.dataTransfer?.files?.[0];
    if (file) {
      this.handleFile(file);
    }
  }

  private validateFile(file: File): string | null {
    if (!ALLOWED_TYPES.includes(file.type)) {
      return 'Only PDF prescriptions are supported.';
    }
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      return `File is too large. Max size is ${MAX_SIZE_MB}MB.`;
    }
    return null;
  }

  private handleFile(file: File): void {
    const error = this.validateFile(file);
    if (error) {
      this.toast.show(error, 'error');
      this.resetUpload();
      return;
    }
    this.uploadedFile = file;
    this.supportText = `Selected: ${file.name} (${(file.size / 1024).toFixed(0)} KB)`;
    this.extractAndValidate(file);
  }

  private extractAndValidate(file: File): void {
    this.isExtracting = true;
    this.extractionSucceeded = false;
    this.placeOrderNote = 'Reading prescription...';

    this.prescriptionService
      .extractFromFile(file)
      .pipe(finalize(() => (this.isExtracting = false)))
      .subscribe({
        next: (response) => {
          if (!response.medicines || response.medicines.length === 0) {
            this.toast.show('No medicines could be read from this prescription. Try a clearer scan.', 'error');
            this.placeOrderNote = 'Upload prescription to place your medicine order';
            return;
          }
          this.orderState.extractedMedicines = response.medicines;
          this.orderState.hospitalId = response.hospitalId;
          this.orderState.doctorId = response.doctorId;
          this.extractionSucceeded = true;
          this.placeOrderNote = `Found ${response.medicines.length} medicine${response.medicines.length > 1 ? 's' : ''}. Ready to place your order.`;
          this.toast.show('Prescription uploaded and read successfully.', 'success');
        },
        error: () => {
          this.placeOrderNote = 'Upload prescription to place your medicine order';
        }
      });
  }

  resetUpload(): void {
    this.uploadedFile = null;
    this.extractionSucceeded = false;
    if (this.fileInputRef) {
      this.fileInputRef.nativeElement.value = '';
    }
    this.supportText = 'Supports: PDF (Max size: 5MB)';
    this.placeOrderNote = 'Upload prescription to place your medicine order';
    this.orderState.extractedMedicines = [];
  }

  placeOrder(): void {
    if (this.placeOrderDisabled) {
      this.toast.show('Please upload a valid prescription before placing your order.', 'error');
      return;
    }
    this.router.navigate(['/user/pharmacy/preview']);
  }
}
