import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  isLoggedIn(): boolean {
    return !!localStorage.getItem('curonex_token');
  }

  getToken(): string | null {
    return localStorage.getItem('curonex_token');
  }

  hasRole(role: string): boolean {
    return localStorage.getItem('curonex_role') === role;
  }

  /**
   * TEMPORARY: no login page exists yet. Replace with the real value once
   * login/session (JWT claim or a /me endpoint) exists.
   */
  getUserId(): number {
    const stored = localStorage.getItem('curonex_user_id');
    return stored ? Number(stored) : 1; // fallback for dev only
  }

  logout(): void {
    localStorage.removeItem('curonex_token');
    localStorage.removeItem('curonex_role');
  }
}
