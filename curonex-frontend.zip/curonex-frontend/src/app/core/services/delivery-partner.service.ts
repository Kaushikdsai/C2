import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { DeliveryPartnerDTO } from '../models/delivery-partner.model';

@Injectable({ providedIn: 'root' })
export class DeliveryPartnerService {
  private baseUrl = `${environment.apiBaseUrl}/api/delivery-partners`;

  constructor(private http: HttpClient) {}

  getAllPartners(): Observable<DeliveryPartnerDTO[]> {
    return this.http.get<DeliveryPartnerDTO[]>(this.baseUrl);
  }

  getAvailablePartners(): Observable<DeliveryPartnerDTO[]> {
    return this.http.get<DeliveryPartnerDTO[]>(`${this.baseUrl}/available`);
  }
}
