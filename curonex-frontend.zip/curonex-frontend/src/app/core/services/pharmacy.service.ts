import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { PharmacyDTO } from '../models/pharmacy.model';

@Injectable({ providedIn: 'root' })
export class PharmacyService {
  private baseUrl = `${environment.apiBaseUrl}/api/pharmacies`;

  constructor(private http: HttpClient) {}

  getAllPharmacies(): Observable<PharmacyDTO[]> {
    return this.http.get<PharmacyDTO[]>(this.baseUrl);
  }

  getActivePharmacies(): Observable<PharmacyDTO[]> {
    return this.http.get<PharmacyDTO[]>(`${this.baseUrl}/active`);
  }

  getPharmacyById(id: number): Observable<PharmacyDTO> {
    return this.http.get<PharmacyDTO>(`${this.baseUrl}/${id}`);
  }
}
