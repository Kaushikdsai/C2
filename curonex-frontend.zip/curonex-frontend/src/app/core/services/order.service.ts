import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { OrderCreateRequestDTO, OrderResponseDTO, OrderTrackingDTO } from '../models/order.model';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private baseUrl = `${environment.apiBaseUrl}/api/orders`;

  constructor(private http: HttpClient) {}

  createOrder(request: OrderCreateRequestDTO): Observable<OrderResponseDTO> {
    return this.http.post<OrderResponseDTO>(this.baseUrl, request);
  }

  getOrderById(orderId: number): Observable<OrderResponseDTO> {
    return this.http.get<OrderResponseDTO>(`${this.baseUrl}/${orderId}`);
  }

  getOrdersByUser(userId: number): Observable<OrderResponseDTO[]> {
    return this.http.get<OrderResponseDTO[]>(`${this.baseUrl}/user/${userId}`);
  }

  getOrderTracking(orderId: number): Observable<OrderTrackingDTO> {
    return this.http.get<OrderTrackingDTO>(`${this.baseUrl}/${orderId}/tracking`);
  }

  cancelOrder(orderId: number): Observable<OrderResponseDTO> {
    return this.http.put<OrderResponseDTO>(`${this.baseUrl}/${orderId}/cancel`, {});
  }
}
