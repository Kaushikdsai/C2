import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin, of, switchMap } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ExtractedMedicineDTO,
  PrescriptionExtractionResponseDTO,
  PrescriptionMedicinesDTO,
  PrescriptionsDTO
} from '../models/prescription.model';

@Injectable({ providedIn: 'root' })
export class PrescriptionService {
  private baseUrl = `${environment.apiBaseUrl}/api/prescriptions`;

  constructor(private http: HttpClient) {}

  /** Confirmed: POST /api/prescriptions/extract, multipart field "file". */
  extractFromFile(file: File): Observable<PrescriptionExtractionResponseDTO> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<PrescriptionExtractionResponseDTO>(`${this.baseUrl}/extract`, formData);
  }

  /** Confirmed: POST /api/prescriptions creates only the header. */
  createPrescriptionHeader(
    userId: number,
    hospitalId: number | null,
    doctorId: number | null
  ): Observable<PrescriptionsDTO> {
    const payload: Partial<PrescriptionsDTO> = {
      userId,
      hospitalId,
      doctorId,
      prescriptionDatetime: new Date().toISOString()
    };
    return this.http.post<PrescriptionsDTO>(this.baseUrl, payload);
  }

  /** Confirmed: POST /api/prescriptions/{prescriptionId}/medicines, one call per medicine. */
  addMedicine(prescriptionId: number, medicine: ExtractedMedicineDTO): Observable<PrescriptionMedicinesDTO> {
    return this.http.post<PrescriptionMedicinesDTO>(`${this.baseUrl}/${prescriptionId}/medicines`, {
      medicineName: medicine.medicineName,
      quantity: medicine.quantity
    });
  }

  /** Creates the header, then attaches every medicine line item in parallel. */
  createFullPrescription(
    userId: number,
    hospitalId: number | null,
    doctorId: number | null,
    medicines: ExtractedMedicineDTO[]
  ): Observable<PrescriptionsDTO> {
    return this.createPrescriptionHeader(userId, hospitalId, doctorId).pipe(
      switchMap((prescription) => {
        if (!prescription.prescriptionId) {
          throw new Error('Prescription was created without an id — check backend ID generation.');
        }
        const medicineCalls = medicines.map((m) => this.addMedicine(prescription.prescriptionId as number, m));
        return medicineCalls.length > 0
          ? forkJoin(medicineCalls).pipe(switchMap(() => of(prescription)))
          : of(prescription);
      })
    );
  }
}
