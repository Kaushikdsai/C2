export interface ExtractedMedicineDTO {
  medicineName: string;
  quantity: number;
}

/**
 * Matches PrescriptionExtractionResponseDTO. hospitalId/doctorId are added
 * per backend change — will be null until PrescriptionParserUtil actually
 * populates them from the document.
 */
export interface PrescriptionExtractionResponseDTO {
  extractedText: string;
  medicines: ExtractedMedicineDTO[];
  hospitalId: number | null;
  doctorId: number | null;
}

/** Matches PrescriptionsDTO — header only, no medicines list. */
export interface PrescriptionsDTO {
  prescriptionId: number | null;
  userId: number;
  hospitalId: number | null;
  doctorId: number | null;
  prescriptionDatetime: string | null;
}

/** Matches PrescriptionMedicinesDTO — added one at a time. */
export interface PrescriptionMedicinesDTO {
  prescriptionId: number;
  medicineName: string;
  quantity: number;
}
