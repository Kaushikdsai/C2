export interface PharmacyDTO {
  id: number;
  licenseNo: string;
  geoAddress: string;
  status: string;
  hospitalId: number | null;
  rating: number;
  ratingCount: number;
}
