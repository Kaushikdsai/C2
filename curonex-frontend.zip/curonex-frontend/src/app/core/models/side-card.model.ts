export interface SideCard {
  title: string;
  sub: string;
  route: string;
  iconSvg: string;
}
