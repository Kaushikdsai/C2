export interface DeliveryPartnerDTO {
  deliveryPartnerId: number;
  name: string;
  mobileNumber: string;
  geoAddress: string;
  status: string;
  rating: number;
  ratingCount: number;
}
