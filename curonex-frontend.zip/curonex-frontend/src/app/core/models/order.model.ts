import { OrderStatus } from './order-status.enum';

export interface OrderItemDTO {
  itemId: number;
  medicineName: string;
  quantity: number;
  price: number | null;
}

export interface OrderResponseDTO {
  orderId: number;
  pharmacyId: number | null;
  deliveryPartnerId: number | null;
  userId: number;
  hospitalId: number | null;
  status: OrderStatus;
  orderDatetime: string;
  totalAmount: number | null;
  confirmedAt: string | null;
  pickedUpAt: string | null;
  deliveredAt: string | null;
  cancelledAt: string | null;
  items: OrderItemDTO[];
}

export interface OrderCreateItemDTO {
  medicineName: string;
  quantity: number;
}

export interface OrderCreateRequestDTO {
  userId: number;
  prescriptionId: number;
  patientGeoAddress: string;
  items: OrderCreateItemDTO[];
}

/** Matches OrderTrackingDTO — used by delivery-tracking polling. */
export interface OrderTrackingDTO {
  orderId: number;
  status: OrderStatus;
  orderDatetime: string;
  itemCount: number;
  totalAmount: number | null;
  confirmedAt: string | null;
  pickedUpAt: string | null;
  deliveredAt: string | null;
  pharmacyGeoAddress: string | null;
  pharmacyName: string | null;
  deliveryPartnerName: string | null;
  deliveryPartnerPhone: string | null;
}
