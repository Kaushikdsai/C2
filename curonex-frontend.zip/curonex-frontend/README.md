# Curonex Frontend (Angular)

## Setup
```
npm install
ng serve
```
App runs at http://localhost:4200. Backend expected at http://localhost:8083
(see src/environments/environment.ts).

## What's built
- User side complete: Pharmacy Home -> Order Preview -> Delivery Tracking,
  wired to real backend endpoints (extraction, prescriptions, orders).
- Admin side scaffolded only (layout + routing shell) — pages pending.

## Known gaps / flagged items — see conversation for full detail
1. Orders.orderId and Prescriptions.prescriptionId have no @GeneratedValue
   in the backend entities. Confirm ID generation strategy before relying
   on order/prescription creation in a real environment.
2. PrescriptionExtractionResponseDTO needs hospitalId/doctorId fields added
   on the backend (PrescriptionParserUtil) for hospital-priority routing to
   work end-to-end. Frontend already reads these fields; they'll arrive as
   null until the backend populates them.
3. AuthService.getUserId() is a temporary localStorage stub — no real login
   page exists yet.
4. Delivery-tracking polls GET /api/orders/{id}/tracking every 15s; no
   WebSocket/push channel exists on the backend.

## Assets
Icon/image files referenced under src/assets/icons and src/assets/images
are NOT included — drop in bell.png, pharmacy.png, calendar.png,
refugee-camp.png, customer-service.png, dashboard.png, delivery.png, and a
brand-avatar.jpg to match what the templates reference.
