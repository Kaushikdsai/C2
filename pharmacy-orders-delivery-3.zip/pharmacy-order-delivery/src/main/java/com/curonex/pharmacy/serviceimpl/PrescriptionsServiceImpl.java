package com.curonex.pharmacy.serviceimpl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.curonex.pharmacy.dto.PrescriptionsDTO;
import com.curonex.pharmacy.entity.Prescriptions;
import com.curonex.pharmacy.exceptions.PrescriptionNotFoundException;
import com.curonex.pharmacy.repository.PrescriptionsRepository;
import com.curonex.pharmacy.service.PrescriptionsService;

@Service
public class PrescriptionsServiceImpl implements PrescriptionsService {

    private final PrescriptionsRepository prescriptionRepository;

    public PrescriptionsServiceImpl(PrescriptionsRepository prescriptionRepository) {
        this.prescriptionRepository = prescriptionRepository;
    }

    @Override
    public PrescriptionsDTO addPrescription(PrescriptionsDTO dto) {
        Prescriptions prescription = new Prescriptions();
        BeanUtils.copyProperties(dto, prescription);
        prescription.setIsDeleted(false);
        return convertToDTO(prescriptionRepository.save(prescription));
    }

    @Override
    public PrescriptionsDTO getPrescriptionById(Long prescriptionId) {
        return convertToDTO(prescriptionRepository.findById(prescriptionId)
                .orElseThrow(() -> new PrescriptionNotFoundException("Prescription not found with id: " + prescriptionId)));
    }

    @Override
    public List<PrescriptionsDTO> getAllPrescriptions() {
        return prescriptionRepository.findByIsDeletedFalse().stream().map(this::convertToDTO).toList();
    }

    @Override
    public PrescriptionsDTO updatePrescription(Long prescriptionId, PrescriptionsDTO dto) {
        Prescriptions prescription = prescriptionRepository.findById(prescriptionId)
                .orElseThrow(() -> new PrescriptionNotFoundException("Prescription not found with id: " + prescriptionId));

        prescription.setUserId(dto.getUserId());
        prescription.setHospitalId(dto.getHospitalId());
        prescription.setDoctorId(dto.getDoctorId());
        prescription.setPrescriptionDatetime(dto.getPrescriptionDatetime());

        return convertToDTO(prescriptionRepository.save(prescription));
    }

    /**
     * Soft delete only. Prescriptions are medical records and are expected
     * to remain auditable even after a patient "removes" one from view.
     */
    @Override
    @Transactional
    public void deletePrescription(Long prescriptionId) {
        Prescriptions prescription = prescriptionRepository.findById(prescriptionId)
                .orElseThrow(() -> new PrescriptionNotFoundException("Prescription not found with id: " + prescriptionId));
        prescription.setIsDeleted(true);
        prescriptionRepository.save(prescription);
    }

    @Override
    public List<PrescriptionsDTO> getPrescriptionsByUser(Long userId) {
        return prescriptionRepository.findByUserIdAndIsDeletedFalse(userId).stream().map(this::convertToDTO).toList();
    }

    @Override
    public List<PrescriptionsDTO> getPrescriptionsByHospital(Long hospitalId) {
        return prescriptionRepository.findByHospitalIdAndIsDeletedFalse(hospitalId).stream().map(this::convertToDTO).toList();
    }

    @Override
    public List<PrescriptionsDTO> getPrescriptionsByDoctor(Long doctorId) {
        return prescriptionRepository.findByDoctorIdAndIsDeletedFalse(doctorId).stream().map(this::convertToDTO).toList();
    }

    private PrescriptionsDTO convertToDTO(Prescriptions prescription) {
        PrescriptionsDTO dto = new PrescriptionsDTO();
        BeanUtils.copyProperties(prescription, dto);
        return dto;
    }
}
