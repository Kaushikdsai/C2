package com.curonex.pharmacy.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.service.OrderItemService;

/**
 * Read-only by design. Order items are priced as part of the pharmacy
 * accept flow (see PharmacyController#acceptOrder) and that price feeds
 * directly into Orders.totalAmount. Exposing independent create/update/
 * delete here would let a caller mutate an item's price or quantity without
 * ever recalculating the parent order's total, silently corrupting it -
 * so those mutations are intentionally NOT exposed as REST endpoints.
 * All item mutation happens internally through OrderService/PharmacyService.
 */
@RestController
@RequestMapping("/api/order-items")
public class OrderItemController {

    private final OrderItemService service;

    public OrderItemController(OrderItemService service) {
        this.service = service;
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrderItem> getOrderItemById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getOrderItemById(id));
    }

    @GetMapping
    public ResponseEntity<List<OrderItem>> getAllOrderItems() {
        return ResponseEntity.ok(service.getAllOrderItems());
    }

    @GetMapping("/order/{orderId}")
    public ResponseEntity<List<OrderItem>> getItemsByOrderId(@PathVariable Long orderId) {
        return ResponseEntity.ok(service.getOrderItemsByOrderId(orderId));
    }
}
