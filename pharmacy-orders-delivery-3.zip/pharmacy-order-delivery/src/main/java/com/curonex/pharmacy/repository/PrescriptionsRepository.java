package com.curonex.pharmacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.Prescriptions;

@Repository
public interface PrescriptionsRepository extends JpaRepository<Prescriptions, Long> {

    List<Prescriptions> findByUserId(Long userId);

    List<Prescriptions> findByHospitalId(Long hospitalId);

    List<Prescriptions> findByDoctorId(Long doctorId);

    /** Excludes soft-deleted rows - use for any "list" screen. */
    List<Prescriptions> findByUserIdAndIsDeletedFalse(Long userId);

    List<Prescriptions> findByHospitalIdAndIsDeletedFalse(Long hospitalId);

    List<Prescriptions> findByDoctorIdAndIsDeletedFalse(Long doctorId);

    List<Prescriptions> findByIsDeletedFalse();
}
