package com.curonex.pharmacy.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.CoordinateDTO;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.entity.Medicine;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;
import com.curonex.pharmacy.repository.MedicineRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import com.curonex.pharmacy.util.DistanceUtil;
import com.curonex.pharmacy.util.GeoAddressUtil;

@Service
public class PharmacyRoutingServiceImpl implements PharmacyRoutingService {

    private static final double DEFAULT_BROADCAST_RADIUS_KM = 10.0;

    private final PharmacyRepository pharmacyRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final MedicineRepository medicineRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final GeoAddressUtil geoAddressUtil;
    private final DistanceUtil distanceUtil;
    private final OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;

    public PharmacyRoutingServiceImpl(
            PharmacyRepository pharmacyRepository,
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            MedicineRepository medicineRepository,
            DetailsFeignClient detailsFeignClient,
            GeoAddressUtil geoAddressUtil,
            DistanceUtil distanceUtil,
            OrderPharmacyRejectionRepository orderPharmacyRejectionRepository) {

        this.pharmacyRepository = pharmacyRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.medicineRepository = medicineRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.geoAddressUtil = geoAddressUtil;
        this.distanceUtil = distanceUtil;
        this.orderPharmacyRejectionRepository = orderPharmacyRejectionRepository;
    }

    /** Hospital pharmacy gets first priority - first ACTIVE, non-deleted hospital pharmacy within 5km of the patient. */
    @Override
    public Pharmacy assignHospitalPharmacy(Long hospitalId, String patientGeoAddress) {
        List<Pharmacy> hospitalPharmacies =
                pharmacyRepository.findByStatusAndHospitalIdAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE, hospitalId);

        for (Pharmacy pharmacy : hospitalPharmacies) {
            if (isWithinRadius(patientGeoAddress, pharmacy.getGeoAddress(), 5.0)) {
                return pharmacy;
            }
        }
        return null;
    }

    @Override
    public List<Pharmacy> findNearbyPharmacies(String patientGeoAddress, double radiusKm) {
        List<Pharmacy> nearbyPharmacies = new ArrayList<>();
        List<Pharmacy> activePharmacies = pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE);

        for (Pharmacy pharmacy : activePharmacies) {
            if (isWithinRadius(patientGeoAddress, pharmacy.getGeoAddress(), radiusKm)) {
                nearbyPharmacies.add(pharmacy);
            }
        }
        return nearbyPharmacies;
    }

    /** Every ACTIVE pharmacy within radius sees this order at the same instant - no sequential targeting. */
    @Override
    public void broadcastOrder(Long orderId, String patientGeoAddress) {
        if (patientGeoAddress == null || patientGeoAddress.isBlank()) {
            return;
        }
        List<Pharmacy> nearbyPharmacies = findNearbyPharmacies(patientGeoAddress, DEFAULT_BROADCAST_RADIUS_KM);
        org.slf4j.LoggerFactory.getLogger(PharmacyRoutingServiceImpl.class)
                .info("Order {} broadcast to {} nearby pharmacies", orderId, nearbyPharmacies.size());
    }

    @Override
    public void rebroadcastOrder(Long orderId) {
        Orders order = orderRepository.findById(orderId).orElse(null);
        if (order == null) {
            return;
        }
        broadcastOrder(orderId, order.getPatientGeoAddress());
    }

    @Override
    public boolean isWithinRadius(String sourceGeoAddress, String destinationGeoAddress, double radiusKm) {
        CoordinateDTO source = geoAddressUtil.parse(sourceGeoAddress);
        CoordinateDTO destination = geoAddressUtil.parse(destinationGeoAddress);

        double distance = distanceUtil.calculateDistance(
                source.getLatitude(), source.getLongitude(),
                destination.getLatitude(), destination.getLongitude());

        return distance <= radiusKm;
    }

    @Override
    public List<OrderSummaryDTO> getAvailableOrdersForPharmacy(Long pharmacyId) {
        Pharmacy pharmacy = pharmacyRepository.findByIdAndIsDeletedFalse(pharmacyId).orElse(null);
        if (pharmacy == null || pharmacy.getGeoAddress() == null) {
            return List.of();
        }

        List<Orders> unclaimedOrders = orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING);

        return unclaimedOrders.stream()
                .filter(order -> !orderPharmacyRejectionRepository
                        .existsByIdOrderIdAndIdPharmacyId(order.getOrderId(), pharmacyId))
                .filter(order -> {
                    String patientGeoAddress = order.getPatientGeoAddress();
                    return patientGeoAddress == null
                            || isWithinRadius(patientGeoAddress, pharmacy.getGeoAddress(), DEFAULT_BROADCAST_RADIUS_KM);
                })
                .map(this::toSummaryDTO)
                .collect(Collectors.toList());
    }

    private OrderSummaryDTO toSummaryDTO(Orders order) {
        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
        Map<Long, String> names = medicineRepository
                .findAllById(items.stream().map(OrderItem::getMedicineId).collect(Collectors.toSet()))
                .stream().collect(Collectors.toMap(Medicine::getMedicineId, Medicine::getName));

        OrderSummaryDTO dto = new OrderSummaryDTO();
        dto.setOrderId(order.getOrderId());
        dto.setItemCount(items.size());
        dto.setMedicinesSummary(items.stream().map(i -> names.get(i.getMedicineId())).collect(Collectors.joining(", ")));
        dto.setTotalAmount(order.getTotalAmount());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());
        dto.setIsReturned(order.getIsReturned());

        DetailsDTO patientDetails = safeFetchDetails(order.getUserId());
        dto.setPatientName(patientDetails != null ? patientDetails.getName() : null);
        return dto;
    }

    private DetailsDTO safeFetchDetails(Long id) {
        try {
            return detailsFeignClient.getDetails(id);
        } catch (Exception ex) {
            return null;
        }
    }
}
