package com.curonex.pharmacy.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curonex.pharmacy.dto.OrderCreateRequestDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderTrackingDTO;
import com.curonex.pharmacy.service.OrderService;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping
    public ResponseEntity<OrderResponseDTO> createOrder(
            @jakarta.validation.Valid @RequestBody OrderCreateRequestDTO request) {
        return new ResponseEntity<>(orderService.createOrder(request), HttpStatus.CREATED);
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<OrderResponseDTO> getOrderById(@PathVariable Long orderId) {
        return ResponseEntity.ok(orderService.getOrderById(orderId));
    }

    @GetMapping
    public ResponseEntity<List<OrderResponseDTO>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    /** Paginated variant - prefer this for admin/reporting screens with large volumes. */
    @GetMapping("/paged")
    public ResponseEntity<Page<OrderResponseDTO>> getAllOrdersPaged(Pageable pageable) {
        return ResponseEntity.ok(orderService.getAllOrders(pageable));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<OrderResponseDTO>> getOrdersByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(orderService.getOrdersByUser(userId));
    }

    @GetMapping("/{orderId}/tracking")
    public ResponseEntity<OrderTrackingDTO> getOrderTracking(@PathVariable Long orderId) {
        return ResponseEntity.ok(orderService.getOrderTracking(orderId));
    }

    /**
     * Cancels an order that hasn't been delivered yet. This IS the correct
     * "soft delete" for an order - orders are financial/audit records and
     * are never hard-deleted through the API (no DELETE endpoint is exposed
     * here on purpose).
     */
    @PutMapping("/{orderId}/cancel")
    public ResponseEntity<OrderResponseDTO> cancelOrder(@PathVariable Long orderId) {
        return ResponseEntity.ok(orderService.cancelOrder(orderId));
    }

    /** Marks a delivered order as returned. */
    @PutMapping("/{orderId}/return")
    public ResponseEntity<OrderResponseDTO> markReturned(@PathVariable Long orderId) {
        return ResponseEntity.ok(orderService.markReturned(orderId));
    }
}
