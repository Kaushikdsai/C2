package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;
import com.curonex.pharmacy.repository.MedicineRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.util.DistanceUtil;
import com.curonex.pharmacy.util.GeoAddressUtil;

@ExtendWith(MockitoExtension.class)
class PharmacyRoutingServiceImplTest {

    @Mock private PharmacyRepository pharmacyRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private OrderItemRepository orderItemRepository;
    @Mock private MedicineRepository medicineRepository;
    @Mock private DetailsFeignClient detailsFeignClient;
    @Mock private OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;

    private final DistanceUtil distanceUtil = new DistanceUtil();
    private final GeoAddressUtil geoAddressUtil = new GeoAddressUtil();

    private PharmacyRoutingServiceImpl service;

    private static final String CHENNAI = "13.0827,80.2707";
    private static final String DELHI = "28.6139,77.2090";

    @BeforeEach
    void setUp() {
        service = new PharmacyRoutingServiceImpl(
                pharmacyRepository, orderRepository, orderItemRepository, medicineRepository,
                detailsFeignClient, geoAddressUtil, distanceUtil, orderPharmacyRejectionRepository);
    }

    private Pharmacy pharmacy(Long id, String geo, Long hospitalId) {
        Pharmacy p = new Pharmacy();
        p.setId(id);
        p.setGeoAddress(geo);
        p.setStatus(PharmacyStatusEnum.ACTIVE);
        p.setHospitalId(hospitalId);
        p.setIsDeleted(false);
        return p;
    }

    @Test
    void assignHospitalPharmacy_returnsFirstWithinRadius() {
        Pharmacy near = pharmacy(1L, CHENNAI, 99L);
        when(pharmacyRepository.findByStatusAndHospitalIdAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE, 99L))
                .thenReturn(List.of(near));

        Pharmacy result = service.assignHospitalPharmacy(99L, CHENNAI);

        assertThat(result).isEqualTo(near);
    }

    @Test
    void assignHospitalPharmacy_returnsNullWhenNoneWithinRadius() {
        Pharmacy far = pharmacy(1L, DELHI, 99L);
        when(pharmacyRepository.findByStatusAndHospitalIdAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE, 99L))
                .thenReturn(List.of(far));

        Pharmacy result = service.assignHospitalPharmacy(99L, CHENNAI);

        assertThat(result).isNull();
    }

    @Test
    void findNearbyPharmacies_filtersByRadius() {
        Pharmacy near = pharmacy(1L, CHENNAI, null);
        Pharmacy far = pharmacy(2L, DELHI, null);
        when(pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE))
                .thenReturn(List.of(near, far));

        List<Pharmacy> result = service.findNearbyPharmacies(CHENNAI, 10.0);

        assertThat(result).containsExactly(near);
    }

    @Test
    void broadcastOrder_skipsWhenGeoAddressBlank() {
        service.broadcastOrder(1L, "");

        org.mockito.Mockito.verifyNoInteractions(pharmacyRepository);
    }

    @Test
    void broadcastOrder_skipsWhenGeoAddressNull() {
        service.broadcastOrder(1L, null);

        org.mockito.Mockito.verifyNoInteractions(pharmacyRepository);
    }

    @Test
    void broadcastOrder_searchesNearbyWhenGeoAddressPresent() {
        when(pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE)).thenReturn(List.of());

        service.broadcastOrder(1L, CHENNAI);

        org.mockito.Mockito.verify(pharmacyRepository).findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE);
    }

    @Test
    void rebroadcastOrder_doesNothingWhenOrderMissing() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        service.rebroadcastOrder(1L);

        org.mockito.Mockito.verifyNoInteractions(pharmacyRepository);
    }

    @Test
    void rebroadcastOrder_usesOrdersStoredGeoAddress() {
        Orders o = new Orders();
        o.setOrderId(1L);
        o.setPatientGeoAddress(CHENNAI);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        when(pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE)).thenReturn(List.of());

        service.rebroadcastOrder(1L);

        org.mockito.Mockito.verify(pharmacyRepository).findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE);
    }

    @Test
    void isWithinRadius_trueForNearbyPoints() {
        assertThat(service.isWithinRadius(CHENNAI, "13.0900,80.2800", 5.0)).isTrue();
    }

    @Test
    void isWithinRadius_falseForFarPoints() {
        assertThat(service.isWithinRadius(CHENNAI, DELHI, 10.0)).isFalse();
    }

    @Test
    void getAvailableOrdersForPharmacy_emptyWhenPharmacyMissing() {
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.empty());

        assertThat(service.getAvailableOrdersForPharmacy(1L)).isEmpty();
    }

    @Test
    void getAvailableOrdersForPharmacy_excludesRejectedOrders() {
        Pharmacy p = pharmacy(1L, CHENNAI, null);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.of(p));

        Orders rejected = new Orders();
        rejected.setOrderId(10L);
        rejected.setPatientGeoAddress(CHENNAI);
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(rejected));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 1L)).thenReturn(true);

        assertThat(service.getAvailableOrdersForPharmacy(1L)).isEmpty();
    }

    @Test
    void getAvailableOrdersForPharmacy_includesUnrejectedNearbyOrder() {
        Pharmacy p = pharmacy(1L, CHENNAI, null);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.of(p));

        Orders order = new Orders();
        order.setOrderId(10L);
        order.setPatientGeoAddress(CHENNAI);
        order.setUserId(5L);
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(order));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 1L)).thenReturn(false);
        when(orderItemRepository.findByOrderId(10L)).thenReturn(List.of());
        when(detailsFeignClient.getDetails(5L)).thenReturn(new DetailsDTO());

        List<OrderSummaryDTO> result = service.getAvailableOrdersForPharmacy(1L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getOrderId()).isEqualTo(10L);
    }

    @Test
    void getAvailableOrdersForPharmacy_includesOrderWithNoLocation() {
        Pharmacy p = pharmacy(1L, CHENNAI, null);
        when(pharmacyRepository.findByIdAndIsDeletedFalse(1L)).thenReturn(Optional.of(p));

        Orders order = new Orders();
        order.setOrderId(10L);
        order.setPatientGeoAddress(null);
        order.setUserId(5L);
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING)).thenReturn(List.of(order));
        when(orderPharmacyRejectionRepository.existsByIdOrderIdAndIdPharmacyId(10L, 1L)).thenReturn(false);
        when(orderItemRepository.findByOrderId(10L)).thenReturn(List.of());
        when(detailsFeignClient.getDetails(5L)).thenReturn(new DetailsDTO());

        List<OrderSummaryDTO> result = service.getAvailableOrdersForPharmacy(1L);

        assertThat(result).hasSize(1);
    }
}
