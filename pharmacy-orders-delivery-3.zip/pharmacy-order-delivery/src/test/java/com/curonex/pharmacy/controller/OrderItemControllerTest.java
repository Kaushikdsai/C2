package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.service.OrderItemService;

@ExtendWith(MockitoExtension.class)
class OrderItemControllerTest {

    @Mock private OrderItemService service;

    private OrderItemController controller;

    @BeforeEach
    void setUp() {
        controller = new OrderItemController(service);
    }

    @Test
    void getOrderItemById_delegates() {
        OrderItem item = new OrderItem(1L, 5L, 2, null);
        when(service.getOrderItemById(1L)).thenReturn(item);

        assertThat(controller.getOrderItemById(1L).getBody()).isEqualTo(item);
    }

    @Test
    void getAllOrderItems_delegates() {
        when(service.getAllOrderItems()).thenReturn(List.of(new OrderItem(1L, 5L, 2, null)));

        assertThat(controller.getAllOrderItems().getBody()).hasSize(1);
    }

    @Test
    void getItemsByOrderId_delegates() {
        when(service.getOrderItemsByOrderId(1L)).thenReturn(List.of(new OrderItem(1L, 5L, 2, null)));

        assertThat(controller.getItemsByOrderId(1L).getBody()).hasSize(1);
    }
}
