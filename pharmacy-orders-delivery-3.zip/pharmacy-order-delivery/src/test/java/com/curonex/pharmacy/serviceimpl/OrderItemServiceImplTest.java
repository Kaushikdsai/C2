package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.exceptions.OrderItemNotFoundException;
import com.curonex.pharmacy.repository.OrderItemRepository;

@ExtendWith(MockitoExtension.class)
class OrderItemServiceImplTest {

    @Mock private OrderItemRepository orderItemRepository;

    private OrderItemServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new OrderItemServiceImpl(orderItemRepository);
    }

    @Test
    void addOrderItem_delegatesToRepository() {
        OrderItem item = new OrderItem(1L, 5L, 2, new BigDecimal("10.00"));
        when(orderItemRepository.save(item)).thenReturn(item);

        assertThat(service.addOrderItem(item)).isEqualTo(item);
    }

    @Test
    void getOrderItemById_throwsWhenNotFound() {
        when(orderItemRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.getOrderItemById(1L))
                .isInstanceOf(OrderItemNotFoundException.class);
    }

    @Test
    void getOrderItemById_returnsFound() {
        OrderItem item = new OrderItem(1L, 5L, 2, null);
        item.setItemId(1L);
        when(orderItemRepository.findById(1L)).thenReturn(Optional.of(item));

        assertThat(service.getOrderItemById(1L)).isEqualTo(item);
    }

    @Test
    void getAllOrderItems_delegatesToRepository() {
        when(orderItemRepository.findAll()).thenReturn(List.of(new OrderItem(1L, 5L, 2, null)));

        assertThat(service.getAllOrderItems()).hasSize(1);
    }

    @Test
    void updateOrderItem_updatesAllFields() {
        OrderItem existing = new OrderItem(1L, 5L, 2, null);
        existing.setItemId(1L);
        when(orderItemRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(orderItemRepository.save(any(OrderItem.class))).thenAnswer(inv -> inv.getArgument(0));

        OrderItem update = new OrderItem(2L, 6L, 5, new BigDecimal("15.00"));
        OrderItem result = service.updateOrderItem(1L, update);

        assertThat(result.getOrderId()).isEqualTo(2L);
        assertThat(result.getMedicineId()).isEqualTo(6L);
        assertThat(result.getQuantity()).isEqualTo(5);
        assertThat(result.getPrice()).isEqualByComparingTo("15.00");
    }

    @Test
    void deleteOrderItem_throwsWhenNotFound() {
        when(orderItemRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.deleteOrderItem(1L))
                .isInstanceOf(OrderItemNotFoundException.class);
    }

    @Test
    void deleteOrderItem_deletesWhenFound() {
        OrderItem item = new OrderItem(1L, 5L, 2, null);
        item.setItemId(1L);
        when(orderItemRepository.findById(1L)).thenReturn(Optional.of(item));

        service.deleteOrderItem(1L);

        verify(orderItemRepository).delete(item);
    }

    @Test
    void getOrderItemsByOrderId_throwsWhenEmpty() {
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());

        assertThatThrownBy(() -> service.getOrderItemsByOrderId(1L))
                .isInstanceOf(OrderItemNotFoundException.class);
    }

    @Test
    void getOrderItemsByOrderId_returnsWhenPresent() {
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(new OrderItem(1L, 5L, 2, null)));

        assertThat(service.getOrderItemsByOrderId(1L)).hasSize(1);
    }
}
