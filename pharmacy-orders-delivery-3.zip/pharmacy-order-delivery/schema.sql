-- Run this against your existing Curonex Postgres schema BEFORE starting the
-- application. spring.jpa.hibernate.ddl-auto=validate will refuse to boot if
-- these columns/tables are missing, since the entities now map to them.

-- Orders: geoAddress capture + per-status timestamps + return tracking
ALTER TABLE orders ADD COLUMN IF NOT EXISTS patient_geo_address VARCHAR(50);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS confirmed_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS picked_up_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMP;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS is_returned BOOLEAN DEFAULT FALSE;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS returned_at TIMESTAMP;

-- Pharmacy: ratings + soft delete
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS rating NUMERIC(3,2) DEFAULT 0;
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;
ALTER TABLE pharmacy ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Delivery Partners: ratings + soft delete
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS rating NUMERIC(3,2) DEFAULT 0;
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;
ALTER TABLE delivery_partners ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Medicine: soft delete (master data referenced by historical orders/prescriptions)
ALTER TABLE medicine ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Prescriptions: soft delete (medical records, never hard-deleted)
ALTER TABLE prescriptions ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- New table: tracks which pharmacies declined which orders. Many-to-many by
-- nature (one order can be rejected by several pharmacies; one pharmacy can
-- reject many orders) - replaces the old in-memory OrderRejectionTracker so
-- rejections now survive restarts and work correctly across multiple
-- backend instances.
CREATE TABLE IF NOT EXISTS order_pharmacy_rejection (
    order_id BIGINT NOT NULL,
    pharmacy_id BIGINT NOT NULL,
    rejected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (order_id, pharmacy_id)
);

-- Backfill: existing rows must not be left NULL for boolean flags, since
-- the entities read them as non-null Boolean and downstream filtering
-- (findByIsDeletedFalse) treats NULL as neither true nor false in SQL.
UPDATE pharmacy SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE delivery_partners SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE medicine SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE prescriptions SET is_deleted = FALSE WHERE is_deleted IS NULL;
UPDATE orders SET is_returned = FALSE WHERE is_returned IS NULL;
