package com.curonex.pharmacy.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.curonex.pharmacy.dto.ExtractedMedicineDTO;

class PrescriptionParserUtilTest {

    @Test
    void parseMedicines_extractsSingleLineWithColon() {
        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines("Paracetamol 500mg Qty: 10");

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getMedicineName()).isEqualTo("Paracetamol 500mg");
        assertThat(result.get(0).getQuantity()).isEqualTo(10);
    }

    @Test
    void parseMedicines_extractsWithoutColon() {
        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines("Cetirizine 10mg Qty 5");

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getQuantity()).isEqualTo(5);
    }

    @Test
    void parseMedicines_caseInsensitiveQtyKeyword() {
        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines("Ibuprofen qty:20");

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getQuantity()).isEqualTo(20);
    }

    @Test
    void parseMedicines_multipleLinesAllParsed() {
        String text = "Paracetamol 500mg Qty: 10\nCetirizine 10mg Qty: 5\nIbuprofen 400mg Qty: 15";

        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines(text);

        assertThat(result).hasSize(3);
        assertThat(result).extracting(ExtractedMedicineDTO::getQuantity).containsExactly(10, 5, 15);
    }

    @Test
    void parseMedicines_skipsLinesNotMatchingPattern() {
        String text = "Patient: John Doe\nDate: 2026-01-01\nParacetamol 500mg Qty: 10\nDoctor signature";

        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines(text);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getMedicineName()).isEqualTo("Paracetamol 500mg");
    }

    @Test
    void parseMedicines_emptyTextReturnsEmptyList() {
        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines("");

        assertThat(result).isEmpty();
    }

    @Test
    void parseMedicines_handlesWindowsLineEndings() {
        String text = "Paracetamol 500mg Qty: 10\r\nCetirizine 10mg Qty: 5";

        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines(text);

        assertThat(result).hasSize(2);
    }

    @Test
    void parseMedicines_noQuantityKeywordIsSkipped() {
        List<ExtractedMedicineDTO> result = PrescriptionParserUtil.parseMedicines("Paracetamol 500mg - take twice daily");

        assertThat(result).isEmpty();
    }
}
