package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderCreateItemDTO;
import com.curonex.pharmacy.dto.OrderCreateRequestDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderTrackingDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.Medicine;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.entity.PrescriptionMedicineId;
import com.curonex.pharmacy.entity.PrescriptionMedicines;
import com.curonex.pharmacy.entity.Prescriptions;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.exceptions.MedicineNotFoundException;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.exceptions.PrescriptionNotFoundException;
import com.curonex.pharmacy.exceptions.PrescriptionQuantityExceededException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.MedicineRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.repository.PrescriptionMedicinesRepository;
import com.curonex.pharmacy.repository.PrescriptionsRepository;
import com.curonex.pharmacy.service.PharmacyRoutingService;

@ExtendWith(MockitoExtension.class)
class OrderServiceImplTest {

    @Mock private OrderRepository orderRepository;
    @Mock private OrderItemRepository orderItemRepository;
    @Mock private MedicineRepository medicineRepository;
    @Mock private PharmacyRepository pharmacyRepository;
    @Mock private DeliveryPartnerRepository deliveryPartnerRepository;
    @Mock private PrescriptionsRepository prescriptionsRepository;
    @Mock private PrescriptionMedicinesRepository prescriptionMedicinesRepository;
    @Mock private DetailsFeignClient detailsFeignClient;
    @Mock private PharmacyRoutingService pharmacyRoutingService;
    @Mock private OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;
    @Mock private ApplicationEventPublisher eventPublisher;

    private OrderServiceImpl orderService;

    @BeforeEach
    void setUp() {
        orderService = new OrderServiceImpl(
                orderRepository, orderItemRepository, medicineRepository, pharmacyRepository,
                deliveryPartnerRepository, prescriptionsRepository, prescriptionMedicinesRepository,
                detailsFeignClient, pharmacyRoutingService, orderPharmacyRejectionRepository, eventPublisher);
    }

    private Medicine medicine(Long id, String name) {
        Medicine m = new Medicine();
        m.setMedicineId(id);
        m.setName(name);
        m.setIsDeleted(false);
        return m;
    }

    private Orders order(Long id, OrderStatusEnum status) {
        Orders o = new Orders();
        o.setOrderId(id);
        o.setUserId(1L);
        o.setStatus(status);
        o.setOrderDatetime(Timestamp.from(Instant.now()));
        return o;
    }

    private Prescriptions prescription(Long id, Long hospitalId) {
        Prescriptions p = new Prescriptions();
        p.setPrescriptionId(id);
        p.setUserId(1L);
        p.setHospitalId(hospitalId);
        return p;
    }

    private PrescriptionMedicines prescribedMedicine(Long prescriptionId, Long medicineId, int quantity) {
        PrescriptionMedicines pm = new PrescriptionMedicines();
        pm.setId(new PrescriptionMedicineId(prescriptionId, medicineId));
        pm.setQuantity(quantity);
        return pm;
    }

    private OrderCreateRequestDTO baseRequest(Long prescriptionId, OrderCreateItemDTO... items) {
        OrderCreateRequestDTO request = new OrderCreateRequestDTO();
        request.setUserId(1L);
        request.setPatientGeoAddress("13.09,80.27");
        request.setPrescriptionId(prescriptionId);
        request.setItems(List.of(items));
        return request;
    }

    private OrderCreateItemDTO item(Long medicineId, int quantity) {
        OrderCreateItemDTO item = new OrderCreateItemDTO();
        item.setMedicineId(medicineId);
        item.setQuantity(quantity);
        return item;
    }

    @Test
    void createOrder_throwsWhenItemsEmpty() {
        OrderCreateRequestDTO request = new OrderCreateRequestDTO();
        request.setUserId(1L);
        request.setPrescriptionId(50L);
        request.setItems(List.of());

        assertThatThrownBy(() -> orderService.createOrder(request))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void createOrder_throwsWhenPrescriptionNotFound() {
        OrderCreateRequestDTO request = baseRequest(50L, item(5L, 2));
        when(prescriptionsRepository.findById(50L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> orderService.createOrder(request))
                .isInstanceOf(PrescriptionNotFoundException.class);
    }

    @Test
    void createOrder_throwsWhenQuantityExceedsPrescribedAmount() {
        OrderCreateRequestDTO request = baseRequest(50L, item(5L, 10)); // asking for 10
        when(prescriptionsRepository.findById(50L)).thenReturn(Optional.of(prescription(50L, null)));
        when(prescriptionMedicinesRepository.findByIdPrescriptionId(50L))
                .thenReturn(List.of(prescribedMedicine(50L, 5L, 3))); // only 3 were prescribed

        assertThatThrownBy(() -> orderService.createOrder(request))
                .isInstanceOf(PrescriptionQuantityExceededException.class)
                .hasMessageContaining("exceeds the prescribed amount");
    }

    @Test
    void createOrder_throwsWhenMedicineNotOnThePrescriptionAtAll() {
        OrderCreateRequestDTO request = baseRequest(50L, item(99L, 1)); // medicine 99 never prescribed
        when(prescriptionsRepository.findById(50L)).thenReturn(Optional.of(prescription(50L, null)));
        when(prescriptionMedicinesRepository.findByIdPrescriptionId(50L))
                .thenReturn(List.of(prescribedMedicine(50L, 5L, 3)));

        assertThatThrownBy(() -> orderService.createOrder(request))
                .isInstanceOf(PrescriptionQuantityExceededException.class)
                .hasMessageContaining("not part of prescription");
    }

    @Test
    void createOrder_allowsQuantityAtOrBelowPrescribedCeiling() {
        OrderCreateRequestDTO request = baseRequest(50L, item(5L, 3)); // exactly at ceiling
        when(prescriptionsRepository.findById(50L)).thenReturn(Optional.of(prescription(50L, null)));
        when(prescriptionMedicinesRepository.findByIdPrescriptionId(50L))
                .thenReturn(List.of(prescribedMedicine(50L, 5L, 3)));
        when(medicineRepository.findByMedicineIdAndIsDeletedFalse(5L)).thenReturn(Optional.of(medicine(5L, "Paracetamol")));

        Orders saved = order(100L, OrderStatusEnum.PENDING);
        when(orderRepository.save(any(Orders.class))).thenReturn(saved);
        when(orderItemRepository.findByOrderId(100L)).thenReturn(List.of());
        when(medicineRepository.findAllById(any())).thenReturn(List.of());

        OrderResponseDTO result = orderService.createOrder(request);

        assertThat(result.getOrderId()).isEqualTo(100L);
    }

    @Test
    void createOrder_throwsWhenMedicineIsSoftDeleted() {
        OrderCreateRequestDTO request = baseRequest(50L, item(5L, 1));
        when(prescriptionsRepository.findById(50L)).thenReturn(Optional.of(prescription(50L, null)));
        when(prescriptionMedicinesRepository.findByIdPrescriptionId(50L))
                .thenReturn(List.of(prescribedMedicine(50L, 5L, 5)));
        when(medicineRepository.findByMedicineIdAndIsDeletedFalse(5L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> orderService.createOrder(request))
                .isInstanceOf(MedicineNotFoundException.class);
    }

    @Test
    void createOrder_derivesHospitalIdFromPrescriptionNotFromClient() {
        OrderCreateRequestDTO request = baseRequest(50L, item(5L, 1));
        when(prescriptionsRepository.findById(50L)).thenReturn(Optional.of(prescription(50L, 99L)));
        when(prescriptionMedicinesRepository.findByIdPrescriptionId(50L))
                .thenReturn(List.of(prescribedMedicine(50L, 5L, 5)));
        when(medicineRepository.findByMedicineIdAndIsDeletedFalse(5L)).thenReturn(Optional.of(medicine(5L, "Paracetamol")));

        ArgumentCaptor<Orders> captor = ArgumentCaptor.forClass(Orders.class);
        when(orderRepository.save(captor.capture())).thenAnswer(inv -> {
            Orders saved = captor.getValue();
            saved.setOrderId(100L);
            return saved;
        });
        when(orderItemRepository.findByOrderId(100L)).thenReturn(List.of());
        when(medicineRepository.findAllById(any())).thenReturn(List.of());

        OrderResponseDTO result = orderService.createOrder(request);

        assertThat(captor.getValue().getHospitalId()).isEqualTo(99L);
        assertThat(result.getHospitalId()).isEqualTo(99L);
    }

    @Test
    void createOrder_savesItemsAndBroadcasts() {
        OrderCreateRequestDTO request = baseRequest(50L, item(5L, 2));
        when(prescriptionsRepository.findById(50L)).thenReturn(Optional.of(prescription(50L, null)));
        when(prescriptionMedicinesRepository.findByIdPrescriptionId(50L))
                .thenReturn(List.of(prescribedMedicine(50L, 5L, 5)));
        when(medicineRepository.findByMedicineIdAndIsDeletedFalse(5L)).thenReturn(Optional.of(medicine(5L, "Paracetamol")));

        Orders saved = order(100L, OrderStatusEnum.PENDING);
        when(orderRepository.save(any(Orders.class))).thenReturn(saved);
        when(orderItemRepository.findByOrderId(100L)).thenReturn(List.of());
        when(medicineRepository.findAllById(any())).thenReturn(List.of());

        OrderResponseDTO result = orderService.createOrder(request);

        assertThat(result.getOrderId()).isEqualTo(100L);
        verify(orderItemRepository, times(1)).save(any(OrderItem.class));
        verify(pharmacyRoutingService).broadcastOrder(100L, "13.09,80.27");
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void getOrderById_throwsWhenNotFound() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> orderService.getOrderById(1L))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void getOrderById_returnsMappedDto() {
        Orders o = order(1L, OrderStatusEnum.CONFIRMED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());
        when(medicineRepository.findAllById(any())).thenReturn(List.of());

        OrderResponseDTO dto = orderService.getOrderById(1L);

        assertThat(dto.getOrderId()).isEqualTo(1L);
        assertThat(dto.getStatus()).isEqualTo(OrderStatusEnum.CONFIRMED);
    }

    @Test
    void getOrdersByUser_mapsAll() {
        when(orderRepository.findByUserId(1L)).thenReturn(List.of(order(1L, OrderStatusEnum.PENDING)));
        when(orderItemRepository.findByOrderId(anyLong())).thenReturn(List.of());
        when(medicineRepository.findAllById(any())).thenReturn(List.of());

        assertThat(orderService.getOrdersByUser(1L)).hasSize(1);
    }

    @Test
    void getAllOrders_mapsAll() {
        when(orderRepository.findAll()).thenReturn(List.of(order(1L, OrderStatusEnum.PENDING)));
        when(orderItemRepository.findByOrderId(anyLong())).thenReturn(List.of());
        when(medicineRepository.findAllById(any())).thenReturn(List.of());

        assertThat(orderService.getAllOrders()).hasSize(1);
    }

    @Test
    void deleteOrder_cleansUpItemsAndRejectionsBeforeDeletingOrder() {
        Orders o = order(1L, OrderStatusEnum.PENDING);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));

        orderService.deleteOrder(1L);

        verify(orderItemRepository).deleteByOrderId(1L);
        verify(orderPharmacyRejectionRepository).deleteByIdOrderId(1L);
        verify(orderRepository).delete(o);
    }

    @Test
    void getOrderTracking_populatesPharmacyAndPartnerWhenPresent() {
        Orders o = order(1L, OrderStatusEnum.OUT_FOR_DELIVERY);
        o.setPharmacyId(10L);
        o.setDeliveryPartnerId(20L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());

        Pharmacy pharmacy = new Pharmacy();
        pharmacy.setId(10L);
        pharmacy.setGeoAddress("13.0,80.2");
        when(pharmacyRepository.findById(10L)).thenReturn(Optional.of(pharmacy));

        DetailsDTO details = new DetailsDTO();
        details.setName("Apollo Pharmacy");
        when(detailsFeignClient.getDetails(10L)).thenReturn(details);

        DeliveryPartners partner = new DeliveryPartners();
        partner.setDeliveryPartnerId(20L);
        partner.setName("Ramesh");
        partner.setMobileNumber("9999999999");
        when(deliveryPartnerRepository.findById(20L)).thenReturn(Optional.of(partner));

        OrderTrackingDTO dto = orderService.getOrderTracking(1L);

        assertThat(dto.getPharmacyName()).isEqualTo("Apollo Pharmacy");
        assertThat(dto.getDeliveryPartnerName()).isEqualTo("Ramesh");
        assertThat(dto.getDeliveryPartnerPhone()).isEqualTo("9999999999");
    }

    @Test
    void getOrderTracking_toleratesFeignFailure() {
        Orders o = order(1L, OrderStatusEnum.CONFIRMED);
        o.setPharmacyId(10L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());

        Pharmacy pharmacy = new Pharmacy();
        pharmacy.setId(10L);
        pharmacy.setGeoAddress("13.0,80.2");
        when(pharmacyRepository.findById(10L)).thenReturn(Optional.of(pharmacy));
        when(detailsFeignClient.getDetails(10L)).thenThrow(new RuntimeException("feign down"));

        OrderTrackingDTO dto = orderService.getOrderTracking(1L);

        assertThat(dto.getPharmacyName()).isNull();
    }

    @Test
    void getOrderTracking_noPharmacyOrPartner() {
        Orders o = order(1L, OrderStatusEnum.PENDING);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());

        OrderTrackingDTO dto = orderService.getOrderTracking(1L);

        assertThat(dto.getPharmacyName()).isNull();
        assertThat(dto.getDeliveryPartnerName()).isNull();
    }

    @Test
    void cancelOrder_throwsWhenNoRowsAffected() {
        when(orderRepository.cancelOrder(1L, OrderStatusEnum.CANCELLED, OrderStatusEnum.DELIVERED)).thenReturn(0);

        assertThatThrownBy(() -> orderService.cancelOrder(1L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void cancelOrder_succeedsAndCleansRejections() {
        when(orderRepository.cancelOrder(1L, OrderStatusEnum.CANCELLED, OrderStatusEnum.DELIVERED)).thenReturn(1);
        Orders cancelled = order(1L, OrderStatusEnum.CANCELLED);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(cancelled));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());

        OrderResponseDTO dto = orderService.cancelOrder(1L);

        assertThat(dto.getStatus()).isEqualTo(OrderStatusEnum.CANCELLED);
        verify(orderPharmacyRejectionRepository).deleteByIdOrderId(1L);
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void toResponseDTO_mapsItemsWithMedicineNames() {
        Orders o = order(1L, OrderStatusEnum.CONFIRMED);
        o.setTotalAmount(new BigDecimal("150.00"));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));

        OrderItem orderItem = new OrderItem(1L, 5L, 2, new BigDecimal("75.00"));
        orderItem.setItemId(1L);
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of(orderItem));
        when(medicineRepository.findAllById(any())).thenReturn(List.of(medicine(5L, "Cetirizine")));

        OrderResponseDTO dto = orderService.getOrderById(1L);

        assertThat(dto.getItems()).hasSize(1);
        assertThat(dto.getItems().get(0).getMedicineName()).isEqualTo("Cetirizine");
        assertThat(dto.getTotalAmount()).isEqualByComparingTo("150.00");
    }

    @Test
    void deleteOrder_neverDeletesItemsWhenFindFails() {
        when(orderRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> orderService.deleteOrder(404L))
                .isInstanceOf(OrderNotFoundException.class);

        verify(orderItemRepository, never()).deleteByOrderId(anyLong());
    }
}
