package com.curonex.pharmacy.scheduler;

import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.PharmacyRoutingService;

@ExtendWith(MockitoExtension.class)
class OrderRetrySchedulerTest {

    @Mock private OrderRepository orderRepository;
    @Mock private PharmacyRoutingService pharmacyRoutingService;
    @Mock private DeliveryRoutingService deliveryRoutingService;

    private OrderRetryScheduler scheduler;

    @BeforeEach
    void setUp() {
        scheduler = new OrderRetryScheduler(orderRepository, pharmacyRoutingService, deliveryRoutingService);
    }

    private Orders orderAgedMinutes(Long id, long minutesAgo) {
        Orders o = new Orders();
        o.setOrderId(id);
        o.setOrderDatetime(Timestamp.from(Instant.now().minusSeconds(minutesAgo * 60)));
        return o;
    }

    @Test
    void retryUnclaimedPharmacyOrders_rebroadcastsWhenOlderThanFiveMinutes() {
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING))
                .thenReturn(List.of(orderAgedMinutes(1L, 6)));

        scheduler.retryUnclaimedPharmacyOrders();

        verify(pharmacyRoutingService).rebroadcastOrder(1L);
    }

    @Test
    void retryUnclaimedPharmacyOrders_doesNotRebroadcastWhenUnderFiveMinutes() {
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING))
                .thenReturn(List.of(orderAgedMinutes(1L, 2)));

        scheduler.retryUnclaimedPharmacyOrders();

        verify(pharmacyRoutingService, never()).rebroadcastOrder(1L);
    }

    @Test
    void retryUnclaimedPharmacyOrders_skipsOrdersWithNullDatetime() {
        Orders noDate = new Orders();
        noDate.setOrderId(1L);
        noDate.setOrderDatetime(null);
        when(orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING))
                .thenReturn(List.of(noDate));

        scheduler.retryUnclaimedPharmacyOrders();

        verify(pharmacyRoutingService, never()).rebroadcastOrder(1L);
    }

    @Test
    void retryUnclaimedDeliveryOrders_rebroadcastsWhenOlderThanTenMinutes() {
        when(orderRepository.findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum.CONFIRMED))
                .thenReturn(List.of(orderAgedMinutes(2L, 11)));

        scheduler.retryUnclaimedDeliveryOrders();

        verify(deliveryRoutingService).rebroadcastOrder(2L);
    }

    @Test
    void retryUnclaimedDeliveryOrders_doesNotRebroadcastWhenUnderTenMinutes() {
        when(orderRepository.findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum.CONFIRMED))
                .thenReturn(List.of(orderAgedMinutes(2L, 3)));

        scheduler.retryUnclaimedDeliveryOrders();

        verify(deliveryRoutingService, never()).rebroadcastOrder(2L);
    }

    @Test
    void retryUnclaimedDeliveryOrders_skipsOrdersWithNullDatetime() {
        Orders noDate = new Orders();
        noDate.setOrderId(2L);
        noDate.setOrderDatetime(null);
        when(orderRepository.findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum.CONFIRMED))
                .thenReturn(List.of(noDate));

        scheduler.retryUnclaimedDeliveryOrders();

        verify(deliveryRoutingService, never()).rebroadcastOrder(2L);
    }
}
