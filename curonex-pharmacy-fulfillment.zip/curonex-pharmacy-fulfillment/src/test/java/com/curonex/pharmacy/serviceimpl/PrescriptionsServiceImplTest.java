package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.dto.PrescriptionsDTO;
import com.curonex.pharmacy.entity.Prescriptions;
import com.curonex.pharmacy.exceptions.PrescriptionNotFoundException;
import com.curonex.pharmacy.repository.PrescriptionsRepository;

@ExtendWith(MockitoExtension.class)
class PrescriptionsServiceImplTest {

    @Mock private PrescriptionsRepository prescriptionsRepository;

    private PrescriptionsServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new PrescriptionsServiceImpl(prescriptionsRepository);
    }

    private Prescriptions prescription(Long id) {
        Prescriptions p = new Prescriptions();
        p.setPrescriptionId(id);
        p.setUserId(1L);
        p.setHospitalId(2L);
        p.setDoctorId(3L);
        p.setIsDeleted(false);
        return p;
    }

    @Test
    void addPrescription_marksNotDeleted() {
        PrescriptionsDTO dto = new PrescriptionsDTO();
        dto.setUserId(1L);
        when(prescriptionsRepository.save(any(Prescriptions.class))).thenAnswer(inv -> inv.getArgument(0));

        PrescriptionsDTO result = service.addPrescription(dto);

        assertThat(result.getUserId()).isEqualTo(1L);
    }

    @Test
    void getPrescriptionById_throwsWhenNotFound() {
        when(prescriptionsRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.getPrescriptionById(1L))
                .isInstanceOf(PrescriptionNotFoundException.class);
    }

    @Test
    void getAllPrescriptions_usesIsDeletedFalseFilter() {
        when(prescriptionsRepository.findByIsDeletedFalse()).thenReturn(List.of(prescription(1L)));

        assertThat(service.getAllPrescriptions()).hasSize(1);
    }

    @Test
    void updatePrescription_throwsWhenNotFound() {
        when(prescriptionsRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.updatePrescription(1L, new PrescriptionsDTO()))
                .isInstanceOf(PrescriptionNotFoundException.class);
    }

    @Test
    void updatePrescription_updatesFields() {
        Prescriptions existing = prescription(1L);
        when(prescriptionsRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(prescriptionsRepository.save(any(Prescriptions.class))).thenAnswer(inv -> inv.getArgument(0));

        PrescriptionsDTO update = new PrescriptionsDTO();
        update.setUserId(99L);
        update.setHospitalId(88L);
        update.setDoctorId(77L);

        PrescriptionsDTO result = service.updatePrescription(1L, update);

        assertThat(result.getUserId()).isEqualTo(99L);
        assertThat(result.getHospitalId()).isEqualTo(88L);
        assertThat(result.getDoctorId()).isEqualTo(77L);
    }

    @Test
    void deletePrescription_throwsWhenNotFound() {
        when(prescriptionsRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.deletePrescription(1L))
                .isInstanceOf(PrescriptionNotFoundException.class);
    }

    @Test
    void deletePrescription_softDeletesOnly() {
        Prescriptions p = prescription(1L);
        when(prescriptionsRepository.findById(1L)).thenReturn(Optional.of(p));

        service.deletePrescription(1L);

        assertThat(p.getIsDeleted()).isTrue();
        verify(prescriptionsRepository, never()).deleteById(1L);
        verify(prescriptionsRepository).save(p);
    }

    @Test
    void getPrescriptionsByUser_filtersDeleted() {
        when(prescriptionsRepository.findByUserIdAndIsDeletedFalse(1L)).thenReturn(List.of(prescription(1L)));

        assertThat(service.getPrescriptionsByUser(1L)).hasSize(1);
    }
}
