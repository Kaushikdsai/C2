package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import com.curonex.pharmacy.dto.PrescriptionExtractionResponseDTO;
import com.curonex.pharmacy.service.PrescriptionExtractionService;

@ExtendWith(MockitoExtension.class)
class PrescriptionExtractionControllerTest {

    @Mock private PrescriptionExtractionService prescriptionExtractionService;

    private PrescriptionExtractionController controller;

    @BeforeEach
    void setUp() {
        controller = new PrescriptionExtractionController(prescriptionExtractionService);
    }

    @Test
    void extractPrescription_delegatesToService() {
        MockMultipartFile file = new MockMultipartFile("file", "presc.pdf", "application/pdf", "dummy".getBytes());
        PrescriptionExtractionResponseDTO response = new PrescriptionExtractionResponseDTO();
        response.setExtractedText("Paracetamol Qty: 10");
        when(prescriptionExtractionService.extractMedicines(file)).thenReturn(response);

        var result = controller.extractPrescription(file);

        assertThat(result.getBody()).isEqualTo(response);
    }
}
