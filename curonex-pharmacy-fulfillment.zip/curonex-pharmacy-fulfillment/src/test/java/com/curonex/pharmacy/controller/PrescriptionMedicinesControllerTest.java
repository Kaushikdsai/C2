package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.curonex.pharmacy.dto.PrescriptionMedicinesDTO;
import com.curonex.pharmacy.service.PrescriptionMedicinesService;

@ExtendWith(MockitoExtension.class)
class PrescriptionMedicinesControllerTest {

    @Mock private PrescriptionMedicinesService service;

    private PrescriptionMedicinesController controller;

    @BeforeEach
    void setUp() {
        controller = new PrescriptionMedicinesController(service);
    }

    @Test
    void addMedicine_delegates() {
        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        when(service.addMedicine(1L, dto)).thenReturn(dto);

        assertThat(controller.addMedicine(1L, dto).getBody()).isEqualTo(dto);
    }

    @Test
    void getMedicinesByPrescription_delegates() {
        when(service.getMedicinesByPrescription(1L)).thenReturn(List.of(new PrescriptionMedicinesDTO()));

        assertThat(controller.getMedicinesByPrescription(1L).getBody()).hasSize(1);
    }

    @Test
    void updateMedicine_delegates() {
        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        when(service.updateMedicine(1L, 5L, dto)).thenReturn(dto);

        assertThat(controller.updateMedicine(1L, 5L, dto).getBody()).isEqualTo(dto);
    }

    @Test
    void deleteMedicine_returns204() {
        ResponseEntity<Void> result = controller.deleteMedicine(1L, 5L);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.NO_CONTENT);
        verify(service).deleteMedicine(1L, 5L);
    }
}
