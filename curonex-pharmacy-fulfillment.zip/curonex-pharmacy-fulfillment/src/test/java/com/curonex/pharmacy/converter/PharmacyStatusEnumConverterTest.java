package com.curonex.pharmacy.converter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

import com.curonex.pharmacy.enums.PharmacyStatusEnum;

class PharmacyStatusEnumConverterTest {

    private final PharmacyStatusEnumConverter converter = new PharmacyStatusEnumConverter();

    @Test
    void convertToDatabaseColumn_mapsEnumToDbValue() {
        assertThat(converter.convertToDatabaseColumn(PharmacyStatusEnum.SUSPENDED)).isEqualTo("suspended");
    }

    @Test
    void convertToDatabaseColumn_nullReturnsNull() {
        assertThat(converter.convertToDatabaseColumn(null)).isNull();
    }

    @Test
    void convertToEntityAttribute_mapsDbValueToEnum() {
        assertThat(converter.convertToEntityAttribute("active")).isEqualTo(PharmacyStatusEnum.ACTIVE);
    }

    @Test
    void convertToEntityAttribute_nullReturnsNull() {
        assertThat(converter.convertToEntityAttribute(null)).isNull();
    }

    @Test
    void convertToEntityAttribute_throwsOnUnknownValue() {
        assertThatThrownBy(() -> converter.convertToEntityAttribute("nope"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void roundTrip_everyEnumValueSurvivesConversion() {
        for (PharmacyStatusEnum value : PharmacyStatusEnum.values()) {
            String db = converter.convertToDatabaseColumn(value);
            assertThat(converter.convertToEntityAttribute(db)).isEqualTo(value);
        }
    }
}
