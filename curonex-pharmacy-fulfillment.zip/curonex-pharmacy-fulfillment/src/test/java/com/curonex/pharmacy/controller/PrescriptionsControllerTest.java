package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.curonex.pharmacy.dto.PrescriptionsDTO;
import com.curonex.pharmacy.service.PrescriptionsService;

@ExtendWith(MockitoExtension.class)
class PrescriptionsControllerTest {

    @Mock private PrescriptionsService prescriptionsService;

    private PrescriptionsController controller;

    @BeforeEach
    void setUp() {
        controller = new PrescriptionsController(prescriptionsService);
    }

    @Test
    void addPrescription_delegates() {
        PrescriptionsDTO dto = new PrescriptionsDTO();
        when(prescriptionsService.addPrescription(dto)).thenReturn(dto);

        assertThat(controller.addPrescription(dto).getBody()).isEqualTo(dto);
    }

    @Test
    void getPrescriptionById_delegates() {
        PrescriptionsDTO dto = new PrescriptionsDTO();
        when(prescriptionsService.getPrescriptionById(1L)).thenReturn(dto);

        assertThat(controller.getPrescriptionById(1L).getBody()).isEqualTo(dto);
    }

    @Test
    void getAllPrescriptions_delegates() {
        when(prescriptionsService.getAllPrescriptions()).thenReturn(List.of(new PrescriptionsDTO()));

        assertThat(controller.getAllPrescriptions().getBody()).hasSize(1);
    }

    @Test
    void updatePrescription_delegates() {
        PrescriptionsDTO dto = new PrescriptionsDTO();
        when(prescriptionsService.updatePrescription(1L, dto)).thenReturn(dto);

        assertThat(controller.updatePrescription(1L, dto).getBody()).isEqualTo(dto);
    }

    @Test
    void deletePrescription_returns204() {
        ResponseEntity<Void> result = controller.deletePrescription(1L);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.NO_CONTENT);
        verify(prescriptionsService).deletePrescription(1L);
    }

    @Test
    void getPrescriptionsByUser_delegates() {
        when(prescriptionsService.getPrescriptionsByUser(1L)).thenReturn(List.of(new PrescriptionsDTO()));

        assertThat(controller.getPrescriptionsByUser(1L).getBody()).hasSize(1);
    }
}
