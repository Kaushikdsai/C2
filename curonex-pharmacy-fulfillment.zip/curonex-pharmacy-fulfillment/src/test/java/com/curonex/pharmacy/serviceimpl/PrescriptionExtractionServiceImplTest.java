package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.ByteArrayOutputStream;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import com.curonex.pharmacy.dto.PrescriptionExtractionResponseDTO;

class PrescriptionExtractionServiceImplTest {

    private final PrescriptionExtractionServiceImpl service = new PrescriptionExtractionServiceImpl();

    @Test
    void extractMedicines_throwsWhenFileNull() {
        assertThatThrownBy(() -> service.extractMedicines(null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("required");
    }

    @Test
    void extractMedicines_throwsWhenFileEmpty() {
        MockMultipartFile empty = new MockMultipartFile("file", "presc.pdf", "application/pdf", new byte[0]);

        assertThatThrownBy(() -> service.extractMedicines(empty))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("required");
    }

    @Test
    void extractMedicines_throwsWhenNotPdfExtension() {
        MockMultipartFile notPdf = new MockMultipartFile("file", "presc.txt", "text/plain", "hello".getBytes());

        assertThatThrownBy(() -> service.extractMedicines(notPdf))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("PDF");
    }

    @Test
    void extractMedicines_parsesRealPdfIntoMedicines() throws Exception {
        byte[] pdfBytes = buildPdfWithText("Paracetamol 500mg Qty: 10\nCetirizine 10mg Qty:5");
        MockMultipartFile pdf = new MockMultipartFile("file", "presc.pdf", "application/pdf", pdfBytes);

        PrescriptionExtractionResponseDTO result = service.extractMedicines(pdf);

        assertThat(result.getExtractedText()).contains("Paracetamol");
        assertThat(result.getMedicines()).hasSize(2);
        assertThat(result.getMedicines().get(0).getMedicineName()).isEqualTo("Paracetamol 500mg");
        assertThat(result.getMedicines().get(0).getQuantity()).isEqualTo(10);
    }

    @Test
    void extractMedicines_wrapsCorruptPdfBytesAsRuntimeException() {
        MockMultipartFile corrupt = new MockMultipartFile("file", "presc.pdf", "application/pdf", "not a real pdf".getBytes());

        assertThatThrownBy(() -> service.extractMedicines(corrupt))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Failed to extract prescription");
    }

    private byte[] buildPdfWithText(String text) throws Exception {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);
            try (PDPageContentStream stream = new PDPageContentStream(document, page)) {
                stream.beginText();
                stream.setFont(PDType1Font.HELVETICA, 12);
                stream.newLineAtOffset(50, 700);
                for (String line : text.split("\n")) {
                    stream.showText(line);
                    stream.newLineAtOffset(0, -20);
                }
                stream.endText();
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            document.save(out);
            return out.toByteArray();
        }
    }
}
