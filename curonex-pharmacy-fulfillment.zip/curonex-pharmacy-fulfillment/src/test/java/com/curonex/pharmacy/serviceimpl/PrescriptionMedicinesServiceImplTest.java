package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.dto.PrescriptionMedicinesDTO;
import com.curonex.pharmacy.entity.PrescriptionMedicineId;
import com.curonex.pharmacy.entity.PrescriptionMedicines;
import com.curonex.pharmacy.repository.PrescriptionMedicinesRepository;

@ExtendWith(MockitoExtension.class)
class PrescriptionMedicinesServiceImplTest {

    @Mock private PrescriptionMedicinesRepository repository;

    private PrescriptionMedicinesServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new PrescriptionMedicinesServiceImpl(repository);
    }

    @Test
    void addMedicine_savesAndMapsBack() {
        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setMedicineId(5L);
        dto.setQuantity(3);

        when(repository.save(any(PrescriptionMedicines.class))).thenAnswer(inv -> inv.getArgument(0));

        PrescriptionMedicinesDTO result = service.addMedicine(1L, dto);

        assertThat(result.getPrescriptionId()).isEqualTo(1L);
        assertThat(result.getMedicineId()).isEqualTo(5L);
        assertThat(result.getQuantity()).isEqualTo(3);
    }

    @Test
    void getMedicinesByPrescription_mapsAll() {
        PrescriptionMedicines pm = new PrescriptionMedicines();
        pm.setId(new PrescriptionMedicineId(1L, 5L));
        pm.setQuantity(2);
        when(repository.findByIdPrescriptionId(1L)).thenReturn(List.of(pm));

        List<PrescriptionMedicinesDTO> result = service.getMedicinesByPrescription(1L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getMedicineId()).isEqualTo(5L);
    }

    @Test
    void updateMedicine_throwsWhenNotFound() {
        PrescriptionMedicineId id = new PrescriptionMedicineId(1L, 5L);
        when(repository.findById(id)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.updateMedicine(1L, 5L, new PrescriptionMedicinesDTO()))
                .isInstanceOf(RuntimeException.class);
    }

    @Test
    void updateMedicine_updatesQuantity() {
        PrescriptionMedicineId id = new PrescriptionMedicineId(1L, 5L);
        PrescriptionMedicines existing = new PrescriptionMedicines();
        existing.setId(id);
        existing.setQuantity(1);
        when(repository.findById(id)).thenReturn(Optional.of(existing));
        when(repository.save(any(PrescriptionMedicines.class))).thenAnswer(inv -> inv.getArgument(0));

        PrescriptionMedicinesDTO update = new PrescriptionMedicinesDTO();
        update.setQuantity(9);

        PrescriptionMedicinesDTO result = service.updateMedicine(1L, 5L, update);

        assertThat(result.getQuantity()).isEqualTo(9);
    }

    @Test
    void deleteMedicine_delegatesToRepositoryWithCompositeKey() {
        service.deleteMedicine(1L, 5L);

        verify(repository).deleteById(new PrescriptionMedicineId(1L, 5L));
    }
}
