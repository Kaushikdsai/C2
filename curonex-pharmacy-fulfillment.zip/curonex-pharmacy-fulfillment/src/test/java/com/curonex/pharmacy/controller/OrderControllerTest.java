package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.curonex.pharmacy.dto.OrderCreateRequestDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.OrderTrackingDTO;
import com.curonex.pharmacy.service.OrderService;

@ExtendWith(MockitoExtension.class)
class OrderControllerTest {

    @Mock private OrderService orderService;

    private OrderController controller;

    @BeforeEach
    void setUp() {
        controller = new OrderController(orderService);
    }

    @Test
    void createOrder_returns201WithBody() {
        OrderCreateRequestDTO request = new OrderCreateRequestDTO();
        OrderResponseDTO response = new OrderResponseDTO();
        response.setOrderId(1L);
        when(orderService.createOrder(request)).thenReturn(response);

        ResponseEntity<OrderResponseDTO> result = controller.createOrder(request);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(result.getBody().getOrderId()).isEqualTo(1L);
    }

    @Test
    void getOrderById_delegatesToService() {
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setOrderId(5L);
        when(orderService.getOrderById(5L)).thenReturn(dto);

        assertThat(controller.getOrderById(5L).getBody().getOrderId()).isEqualTo(5L);
    }

    @Test
    void getAllOrders_delegatesToService() {
        when(orderService.getAllOrders()).thenReturn(List.of(new OrderResponseDTO()));

        assertThat(controller.getAllOrders().getBody()).hasSize(1);
    }

    @Test
    void getAllOrdersPaged_delegatesToService() {
        Page<OrderResponseDTO> page = new PageImpl<>(List.of(new OrderResponseDTO()));
        when(orderService.getAllOrders(any(Pageable.class))).thenReturn(page);

        ResponseEntity<Page<OrderResponseDTO>> result = controller.getAllOrdersPaged(Pageable.unpaged());

        assertThat(result.getBody().getContent()).hasSize(1);
    }

    @Test
    void getOrdersByUser_delegatesToService() {
        when(orderService.getOrdersByUser(1L)).thenReturn(List.of(new OrderResponseDTO()));

        assertThat(controller.getOrdersByUser(1L).getBody()).hasSize(1);
    }

    @Test
    void getOrderTracking_delegatesToService() {
        OrderTrackingDTO tracking = new OrderTrackingDTO();
        tracking.setOrderId(1L);
        when(orderService.getOrderTracking(1L)).thenReturn(tracking);

        assertThat(controller.getOrderTracking(1L).getBody().getOrderId()).isEqualTo(1L);
    }

    @Test
    void cancelOrder_delegatesToService() {
        OrderResponseDTO dto = new OrderResponseDTO();
        when(orderService.cancelOrder(1L)).thenReturn(dto);

        assertThat(controller.cancelOrder(1L).getBody()).isEqualTo(dto);
    }
}
