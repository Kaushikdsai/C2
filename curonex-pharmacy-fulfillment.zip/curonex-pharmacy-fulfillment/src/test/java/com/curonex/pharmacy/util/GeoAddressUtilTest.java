package com.curonex.pharmacy.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

import com.curonex.pharmacy.dto.CoordinateDTO;

class GeoAddressUtilTest {

    private final GeoAddressUtil geoAddressUtil = new GeoAddressUtil();

    @Test
    void parse_validGeoAddress() {
        CoordinateDTO result = geoAddressUtil.parse("13.0827,80.2707");

        assertThat(result.getLatitude()).isEqualTo(13.0827);
        assertThat(result.getLongitude()).isEqualTo(80.2707);
    }

    @Test
    void parse_trimsWhitespaceAroundValues() {
        CoordinateDTO result = geoAddressUtil.parse(" 13.0827 , 80.2707 ");

        assertThat(result.getLatitude()).isEqualTo(13.0827);
        assertThat(result.getLongitude()).isEqualTo(80.2707);
    }

    @Test
    void parse_handlesNegativeCoordinates() {
        CoordinateDTO result = geoAddressUtil.parse("-33.8688,151.2093");

        assertThat(result.getLatitude()).isEqualTo(-33.8688);
        assertThat(result.getLongitude()).isEqualTo(151.2093);
    }

    @Test
    void parse_throwsWhenNull() {
        assertThatThrownBy(() -> geoAddressUtil.parse(null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("cannot be null or empty");
    }

    @Test
    void parse_throwsWhenBlank() {
        assertThatThrownBy(() -> geoAddressUtil.parse("   "))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("cannot be null or empty");
    }

    @Test
    void parse_throwsWhenMissingComma() {
        assertThatThrownBy(() -> geoAddressUtil.parse("13.0827"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Invalid geoAddress format");
    }

    @Test
    void parse_throwsWhenTooManyParts() {
        assertThatThrownBy(() -> geoAddressUtil.parse("13.0827,80.2707,99.0"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Invalid geoAddress format");
    }

    @Test
    void parse_throwsWhenNonNumeric() {
        assertThatThrownBy(() -> geoAddressUtil.parse("abc,def"))
                .isInstanceOf(NumberFormatException.class);
    }
}
