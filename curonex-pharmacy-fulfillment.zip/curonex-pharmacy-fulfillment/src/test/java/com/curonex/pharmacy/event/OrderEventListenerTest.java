package com.curonex.pharmacy.event;

import static org.assertj.core.api.Assertions.assertThatCode;

import org.junit.jupiter.api.Test;

import com.curonex.pharmacy.enums.OrderStatusEnum;

class OrderEventListenerTest {

    private final OrderEventListener listener = new OrderEventListener();

    @Test
    void onOrderStatusChanged_handlesEventWithoutThrowing() {
        OrderStatusChangedEvent event = new OrderStatusChangedEvent(1L, OrderStatusEnum.CONFIRMED, "test message");

        assertThatCode(() -> listener.onOrderStatusChanged(event)).doesNotThrowAnyException();
    }

    @Test
    void onOrderStatusChanged_handlesNullMessageGracefully() {
        OrderStatusChangedEvent event = new OrderStatusChangedEvent(1L, OrderStatusEnum.PENDING, null);

        assertThatCode(() -> listener.onOrderStatusChanged(event)).doesNotThrowAnyException();
    }
}
