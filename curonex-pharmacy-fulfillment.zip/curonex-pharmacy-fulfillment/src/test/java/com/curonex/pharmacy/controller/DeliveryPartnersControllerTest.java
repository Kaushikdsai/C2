package com.curonex.pharmacy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.curonex.pharmacy.dto.ActiveDeliveryDTO;
import com.curonex.pharmacy.dto.AvailableOrderDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerDashboardDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerProfileDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.RatingRequestDTO;
import com.curonex.pharmacy.service.DeliveryPartnersService;
import com.curonex.pharmacy.service.DeliveryRoutingService;

@ExtendWith(MockitoExtension.class)
class DeliveryPartnersControllerTest {

    @Mock private DeliveryPartnersService deliveryPartnersService;
    @Mock private DeliveryRoutingService deliveryRoutingService;

    private DeliveryPartnersController controller;

    @BeforeEach
    void setUp() {
        controller = new DeliveryPartnersController(deliveryPartnersService, deliveryRoutingService);
    }

    @Test
    void addDeliveryPartner_delegates() {
        DeliveryPartnerDTO dto = new DeliveryPartnerDTO();
        when(deliveryPartnersService.addDeliveryPartner(dto)).thenReturn(dto);

        assertThat(controller.addDeliveryPartner(dto).getBody()).isEqualTo(dto);
    }

    @Test
    void getDeliveryPartnerById_delegates() {
        DeliveryPartnerDTO dto = new DeliveryPartnerDTO();
        when(deliveryPartnersService.getDeliveryPartnerById(1L)).thenReturn(dto);

        assertThat(controller.getDeliveryPartnerById(1L).getBody()).isEqualTo(dto);
    }

    @Test
    void getAllDeliveryPartners_delegates() {
        when(deliveryPartnersService.getAllDeliveryPartners()).thenReturn(List.of(new DeliveryPartnerDTO()));

        assertThat(controller.getAllDeliveryPartners().getBody()).hasSize(1);
    }

    @Test
    void updateDeliveryPartner_delegates() {
        DeliveryPartnerDTO dto = new DeliveryPartnerDTO();
        when(deliveryPartnersService.updateDeliveryPartner(1L, dto)).thenReturn(dto);

        assertThat(controller.updateDeliveryPartner(1L, dto).getBody()).isEqualTo(dto);
    }

    @Test
    void deleteDeliveryPartner_returns204() {
        ResponseEntity<Void> result = controller.deleteDeliveryPartner(1L);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.NO_CONTENT);
        verify(deliveryPartnersService).deleteDeliveryPartner(1L);
    }

    @Test
    void getAvailableDeliveryPartners_delegates() {
        when(deliveryPartnersService.getAvailableDeliveryPartners()).thenReturn(List.of(new DeliveryPartnerDTO()));

        assertThat(controller.getAvailableDeliveryPartners().getBody()).hasSize(1);
    }

    @Test
    void markAvailable_delegates() {
        when(deliveryPartnersService.markAvailable(1L)).thenReturn(true);

        assertThat(controller.markAvailable(1L).getBody()).isTrue();
    }

    @Test
    void markOnDelivery_delegates() {
        when(deliveryPartnersService.markOnDelivery(1L)).thenReturn(true);

        assertThat(controller.markOnDelivery(1L).getBody()).isTrue();
    }

    @Test
    void markOffline_delegates() {
        when(deliveryPartnersService.markOffline(1L)).thenReturn(true);

        assertThat(controller.markOffline(1L).getBody()).isTrue();
    }

    @Test
    void getProfile_delegates() {
        DeliveryPartnerProfileDTO dto = new DeliveryPartnerProfileDTO();
        when(deliveryPartnersService.getPartnerProfile(1L)).thenReturn(dto);

        assertThat(controller.getProfile(1L).getBody()).isEqualTo(dto);
    }

    @Test
    void updateProfile_delegates() {
        DeliveryPartnerProfileDTO dto = new DeliveryPartnerProfileDTO();
        when(deliveryPartnersService.updatePartnerProfile(1L, dto)).thenReturn(dto);

        assertThat(controller.updateProfile(1L, dto).getBody()).isEqualTo(dto);
    }

    @Test
    void submitRating_delegates() {
        RatingRequestDTO request = new RatingRequestDTO();
        request.setRating(new BigDecimal("4.8"));
        DeliveryPartnerProfileDTO dto = new DeliveryPartnerProfileDTO();
        when(deliveryPartnersService.submitRating(1L, new BigDecimal("4.8"))).thenReturn(dto);

        assertThat(controller.submitRating(1L, request).getBody()).isEqualTo(dto);
    }

    @Test
    void getDashboard_delegates() {
        DeliveryPartnerDashboardDTO dto = new DeliveryPartnerDashboardDTO();
        when(deliveryPartnersService.getDashboard(1L)).thenReturn(dto);

        assertThat(controller.getDashboard(1L).getBody()).isEqualTo(dto);
    }

    @Test
    void getAvailableOrders_delegatesToRoutingService() {
        when(deliveryRoutingService.getAvailableOrdersForPartner(1L)).thenReturn(List.of(new AvailableOrderDTO()));

        assertThat(controller.getAvailableOrders(1L).getBody()).hasSize(1);
    }

    @Test
    void getActiveDeliveries_delegates() {
        when(deliveryRoutingService.getActiveDeliveriesForPartner(1L)).thenReturn(List.of(new ActiveDeliveryDTO()));

        assertThat(controller.getActiveDeliveries(1L).getBody()).hasSize(1);
    }

    @Test
    void getDeliveryHistory_delegates() {
        when(deliveryRoutingService.getDeliveryHistoryForPartner(1L)).thenReturn(List.of(new OrderResponseDTO()));

        assertThat(controller.getDeliveryHistory(1L).getBody()).hasSize(1);
    }

    @Test
    void acceptDelivery_delegates() {
        when(deliveryRoutingService.acceptDelivery(1L, 20L)).thenReturn(true);

        assertThat(controller.acceptDelivery(1L, 20L).getBody()).isTrue();
    }

    @Test
    void cancelDelivery_delegates() {
        when(deliveryRoutingService.cancelDelivery(1L, 20L)).thenReturn(true);

        assertThat(controller.cancelDelivery(1L, 20L).getBody()).isTrue();
    }

    @Test
    void pickupOrder_delegates() {
        when(deliveryRoutingService.pickupOrder(1L, 20L)).thenReturn(true);

        assertThat(controller.pickupOrder(1L, 20L).getBody()).isTrue();
    }

    @Test
    void markDelivered_delegates() {
        when(deliveryRoutingService.markDelivered(1L, 20L)).thenReturn(true);

        assertThat(controller.markDelivered(1L, 20L).getBody()).isTrue();
    }
}
