package com.curonex.pharmacy.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

import org.junit.jupiter.api.Test;

class DistanceUtilTest {

    private final DistanceUtil distanceUtil = new DistanceUtil();

    @Test
    void calculateDistance_zeroForIdenticalPoints() {
        double distance = distanceUtil.calculateDistance(13.0827, 80.2707, 13.0827, 80.2707);

        assertThat(distance).isCloseTo(0.0, within(0.001));
    }

    @Test
    void calculateDistance_matchesKnownChennaiToDelhiDistance() {
        // Chennai to Delhi is approximately 1760 km great-circle distance.
        double distance = distanceUtil.calculateDistance(13.0827, 80.2707, 28.6139, 77.2090);

        assertThat(distance).isCloseTo(1760.0, within(50.0));
    }

    @Test
    void calculateDistance_shortDistanceWithinACity() {
        // Two points ~1.1km apart within Chennai.
        double distance = distanceUtil.calculateDistance(13.0827, 80.2707, 13.0900, 80.2800);

        assertThat(distance).isLessThan(2.0);
        assertThat(distance).isGreaterThan(0.5);
    }

    @Test
    void calculateDistance_isSymmetric() {
        double forward = distanceUtil.calculateDistance(13.0827, 80.2707, 28.6139, 77.2090);
        double backward = distanceUtil.calculateDistance(28.6139, 77.2090, 13.0827, 80.2707);

        assertThat(forward).isCloseTo(backward, within(0.0001));
    }
}
