package com.curonex.pharmacy.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.ActiveDeliveryDTO;
import com.curonex.pharmacy.dto.AvailableOrderDTO;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.entity.DeliveryPartners;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.exceptions.OrderNotFoundException;
import com.curonex.pharmacy.repository.DeliveryPartnerRepository;
import com.curonex.pharmacy.repository.MedicineRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.util.DistanceUtil;
import com.curonex.pharmacy.util.GeoAddressUtil;
import org.springframework.context.ApplicationEventPublisher;

@ExtendWith(MockitoExtension.class)
class DeliveryRoutingServiceImplTest {

    @Mock private DeliveryPartnerRepository deliveryPartnerRepository;
    @Mock private OrderRepository orderRepository;
    @Mock private OrderItemRepository orderItemRepository;
    @Mock private MedicineRepository medicineRepository;
    @Mock private PharmacyRepository pharmacyRepository;
    @Mock private DetailsFeignClient detailsFeignClient;
    @Mock private ApplicationEventPublisher eventPublisher;

    private DeliveryRoutingServiceImpl service;

    // Real (non-mocked) utils since they're pure logic and cheap to run for real.
    private final DistanceUtil distanceUtil = new DistanceUtil();
    private final GeoAddressUtil geoAddressUtil = new GeoAddressUtil();

    @BeforeEach
    void setUp() {
        service = new DeliveryRoutingServiceImpl(
                deliveryPartnerRepository, orderRepository, orderItemRepository, medicineRepository,
                pharmacyRepository, detailsFeignClient, distanceUtil, geoAddressUtil, eventPublisher);
    }

    private DeliveryPartners partner(Long id, String geo, DeliveryPartnerStatusEnum status) {
        DeliveryPartners p = new DeliveryPartners();
        p.setDeliveryPartnerId(id);
        p.setGeoAddress(geo);
        p.setStatus(status);
        return p;
    }

    private Orders order(Long id, OrderStatusEnum status) {
        Orders o = new Orders();
        o.setOrderId(id);
        o.setUserId(1L);
        o.setStatus(status);
        return o;
    }

    // findNearbyDeliveryPartners is no longer part of the public interface -
    // it was an unused REST endpoint and is now a private helper only
    // reachable via broadcastOrder(). Its radius/null-geoAddress filtering
    // is exercised indirectly by broadcastOrder_looksUpNearbyPartnersWhenPharmacyAssigned()
    // below, using real (non-mocked) distance math.

    @Test
    void acceptDelivery_throwsConflictWhenAlreadyClaimed() {
        when(orderRepository.acceptOrderByDeliveryPartner(1L, 20L, OrderStatusEnum.CONFIRMED)).thenReturn(0);

        assertThatThrownBy(() -> service.acceptDelivery(1L, 20L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void acceptDelivery_marksPartnerOnDeliveryOnSuccess() {
        when(orderRepository.acceptOrderByDeliveryPartner(1L, 20L, OrderStatusEnum.CONFIRMED)).thenReturn(1);
        DeliveryPartners p = partner(20L, "13.0,80.2", DeliveryPartnerStatusEnum.AVAILABLE);
        when(deliveryPartnerRepository.findById(20L)).thenReturn(Optional.of(p));

        boolean result = service.acceptDelivery(1L, 20L);

        assertThat(result).isTrue();
        assertThat(p.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.ON_DELIVERY);
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void cancelDelivery_throwsWhenNotAssigned() {
        when(orderRepository.releaseOrderFromDeliveryPartner(1L, 20L, OrderStatusEnum.CONFIRMED)).thenReturn(0);

        assertThatThrownBy(() -> service.cancelDelivery(1L, 20L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void cancelDelivery_freesPartnerAndRebroadcasts() {
        when(orderRepository.releaseOrderFromDeliveryPartner(1L, 20L, OrderStatusEnum.CONFIRMED)).thenReturn(1);
        DeliveryPartners p = partner(20L, "13.0,80.2", DeliveryPartnerStatusEnum.ON_DELIVERY);
        when(deliveryPartnerRepository.findById(20L)).thenReturn(Optional.of(p));

        Orders o = order(1L, OrderStatusEnum.CONFIRMED);
        o.setPharmacyId(5L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        Pharmacy pharmacy = new Pharmacy();
        pharmacy.setId(5L);
        pharmacy.setGeoAddress("13.0,80.2");
        when(pharmacyRepository.findById(5L)).thenReturn(Optional.of(pharmacy));
        when(deliveryPartnerRepository.findByStatus(DeliveryPartnerStatusEnum.AVAILABLE)).thenReturn(List.of());

        boolean result = service.cancelDelivery(1L, 20L);

        assertThat(result).isTrue();
        assertThat(p.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.AVAILABLE);
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void pickupOrder_throwsOnConflict() {
        when(orderRepository.pickupOrderByDeliveryPartner(1L, 20L, OrderStatusEnum.OUT_FOR_DELIVERY, OrderStatusEnum.CONFIRMED))
                .thenReturn(0);

        assertThatThrownBy(() -> service.pickupOrder(1L, 20L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void pickupOrder_succeedsAndPublishesEvent() {
        when(orderRepository.pickupOrderByDeliveryPartner(1L, 20L, OrderStatusEnum.OUT_FOR_DELIVERY, OrderStatusEnum.CONFIRMED))
                .thenReturn(1);

        assertThat(service.pickupOrder(1L, 20L)).isTrue();
        verify(eventPublisher).publishEvent(any());
    }

    @Test
    void markDelivered_throwsOnConflict() {
        when(orderRepository.markDeliveredByDeliveryPartner(1L, 20L, OrderStatusEnum.DELIVERED, OrderStatusEnum.OUT_FOR_DELIVERY))
                .thenReturn(0);

        assertThatThrownBy(() -> service.markDelivered(1L, 20L))
                .isInstanceOf(OrderConflictException.class);
    }

    @Test
    void markDelivered_freesPartnerOnSuccess() {
        when(orderRepository.markDeliveredByDeliveryPartner(1L, 20L, OrderStatusEnum.DELIVERED, OrderStatusEnum.OUT_FOR_DELIVERY))
                .thenReturn(1);
        DeliveryPartners p = partner(20L, "13.0,80.2", DeliveryPartnerStatusEnum.ON_DELIVERY);
        when(deliveryPartnerRepository.findById(20L)).thenReturn(Optional.of(p));

        assertThat(service.markDelivered(1L, 20L)).isTrue();
        assertThat(p.getStatus()).isEqualTo(DeliveryPartnerStatusEnum.AVAILABLE);
    }

    @Test
    void broadcastOrder_throwsWhenOrderNotFound() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.broadcastOrder(1L))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void broadcastOrder_returnsEarlyWhenNoPharmacyAssigned() {
        Orders o = order(1L, OrderStatusEnum.PENDING);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));

        service.broadcastOrder(1L);

        verify(pharmacyRepository, never()).findById(anyLong());
    }

    @Test
    void broadcastOrder_looksUpNearbyPartnersWhenPharmacyAssigned() {
        Orders o = order(1L, OrderStatusEnum.CONFIRMED);
        o.setPharmacyId(5L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(o));
        Pharmacy pharmacy = new Pharmacy();
        pharmacy.setId(5L);
        pharmacy.setGeoAddress("13.0,80.2");
        when(pharmacyRepository.findById(5L)).thenReturn(Optional.of(pharmacy));
        when(deliveryPartnerRepository.findByStatus(DeliveryPartnerStatusEnum.AVAILABLE)).thenReturn(List.of());

        service.broadcastOrder(1L);

        verify(deliveryPartnerRepository).findByStatus(DeliveryPartnerStatusEnum.AVAILABLE);
    }

    @Test
    void getAvailableOrdersForPartner_emptyWhenPartnerMissingOrNoGeo() {
        when(deliveryPartnerRepository.findById(20L)).thenReturn(Optional.empty());

        assertThat(service.getAvailableOrdersForPartner(20L)).isEmpty();
    }

    @Test
    void getAvailableOrdersForPartner_filtersByDistanceAndSorts() {
        DeliveryPartners p = partner(20L, "13.0827,80.2707", DeliveryPartnerStatusEnum.AVAILABLE);
        when(deliveryPartnerRepository.findById(20L)).thenReturn(Optional.of(p));

        Orders nearOrder = order(1L, OrderStatusEnum.CONFIRMED);
        nearOrder.setPharmacyId(5L);
        nearOrder.setTotalAmount(new BigDecimal("100.00"));
        when(orderRepository.findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum.CONFIRMED))
                .thenReturn(List.of(nearOrder));

        Pharmacy pharmacy = new Pharmacy();
        pharmacy.setId(5L);
        pharmacy.setGeoAddress("13.0827,80.2707");
        when(pharmacyRepository.findById(5L)).thenReturn(Optional.of(pharmacy));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());
        when(detailsFeignClient.getDetails(5L)).thenReturn(new DetailsDTO());

        List<AvailableOrderDTO> result = service.getAvailableOrdersForPartner(20L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getOrderId()).isEqualTo(1L);
    }

    @Test
    void getAvailableOrdersForPartner_excludesOrdersBeyondRadius() {
        DeliveryPartners p = partner(20L, "13.0827,80.2707", DeliveryPartnerStatusEnum.AVAILABLE); // Chennai
        when(deliveryPartnerRepository.findById(20L)).thenReturn(Optional.of(p));

        Orders farOrder = order(1L, OrderStatusEnum.CONFIRMED);
        farOrder.setPharmacyId(5L);
        when(orderRepository.findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum.CONFIRMED))
                .thenReturn(List.of(farOrder));

        Pharmacy pharmacy = new Pharmacy();
        pharmacy.setId(5L);
        pharmacy.setGeoAddress("28.6139,77.2090"); // Delhi - way beyond 5km
        when(pharmacyRepository.findById(5L)).thenReturn(Optional.of(pharmacy));

        List<AvailableOrderDTO> result = service.getAvailableOrdersForPartner(20L);

        assertThat(result).isEmpty();
    }

    @Test
    void getActiveDeliveriesForPartner_onlyConfirmedAndOutForDelivery() {
        Orders confirmed = order(1L, OrderStatusEnum.CONFIRMED);
        Orders delivered = order(2L, OrderStatusEnum.DELIVERED);
        when(orderRepository.findByDeliveryPartnerId(20L)).thenReturn(List.of(confirmed, delivered));
        when(orderItemRepository.findByOrderId(anyLong())).thenReturn(List.of());
        when(detailsFeignClient.getDetails(anyLong())).thenReturn(new DetailsDTO());

        List<ActiveDeliveryDTO> result = service.getActiveDeliveriesForPartner(20L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getOrderId()).isEqualTo(1L);
    }

    @Test
    void getDeliveryHistoryForPartner_returnsOnlyDeliveredMapped() {
        when(orderRepository.findByDeliveryPartnerIdAndStatus(20L, OrderStatusEnum.DELIVERED))
                .thenReturn(List.of(order(1L, OrderStatusEnum.DELIVERED)));
        when(orderItemRepository.findByOrderId(1L)).thenReturn(List.of());
        when(medicineRepository.findAllById(any())).thenReturn(List.of());

        List<?> result = service.getDeliveryHistoryForPartner(20L);

        assertThat(result).hasSize(1);
    }
}
