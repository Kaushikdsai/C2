package com.curonex.pharmacy.converter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

import com.curonex.pharmacy.enums.OrderStatusEnum;

class OrderStatusEnumConverterTest {

    private final OrderStatusEnumConverter converter = new OrderStatusEnumConverter();

    @Test
    void convertToDatabaseColumn_mapsEnumToDbValue() {
        assertThat(converter.convertToDatabaseColumn(OrderStatusEnum.OUT_FOR_DELIVERY)).isEqualTo("out_for_delivery");
    }

    @Test
    void convertToDatabaseColumn_nullReturnsNull() {
        assertThat(converter.convertToDatabaseColumn(null)).isNull();
    }

    @Test
    void convertToEntityAttribute_mapsDbValueToEnum() {
        assertThat(converter.convertToEntityAttribute("delivered")).isEqualTo(OrderStatusEnum.DELIVERED);
    }

    @Test
    void convertToEntityAttribute_nullReturnsNull() {
        assertThat(converter.convertToEntityAttribute(null)).isNull();
    }

    @Test
    void convertToEntityAttribute_throwsOnUnknownValue() {
        assertThatThrownBy(() -> converter.convertToEntityAttribute("not_a_status"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void roundTrip_everyEnumValueSurvivesConversion() {
        for (OrderStatusEnum value : OrderStatusEnum.values()) {
            String db = converter.convertToDatabaseColumn(value);
            assertThat(converter.convertToEntityAttribute(db)).isEqualTo(value);
        }
    }
}
