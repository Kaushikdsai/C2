package com.curonex.pharmacy.converter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;

class DeliveryPartnerStatusEnumConverterTest {

    private final DeliveryPartnerStatusEnumConverter converter = new DeliveryPartnerStatusEnumConverter();

    @Test
    void convertToDatabaseColumn_mapsEnumToDbValue() {
        assertThat(converter.convertToDatabaseColumn(DeliveryPartnerStatusEnum.ON_DELIVERY)).isEqualTo("on_delivery");
    }

    @Test
    void convertToDatabaseColumn_nullReturnsNull() {
        assertThat(converter.convertToDatabaseColumn(null)).isNull();
    }

    @Test
    void convertToEntityAttribute_mapsDbValueToEnum() {
        assertThat(converter.convertToEntityAttribute("available")).isEqualTo(DeliveryPartnerStatusEnum.AVAILABLE);
    }

    @Test
    void convertToEntityAttribute_nullReturnsNull() {
        assertThat(converter.convertToEntityAttribute(null)).isNull();
    }

    @Test
    void convertToEntityAttribute_throwsOnUnknownValue() {
        assertThatThrownBy(() -> converter.convertToEntityAttribute("bogus"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void roundTrip_everyEnumValueSurvivesConversion() {
        for (DeliveryPartnerStatusEnum value : DeliveryPartnerStatusEnum.values()) {
            String db = converter.convertToDatabaseColumn(value);
            assertThat(converter.convertToEntityAttribute(db)).isEqualTo(value);
        }
    }
}
