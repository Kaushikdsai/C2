package com.curonex.pharmacy.converter;

import com.curonex.pharmacy.enums.OrderStatusEnum;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = false)
public class OrderStatusEnumConverter implements AttributeConverter<OrderStatusEnum, String> {

    @Override
    public String convertToDatabaseColumn(OrderStatusEnum attribute) {
        return attribute == null ? null : attribute.getDbValue();
    }

    @Override
    public OrderStatusEnum convertToEntityAttribute(String dbData) {
        return dbData == null ? null : OrderStatusEnum.fromDbValue(dbData);
    }
}
