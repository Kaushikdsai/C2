package com.curonex.pharmacy.event;

import com.curonex.pharmacy.enums.OrderStatusEnum;

/**
 * Published on every meaningful order-lifecycle change. A future
 * WebSocket/push-notification layer can subscribe to this without any
 * change to service logic - just add another @EventListener.
 */
public class OrderStatusChangedEvent {

    private final Long orderId;
    private final OrderStatusEnum status;
    private final String message;

    public OrderStatusChangedEvent(Long orderId, OrderStatusEnum status, String message) {
        this.orderId = orderId;
        this.status = status;
        this.message = message;
    }

    public Long getOrderId() {
        return orderId;
    }

    public OrderStatusEnum getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}
