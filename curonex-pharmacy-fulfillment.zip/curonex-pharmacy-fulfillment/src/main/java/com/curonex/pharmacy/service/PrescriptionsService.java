package com.curonex.pharmacy.service;

import java.util.List;

import com.curonex.pharmacy.dto.PrescriptionsDTO;

/**
 * getPrescriptionsByHospital/getPrescriptionsByDoctor were removed - they
 * had no caller anywhere in the pharmacy/order/delivery frontend flow
 * (prescriptions.html only ever needs the current patient's own list, via
 * getPrescriptionsByUser). Those two reads belong to Hospital Admin /
 * Doctor portal concerns, not this module - if those modules need them,
 * they should be exposed there against the same underlying table.
 */
public interface PrescriptionsService {

    PrescriptionsDTO addPrescription(PrescriptionsDTO dto);

    PrescriptionsDTO getPrescriptionById(Long prescriptionId);

    List<PrescriptionsDTO> getAllPrescriptions();

    PrescriptionsDTO updatePrescription(Long prescriptionId, PrescriptionsDTO dto);

    void deletePrescription(Long prescriptionId);

    List<PrescriptionsDTO> getPrescriptionsByUser(Long userId);
}
