package com.curonex.pharmacy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;

@Repository
public interface PharmacyRepository extends JpaRepository<Pharmacy, Long> {

    List<Pharmacy> findByStatus(PharmacyStatusEnum status);

    List<Pharmacy> findByHospitalId(Long hospitalId);

    List<Pharmacy> findByStatusAndHospitalId(PharmacyStatusEnum status, Long hospitalId);

    boolean existsByLicenseNo(String licenseNo);

    /** Excludes soft-deleted rows - use for any "list all" / "list active" screen. */
    List<Pharmacy> findByIsDeletedFalse();

    List<Pharmacy> findByStatusAndIsDeletedFalse(PharmacyStatusEnum status);

    List<Pharmacy> findByStatusAndHospitalIdAndIsDeletedFalse(PharmacyStatusEnum status, Long hospitalId);

    /** Use for single-record lookups where a soft-deleted pharmacy should behave as "not found". */
    Optional<Pharmacy> findByIdAndIsDeletedFalse(Long id);
}
