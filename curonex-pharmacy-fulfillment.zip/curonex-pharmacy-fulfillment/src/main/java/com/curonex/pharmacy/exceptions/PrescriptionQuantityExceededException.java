package com.curonex.pharmacy.exceptions;

/**
 * Thrown when an order tries to buy more of a medicine than was actually
 * prescribed (or a medicine not on the prescription at all). A patient can
 * reduce quantity toward zero (which just means dropping the item from the
 * order) but can never exceed the prescribed amount - that's a real safety
 * boundary, not just a UX nicety, so it's enforced server-side regardless of
 * what the client sends.
 */
public class PrescriptionQuantityExceededException extends RuntimeException {
    public PrescriptionQuantityExceededException(String message) {
        super(message);
    }
}
