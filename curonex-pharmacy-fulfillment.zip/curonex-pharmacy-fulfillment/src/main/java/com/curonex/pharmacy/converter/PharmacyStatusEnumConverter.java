package com.curonex.pharmacy.converter;

import com.curonex.pharmacy.enums.PharmacyStatusEnum;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = false)
public class PharmacyStatusEnumConverter implements AttributeConverter<PharmacyStatusEnum, String> {

    @Override
    public String convertToDatabaseColumn(PharmacyStatusEnum attribute) {
        return attribute == null ? null : attribute.getDbValue();
    }

    @Override
    public PharmacyStatusEnum convertToEntityAttribute(String dbData) {
        return dbData == null ? null : PharmacyStatusEnum.fromDbValue(dbData);
    }
}
