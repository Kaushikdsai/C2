package com.curonex.pharmacy.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.curonex.pharmacy.dto.DetailsDTO;

@FeignClient(name = "details-service", url = "${details.service.url}")
public interface DetailsFeignClient {

    @GetMapping("/details/{id}")
    DetailsDTO getDetails(@PathVariable("id") Long id);

    @PutMapping("/details/{id}")
    DetailsDTO updateDetails(@PathVariable("id") Long id, @RequestBody DetailsDTO detailsDTO);
}
