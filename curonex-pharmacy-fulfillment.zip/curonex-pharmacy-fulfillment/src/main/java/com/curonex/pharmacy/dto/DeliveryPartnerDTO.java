package com.curonex.pharmacy.dto;

import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;

public class DeliveryPartnerDTO {

    private Long deliveryPartnerId;
    private String name;
    private String mobileNumber;
    private String geoAddress;
    private DeliveryPartnerStatusEnum status;

    public Long getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(Long deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getGeoAddress() {
        return geoAddress;
    }

    public void setGeoAddress(String geoAddress) {
        this.geoAddress = geoAddress;
    }

    public DeliveryPartnerStatusEnum getStatus() {
        return status;
    }

    public void setStatus(DeliveryPartnerStatusEnum status) {
        this.status = status;
    }
}
