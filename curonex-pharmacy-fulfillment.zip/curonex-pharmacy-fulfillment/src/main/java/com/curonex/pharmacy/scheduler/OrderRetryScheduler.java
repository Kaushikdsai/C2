package com.curonex.pharmacy.scheduler;

import java.time.Instant;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.service.DeliveryRoutingService;
import com.curonex.pharmacy.service.PharmacyRoutingService;

@Component
public class OrderRetryScheduler {

    private static final Logger log = LoggerFactory.getLogger(OrderRetryScheduler.class);

    private static final long PHARMACY_TIMEOUT_MINUTES = 5;
    private static final long DELIVERY_TIMEOUT_MINUTES = 10;

    private final OrderRepository orderRepository;
    private final PharmacyRoutingService pharmacyRoutingService;
    private final DeliveryRoutingService deliveryRoutingService;

    public OrderRetryScheduler(
            OrderRepository orderRepository,
            PharmacyRoutingService pharmacyRoutingService,
            DeliveryRoutingService deliveryRoutingService) {
        this.orderRepository = orderRepository;
        this.pharmacyRoutingService = pharmacyRoutingService;
        this.deliveryRoutingService = deliveryRoutingService;
    }

    /** Still PENDING (no pharmacy) after 5 minutes -> rebroadcast to nearby pharmacies. */
    @Scheduled(fixedRate = 60000)
    public void retryUnclaimedPharmacyOrders() {
        List<Orders> pendingOrders = orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING);

        for (Orders order : pendingOrders) {
            if (order.getOrderDatetime() == null) {
                continue;
            }
            long minutesElapsed = (Instant.now().toEpochMilli() - order.getOrderDatetime().getTime()) / 60000;
            if (minutesElapsed >= PHARMACY_TIMEOUT_MINUTES) {
                log.info("Order {} unclaimed by any pharmacy after {} min - rebroadcasting", order.getOrderId(), minutesElapsed);
                pharmacyRoutingService.rebroadcastOrder(order.getOrderId());
            }
        }
    }

    /** CONFIRMED but no delivery partner after 10 minutes -> rebroadcast to nearby partners. */
    @Scheduled(fixedRate = 60000)
    public void retryUnclaimedDeliveryOrders() {
        List<Orders> confirmedOrders =
                orderRepository.findByStatusAndDeliveryPartnerIdIsNull(OrderStatusEnum.CONFIRMED);

        for (Orders order : confirmedOrders) {
            if (order.getOrderDatetime() == null) {
                continue;
            }
            long minutesElapsed = (Instant.now().toEpochMilli() - order.getOrderDatetime().getTime()) / 60000;
            if (minutesElapsed >= DELIVERY_TIMEOUT_MINUTES) {
                log.info("Order {} unclaimed by any delivery partner after {} min - rebroadcasting", order.getOrderId(), minutesElapsed);
                deliveryRoutingService.rebroadcastOrder(order.getOrderId());
            }
        }
    }
}
