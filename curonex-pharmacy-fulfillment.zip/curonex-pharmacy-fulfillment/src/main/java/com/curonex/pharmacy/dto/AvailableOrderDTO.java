package com.curonex.pharmacy.dto;

import java.math.BigDecimal;

public class AvailableOrderDTO {

    private Long orderId;
    private String pharmacyName;
    private String pharmacyGeoAddress;
    private Integer itemCount;
    private BigDecimal totalAmount;
    private double distanceKm;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getPharmacyName() {
        return pharmacyName;
    }

    public void setPharmacyName(String pharmacyName) {
        this.pharmacyName = pharmacyName;
    }

    public String getPharmacyGeoAddress() {
        return pharmacyGeoAddress;
    }

    public void setPharmacyGeoAddress(String pharmacyGeoAddress) {
        this.pharmacyGeoAddress = pharmacyGeoAddress;
    }

    public Integer getItemCount() {
        return itemCount;
    }

    public void setItemCount(Integer itemCount) {
        this.itemCount = itemCount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getDistanceKm() {
        return distanceKm;
    }

    public void setDistanceKm(double distanceKm) {
        this.distanceKm = distanceKm;
    }
}
