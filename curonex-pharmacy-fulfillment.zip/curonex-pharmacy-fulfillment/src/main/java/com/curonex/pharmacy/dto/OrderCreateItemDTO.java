package com.curonex.pharmacy.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class OrderCreateItemDTO {

    @NotNull(message = "medicineId is required")
    private Long medicineId;

    @NotNull(message = "quantity is required")
    @Min(value = 1, message = "quantity must be at least 1 (remove the item entirely instead of sending 0)")
    private Integer quantity;

    /**
     * The quantity originally extracted from the prescription for this
     * medicine - the ceiling the patient is allowed to order. The patient
     * can only decrease from this (down to 1) or remove the item entirely
     * (by leaving it out of the items list); they can never submit a
     * quantity higher than what was actually prescribed. Enforced in
     * OrderServiceImpl.createOrder() against the "quantity" field above.
     */
    @NotNull(message = "prescribedQuantity is required")
    @Min(value = 1, message = "prescribedQuantity must be at least 1")
    private Integer prescribedQuantity;

    public Long getMedicineId() {
        return medicineId;
    }

    public void setMedicineId(Long medicineId) {
        this.medicineId = medicineId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getPrescribedQuantity() {
        return prescribedQuantity;
    }

    public void setPrescribedQuantity(Integer prescribedQuantity) {
        this.prescribedQuantity = prescribedQuantity;
    }
}
