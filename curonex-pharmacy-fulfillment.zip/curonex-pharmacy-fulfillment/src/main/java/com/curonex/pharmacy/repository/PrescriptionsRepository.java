package com.curonex.pharmacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.Prescriptions;

@Repository
public interface PrescriptionsRepository extends JpaRepository<Prescriptions, Long> {

    /** Excludes soft-deleted rows - use for any "list" screen. */
    List<Prescriptions> findByUserIdAndIsDeletedFalse(Long userId);

    List<Prescriptions> findByIsDeletedFalse();
}
