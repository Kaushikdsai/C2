package com.curonex.pharmacy.serviceimpl;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.curonex.pharmacy.dto.PrescriptionExtractionResponseDTO;
import com.curonex.pharmacy.service.PrescriptionExtractionService;
import com.curonex.pharmacy.util.PrescriptionParserUtil;

@Service
public class PrescriptionExtractionServiceImpl implements PrescriptionExtractionService {

    @Override
    public PrescriptionExtractionResponseDTO extractMedicines(MultipartFile file) {
        try {
            if (file == null || file.isEmpty()) {
                throw new IllegalArgumentException("Prescription file is required.");
            }

            String fileName = file.getOriginalFilename();
            if (fileName == null || !fileName.toLowerCase().endsWith(".pdf")) {
                throw new IllegalArgumentException("Only PDF prescriptions are supported.");
            }

            PDDocument document = Loader.loadPDF(file.getBytes());
            PDFTextStripper stripper = new PDFTextStripper();
            String extractedText = stripper.getText(document);
            document.close();

            PrescriptionExtractionResponseDTO response = new PrescriptionExtractionResponseDTO();
            response.setExtractedText(extractedText);
            response.setMedicines(PrescriptionParserUtil.parseMedicines(extractedText));
            return response;

        } catch (IllegalArgumentException ex) {
            throw ex;
        } catch (Exception exception) {
            throw new RuntimeException("Failed to extract prescription.", exception);
        }
    }
}
