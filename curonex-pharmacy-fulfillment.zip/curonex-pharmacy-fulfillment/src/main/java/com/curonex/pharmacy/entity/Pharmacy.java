package com.curonex.pharmacy.entity;

import java.math.BigDecimal;

import com.curonex.pharmacy.converter.PharmacyStatusEnumConverter;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "pharmacy")
public class Pharmacy {

    @Id
    @Column(name = "pharmacy_id")
    private Long id;

    @Column(name = "license_no")
    private String licenseNo;

    @Column(name = "geo_address")
    private String geoAddress;

    @Convert(converter = PharmacyStatusEnumConverter.class)
    @Column(name = "status")
    private PharmacyStatusEnum status;

    @Column(name = "hospital_id")
    private Long hospitalId;

    @Column(name = "rating")
    private BigDecimal rating;

    @Column(name = "rating_count")
    private Integer ratingCount;

    /** Soft-delete flag. Pharmacies are referenced by historical orders and must never be hard-deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLicenseNo() {
        return licenseNo;
    }

    public void setLicenseNo(String licenseNo) {
        this.licenseNo = licenseNo;
    }

    public String getGeoAddress() {
        return geoAddress;
    }

    public void setGeoAddress(String geoAddress) {
        this.geoAddress = geoAddress;
    }

    public PharmacyStatusEnum getStatus() {
        return status;
    }

    public void setStatus(PharmacyStatusEnum status) {
        this.status = status;
    }

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public BigDecimal getRating() {
        return rating;
    }

    public void setRating(BigDecimal rating) {
        this.rating = rating;
    }

    public Integer getRatingCount() {
        return ratingCount;
    }

    public void setRatingCount(Integer ratingCount) {
        this.ratingCount = ratingCount;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }
}
