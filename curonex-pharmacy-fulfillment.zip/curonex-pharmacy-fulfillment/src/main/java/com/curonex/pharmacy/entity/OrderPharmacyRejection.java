package com.curonex.pharmacy.entity;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/**
 * Records that a given pharmacy declined a given order, so it stops
 * appearing in that pharmacy's "available orders" list. Many-to-many by
 * nature (one order can be rejected by several pharmacies; one pharmacy can
 * reject many orders) - a single field on Orders cannot represent this
 * correctly, hence the join table.
 */
@Entity
@Table(name = "order_pharmacy_rejection")
public class OrderPharmacyRejection {

    @EmbeddedId
    private OrderPharmacyRejectionId id;

    @Column(name = "rejected_at")
    private Timestamp rejectedAt;

    public OrderPharmacyRejection() {
    }

    public OrderPharmacyRejection(OrderPharmacyRejectionId id, Timestamp rejectedAt) {
        this.id = id;
        this.rejectedAt = rejectedAt;
    }

    public OrderPharmacyRejectionId getId() {
        return id;
    }

    public void setId(OrderPharmacyRejectionId id) {
        this.id = id;
    }

    public Timestamp getRejectedAt() {
        return rejectedAt;
    }

    public void setRejectedAt(Timestamp rejectedAt) {
        this.rejectedAt = rejectedAt;
    }
}
