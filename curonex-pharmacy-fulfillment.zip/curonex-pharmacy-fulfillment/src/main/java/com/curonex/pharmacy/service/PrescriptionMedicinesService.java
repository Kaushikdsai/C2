package com.curonex.pharmacy.service;

import java.util.List;

import com.curonex.pharmacy.dto.PrescriptionMedicinesDTO;

public interface PrescriptionMedicinesService {

    PrescriptionMedicinesDTO addMedicine(Long prescriptionId, PrescriptionMedicinesDTO dto);

    List<PrescriptionMedicinesDTO> getMedicinesByPrescription(Long prescriptionId);

    PrescriptionMedicinesDTO updateMedicine(Long prescriptionId, Long medicineId, PrescriptionMedicinesDTO dto);

    void deleteMedicine(Long prescriptionId, Long medicineId);
}
