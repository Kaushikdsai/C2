package com.curonex.pharmacy.entity;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class OrderPharmacyRejectionId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "order_id")
    private Long orderId;

    @Column(name = "pharmacy_id")
    private Long pharmacyId;

    public OrderPharmacyRejectionId() {
    }

    public OrderPharmacyRejectionId(Long orderId, Long pharmacyId) {
        this.orderId = orderId;
        this.pharmacyId = pharmacyId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getPharmacyId() {
        return pharmacyId;
    }

    public void setPharmacyId(Long pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OrderPharmacyRejectionId)) return false;
        OrderPharmacyRejectionId that = (OrderPharmacyRejectionId) o;
        return Objects.equals(orderId, that.orderId) && Objects.equals(pharmacyId, that.pharmacyId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId, pharmacyId);
    }
}
