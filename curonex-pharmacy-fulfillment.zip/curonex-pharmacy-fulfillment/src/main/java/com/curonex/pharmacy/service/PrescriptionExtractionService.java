package com.curonex.pharmacy.service;

import org.springframework.web.multipart.MultipartFile;

import com.curonex.pharmacy.dto.PrescriptionExtractionResponseDTO;

public interface PrescriptionExtractionService {

    PrescriptionExtractionResponseDTO extractMedicines(MultipartFile file);
}
