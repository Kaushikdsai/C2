package com.curonex.pharmacy.dto;

import java.math.BigDecimal;

public class DeliveryPartnerDashboardDTO {

    private long todaysDeliveries;
    private long pendingPickups;
    private long completedDeliveries;

    private long acceptedCount;
    private long outForDeliveryCount;
    private long completedCount;

    private BigDecimal todaysEarnings;
    private BigDecimal weekEarnings;
    private BigDecimal monthEarnings;

    private BigDecimal rating;
    private Integer ratingCount;

    public long getTodaysDeliveries() {
        return todaysDeliveries;
    }

    public void setTodaysDeliveries(long todaysDeliveries) {
        this.todaysDeliveries = todaysDeliveries;
    }

    public long getPendingPickups() {
        return pendingPickups;
    }

    public void setPendingPickups(long pendingPickups) {
        this.pendingPickups = pendingPickups;
    }

    public long getCompletedDeliveries() {
        return completedDeliveries;
    }

    public void setCompletedDeliveries(long completedDeliveries) {
        this.completedDeliveries = completedDeliveries;
    }

    public long getAcceptedCount() {
        return acceptedCount;
    }

    public void setAcceptedCount(long acceptedCount) {
        this.acceptedCount = acceptedCount;
    }

    public long getOutForDeliveryCount() {
        return outForDeliveryCount;
    }

    public void setOutForDeliveryCount(long outForDeliveryCount) {
        this.outForDeliveryCount = outForDeliveryCount;
    }

    public long getCompletedCount() {
        return completedCount;
    }

    public void setCompletedCount(long completedCount) {
        this.completedCount = completedCount;
    }

    public BigDecimal getTodaysEarnings() {
        return todaysEarnings;
    }

    public void setTodaysEarnings(BigDecimal todaysEarnings) {
        this.todaysEarnings = todaysEarnings;
    }

    public BigDecimal getWeekEarnings() {
        return weekEarnings;
    }

    public void setWeekEarnings(BigDecimal weekEarnings) {
        this.weekEarnings = weekEarnings;
    }

    public BigDecimal getMonthEarnings() {
        return monthEarnings;
    }

    public void setMonthEarnings(BigDecimal monthEarnings) {
        this.monthEarnings = monthEarnings;
    }

    public BigDecimal getRating() {
        return rating;
    }

    public void setRating(BigDecimal rating) {
        this.rating = rating;
    }

    public Integer getRatingCount() {
        return ratingCount;
    }

    public void setRatingCount(Integer ratingCount) {
        this.ratingCount = ratingCount;
    }
}
