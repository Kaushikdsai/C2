package com.curonex.pharmacy.converter;

import com.curonex.pharmacy.enums.DeliveryPartnerStatusEnum;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = false)
public class DeliveryPartnerStatusEnumConverter implements AttributeConverter<DeliveryPartnerStatusEnum, String> {

    @Override
    public String convertToDatabaseColumn(DeliveryPartnerStatusEnum attribute) {
        return attribute == null ? null : attribute.getDbValue();
    }

    @Override
    public DeliveryPartnerStatusEnum convertToEntityAttribute(String dbData) {
        return dbData == null ? null : DeliveryPartnerStatusEnum.fromDbValue(dbData);
    }
}
