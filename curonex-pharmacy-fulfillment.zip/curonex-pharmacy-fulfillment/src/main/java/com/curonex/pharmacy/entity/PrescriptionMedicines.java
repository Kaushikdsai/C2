package com.curonex.pharmacy.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "prescription_medicines")
public class PrescriptionMedicines {

    @EmbeddedId
    private PrescriptionMedicineId id;

    @Column(name = "quantity")
    private Integer quantity;

    public PrescriptionMedicineId getId() {
        return id;
    }

    public void setId(PrescriptionMedicineId id) {
        this.id = id;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
