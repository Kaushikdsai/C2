package com.curonex.pharmacy.dto;

import java.sql.Timestamp;

public class PrescriptionsDTO {

    private Long prescriptionId;
    private Long userId;
    private Long hospitalId;
    private Long doctorId;
    private Timestamp prescriptionDatetime;

    public Long getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(Long prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public Timestamp getPrescriptionDatetime() {
        return prescriptionDatetime;
    }

    public void setPrescriptionDatetime(Timestamp prescriptionDatetime) {
        this.prescriptionDatetime = prescriptionDatetime;
    }
}
