package com.curonex.pharmacy.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curonex.pharmacy.dto.PrescriptionsDTO;
import com.curonex.pharmacy.service.PrescriptionsService;

@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionsController {

    private final PrescriptionsService prescriptionsService;

    public PrescriptionsController(PrescriptionsService prescriptionsService) {
        this.prescriptionsService = prescriptionsService;
    }

    @PostMapping
    public ResponseEntity<PrescriptionsDTO> addPrescription(@RequestBody PrescriptionsDTO dto) {
        return ResponseEntity.ok(prescriptionsService.addPrescription(dto));
    }

    @GetMapping("/{prescriptionId}")
    public ResponseEntity<PrescriptionsDTO> getPrescriptionById(@PathVariable Long prescriptionId) {
        return ResponseEntity.ok(prescriptionsService.getPrescriptionById(prescriptionId));
    }

    @GetMapping
    public ResponseEntity<List<PrescriptionsDTO>> getAllPrescriptions() {
        return ResponseEntity.ok(prescriptionsService.getAllPrescriptions());
    }

    @PutMapping("/{prescriptionId}")
    public ResponseEntity<PrescriptionsDTO> updatePrescription(
            @PathVariable Long prescriptionId, @RequestBody PrescriptionsDTO dto) {
        return ResponseEntity.ok(prescriptionsService.updatePrescription(prescriptionId, dto));
    }

    @DeleteMapping("/{prescriptionId}")
    public ResponseEntity<Void> deletePrescription(@PathVariable Long prescriptionId) {
        prescriptionsService.deletePrescription(prescriptionId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<PrescriptionsDTO>> getPrescriptionsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(prescriptionsService.getPrescriptionsByUser(userId));
    }
}
