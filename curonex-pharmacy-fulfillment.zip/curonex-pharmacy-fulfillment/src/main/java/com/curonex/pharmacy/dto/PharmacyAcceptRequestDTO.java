package com.curonex.pharmacy.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

public class PharmacyAcceptRequestDTO {

    @NotEmpty(message = "itemPrices must not be empty")
    @Valid
    private List<PharmacyAcceptItemDTO> itemPrices;

    public List<PharmacyAcceptItemDTO> getItemPrices() {
        return itemPrices;
    }

    public void setItemPrices(List<PharmacyAcceptItemDTO> itemPrices) {
        this.itemPrices = itemPrices;
    }
}
