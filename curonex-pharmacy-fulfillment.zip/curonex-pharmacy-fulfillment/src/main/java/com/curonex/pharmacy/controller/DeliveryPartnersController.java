package com.curonex.pharmacy.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curonex.pharmacy.dto.ActiveDeliveryDTO;
import com.curonex.pharmacy.dto.AvailableOrderDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerDashboardDTO;
import com.curonex.pharmacy.dto.DeliveryPartnerProfileDTO;
import com.curonex.pharmacy.dto.OrderResponseDTO;
import com.curonex.pharmacy.dto.RatingRequestDTO;
import com.curonex.pharmacy.service.DeliveryPartnersService;
import com.curonex.pharmacy.service.DeliveryRoutingService;

@RestController
@RequestMapping("/api/delivery-partners")
public class DeliveryPartnersController {

    private final DeliveryPartnersService deliveryPartnersService;
    private final DeliveryRoutingService deliveryRoutingService;

    public DeliveryPartnersController(
            DeliveryPartnersService deliveryPartnersService, DeliveryRoutingService deliveryRoutingService) {
        this.deliveryPartnersService = deliveryPartnersService;
        this.deliveryRoutingService = deliveryRoutingService;
    }

    /*
     * CRUD
     */

    @PostMapping
    public ResponseEntity<DeliveryPartnerDTO> addDeliveryPartner(@RequestBody DeliveryPartnerDTO dto) {
        return ResponseEntity.ok(deliveryPartnersService.addDeliveryPartner(dto));
    }

    @GetMapping("/{deliveryPartnerId}")
    public ResponseEntity<DeliveryPartnerDTO> getDeliveryPartnerById(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(deliveryPartnersService.getDeliveryPartnerById(deliveryPartnerId));
    }

    @GetMapping
    public ResponseEntity<List<DeliveryPartnerDTO>> getAllDeliveryPartners() {
        return ResponseEntity.ok(deliveryPartnersService.getAllDeliveryPartners());
    }

    @PutMapping("/{deliveryPartnerId}")
    public ResponseEntity<DeliveryPartnerDTO> updateDeliveryPartner(
            @PathVariable Long deliveryPartnerId, @RequestBody DeliveryPartnerDTO dto) {
        return ResponseEntity.ok(deliveryPartnersService.updateDeliveryPartner(deliveryPartnerId, dto));
    }

    @DeleteMapping("/{deliveryPartnerId}")
    public ResponseEntity<Void> deleteDeliveryPartner(@PathVariable Long deliveryPartnerId) {
        deliveryPartnersService.deleteDeliveryPartner(deliveryPartnerId);
        return ResponseEntity.noContent().build();
    }

    /*
     * Status / Availability toggle
     */

    @GetMapping("/available")
    public ResponseEntity<List<DeliveryPartnerDTO>> getAvailableDeliveryPartners() {
        return ResponseEntity.ok(deliveryPartnersService.getAvailableDeliveryPartners());
    }

    @PutMapping("/{deliveryPartnerId}/available")
    public ResponseEntity<Boolean> markAvailable(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(deliveryPartnersService.markAvailable(deliveryPartnerId));
    }

    @PutMapping("/{deliveryPartnerId}/on-delivery")
    public ResponseEntity<Boolean> markOnDelivery(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(deliveryPartnersService.markOnDelivery(deliveryPartnerId));
    }

    @PutMapping("/{deliveryPartnerId}/offline")
    public ResponseEntity<Boolean> markOffline(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(deliveryPartnersService.markOffline(deliveryPartnerId));
    }

    /*
     * Profile (delivery_partner.html "My Profile")
     */

    @GetMapping("/{deliveryPartnerId}/profile")
    public ResponseEntity<DeliveryPartnerProfileDTO> getProfile(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(deliveryPartnersService.getPartnerProfile(deliveryPartnerId));
    }

    @PutMapping("/{deliveryPartnerId}/profile")
    public ResponseEntity<DeliveryPartnerProfileDTO> updateProfile(
            @PathVariable Long deliveryPartnerId, @RequestBody DeliveryPartnerProfileDTO dto) {
        return ResponseEntity.ok(deliveryPartnersService.updatePartnerProfile(deliveryPartnerId, dto));
    }

    /** Called after a delivered order, from the patient side, to rate the delivery partner. */
    @PutMapping("/{deliveryPartnerId}/rating")
    public ResponseEntity<DeliveryPartnerProfileDTO> submitRating(
            @PathVariable Long deliveryPartnerId,
            @jakarta.validation.Valid @RequestBody RatingRequestDTO request) {
        return ResponseEntity.ok(deliveryPartnersService.submitRating(deliveryPartnerId, request.getRating()));
    }

    /*
     * Dashboard
     */

    @GetMapping("/{deliveryPartnerId}/dashboard")
    public ResponseEntity<DeliveryPartnerDashboardDTO> getDashboard(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(deliveryPartnersService.getDashboard(deliveryPartnerId));
    }

    /*
     * Available Orders / Active Deliveries / History tabs
     */

    @GetMapping("/{deliveryPartnerId}/orders/available")
    public ResponseEntity<List<AvailableOrderDTO>> getAvailableOrders(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(deliveryRoutingService.getAvailableOrdersForPartner(deliveryPartnerId));
    }

    @GetMapping("/{deliveryPartnerId}/orders/active")
    public ResponseEntity<List<ActiveDeliveryDTO>> getActiveDeliveries(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(deliveryRoutingService.getActiveDeliveriesForPartner(deliveryPartnerId));
    }

    @GetMapping("/{deliveryPartnerId}/orders/history")
    public ResponseEntity<List<OrderResponseDTO>> getDeliveryHistory(@PathVariable Long deliveryPartnerId) {
        return ResponseEntity.ok(deliveryRoutingService.getDeliveryHistoryForPartner(deliveryPartnerId));
    }

    /*
     * Delivery lifecycle actions
     */

    @PutMapping("/orders/{orderId}/accept/{partnerId}")
    public ResponseEntity<Boolean> acceptDelivery(@PathVariable Long orderId, @PathVariable Long partnerId) {
        return ResponseEntity.ok(deliveryRoutingService.acceptDelivery(orderId, partnerId));
    }

    @PutMapping("/orders/{orderId}/cancel/{partnerId}")
    public ResponseEntity<Boolean> cancelDelivery(@PathVariable Long orderId, @PathVariable Long partnerId) {
        return ResponseEntity.ok(deliveryRoutingService.cancelDelivery(orderId, partnerId));
    }

    @PutMapping("/orders/{orderId}/pickup/{partnerId}")
    public ResponseEntity<Boolean> pickupOrder(@PathVariable Long orderId, @PathVariable Long partnerId) {
        return ResponseEntity.ok(deliveryRoutingService.pickupOrder(orderId, partnerId));
    }

    @PutMapping("/orders/{orderId}/delivered/{partnerId}")
    public ResponseEntity<Boolean> markDelivered(@PathVariable Long orderId, @PathVariable Long partnerId) {
        return ResponseEntity.ok(deliveryRoutingService.markDelivered(orderId, partnerId));
    }
}
