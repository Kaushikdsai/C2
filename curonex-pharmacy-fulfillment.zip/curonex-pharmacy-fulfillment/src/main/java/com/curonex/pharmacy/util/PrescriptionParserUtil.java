package com.curonex.pharmacy.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.curonex.pharmacy.dto.ExtractedMedicineDTO;

public final class PrescriptionParserUtil {

    private PrescriptionParserUtil() {
    }

    private static final Pattern MEDICINE_PATTERN =
            Pattern.compile("(.+?)\\s+Qty\\s*:?\\s*(\\d+)", Pattern.CASE_INSENSITIVE);

    public static List<ExtractedMedicineDTO> parseMedicines(String extractedText) {
        List<ExtractedMedicineDTO> medicines = new ArrayList<>();
        String[] lines = extractedText.split("\\r?\\n");

        for (String line : lines) {
            Matcher matcher = MEDICINE_PATTERN.matcher(line.trim());
            if (matcher.find()) {
                ExtractedMedicineDTO dto = new ExtractedMedicineDTO();
                dto.setMedicineName(matcher.group(1).trim());
                dto.setQuantity(Integer.parseInt(matcher.group(2)));
                medicines.add(dto);
            }
        }

        return medicines;
    }
}
