package com.curonex.pharmacy.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * Placeholder notification sink. Swap the body of this method for a
 * WebSocket broadcast / push-notification call when that layer is built -
 * nothing else in the codebase needs to change.
 */
@Component
public class OrderEventListener {

    private static final Logger log = LoggerFactory.getLogger(OrderEventListener.class);

    @EventListener
    public void onOrderStatusChanged(OrderStatusChangedEvent event) {
        log.info("Order {} -> {} : {}", event.getOrderId(), event.getStatus(), event.getMessage());
    }
}
