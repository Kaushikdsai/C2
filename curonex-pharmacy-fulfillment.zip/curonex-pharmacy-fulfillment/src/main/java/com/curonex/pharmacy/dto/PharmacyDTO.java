package com.curonex.pharmacy.dto;

import com.curonex.pharmacy.enums.PharmacyStatusEnum;

public class PharmacyDTO {

    private Long id;
    private String licenseNo;
    private String geoAddress;
    private PharmacyStatusEnum status;
    private Long hospitalId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLicenseNo() {
        return licenseNo;
    }

    public void setLicenseNo(String licenseNo) {
        this.licenseNo = licenseNo;
    }

    public String getGeoAddress() {
        return geoAddress;
    }

    public void setGeoAddress(String geoAddress) {
        this.geoAddress = geoAddress;
    }

    public PharmacyStatusEnum getStatus() {
        return status;
    }

    public void setStatus(PharmacyStatusEnum status) {
        this.status = status;
    }

    public Long getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Long hospitalId) {
        this.hospitalId = hospitalId;
    }
}
