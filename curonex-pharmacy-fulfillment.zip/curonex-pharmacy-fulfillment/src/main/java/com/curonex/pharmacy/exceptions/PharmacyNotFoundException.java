package com.curonex.pharmacy.exceptions;

public class PharmacyNotFoundException extends RuntimeException {
    public PharmacyNotFoundException(String message) {
        super(message);
    }
}
