package com.curonex.pharmacy.dto;

import java.math.BigDecimal;

public class PharmacyDashboardDTO {

    private long newOrders;
    private long processingOrders;
    private long todaysDeliveries;
    private BigDecimal todaysRevenue;

    public long getNewOrders() {
        return newOrders;
    }

    public void setNewOrders(long newOrders) {
        this.newOrders = newOrders;
    }

    public long getProcessingOrders() {
        return processingOrders;
    }

    public void setProcessingOrders(long processingOrders) {
        this.processingOrders = processingOrders;
    }

    public long getTodaysDeliveries() {
        return todaysDeliveries;
    }

    public void setTodaysDeliveries(long todaysDeliveries) {
        this.todaysDeliveries = todaysDeliveries;
    }

    public BigDecimal getTodaysRevenue() {
        return todaysRevenue;
    }

    public void setTodaysRevenue(BigDecimal todaysRevenue) {
        this.todaysRevenue = todaysRevenue;
    }
}
