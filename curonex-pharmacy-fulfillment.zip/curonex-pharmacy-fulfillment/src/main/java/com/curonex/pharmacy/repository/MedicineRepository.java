package com.curonex.pharmacy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.Medicine;

@Repository
public interface MedicineRepository extends JpaRepository<Medicine, Long> {

    /** Excludes soft-deleted rows - use whenever placing/pricing a NEW order. */
    Optional<Medicine> findByMedicineIdAndIsDeletedFalse(Long medicineId);

    List<Medicine> findByIsDeletedFalse();
}
