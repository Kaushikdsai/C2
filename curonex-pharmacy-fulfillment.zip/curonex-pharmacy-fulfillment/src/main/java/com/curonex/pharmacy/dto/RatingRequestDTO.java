package com.curonex.pharmacy.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

public class RatingRequestDTO {

    @NotNull(message = "rating is required")
    @DecimalMin(value = "0.0", message = "rating must be at least 0")
    @DecimalMax(value = "5.0", message = "rating must be at most 5")
    private BigDecimal rating;

    public BigDecimal getRating() {
        return rating;
    }

    public void setRating(BigDecimal rating) {
        this.rating = rating;
    }
}
