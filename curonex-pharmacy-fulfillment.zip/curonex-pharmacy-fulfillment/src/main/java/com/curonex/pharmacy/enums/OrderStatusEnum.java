package com.curonex.pharmacy.enums;

public enum OrderStatusEnum {
    PENDING("pending"),
    CONFIRMED("confirmed"),
    OUT_FOR_DELIVERY("out_for_delivery"),
    DELIVERED("delivered"),
    CANCELLED("cancelled");

    private final String dbValue;

    OrderStatusEnum(String dbValue) {
        this.dbValue = dbValue;
    }

    public String getDbValue() {
        return dbValue;
    }

    public static OrderStatusEnum fromDbValue(String dbValue) {
        for (OrderStatusEnum value : values()) {
            if (value.dbValue.equalsIgnoreCase(dbValue)) {
                return value;
            }
        }
        throw new IllegalArgumentException("Unknown OrderStatusEnum db value: " + dbValue);
    }
}
