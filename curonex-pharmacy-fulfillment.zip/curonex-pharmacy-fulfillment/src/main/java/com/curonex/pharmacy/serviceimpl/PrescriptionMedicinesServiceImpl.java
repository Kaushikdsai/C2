package com.curonex.pharmacy.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.curonex.pharmacy.dto.PrescriptionMedicinesDTO;
import com.curonex.pharmacy.entity.PrescriptionMedicineId;
import com.curonex.pharmacy.entity.PrescriptionMedicines;
import com.curonex.pharmacy.repository.PrescriptionMedicinesRepository;
import com.curonex.pharmacy.service.PrescriptionMedicinesService;

@Service
public class PrescriptionMedicinesServiceImpl implements PrescriptionMedicinesService {

    private final PrescriptionMedicinesRepository prescriptionMedicineRepository;

    public PrescriptionMedicinesServiceImpl(PrescriptionMedicinesRepository prescriptionMedicineRepository) {
        this.prescriptionMedicineRepository = prescriptionMedicineRepository;
    }

    @Override
    public PrescriptionMedicinesDTO addMedicine(Long prescriptionId, PrescriptionMedicinesDTO dto) {
        PrescriptionMedicineId id = new PrescriptionMedicineId(prescriptionId, dto.getMedicineId());

        PrescriptionMedicines medicine = new PrescriptionMedicines();
        medicine.setId(id);
        medicine.setQuantity(dto.getQuantity());

        return convertToDTO(prescriptionMedicineRepository.save(medicine));
    }

    @Override
    public List<PrescriptionMedicinesDTO> getMedicinesByPrescription(Long prescriptionId) {
        return prescriptionMedicineRepository.findByIdPrescriptionId(prescriptionId)
                .stream().map(this::convertToDTO).toList();
    }

    @Override
    public PrescriptionMedicinesDTO updateMedicine(Long prescriptionId, Long medicineId, PrescriptionMedicinesDTO dto) {
        PrescriptionMedicineId id = new PrescriptionMedicineId(prescriptionId, medicineId);

        PrescriptionMedicines medicine = prescriptionMedicineRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Medicine not found"));

        medicine.setQuantity(dto.getQuantity());

        return convertToDTO(prescriptionMedicineRepository.save(medicine));
    }

    @Override
    public void deleteMedicine(Long prescriptionId, Long medicineId) {
        PrescriptionMedicineId id = new PrescriptionMedicineId(prescriptionId, medicineId);
        prescriptionMedicineRepository.deleteById(id);
    }

    private PrescriptionMedicinesDTO convertToDTO(PrescriptionMedicines medicine) {
        PrescriptionMedicinesDTO dto = new PrescriptionMedicinesDTO();
        dto.setPrescriptionId(medicine.getId().getPrescriptionId());
        dto.setMedicineId(medicine.getId().getMedicineId());
        dto.setQuantity(medicine.getQuantity());
        return dto;
    }
}
