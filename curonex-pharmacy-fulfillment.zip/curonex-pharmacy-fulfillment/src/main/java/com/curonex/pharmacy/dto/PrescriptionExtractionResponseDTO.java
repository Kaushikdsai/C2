package com.curonex.pharmacy.dto;

import java.util.List;

public class PrescriptionExtractionResponseDTO {

    private String extractedText;
    private List<ExtractedMedicineDTO> medicines;

    public String getExtractedText() {
        return extractedText;
    }

    public void setExtractedText(String extractedText) {
        this.extractedText = extractedText;
    }

    public List<ExtractedMedicineDTO> getMedicines() {
        return medicines;
    }

    public void setMedicines(List<ExtractedMedicineDTO> medicines) {
        this.medicines = medicines;
    }
}
