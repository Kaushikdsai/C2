package com.curonex.pharmacy.serviceimpl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.curonex.pharmacy.client.DetailsFeignClient;
import com.curonex.pharmacy.dto.CoordinateDTO;
import com.curonex.pharmacy.dto.DetailsDTO;
import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.entity.Medicine;
import com.curonex.pharmacy.entity.OrderItem;
import com.curonex.pharmacy.entity.Orders;
import com.curonex.pharmacy.entity.Pharmacy;
import com.curonex.pharmacy.enums.OrderStatusEnum;
import com.curonex.pharmacy.enums.PharmacyStatusEnum;
import com.curonex.pharmacy.exceptions.OrderConflictException;
import com.curonex.pharmacy.repository.MedicineRepository;
import com.curonex.pharmacy.repository.OrderItemRepository;
import com.curonex.pharmacy.repository.OrderPharmacyRejectionRepository;
import com.curonex.pharmacy.repository.OrderRepository;
import com.curonex.pharmacy.repository.PharmacyRepository;
import com.curonex.pharmacy.service.PharmacyRoutingService;
import com.curonex.pharmacy.util.DistanceUtil;
import com.curonex.pharmacy.util.GeoAddressUtil;

@Service
public class PharmacyRoutingServiceImpl implements PharmacyRoutingService {

    private static final double DEFAULT_BROADCAST_RADIUS_KM = 10.0;
    private static final double HOSPITAL_PHARMACY_RADIUS_KM = 5.0;

    /**
     * "Hospital pharmacy gets first priority" - implemented as an exclusive
     * window: if the order has a hospitalId and that hospital has an ACTIVE
     * pharmacy within HOSPITAL_PHARMACY_RADIUS_KM, only that pharmacy can
     * see/accept the order for this many minutes. Every other nearby
     * pharmacy only sees it once the window has elapsed.
     */
    private static final long HOSPITAL_PRIORITY_WINDOW_MINUTES = 2;

    private final PharmacyRepository pharmacyRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final MedicineRepository medicineRepository;
    private final DetailsFeignClient detailsFeignClient;
    private final GeoAddressUtil geoAddressUtil;
    private final DistanceUtil distanceUtil;
    private final OrderPharmacyRejectionRepository orderPharmacyRejectionRepository;

    public PharmacyRoutingServiceImpl(
            PharmacyRepository pharmacyRepository,
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            MedicineRepository medicineRepository,
            DetailsFeignClient detailsFeignClient,
            GeoAddressUtil geoAddressUtil,
            DistanceUtil distanceUtil,
            OrderPharmacyRejectionRepository orderPharmacyRejectionRepository) {

        this.pharmacyRepository = pharmacyRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.medicineRepository = medicineRepository;
        this.detailsFeignClient = detailsFeignClient;
        this.geoAddressUtil = geoAddressUtil;
        this.distanceUtil = distanceUtil;
        this.orderPharmacyRejectionRepository = orderPharmacyRejectionRepository;
    }

    /** Every ACTIVE pharmacy within radius sees this order at the same instant - no sequential targeting. */
    @Override
    public void broadcastOrder(Long orderId, String patientGeoAddress) {
        if (patientGeoAddress == null || patientGeoAddress.isBlank()) {
            return;
        }
        List<Pharmacy> nearbyPharmacies = findNearbyPharmacies(patientGeoAddress, DEFAULT_BROADCAST_RADIUS_KM);
        org.slf4j.LoggerFactory.getLogger(PharmacyRoutingServiceImpl.class)
                .info("Order {} broadcast to {} nearby pharmacies", orderId, nearbyPharmacies.size());
    }

    @Override
    public void rebroadcastOrder(Long orderId) {
        Orders order = orderRepository.findById(orderId).orElse(null);
        if (order == null) {
            return;
        }
        broadcastOrder(orderId, order.getPatientGeoAddress());
    }

    @Override
    public List<OrderSummaryDTO> getAvailableOrdersForPharmacy(Long pharmacyId) {
        Pharmacy pharmacy = pharmacyRepository.findByIdAndIsDeletedFalse(pharmacyId).orElse(null);
        if (pharmacy == null || pharmacy.getGeoAddress() == null) {
            return List.of();
        }

        List<Orders> unclaimedOrders = orderRepository.findByStatusAndPharmacyIdIsNull(OrderStatusEnum.PENDING);

        return unclaimedOrders.stream()
                .filter(order -> !orderPharmacyRejectionRepository
                        .existsByIdOrderIdAndIdPharmacyId(order.getOrderId(), pharmacyId))
                .filter(order -> isWithinGeneralRadius(order, pharmacy))
                .filter(order -> isVisibleToPharmacy(order, pharmacy))
                .map(this::toSummaryDTO)
                .collect(Collectors.toList());
    }

    private boolean isWithinGeneralRadius(Orders order, Pharmacy pharmacy) {
        String patientGeoAddress = order.getPatientGeoAddress();
        return patientGeoAddress == null
                || isWithinRadius(patientGeoAddress, pharmacy.getGeoAddress(), DEFAULT_BROADCAST_RADIUS_KM);
    }

    /**
     * Enforces the hospital-priority window: if the order belongs to a
     * hospital that has its own ACTIVE pharmacy within
     * HOSPITAL_PHARMACY_RADIUS_KM of the patient, only that specific
     * pharmacy can see the order during the priority window. Every other
     * pharmacy (including ones closer to the patient) has to wait. Once the
     * window elapses without the hospital pharmacy accepting, it opens up
     * to everyone within the general radius - OrderRetryScheduler's
     * rebroadcast on the same 5-minute cadence keeps this moving even if no
     * one is actively polling.
     */
    private boolean isVisibleToPharmacy(Orders order, Pharmacy pharmacy) {
        if (order.getHospitalId() == null || order.getPatientGeoAddress() == null) {
            return true;
        }

        Pharmacy hospitalPharmacy = findActiveHospitalPharmacyInRange(order.getHospitalId(), order.getPatientGeoAddress());
        if (hospitalPharmacy == null) {
            // Hospital has no pharmacy in range - no priority window applies, falls through to general radius rule.
            return true;
        }

        boolean isTheHospitalPharmacy = hospitalPharmacy.getId().equals(pharmacy.getId());
        if (isTheHospitalPharmacy) {
            return true;
        }

        return priorityWindowHasElapsed(order);
    }

    private boolean priorityWindowHasElapsed(Orders order) {
        if (order.getOrderDatetime() == null) {
            return true;
        }
        long minutesElapsed = (Instant.now().toEpochMilli() - order.getOrderDatetime().getTime()) / 60000;
        return minutesElapsed >= HOSPITAL_PRIORITY_WINDOW_MINUTES;
    }

    @Override
    public void assertPharmacyCanAcceptOrder(Orders order, Long pharmacyId) {
        if (order.getHospitalId() == null || order.getPatientGeoAddress() == null) {
            return;
        }

        Pharmacy hospitalPharmacy = findActiveHospitalPharmacyInRange(order.getHospitalId(), order.getPatientGeoAddress());
        if (hospitalPharmacy == null) {
            return;
        }

        if (hospitalPharmacy.getId().equals(pharmacyId)) {
            return;
        }

        if (!priorityWindowHasElapsed(order)) {
            throw new OrderConflictException(
                    "This order is reserved for the patient's hospital pharmacy for the first "
                            + HOSPITAL_PRIORITY_WINDOW_MINUTES + " minutes.");
        }
    }

    /**
     * Restored from what used to be the public/REST-exposed
     * assignHospitalPharmacy - it was deleted in an earlier pass as "dead
     * code" because nothing called it, but that was the actual bug: the
     * hospital-priority business rule was implemented but never wired into
     * the real order flow. It's back as the mechanism getAvailableOrdersForPharmacy
     * uses to decide priority, instead of sitting unused behind its own endpoint.
     */
    private Pharmacy findActiveHospitalPharmacyInRange(Long hospitalId, String patientGeoAddress) {
        List<Pharmacy> hospitalPharmacies =
                pharmacyRepository.findByStatusAndHospitalIdAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE, hospitalId);

        for (Pharmacy candidate : hospitalPharmacies) {
            if (isWithinRadius(patientGeoAddress, candidate.getGeoAddress(), HOSPITAL_PHARMACY_RADIUS_KM)) {
                return candidate;
            }
        }
        return null;
    }

    private List<Pharmacy> findNearbyPharmacies(String patientGeoAddress, double radiusKm) {
        List<Pharmacy> nearbyPharmacies = new ArrayList<>();
        List<Pharmacy> activePharmacies = pharmacyRepository.findByStatusAndIsDeletedFalse(PharmacyStatusEnum.ACTIVE);

        for (Pharmacy pharmacy : activePharmacies) {
            if (isWithinRadius(patientGeoAddress, pharmacy.getGeoAddress(), radiusKm)) {
                nearbyPharmacies.add(pharmacy);
            }
        }
        return nearbyPharmacies;
    }

    private boolean isWithinRadius(String sourceGeoAddress, String destinationGeoAddress, double radiusKm) {
        CoordinateDTO source = geoAddressUtil.parse(sourceGeoAddress);
        CoordinateDTO destination = geoAddressUtil.parse(destinationGeoAddress);

        double distance = distanceUtil.calculateDistance(
                source.getLatitude(), source.getLongitude(),
                destination.getLatitude(), destination.getLongitude());

        return distance <= radiusKm;
    }

    private OrderSummaryDTO toSummaryDTO(Orders order) {
        List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
        Map<Long, String> names = medicineRepository
                .findAllById(items.stream().map(OrderItem::getMedicineId).collect(Collectors.toSet()))
                .stream().collect(Collectors.toMap(Medicine::getMedicineId, Medicine::getName));

        OrderSummaryDTO dto = new OrderSummaryDTO();
        dto.setOrderId(order.getOrderId());
        dto.setItemCount(items.size());
        dto.setMedicinesSummary(items.stream().map(i -> names.get(i.getMedicineId())).collect(Collectors.joining(", ")));
        dto.setTotalAmount(order.getTotalAmount());
        dto.setStatus(order.getStatus());
        dto.setOrderDatetime(order.getOrderDatetime());

        DetailsDTO patientDetails = safeFetchDetails(order.getUserId());
        dto.setPatientName(patientDetails != null ? patientDetails.getName() : null);
        return dto;
    }

    private DetailsDTO safeFetchDetails(Long id) {
        try {
            return detailsFeignClient.getDetails(id);
        } catch (Exception ex) {
            return null;
        }
    }
}
