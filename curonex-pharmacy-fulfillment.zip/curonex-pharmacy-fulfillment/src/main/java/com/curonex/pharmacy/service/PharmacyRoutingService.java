package com.curonex.pharmacy.service;

import java.util.List;

import com.curonex.pharmacy.dto.OrderSummaryDTO;
import com.curonex.pharmacy.entity.Orders;

/**
 * Public surface trimmed to only what other services actually call.
 * findNearbyPharmacies/isWithinRadius used to be public here (and
 * REST-exposed via PharmacyController) but had no real caller anywhere in
 * the codebase or frontend - they're private helpers inside
 * PharmacyRoutingServiceImpl now, still used internally by broadcastOrder()
 * and getAvailableOrdersForPharmacy().
 *
 * assignHospitalPharmacy is also private now (findActiveHospitalPharmacyInRange)
 * - it was briefly deleted entirely as "dead code," which was a mistake: the
 * hospital-priority business rule ("hospital's own pharmacy gets first
 * shot") is real, it just wasn't wired into the actual order flow before.
 * getAvailableOrdersForPharmacy() and assertPharmacyCanAcceptOrder() now
 * enforce it directly: if an order has a hospitalId and that hospital has
 * an ACTIVE pharmacy within 5km, only that pharmacy can see or accept the
 * order for the first 2 minutes; other nearby pharmacies only get a shot
 * after that priority window elapses.
 */
public interface PharmacyRoutingService {

    void broadcastOrder(Long orderId, String patientGeoAddress);

    void rebroadcastOrder(Long orderId);

    /** Orders currently broadcast and still unclaimed, visible to this pharmacy (hospital-priority-aware). */
    List<OrderSummaryDTO> getAvailableOrdersForPharmacy(Long pharmacyId);

    /**
     * Enforces the hospital-priority window at the moment of accept, not
     * just at listing time. getAvailableOrdersForPharmacy() hides the order
     * from non-hospital pharmacies during the window, but that alone only
     * stops them from seeing it in their UI - a pharmacy that already knows
     * (or guesses) the orderId could otherwise call accept directly and
     * bypass the window entirely. This must be called before attempting the
     * atomic accept in PharmacyServiceImpl#acceptOrder. Throws
     * OrderConflictException if this pharmacy isn't allowed to accept yet.
     */
    void assertPharmacyCanAcceptOrder(Orders order, Long pharmacyId);
}
