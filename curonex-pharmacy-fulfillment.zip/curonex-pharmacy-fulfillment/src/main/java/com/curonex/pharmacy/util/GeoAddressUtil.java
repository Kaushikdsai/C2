package com.curonex.pharmacy.util;

import org.springframework.stereotype.Component;

import com.curonex.pharmacy.dto.CoordinateDTO;

@Component
public class GeoAddressUtil {

    /**
     * Input: "12.9716,77.5946"
     * Output: CoordinateDTO(latitude=12.9716, longitude=77.5946)
     */
    public CoordinateDTO parse(String geoAddress) {
        if (geoAddress == null || geoAddress.isBlank()) {
            throw new IllegalArgumentException("Geo address cannot be null or empty");
        }

        String[] values = geoAddress.split(",");
        if (values.length != 2) {
            throw new IllegalArgumentException("Invalid geoAddress format. Expected: latitude,longitude");
        }

        double latitude = Double.parseDouble(values[0].trim());
        double longitude = Double.parseDouble(values[1].trim());

        return new CoordinateDTO(latitude, longitude);
    }
}
