package com.curonex.pharmacy.enums;

public enum PharmacyStatusEnum {
    ACTIVE("active"),
    INACTIVE("inactive"),
    SUSPENDED("suspended");

    private final String dbValue;

    PharmacyStatusEnum(String dbValue) {
        this.dbValue = dbValue;
    }

    public String getDbValue() {
        return dbValue;
    }

    public static PharmacyStatusEnum fromDbValue(String dbValue) {
        for (PharmacyStatusEnum value : values()) {
            if (value.dbValue.equalsIgnoreCase(dbValue)) {
                return value;
            }
        }
        throw new IllegalArgumentException("Unknown PharmacyStatusEnum value: " + dbValue);
    }
}
