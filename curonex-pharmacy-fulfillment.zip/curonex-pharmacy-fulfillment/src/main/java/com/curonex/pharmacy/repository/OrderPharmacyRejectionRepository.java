package com.curonex.pharmacy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.curonex.pharmacy.entity.OrderPharmacyRejection;
import com.curonex.pharmacy.entity.OrderPharmacyRejectionId;

@Repository
public interface OrderPharmacyRejectionRepository
        extends JpaRepository<OrderPharmacyRejection, OrderPharmacyRejectionId> {

    boolean existsByIdOrderIdAndIdPharmacyId(Long orderId, Long pharmacyId);

    @Modifying
    @Query("DELETE FROM OrderPharmacyRejection r WHERE r.id.orderId = :orderId")
    void deleteByIdOrderId(@Param("orderId") Long orderId);
}
